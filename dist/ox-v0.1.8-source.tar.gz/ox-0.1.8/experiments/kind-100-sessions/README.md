# kind 100-session experiment

This directory contains a reproducible experiment for running 100 containerized
`ox` shell sessions on a local `kind` cluster.

Design:

- One Kubernetes pod hosts one detached `ox` shell agent.
- Each pod creates one tmux session whose name matches the pod name.
- The pod stays alive after provisioning so the tmux session can be inspected.

Files:

- `Dockerfile`: builds a Linux `ox` binary and a minimal runtime image with `tmux`.
- `entrypoint.sh`: creates one `ox` session, verifies it, and then keeps the pod alive.
- `kind-config.yaml`: three-node local kind cluster shape.
- `deployment.yaml`: 100-replica workload for the experiment.

Manual run:

```bash
docker build -f experiments/kind-100-sessions/Dockerfile -t ox-kind-session:dev .
kind create cluster --name ox-kind-100 --config experiments/kind-100-sessions/kind-config.yaml
kind load docker-image ox-kind-session:dev --name ox-kind-100
kubectl apply -f experiments/kind-100-sessions/deployment.yaml
kubectl rollout status deployment/ox-kind-sessions -n ox-kind-sessions --timeout=10m
kubectl get pods -n ox-kind-sessions
```

Reruns:

- On `kind`, reusing the same tag can leave pods on an older imported image
  because the node already has that tag cached. When testing a rebuilt binary,
  tag it uniquely and update the deployment image before rolling out:

```bash
IMAGE_TAG="ox-kind-session:exp-$(date +%Y%m%d-%H%M%S)"
docker tag ox-kind-session:dev "${IMAGE_TAG}"
kind load docker-image "${IMAGE_TAG}" --name ox-kind-100
kubectl set image deployment/ox-kind-sessions \
  ox="${IMAGE_TAG}" \
  -n ox-kind-sessions
kubectl rollout status deployment/ox-kind-sessions -n ox-kind-sessions --timeout=10m
```

Inspection:

```bash
kubectl exec -n ox-kind-sessions deploy/ox-kind-sessions -- ox agents list --json
kubectl exec -n ox-kind-sessions deploy/ox-kind-sessions -- tmux ls
```
