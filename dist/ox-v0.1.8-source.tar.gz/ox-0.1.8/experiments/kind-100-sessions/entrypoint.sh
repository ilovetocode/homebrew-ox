#!/usr/bin/env bash

set -euo pipefail

session_name="${OX_SESSION_NAME:-${HOSTNAME:-ox-session}}"
repo_dir="${OX_REPO_DIR:-/workspace}"
state_dir="${HOME}/.local/state/ox"
log_dir="${HOME}/experiment-logs"

mkdir -p "${repo_dir}" "${state_dir}" "${log_dir}"
cd "${repo_dir}"

echo "creating ox session: ${session_name}"
ox agents create "${session_name}" --agent-kind shell --repo "${repo_dir}"

# Verify the tmux runtime state before the pod declares itself ready. This
# keeps the experiment honest: a Ready pod should already have a live session.
tmux has-session -t "${session_name}"
ox agents list --json | tee "${log_dir}/agents-list.json"
tmux ls | tee "${log_dir}/tmux-ls.txt"

touch "${HOME}/.ox-session-ready"
echo "session ${session_name} is ready"

exec tail -f /dev/null
