# Releasing ox for Homebrew tap installs

This runbook documents the minimum release flow used by the custom tap install:

```bash
brew install ilovetocode/ox/ox
```

## 1) Prepare and tag a release in this repo

1. Update `version` in `Cargo.toml`.
2. Commit the version bump.
3. Create and push a version tag in `vX.Y.Z` format.

Example:

```bash
git tag v0.1.1
git push origin v0.1.1
```

The release workflow is tag-driven and will:

- verify `Cargo.toml` version matches the tag.
- build macOS artifacts for:
  - `aarch64-apple-darwin`
  - `x86_64-apple-darwin`
- upload `tar.gz` archives and `.sha256` files to the GitHub release.

## 2) Update the Homebrew tap formula

In `ilovetocode/homebrew-ox`, update `Formula/ox.rb`:

- set `url` per architecture to the new release asset URL.
- set `sha256` per architecture from the uploaded checksum files.

Commit and push the formula update.

## 3) Verify install end-to-end

On a clean macOS shell:

```bash
brew install ilovetocode/ox/ox
ox --version
ox --help
```

If commands are not found, load Homebrew shellenv and retry.

## 4) Rollback approach

If a release is broken:

1. Revert the tap formula commit to the previous working version.
2. Push the revert in `homebrew-ox`.
3. Investigate and cut a new tag with a fix.
