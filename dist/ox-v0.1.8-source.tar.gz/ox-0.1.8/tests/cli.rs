//! Integration tests for the `ox` command-line interface.
//!
//! These tests execute the compiled binary and assert observable behavior.

#[path = "cli/support.rs"]
mod support;

#[path = "cli/help.rs"]
mod help;

#[path = "cli/events.rs"]
mod events;

#[path = "cli/agents.rs"]
mod agents;

#[path = "cli/runtime.rs"]
mod runtime;
