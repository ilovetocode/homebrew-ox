use std::fs;
use std::io::Write;
#[cfg(unix)]
use std::os::unix::fs::PermissionsExt;
use std::process::Stdio;

use crate::support::{
    CrudTestEnv, TestResult, agents_array, assert_existing_path_matches, assert_failure,
    assert_success, find_agent_named, git_cmd, init_git_repo, parse_stdout_json,
    skip_if_missing_commands, wait_for_tmux_path,
};

#[test]
fn agents_crud_via_cli_round_trips_state() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-crud-test")?;
    let created_name = format!("ox_crud_create_{}", std::process::id());
    let renamed_name = format!("ox_crud_renamed_{}", std::process::id());

    let create_output = env.run_agents(&["create", created_name.as_str()])?;
    assert_success(&create_output, "expected agent creation success");

    let payload_after_create = parse_stdout_json(&env.run_agents(&["list", "--json"])?)?;
    let agents_after_create = agents_array(&payload_after_create)?;
    find_agent_named(agents_after_create, created_name.as_str())?;

    let update_output =
        env.run_agents(&["update", created_name.as_str(), renamed_name.as_str()])?;
    assert_success(&update_output, "expected agent update success");

    let payload_after_update = parse_stdout_json(&env.run_agents(&["list", "--json"])?)?;
    let agents_after_update = agents_array(&payload_after_update)?;
    find_agent_named(agents_after_update, renamed_name.as_str())?;
    assert!(
        find_agent_named(agents_after_update, created_name.as_str()).is_err(),
        "expected old agent name to be absent after rename"
    );

    let delete_output = env.run_agents(&["delete", renamed_name.as_str()])?;
    assert_success(&delete_output, "expected agent delete success");

    let payload_after_delete = parse_stdout_json(&env.run_agents(&["list", "--json"])?)?;
    let agents_after_delete = agents_array(&payload_after_delete)?;
    assert!(
        find_agent_named(agents_after_delete, renamed_name.as_str()).is_err(),
        "expected deleted agent to be absent after delete"
    );

    Ok(())
}

#[test]
fn agents_new_without_name_auto_generates_shell_name() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-auto-name-test")?;
    let create_output = env.run_agents(&["create"])?;
    assert_success(
        &create_output,
        "expected unnamed agent creation to auto-generate a name",
    );

    let payload = parse_stdout_json(&env.run_agents(&["list", "--json"])?)?;
    let agents = agents_array(&payload)?;
    find_agent_named(agents, "opencode-1")?;

    let delete_output = env.run_agents(&["delete", "opencode-1"])?;
    assert_success(&delete_output, "expected cleanup success");
    Ok(())
}

#[test]
fn agents_new_auto_name_reuses_smallest_available_gap() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-auto-name-gap-test")?;
    assert_success(
        &env.run_agents(&["create", "--agent-kind", "shell"])?,
        "expected first auto-generated name to succeed",
    );
    assert_success(
        &env.run_agents(&["create", "--agent-kind", "shell"])?,
        "expected second auto-generated name to succeed",
    );
    assert_success(
        &env.run_agents(&["delete", "shell-1"])?,
        "expected delete shell-1 to succeed",
    );
    assert_success(
        &env.run_agents(&["create", "--agent-kind", "shell"])?,
        "expected create to reuse smallest available generated name",
    );

    let payload = parse_stdout_json(&env.run_agents(&["list", "--json"])?)?;
    let agents = agents_array(&payload)?;
    find_agent_named(agents, "shell-1")?;
    find_agent_named(agents, "shell-2")?;

    assert_success(
        &env.run_agents(&["delete", "shell-1"])?,
        "expected cleanup delete shell-1 success",
    );
    assert_success(
        &env.run_agents(&["delete", "shell-2"])?,
        "expected cleanup delete shell-2 success",
    );
    Ok(())
}

#[test]
fn agents_new_auto_name_reuses_gap_after_rename() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-auto-name-rename-gap-test")?;
    let renamed_name = format!("custom-renamed-{}", std::process::id());

    assert_success(
        &env.run_agents(&["create", "--agent-kind", "shell"])?,
        "expected initial unnamed create to succeed",
    );
    assert_success(
        &env.run_agents(&["update", "shell-1", renamed_name.as_str()])?,
        "expected rename to succeed",
    );
    assert_success(
        &env.run_agents(&["create", "--agent-kind", "shell"])?,
        "expected unnamed create to reuse shell-1 after rename",
    );

    let payload = parse_stdout_json(&env.run_agents(&["list", "--json"])?)?;
    let agents = agents_array(&payload)?;
    find_agent_named(agents, "shell-1")?;
    find_agent_named(agents, renamed_name.as_str())?;

    assert_success(
        &env.run_agents(&["delete", "shell-1"])?,
        "expected cleanup delete shell-1 success",
    );
    assert_success(
        &env.run_agents(&["delete", renamed_name.as_str()])?,
        "expected cleanup delete renamed agent success",
    );
    Ok(())
}

#[test]
fn codex_agent_create_supports_current_app_server_protocol() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    #[cfg(not(unix))]
    {
        eprintln!("skipping test: fake codex shim uses unix executable permissions");
        return Ok(());
    }

    #[cfg(unix)]
    {
        let env = CrudTestEnv::new("ox-codex-current-protocol-test")?;
        let fake_bin_dir = env.temp_dir.join("fake-bin");
        fs::create_dir_all(&fake_bin_dir)?;

        let rollout_path = env.temp_dir.join("fake-codex-rollout.jsonl");
        let thread_id = "thread_fake_current_protocol";
        let shim_path = fake_bin_dir.join("codex");
        let shim = format!(
            r#"#!/bin/sh
set -eu
rollout_path='{rollout_path}'
thread_id='{thread_id}'
if [ "${{1:-}}" = "app-server" ]; then
  while IFS= read -r line; do
    request_id=$(printf '%s' "$line" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
    case "$line" in
      *'"method":"initialize"'*)
        printf '{{"id":"%s","result":{{"userAgent":"fake-codex"}}}}\n' "$request_id"
        ;;
      *'"method":"thread/start"'*)
        printf '{{"id":"%s","result":{{"thread":{{"id":"%s","path":"%s"}}}}}}\n' "$request_id" "$thread_id" "$rollout_path"
        ;;
      *'"method":"getConversationSummary"'*)
        printf '{{"id":"%s","result":{{"summary":{{"conversationId":"%s","path":"%s"}}}}}}\n' "$request_id" "$thread_id" "$rollout_path"
        ;;
      *'"method":"newConversation"'*)
        printf '{{"id":"%s","error":{{"code":-32600,"message":"Invalid request: unknown variant `newConversation`, expected one of `initialize`, `thread/start`, `getConversationSummary`"}}}}\n' "$request_id"
        ;;
      *)
        :
        ;;
    esac
  done
  exit 0
fi
if [ "${{1:-}}" = "resume" ]; then
  printf 'fake codex resume %s\n' "${{2:-}}"
  exit 0
fi
printf 'unsupported fake codex invocation\n' >&2
exit 1
"#,
            rollout_path = rollout_path.to_string_lossy(),
            thread_id = thread_id,
        );
        fs::write(&shim_path, shim)?;
        let mut permissions = fs::metadata(&shim_path)?.permissions();
        permissions.set_mode(0o755);
        fs::set_permissions(&shim_path, permissions)?;

        let path = std::env::var("PATH")?;
        let create_output = env
            .ox_cmd()
            .env("PATH", format!("{}:{path}", fake_bin_dir.display()))
            .arg("agents")
            .arg("create")
            .arg("codex-current")
            .arg("--agent-kind")
            .arg("codex")
            .output()?;

        assert_success(
            &create_output,
            "expected codex agent creation success with current app-server protocol",
        );

        let payload = parse_stdout_json(&env.run_agents(&["list", "--json"])?)?;
        let agents = agents_array(&payload)?;
        find_agent_named(agents, "codex-current")?;

        let rollout = fs::read_to_string(&rollout_path)?;
        assert!(
            rollout.contains("\"type\":\"session_meta\""),
            "expected ox to scaffold rollout metadata for resume; rollout={rollout}"
        );
        assert!(
            rollout.contains(thread_id),
            "expected rollout metadata to include fake thread id; rollout={rollout}"
        );

        assert_success(
            &env.run_agents(&["delete", "codex-current"])?,
            "expected cleanup delete codex-current success",
        );
        Ok(())
    }
}

#[test]
fn agents_ls_json_outputs_structured_rows() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-ls-json-test")?;
    let created_name = format!("ox_json_list_{}", std::process::id());
    let repo_root = std::fs::canonicalize(std::env::current_dir()?)?;
    let repo_root_arg = repo_root.to_string_lossy().to_string();

    let create_output = env.run_agents(&[
        "create",
        created_name.as_str(),
        "--repo",
        repo_root_arg.as_str(),
    ])?;
    assert_success(&create_output, "expected agent creation success");

    let ls_output = env.run_agents(&["list", "--json"])?;
    assert_success(&ls_output, "expected list success");

    let payload = parse_stdout_json(&ls_output)?;
    let agents = agents_array(&payload)?;
    assert!(
        agents.iter().any(|agent| {
            agent
                .get("name")
                .and_then(serde_json::Value::as_str)
                .is_some_and(|name| name == created_name)
        }),
        "expected created agent in JSON ls output; stdout={}",
        String::from_utf8_lossy(&ls_output.stdout)
    );
    let created_agent = find_agent_named(agents, created_name.as_str())?;
    assert_eq!(
        created_agent
            .get("working_dir")
            .and_then(serde_json::Value::as_str)
            .map(std::path::Path::new),
        Some(repo_root.as_path()),
        "expected working_dir to match explicit --repo"
    );
    assert_eq!(
        created_agent
            .get("git_root")
            .and_then(serde_json::Value::as_str)
            .map(std::path::Path::new),
        Some(repo_root.as_path()),
        "expected git_root to be derived from --repo"
    );

    let delete_output = env.run_agents(&["delete", created_name.as_str()])?;
    assert_success(&delete_output, "expected cleanup success");
    Ok(())
}

#[test]
fn agents_ls_does_not_auto_create_default_pinned_sessions() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-manager-auto-create-test")?;
    let ls_output = env.run_agents(&["list", "--json"])?;
    assert_success(&ls_output, "expected list success");

    let payload = parse_stdout_json(&ls_output)?;
    let agents = agents_array(&payload)?;
    assert!(
        agents.is_empty(),
        "expected list to stay empty without reconcile"
    );

    let has_manager = env.tmux_has_session("manager")?;
    assert_failure(
        &has_manager,
        "expected manager tmux session to remain absent without reconcile",
    );

    Ok(())
}

#[test]
fn agents_reconcile_pinned_creates_default_pinned_sessions() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-manager-reconcile-create-test")?;
    let reconcile_output = env.run_agents(&["reconcile-pinned"])?;
    assert_success(&reconcile_output, "expected reconcile success");

    let ls_output = env.run_agents(&["list", "--json"])?;
    assert_success(&ls_output, "expected list success");

    let payload = parse_stdout_json(&ls_output)?;
    let agents = agents_array(&payload)?;
    assert_eq!(
        agents
            .first()
            .and_then(|agent| agent.get("name"))
            .and_then(serde_json::Value::as_str),
        Some("manager"),
        "expected manager to be pinned as first row"
    );
    assert_existing_path_matches(
        agents
            .first()
            .and_then(|agent| agent.get("working_dir"))
            .and_then(serde_json::Value::as_str),
        env.home_dir.as_path(),
        "expected manager to start in the home directory",
    )?;
    assert_eq!(
        agents
            .get(1)
            .and_then(|agent| agent.get("name"))
            .and_then(serde_json::Value::as_str),
        Some("planner"),
        "expected planner to be pinned as second row"
    );
    assert_eq!(
        agents
            .get(2)
            .and_then(|agent| agent.get("name"))
            .and_then(serde_json::Value::as_str),
        Some("settings"),
        "expected settings to be pinned as third row"
    );
    assert_existing_path_matches(
        agents
            .get(2)
            .and_then(|agent| agent.get("working_dir"))
            .and_then(serde_json::Value::as_str),
        env.home_dir.as_path(),
        "expected settings to start in the chezmoi target directory",
    )?;

    Ok(())
}

#[test]
fn agents_ls_keeps_default_pinned_sessions_first_when_other_agents_exist() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-pinned-order-test")?;
    let reconcile_output = env.run_agents(&["reconcile-pinned"])?;
    assert_success(&reconcile_output, "expected reconcile success");
    let created_name = format!("ox_pinned_order_{}", std::process::id());
    let create_output = env.run_agents(&["create", created_name.as_str()])?;
    assert_success(&create_output, "expected create success");

    let ls_output = env.run_agents(&["list", "--json"])?;
    assert_success(&ls_output, "expected list success");
    let payload = parse_stdout_json(&ls_output)?;
    let agents = agents_array(&payload)?;
    assert_eq!(
        agents
            .first()
            .and_then(|agent| agent.get("name"))
            .and_then(serde_json::Value::as_str),
        Some("manager"),
        "expected manager to stay pinned as first row"
    );
    assert_existing_path_matches(
        agents
            .first()
            .and_then(|agent| agent.get("working_dir"))
            .and_then(serde_json::Value::as_str),
        env.home_dir.as_path(),
        "expected manager to keep the home directory startup path",
    )?;
    assert_eq!(
        agents
            .get(1)
            .and_then(|agent| agent.get("name"))
            .and_then(serde_json::Value::as_str),
        Some("planner"),
        "expected planner to stay pinned as second row"
    );
    assert_eq!(
        agents
            .get(2)
            .and_then(|agent| agent.get("name"))
            .and_then(serde_json::Value::as_str),
        Some("settings"),
        "expected settings to stay pinned as third row"
    );
    assert_eq!(
        agents
            .get(3)
            .and_then(|agent| agent.get("name"))
            .and_then(serde_json::Value::as_str),
        Some(created_name.as_str()),
        "expected non-pinned agent to sort after the pinned rows"
    );

    let delete_output = env.run_agents(&["delete", created_name.as_str()])?;
    assert_success(&delete_output, "expected cleanup success");
    Ok(())
}

#[test]
fn deleting_pinned_sessions_is_rejected() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-pinned-delete-reject-test")?;
    let reconcile_output = env.run_agents(&["reconcile-pinned"])?;
    assert_success(&reconcile_output, "expected reconcile success");
    let ls_output = env.run_agents(&["list", "--json"])?;
    assert_success(&ls_output, "expected list success");

    for pinned_name in ["manager", "planner", "settings"] {
        let delete_output = env.run_agents(&["delete", pinned_name])?;
        assert_success(
            &delete_output,
            "expected pinned delete to recycle the session in place",
        );

        let has_session = env.tmux_has_session(pinned_name)?;
        assert_success(
            &has_session,
            "expected pinned delete to leave the tmux session managed",
        );
    }

    Ok(())
}

#[test]
fn killing_planner_tmux_session_is_healed_on_next_list() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-planner-runtime-heal-test")?;
    let reconcile_output = env.run_agents(&["reconcile-pinned"])?;
    assert_success(&reconcile_output, "expected reconcile success");
    let ls_output = env.run_agents(&["list", "--json"])?;
    assert_success(&ls_output, "expected initial list success");

    let has_planner_before = env.tmux_has_session("planner")?;
    assert_success(
        &has_planner_before,
        "expected planner tmux session to exist before kill",
    );

    let kill_planner = env.run_tmux(&["kill-session", "-t", "planner"])?;
    assert_success(&kill_planner, "expected planner tmux session kill success");

    let has_planner_after_kill = env.tmux_has_session("planner")?;
    assert_failure(
        &has_planner_after_kill,
        "expected planner tmux session to be absent after kill",
    );

    let list_output = env.run_agents(&["list", "--json"])?;
    assert_success(&list_output, "expected list success after planner kill");

    let has_planner_after_list = env.tmux_has_session("planner")?;
    assert_success(
        &has_planner_after_list,
        "expected the next command invocation to heal planner runtime",
    );

    Ok(())
}

#[test]
fn pinned_sessions_yaml_change_applies_on_next_invocation() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-pinned-yaml-reload-test")?;
    let initial_ls_output = env.run_agents(&["list", "--json"])?;
    assert_success(&initial_ls_output, "expected initial list success");

    env.write_pinned_sessions_yaml(
        "pinned_sessions:\n  - name: manager\n    position: 1\n    agent_kind: shell\n  - name: architect\n    position: 2\n    agent_kind: shell\n",
    )?;

    let reconcile_output = env.run_agents(&["reconcile-pinned"])?;
    assert_success(
        &reconcile_output,
        "expected reconcile success after YAML change",
    );

    let updated_ls_output = env.run_agents(&["list", "--json"])?;
    assert_success(
        &updated_ls_output,
        "expected list success after YAML change",
    );

    let payload = parse_stdout_json(&updated_ls_output)?;
    let agents = agents_array(&payload)?;
    assert_eq!(
        agents
            .first()
            .and_then(|agent| agent.get("name"))
            .and_then(serde_json::Value::as_str),
        Some("manager"),
        "expected manager pinned at first row after YAML update"
    );
    assert_eq!(
        agents
            .get(1)
            .and_then(|agent| agent.get("name"))
            .and_then(serde_json::Value::as_str),
        Some("architect"),
        "expected architect auto-created and pinned at second row after YAML update"
    );

    let has_architect = env.tmux_has_session("architect")?;
    assert_success(
        &has_architect,
        "expected architect tmux session to exist after YAML update",
    );

    Ok(())
}

#[test]
fn agents_new_rejects_removed_git_root_flag() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-git-root-removed-test")?;
    let created_name = format!("ox_git_root_removed_{}", std::process::id());
    let repo_root = std::fs::canonicalize(std::env::current_dir()?)?;

    let create_output = env.run_agents(&[
        "create",
        created_name.as_str(),
        "--repo",
        repo_root.to_string_lossy().as_ref(),
        "--git-root",
        repo_root.to_string_lossy().as_ref(),
    ])?;
    assert_failure(
        &create_output,
        "expected create failure for removed --git-root flag",
    );
    assert!(
        String::from_utf8_lossy(&create_output.stderr).contains("unexpected argument '--git-root'"),
        "expected clap unknown-arg message; stderr={}",
        String::from_utf8_lossy(&create_output.stderr)
    );

    Ok(())
}

#[test]
fn agents_new_rejects_removed_worktree_base_ref_flag() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-worktree-base-ref-removed-test")?;
    let created_name = format!("ox_worktree_base_ref_removed_{}", std::process::id());

    let create_output = env.run_agents(&[
        "create",
        created_name.as_str(),
        "--worktree-base-ref",
        "HEAD",
    ])?;
    assert_failure(
        &create_output,
        "expected create failure for removed --worktree-base-ref flag",
    );
    assert!(
        String::from_utf8_lossy(&create_output.stderr)
            .contains("unexpected argument '--worktree-base-ref'"),
        "expected clap unknown-arg message; stderr={}",
        String::from_utf8_lossy(&create_output.stderr)
    );

    Ok(())
}

#[test]
fn agents_new_with_cwd_and_worktree_starts_inside_managed_worktree() -> TestResult {
    if skip_if_missing_commands(&["tmux", "git"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-cwd-worktree-test")?;
    let repo_root = env.temp_dir.join("repo");
    init_git_repo(&repo_root)?;

    let label = format!("feature-{}", std::process::id());
    let created_name = format!("ox_cwd_worktree_{}", std::process::id());
    let create_output = env.run_agents(&[
        "create",
        created_name.as_str(),
        "--agent-kind",
        "shell",
        "--repo",
        repo_root.to_string_lossy().as_ref(),
        "--workspace-backend",
        "local-worktree",
        "--workspace-name",
        label.as_str(),
    ])?;
    assert_success(&create_output, "expected create success");

    let ls_output = env.run_agents(&["list", "--json"])?;
    assert_success(&ls_output, "expected list success");
    let payload = parse_stdout_json(&ls_output)?;
    let agents = agents_array(&payload)?;
    let created_agent = find_agent_named(agents, created_name.as_str())?;

    let expected_worktree =
        std::fs::canonicalize(repo_root.join(".ox").join("worktrees").join(&label))?;
    let expected_repo_root = std::fs::canonicalize(&repo_root)?;
    assert_existing_path_matches(
        created_agent
            .get("working_dir")
            .and_then(serde_json::Value::as_str),
        expected_worktree.as_path(),
        "expected working_dir to be the managed worktree path",
    )?;
    assert_existing_path_matches(
        created_agent
            .get("git_root")
            .and_then(serde_json::Value::as_str),
        expected_repo_root.as_path(),
        "expected git_root to point to repository root",
    )?;
    assert_eq!(
        created_agent
            .get("git_branch")
            .and_then(serde_json::Value::as_str),
        Some(label.as_str()),
        "expected branch to match managed worktree label"
    );

    let delete_output = env.run_agents(&["delete", created_name.as_str()])?;
    assert_success(&delete_output, "expected cleanup success");
    Ok(())
}

#[test]
fn agents_worktree_detach_recreates_session_inside_managed_worktree() -> TestResult {
    if skip_if_missing_commands(&["tmux", "git"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-worktree-switch-test")?;
    let repo_root = env.temp_dir.join("repo");
    init_git_repo(&repo_root)?;

    let created_name = format!("ox_worktree_switch_{}", std::process::id());
    let create_output = env.run_agents(&[
        "create",
        created_name.as_str(),
        "--agent-kind",
        "shell",
        "--repo",
        repo_root.to_string_lossy().as_ref(),
    ])?;
    assert_success(&create_output, "expected create success");

    let branch = format!("feature-switch-{}", std::process::id());
    let switch_output = env.run_agents(&[
        "worktree",
        created_name.as_str(),
        branch.as_str(),
        "--detach",
    ])?;
    assert_success(&switch_output, "expected worktree switch success");

    let expected_worktree =
        std::fs::canonicalize(repo_root.join(".ox").join("worktrees").join(&branch))?;
    let expected_repo_root = std::fs::canonicalize(&repo_root)?;
    wait_for_tmux_path(&env, created_name.as_str(), &expected_worktree)?;

    let ls_output = env.run_agents(&["list", "--json"])?;
    assert_success(&ls_output, "expected list success");
    let payload = parse_stdout_json(&ls_output)?;
    let agents = agents_array(&payload)?;
    let created_agent = find_agent_named(agents, created_name.as_str())?;

    assert_existing_path_matches(
        created_agent
            .get("working_dir")
            .and_then(serde_json::Value::as_str),
        expected_worktree.as_path(),
        "expected working_dir to move into the managed worktree",
    )?;
    assert_existing_path_matches(
        created_agent
            .get("git_root")
            .and_then(serde_json::Value::as_str),
        expected_repo_root.as_path(),
        "expected git_root to remain the original repository root",
    )?;
    assert_eq!(
        created_agent
            .get("git_branch")
            .and_then(serde_json::Value::as_str),
        Some(branch.as_str()),
        "expected git_branch to match the requested worktree branch"
    );

    let delete_output = env.run_agents(&["delete", created_name.as_str()])?;
    assert_success(&delete_output, "expected cleanup success");
    Ok(())
}

#[test]
fn agents_new_with_existing_branch_worktree_succeeds() -> TestResult {
    if skip_if_missing_commands(&["tmux", "git"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-existing-branch-worktree-test")?;
    let repo_root = env.temp_dir.join("repo");
    init_git_repo(&repo_root)?;
    let branch = format!("feature-existing-{}", std::process::id());

    let branch_output = git_cmd()
        .arg("-C")
        .arg(&repo_root)
        .arg("branch")
        .arg(branch.as_str())
        .output()?;
    assert_success(&branch_output, "expected git branch success");

    let created_name = format!("ox_existing_branch_{}", std::process::id());
    let create_output = env.run_agents(&[
        "create",
        created_name.as_str(),
        "--agent-kind",
        "shell",
        "--repo",
        repo_root.to_string_lossy().as_ref(),
        "--workspace-backend",
        "local-worktree",
        "--workspace-name",
        branch.as_str(),
    ])?;
    assert_success(
        &create_output,
        "expected create success when the branch already exists",
    );

    let expected_worktree =
        std::fs::canonicalize(repo_root.join(".ox").join("worktrees").join(&branch))?;
    let expected_repo_root = std::fs::canonicalize(&repo_root)?;

    let ls_output = env.run_agents(&["list", "--json"])?;
    assert_success(&ls_output, "expected list success");
    let payload = parse_stdout_json(&ls_output)?;
    let agents = agents_array(&payload)?;
    let created_agent = find_agent_named(agents, created_name.as_str())?;

    assert_existing_path_matches(
        created_agent
            .get("working_dir")
            .and_then(serde_json::Value::as_str),
        expected_worktree.as_path(),
        "expected working_dir to be the reused branch worktree path",
    )?;
    assert_existing_path_matches(
        created_agent
            .get("git_root")
            .and_then(serde_json::Value::as_str),
        expected_repo_root.as_path(),
        "expected git_root to stay on the source repository root",
    )?;
    assert_eq!(
        created_agent
            .get("git_branch")
            .and_then(serde_json::Value::as_str),
        Some(branch.as_str()),
        "expected git_branch to report the reused branch name"
    );

    let delete_output = env.run_agents(&["delete", created_name.as_str()])?;
    assert_success(&delete_output, "expected cleanup success");
    Ok(())
}

#[test]
fn agents_create_rejects_removed_k8s_workspace_backend_at_parse_time() -> TestResult {
    let env = CrudTestEnv::new("ox-agents-k8s-backend-removed")?;
    let output = env.run_agents(&["create", "k8s-test", "--workspace-backend", "k8s-checkout"])?;

    assert_failure(
        &output,
        "expected create failure for removed workspace backend",
    );
    assert!(
        String::from_utf8_lossy(&output.stderr)
            .contains("invalid value 'k8s-checkout' for '--workspace-backend <WORKSPACE_BACKEND>'"),
        "expected clap invalid-value message; stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );

    Ok(())
}

#[test]
fn agents_ls_tracks_live_tmux_cwd_after_manual_cd() -> TestResult {
    if skip_if_missing_commands(&["tmux", "git"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-live-cwd-test")?;
    let repo_root = env.temp_dir.join("repo");
    let nested = repo_root.join("nested");
    init_git_repo(&repo_root)?;
    std::fs::create_dir_all(&nested)?;
    let nested = std::fs::canonicalize(nested)?;
    let created_name = format!("ox_live_cwd_{}", std::process::id());

    let create_output = env.run_agents(&[
        "create",
        created_name.as_str(),
        "--agent-kind",
        "shell",
        "--repo",
        repo_root.to_string_lossy().as_ref(),
    ])?;
    assert_success(&create_output, "expected create success");
    let expected_repo_root = std::fs::canonicalize(&repo_root)?;
    wait_for_tmux_path(&env, created_name.as_str(), expected_repo_root.as_path())?;

    let respawn_pane = env.run_tmux(&[
        "respawn-pane",
        "-k",
        "-t",
        created_name.as_str(),
        "-c",
        nested.to_string_lossy().as_ref(),
    ])?;
    assert_success(
        &respawn_pane,
        "expected respawn-pane to restart the shell in the nested directory",
    );
    wait_for_tmux_path(&env, created_name.as_str(), nested.as_path())?;

    let ls_output = env.run_agents(&["list", "--json"])?;
    assert_success(&ls_output, "expected list success");
    let payload = parse_stdout_json(&ls_output)?;
    let agents = agents_array(&payload)?;
    let created_agent = find_agent_named(agents, created_name.as_str())?;
    assert_existing_path_matches(
        created_agent
            .get("working_dir")
            .and_then(serde_json::Value::as_str),
        nested.as_path(),
        "expected working_dir to reflect live tmux pane path",
    )?;
    assert_existing_path_matches(
        created_agent
            .get("git_root")
            .and_then(serde_json::Value::as_str),
        expected_repo_root.as_path(),
        "expected git_root derived from live tmux pane path",
    )?;

    let delete_output = env.run_agents(&["delete", created_name.as_str()])?;
    assert_success(&delete_output, "expected cleanup success");
    Ok(())
}

#[test]
fn agents_send_with_enter_delivers_message_to_session() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-test")?;
    let created_name = format!("ox_send_target_{}", std::process::id());

    let create_output = env.run_agents(&["create", created_name.as_str()])?;
    assert_success(&create_output, "expected create success");

    let send_output = env.run_agents(&[
        "send",
        "--agent",
        created_name.as_str(),
        "--message",
        "printf 'OX_SEND_OK\\n'",
        "--enter",
    ])?;
    assert_success(&send_output, "expected send success");

    assert_session_output_contains(&env, created_name.as_str(), "OX_SEND_OK")?;

    let delete_output = env.run_agents(&["delete", created_name.as_str()])?;
    assert_success(&delete_output, "expected cleanup success");
    Ok(())
}

#[test]
fn agents_send_positional_message_resolves_to_message_mode() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-positional-message-test")?;
    let created_name = format!("ox_send_positional_msg_{}", std::process::id());

    assert_success(
        &env.run_agents(&["create", created_name.as_str(), "--agent-kind", "shell"])?,
        "expected create success",
    );

    let send_output = env.run_agents(&[
        "send",
        "--agent",
        created_name.as_str(),
        "printf 'OX_SEND_POSITIONAL_MSG_OK\\n'",
        "--enter",
    ])?;
    assert_success(&send_output, "expected positional message send success");
    assert_session_output_contains(&env, created_name.as_str(), "OX_SEND_POSITIONAL_MSG_OK")?;

    assert_success(
        &env.run_agents(&["delete", created_name.as_str()])?,
        "expected cleanup success",
    );
    Ok(())
}

#[test]
fn agents_send_positional_slash_rejected_for_non_opencode_agent() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-positional-slash-kind-test")?;
    let created_name = format!("ox_send_positional_slash_{}", std::process::id());

    assert_success(
        &env.run_agents(&["create", created_name.as_str(), "--agent-kind", "shell"])?,
        "expected create success",
    );

    let send_output =
        env.run_agents(&["send", "--agent", created_name.as_str(), "/consistency"])?;
    assert_failure(
        &send_output,
        "expected positional slash command rejection for non-opencode agent",
    );
    let stderr = String::from_utf8_lossy(&send_output.stderr);
    assert!(
        stderr.contains("slash commands are only supported for opencode agents"),
        "expected non-opencode slash-command error; stderr={stderr}"
    );

    assert_success(
        &env.run_agents(&["delete", created_name.as_str()])?,
        "expected cleanup success",
    );
    Ok(())
}

#[test]
fn agents_send_rejects_positional_slash_root() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-positional-slash-root-test")?;
    let created_name = format!("ox_send_positional_slash_root_{}", std::process::id());

    assert_success(
        &env.run_agents(&["create", created_name.as_str(), "--agent-kind", "shell"])?,
        "expected create success",
    );

    let send_output = env.run_agents(&["send", "--agent", created_name.as_str(), "/"])?;
    assert_failure(&send_output, "expected slash root input rejection");
    let stderr = String::from_utf8_lossy(&send_output.stderr);
    assert!(
        stderr.contains("slash command cannot be empty"),
        "expected slash-empty error; stderr={stderr}"
    );

    assert_success(
        &env.run_agents(&["delete", created_name.as_str()])?,
        "expected cleanup success",
    );
    Ok(())
}

#[test]
fn agents_send_accepts_positional_input_with_agent_flag() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-positional-order-test")?;
    let created_name = format!("ox_send_positional_order_target_{}", std::process::id());

    let create_output = env.run_agents(&["create", created_name.as_str()])?;
    assert_success(&create_output, "expected create success");

    let send_output = env.run_agents(&[
        "send",
        "--agent",
        created_name.as_str(),
        "printf 'OX_SEND_SELECTOR_FIRST_OK\\n'",
        "--enter",
    ])?;
    assert_success(&send_output, "expected positional input send success");
    assert_session_output_contains(&env, created_name.as_str(), "OX_SEND_SELECTOR_FIRST_OK")?;

    let delete_output = env.run_agents(&["delete", created_name.as_str()])?;
    assert_success(&delete_output, "expected cleanup success");
    Ok(())
}

#[test]
fn agents_send_file_reads_message_from_path() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-file-test")?;
    let created_name = format!("ox_send_file_target_{}", std::process::id());

    let create_output = env.run_agents(&["create", created_name.as_str()])?;
    assert_success(&create_output, "expected create success");

    let message_file = env.temp_dir.join("send-message.txt");
    std::fs::write(&message_file, "printf 'OX_SEND_FILE_OK\\n'")?;

    let send_output = env.run_agents(&[
        "send",
        "--agent",
        created_name.as_str(),
        "--file",
        message_file.to_string_lossy().as_ref(),
        "--enter",
    ])?;
    assert_success(&send_output, "expected send success");

    assert_session_output_contains(&env, created_name.as_str(), "OX_SEND_FILE_OK")?;

    let delete_output = env.run_agents(&["delete", created_name.as_str()])?;
    assert_success(&delete_output, "expected cleanup success");
    Ok(())
}

#[test]
fn agents_send_stdin_reads_message_from_standard_input() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-stdin-test")?;
    let created_name = format!("ox_send_stdin_target_{}", std::process::id());

    let create_output = env.run_agents(&["create", created_name.as_str()])?;
    assert_success(&create_output, "expected create success");

    let mut send_cmd = env.ox_child(&[
        "agents",
        "send",
        "--agent",
        created_name.as_str(),
        "--stdin",
        "--enter",
    ]);
    send_cmd.stdin(Stdio::piped());
    let mut child = send_cmd.spawn()?;
    {
        let stdin = child
            .stdin
            .as_mut()
            .ok_or("expected stdin pipe to be available")?;
        stdin.write_all(b"printf 'OX_SEND_STDIN_OK\\n'")?;
    }
    let send_output = child.wait_with_output()?;
    assert_success(&send_output, "expected send success");

    assert_session_output_contains(&env, created_name.as_str(), "OX_SEND_STDIN_OK")?;

    let delete_output = env.run_agents(&["delete", created_name.as_str()])?;
    assert_success(&delete_output, "expected cleanup success");
    Ok(())
}

#[test]
fn agents_send_rejects_conflicting_input_modes() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-invalid-input-mode-test")?;
    let created_name = format!("ox_send_invalid_input_target_{}", std::process::id());

    let create_output = env.run_agents(&["create", created_name.as_str()])?;
    assert_success(&create_output, "expected create success");

    let invalid_stdin_with_message = env.run_agents(&[
        "send",
        "--agent",
        created_name.as_str(),
        "--message",
        "printf 'OX_SEND_INVALID_STDIN_WITH_MESSAGE\\n'",
        "--stdin",
    ])?;
    assert_failure(
        &invalid_stdin_with_message,
        "expected conflict between <MESSAGE> and --stdin",
    );
    let stderr = String::from_utf8_lossy(&invalid_stdin_with_message.stderr);
    assert!(
        stderr.contains("cannot be used with"),
        "expected clap conflict error; stderr={stderr}"
    );

    let message_file = env.temp_dir.join("send-invalid-message.txt");
    std::fs::write(&message_file, "printf 'OX_SEND_INVALID_FILE_WITH_STDIN\\n'")?;
    let invalid_stdin_with_file = env.run_agents(&[
        "send",
        "--agent",
        created_name.as_str(),
        "--stdin",
        "--file",
        message_file.to_string_lossy().as_ref(),
    ])?;
    assert_failure(
        &invalid_stdin_with_file,
        "expected conflict between --stdin and --file",
    );
    let stderr = String::from_utf8_lossy(&invalid_stdin_with_file.stderr);
    assert!(
        stderr.contains("cannot be used with"),
        "expected clap conflict error; stderr={stderr}"
    );

    let delete_output = env.run_agents(&["delete", created_name.as_str()])?;
    assert_success(&delete_output, "expected cleanup success");
    Ok(())
}

#[test]
fn agents_send_rejects_positional_with_message() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-positional-message-conflict-test")?;
    let created_name = format!("ox_send_positional_msg_conflict_{}", std::process::id());
    assert_success(
        &env.run_agents(&["create", created_name.as_str(), "--agent-kind", "shell"])?,
        "expected create success",
    );

    let output = env.run_agents(&[
        "send",
        "--agent",
        created_name.as_str(),
        "hello",
        "--message",
        "world",
    ])?;
    assert_failure(&output, "expected positional + --message conflict");
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("cannot be used with"),
        "expected clap conflict error; stderr={stderr}"
    );

    assert_success(
        &env.run_agents(&["delete", created_name.as_str()])?,
        "expected cleanup success",
    );
    Ok(())
}

#[test]
fn agents_send_rejects_positional_with_file() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-positional-file-conflict-test")?;
    let created_name = format!("ox_send_positional_file_conflict_{}", std::process::id());
    assert_success(
        &env.run_agents(&["create", created_name.as_str(), "--agent-kind", "shell"])?,
        "expected create success",
    );
    let message_file = env.temp_dir.join("send-positional-conflict-message.txt");
    std::fs::write(&message_file, "printf 'SHOULD_NOT_RUN\\n'")?;

    let output = env.run_agents(&[
        "send",
        "--agent",
        created_name.as_str(),
        "hello",
        "--file",
        message_file.to_string_lossy().as_ref(),
    ])?;
    assert_failure(&output, "expected positional + --file conflict");
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("cannot be used with"),
        "expected clap conflict error; stderr={stderr}"
    );

    assert_success(
        &env.run_agents(&["delete", created_name.as_str()])?,
        "expected cleanup success",
    );
    Ok(())
}

#[test]
fn agents_send_rejects_positional_with_stdin() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-positional-stdin-conflict-test")?;
    let created_name = format!("ox_send_positional_stdin_conflict_{}", std::process::id());
    assert_success(
        &env.run_agents(&["create", created_name.as_str(), "--agent-kind", "shell"])?,
        "expected create success",
    );

    let output = env.run_agents(&["send", "--agent", created_name.as_str(), "hello", "--stdin"])?;
    assert_failure(&output, "expected positional + --stdin conflict");
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("cannot be used with"),
        "expected clap conflict error; stderr={stderr}"
    );

    assert_success(
        &env.run_agents(&["delete", created_name.as_str()])?,
        "expected cleanup success",
    );
    Ok(())
}

#[test]
fn agents_send_selector_targets_multiple_sessions() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-selector-bulk-test")?;
    let target_a = format!("ox_send_bulk_a_{}", std::process::id());
    let target_b = format!("ox_send_bulk_b_{}", std::process::id());
    let other = format!("ox_send_other_{}", std::process::id());

    assert_success(
        &env.run_agents(&["create", target_a.as_str()])?,
        "expected create target_a success",
    );
    assert_success(
        &env.run_agents(&["create", target_b.as_str()])?,
        "expected create target_b success",
    );
    assert_success(
        &env.run_agents(&["create", other.as_str()])?,
        "expected create other success",
    );

    let send_output = env.run_agents(&[
        "send",
        "--selector",
        "name:ox_send_bulk_*",
        "--message",
        "printf 'OX_SEND_BULK_OK\\n'",
        "--enter",
    ])?;
    assert_success(&send_output, "expected selector bulk send success");

    assert_session_output_contains(&env, target_a.as_str(), "OX_SEND_BULK_OK")?;
    assert_session_output_contains(&env, target_b.as_str(), "OX_SEND_BULK_OK")?;

    let capture_other = env.run_tmux(&["capture-pane", "-p", "-S", "-80", "-t", other.as_str()])?;
    assert_success(&capture_other, "expected capture other session success");
    let other_pane = String::from_utf8_lossy(&capture_other.stdout);
    assert!(
        !other_pane.contains("OX_SEND_BULK_OK"),
        "expected non-matching session to not receive bulk selector message"
    );

    assert_success(
        &env.run_agents(&["delete", target_a.as_str()])?,
        "expected cleanup delete target_a success",
    );
    assert_success(
        &env.run_agents(&["delete", target_b.as_str()])?,
        "expected cleanup delete target_b success",
    );
    assert_success(
        &env.run_agents(&["delete", other.as_str()])?,
        "expected cleanup delete other success",
    );
    Ok(())
}

#[test]
fn agents_send_rejects_conflicting_target_modes() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-agents-send-invalid-target-mode-test")?;
    let created_name = format!("ox_send_invalid_target_{}", std::process::id());
    assert_success(
        &env.run_agents(&["create", created_name.as_str()])?,
        "expected create success",
    );

    let output = env.run_agents(&[
        "send",
        "--agent",
        created_name.as_str(),
        "--all",
        "--message",
        "printf 'SHOULD_NOT_SEND\\n'",
    ])?;
    assert_failure(&output, "expected clap conflict for target selectors");
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("cannot be used with"),
        "expected clap conflict error; stderr={stderr}"
    );

    assert_success(
        &env.run_agents(&["delete", created_name.as_str()])?,
        "expected cleanup success",
    );
    Ok(())
}

fn assert_session_output_contains(
    env: &CrudTestEnv,
    session_name: &str,
    needle: &str,
) -> TestResult {
    // Poll tmux pane output so this assertion stays stable when multiple
    // opencode-backed integration tests are starting sessions in parallel.
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(8);
    let mut saw_output = false;
    while std::time::Instant::now() < deadline {
        let capture_output =
            env.run_tmux(&["capture-pane", "-p", "-S", "-80", "-t", session_name])?;
        if capture_output.status.success() {
            let pane = String::from_utf8_lossy(&capture_output.stdout);
            if pane.contains(needle) {
                saw_output = true;
                break;
            }
        }
        std::thread::sleep(std::time::Duration::from_millis(50));
    }

    assert!(
        saw_output,
        "expected pane output to include {needle}; session={session_name}"
    );
    Ok(())
}
