use crate::support::{TestResult, assert_help_contains, assert_success, run_ox};

#[test]
fn no_args_exits_success() -> TestResult {
    assert_help_contains(&[], &["ox CLI", "Usage:", "Start here:"])
}

#[test]
fn help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["--help"],
        &[
            "ox CLI", "Usage:", "tui", "agents", "status", "doctor", "events",
        ],
    )
}

#[test]
fn short_help_alias_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(&["-h"], &["ox CLI", "Usage:", "Examples:", "See also:"])
}

#[test]
fn help_subcommand_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(&["help"], &["ox CLI", "Usage:", "Examples:", "See also:"])
}

#[test]
fn help_shortcut_h_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(&["h"], &["ox CLI", "Usage:", "Examples:", "See also:"])
}

#[test]
fn help_shortcut_question_mark_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(&["?"], &["ox CLI", "Usage:", "Examples:", "See also:"])
}

#[test]
fn help_shortcut_assist_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(&["assist"], &["ox CLI", "Usage:", "Examples:", "See also:"])
}

#[test]
fn prefix_help_for_agents_send_exits_success() -> TestResult {
    assert_help_contains(
        &["help", "agents", "send"],
        &[
            "Send one message or opencode slash command to an existing agent",
            "Usage: ox agents send",
            "[INPUT]",
            "--message <TEXT>",
            "--file <PATH>",
            "--stdin",
            "ox agents send --agent slash-test /consistency",
            "ox agents send --agent slash-test \"summarize this repo\"",
            "Examples:",
            "Filter syntax:",
            "See also:",
        ],
    )
}

#[test]
fn postfix_help_for_agents_send_exits_success() -> TestResult {
    assert_help_contains(
        &["agents", "send", "help"],
        &[
            "Send one message or opencode slash command to an existing agent",
            "Usage: ox agents send",
            "[INPUT]",
            "--message <TEXT>",
            "--file <PATH>",
            "--stdin",
            "ox agents send --agent slash-test /consistency",
            "ox agents send --agent slash-test \"summarize this repo\"",
            "Examples:",
            "Filter syntax:",
            "See also:",
        ],
    )
}

#[test]
fn postfix_help_for_agents_exits_success() -> TestResult {
    assert_help_contains(
        &["agents", "help"],
        &[
            "Commands for working with tmux agents",
            "Usage: ox agents",
            "Examples:",
            "See also:",
        ],
    )
}

#[test]
fn postfix_help_for_status_exits_success() -> TestResult {
    assert_help_contains(
        &["status", "help"],
        &[
            "Print a quick health summary of tmux + managed ox state",
            "Usage: ox status",
            "Examples:",
            "See also:",
        ],
    )
}

#[test]
fn version_exits_success_and_prints_version() -> TestResult {
    let output = run_ox(&["--version"])?;
    assert_success(&output, "expected success status");

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        stdout.starts_with("ox "),
        "expected binary name in version output"
    );

    Ok(())
}

#[test]
fn tui_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["tui", "--help"],
        &[
            "Launch the text user interface",
            "Usage: ox tui",
            "status",
            "search",
            "create",
            "rename",
        ],
    )
}

#[test]
fn tui_status_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["tui", "status", "--help"],
        &["Open directly on the status screen", "Usage: ox tui status"],
    )
}

#[test]
fn tui_search_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["tui", "search", "--help"],
        &["Open directly on the search screen", "Usage: ox tui search"],
    )
}

#[test]
fn tui_new_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["tui", "create", "--help"],
        &[
            "Open directly on the create-agent screen",
            "Usage: ox tui create",
        ],
    )
}

#[test]
fn tui_rename_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["tui", "rename", "--help"],
        &[
            "Open directly on the rename-agent screen",
            "Usage: ox tui rename",
        ],
    )
}

#[test]
fn agents_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["agents", "--help"],
        &[
            "Commands for working with tmux agents",
            "Usage: ox agents",
            "list",
            "reconcile-pinned",
            "create",
            "delete",
            "update",
            "attach",
            "worktree",
            "send",
            "read",
            "pick",
        ],
    )
}

#[test]
fn agents_reconcile_pinned_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["agents", "reconcile-pinned", "--help"],
        &[
            "Reconcile pinned sessions (create/heal/reorder) immediately",
            "Usage: ox agents reconcile-pinned",
            "Examples:",
            "See also:",
        ],
    )
}

#[test]
fn agents_ls_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["agents", "list", "--help"],
        &[
            "List current tmux agents",
            "Usage: ox agents list",
            "Examples:",
            "See also:",
        ],
    )
}

#[test]
fn agents_new_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["agents", "create", "--help"],
        &[
            "Create a new detached tmux agent by name",
            "Usage: ox agents create",
            "--attach",
            "--workspace-backend",
            "--workspace-name",
            "--repo",
            "Examples:",
            "Advanced:",
            "See also:",
        ],
    )
}

#[test]
fn agents_new_help_does_not_advertise_removed_k8s_backend() -> TestResult {
    let output = run_ox(&["agents", "create", "--help"])?;
    assert_success(&output, "expected help command success");

    let stdout = String::from_utf8_lossy(&output.stdout);
    assert!(
        !stdout.contains("k8s-checkout"),
        "expected removed workspace backend to be absent from help; stdout={stdout}"
    );

    Ok(())
}

#[test]
fn agents_delete_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["agents", "delete", "--help"],
        &[
            "Delete (kill) an existing tmux agent by name",
            "Usage: ox agents delete",
            "Examples:",
            "See also:",
        ],
    )
}

#[test]
fn agents_update_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["agents", "update", "--help"],
        &[
            "Update a tmux agent (rename or reorder)",
            "Usage: ox agents update",
            "Examples:",
            "See also:",
        ],
    )
}

#[test]
fn agents_attach_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["agents", "attach", "--help"],
        &[
            "Attach this terminal to an existing tmux agent",
            "Usage: ox agents attach",
            "Examples:",
            "See also:",
        ],
    )
}

#[test]
fn agents_worktree_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["agents", "worktree", "--help"],
        &[
            "Recreate an agent as a shell rooted in a managed git worktree",
            "Usage: ox agents worktree",
            "--detach",
            "Examples:",
            "See also:",
        ],
    )
}

#[test]
fn agents_send_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["agents", "send", "--help"],
        &[
            "Send one message or opencode slash command to an existing agent",
            "Usage: ox agents send",
            "--agent <TARGET>",
            "--filter <EXPR>",
            "--all",
            "[INPUT]",
            "--message <TEXT>",
            "--file <PATH>",
            "--stdin",
            "--enter",
            "ox agents send --agent slash-test /consistency",
            "ox agents send --agent slash-test \"summarize this repo\"",
            "Examples:",
            "Filter syntax:",
            "See also:",
        ],
    )
}

#[test]
fn agents_read_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["agents", "read", "--help"],
        &[
            "Read messages from an agent conversation transcript",
            "Usage: ox agents read",
            "--agent <TARGET>",
            "--filter <EXPR>",
            "--all",
            "--last",
            "--full",
            "Examples:",
            "Filter syntax:",
            "See also:",
        ],
    )
}

#[test]
fn agents_pick_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["agents", "pick", "--help"],
        &[
            "Open a fuzzy picker and either attach to an agent or choose dashboard",
            "Usage: ox agents pick",
            "Examples:",
            "See also:",
        ],
    )
}

#[test]
fn help_lists_json_flag() -> TestResult {
    assert_help_contains(&["--help"], &["--json"])
}

#[test]
fn status_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["status", "--help"],
        &[
            "Print a quick health summary of tmux + managed ox state",
            "Usage: ox status",
            "Examples:",
            "See also:",
        ],
    )
}

#[test]
fn doctor_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["doctor", "--help"],
        &[
            "Run deeper diagnostics for tmux + managed ox state",
            "--fix",
            "Usage: ox doctor",
            "Examples:",
            "See also:",
        ],
    )
}

#[test]
fn events_help_exits_success_and_prints_usage() -> TestResult {
    assert_help_contains(
        &["events", "--help"],
        &[
            "Print recent application events from the local event log",
            "--limit",
            "Usage: ox events",
            "Examples:",
            "See also:",
        ],
    )
}
