use std::process::Command;

use crate::support::{
    CrudTestEnv, TestResult, assert_failure, assert_success, parse_stderr_json,
    skip_if_missing_commands,
};

#[test]
fn attach_allows_no_prefix_ctrl_w_to_detach_and_keeps_agent_alive() -> TestResult {
    if skip_if_missing_commands(&["tmux", "script"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-attach-test")?;
    let agent_name = format!("ox_attach_{}", std::process::id());

    let new_output = env.run_ox(&["agents", "create", &agent_name])?;

    assert_success(&new_output, "expected agent creation success");

    // `script` allocates a PTY so `tmux attach-session` can run in integration tests.
    let attach_output = Command::new("sh")
        .env("TMUX_TMPDIR", &env.socket_dir)
        .env("OX_BIN", env!("CARGO_BIN_EXE_ox"))
        .env("HOME", &env.home_dir)
        .env("OX_AGENT", &agent_name)
        // The integration test itself may already be running inside tmux, but
        // the spawned attach flow must bind only to the temp server created by
        // this test case.
        .env_remove("TMUX")
        .arg("-c")
        .arg("printf '\\027' | script -q /dev/null \"$OX_BIN\" agents attach \"$OX_AGENT\"")
        .output()?;

    assert_success(&attach_output, "expected attach/detach success");

    let ls_output = env.run_ox(&["agents", "list"])?;

    assert_success(&ls_output, "expected list success");

    let stdout = String::from_utf8_lossy(&ls_output.stdout);
    assert!(
        stdout.contains(&format!("{agent_name}\twindows=")),
        "expected agent to still exist after detach; stdout={stdout}"
    );

    let delete_output = env.run_ox(&["agents", "delete", &agent_name])?;

    assert_success(&delete_output, "expected cleanup success");

    Ok(())
}

#[test]
fn json_mode_renders_command_errors_as_json() -> TestResult {
    if skip_if_missing_commands(&["tmux"]) {
        return Ok(());
    }

    let env = CrudTestEnv::new("ox-json-error-test")?;
    let output = env.run_ox(&["--json", "agents", "delete", " bad"])?;

    assert_failure(&output, "expected invalid delete name to fail");
    let payload = parse_stderr_json(&output)?;
    assert_eq!(
        payload.get("ok").and_then(serde_json::Value::as_bool),
        Some(false)
    );
    let message = payload
        .get("error")
        .and_then(|error| error.get("message"))
        .and_then(serde_json::Value::as_str)
        .unwrap_or("");
    assert!(
        message.contains("agent selector 'bad' was not found"),
        "expected selector failure in JSON error payload; stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );

    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        !stderr.contains("error: "),
        "expected no plain-text prefix in json mode; stderr={stderr}"
    );
    Ok(())
}
