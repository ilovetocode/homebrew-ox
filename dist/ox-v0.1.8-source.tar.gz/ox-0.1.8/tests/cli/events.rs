use crate::support::{CrudTestEnv, TestResult, assert_failure};

#[test]
fn events_fails_when_tmux_is_missing_from_path() -> TestResult {
    let env = CrudTestEnv::new("ox-missing-tmux-test")?;

    // Empty PATH ensures the startup probe cannot find `tmux`.
    let output = env.ox_cmd().env("PATH", "").arg("events").output()?;

    assert_failure(&output, "expected startup failure without tmux on PATH");
    let stderr = String::from_utf8_lossy(&output.stderr);
    assert!(
        stderr.contains("tmux is not on PATH"),
        "expected tmux startup requirement message; stderr={stderr}"
    );
    Ok(())
}
