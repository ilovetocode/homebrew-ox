use std::error::Error;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::Value;

pub(crate) type TestResult = Result<(), Box<dyn Error>>;

const GIT_REPO_ENV_VARS: &[&str] = &[
    "GIT_DIR",
    "GIT_WORK_TREE",
    "GIT_INDEX_FILE",
    "GIT_COMMON_DIR",
    "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_CEILING_DIRECTORIES",
    "GIT_DISCOVERY_ACROSS_FILESYSTEM",
    "GIT_PREFIX",
];

pub(crate) fn ox_bin() -> Command {
    Command::new(env!("CARGO_BIN_EXE_ox"))
}

pub(crate) fn git_cmd() -> Command {
    let mut cmd = Command::new("git");
    scrub_git_repo_env(&mut cmd);
    cmd
}

pub(crate) fn run_ox(args: &[&str]) -> Result<Output, std::io::Error> {
    ox_bin().args(args).output()
}

pub(crate) fn assert_help_contains(args: &[&str], snippets: &[&str]) -> TestResult {
    let output = run_ox(args)?;
    assert_success(&output, "expected success status");

    let stdout = String::from_utf8_lossy(&output.stdout);
    for snippet in snippets {
        assert!(
            stdout.contains(snippet),
            "expected '{snippet}' in help output, got: {stdout}"
        );
    }

    Ok(())
}

pub(crate) fn command_exists(name: &str) -> bool {
    let version_flag = if name == "tmux" { "-V" } else { "--version" };
    Command::new(name)
        .arg(version_flag)
        .output()
        .is_ok_and(|output| output.status.success())
}

pub(crate) fn skip_if_missing_commands(commands: &[&str]) -> bool {
    let missing = commands
        .iter()
        .copied()
        .filter(|command| !command_exists(command))
        .collect::<Vec<_>>();
    if missing.is_empty() {
        return false;
    }

    let binaries = if missing.len() == 1 {
        "binary"
    } else {
        "binaries"
    };
    let joined = join_with_and(&missing);
    eprintln!("skipping test: requires {joined} {binaries} on PATH");
    true
}

pub(crate) fn parse_stdout_json(output: &Output) -> Result<Value, Box<dyn Error>> {
    parse_json(&output.stdout)
}

pub(crate) fn parse_stderr_json(output: &Output) -> Result<Value, Box<dyn Error>> {
    parse_json(&output.stderr)
}

pub(crate) fn agents_array(payload: &Value) -> Result<&[Value], Box<dyn Error>> {
    payload
        .get("agents")
        .and_then(serde_json::Value::as_array)
        .map(Vec::as_slice)
        .ok_or_else(|| "expected `agents` array in JSON payload".into())
}

pub(crate) fn find_agent_named<'a>(
    agents: &'a [Value],
    name: &str,
) -> Result<&'a Value, Box<dyn Error>> {
    agents
        .iter()
        .find(|agent| {
            agent
                .get("name")
                .and_then(serde_json::Value::as_str)
                .is_some_and(|value| value == name)
        })
        .ok_or_else(|| format!("expected agent '{name}' row in JSON payload").into())
}

pub(crate) fn assert_existing_path_matches(
    actual: Option<&str>,
    expected: &Path,
    context: &str,
) -> TestResult {
    let actual = actual.ok_or_else(|| format!("{context}; missing actual path"))?;
    let actual = std::fs::canonicalize(actual)?;
    let expected = std::fs::canonicalize(expected)?;
    assert_eq!(actual, expected, "{context}");
    Ok(())
}

fn parse_json(bytes: &[u8]) -> Result<Value, Box<dyn Error>> {
    let text = String::from_utf8(bytes.to_vec())?;
    let payload = serde_json::from_str::<Value>(&text)?;
    Ok(payload)
}

fn join_with_and(items: &[&str]) -> String {
    match items {
        [] => String::new(),
        [single] => (*single).to_string(),
        [first, second] => format!("{first} and {second}"),
        [head @ .., tail] => format!("{} and {tail}", head.join(", ")),
    }
}

fn scrub_git_repo_env(cmd: &mut Command) {
    for key in GIT_REPO_ENV_VARS {
        cmd.env_remove(key);
    }
}

pub(crate) fn unique_temp_dir(prefix: &str) -> Result<PathBuf, Box<dyn Error>> {
    let nanos = SystemTime::now().duration_since(UNIX_EPOCH)?.as_nanos();
    Ok(std::env::temp_dir().join(format!("{prefix}-{}-{nanos}", std::process::id())))
}

fn unique_short_temp_dir(prefix: &str) -> Result<PathBuf, Box<dyn Error>> {
    let nanos = SystemTime::now().duration_since(UNIX_EPOCH)?.as_nanos();
    // tmux appends `/tmux-<uid>/default` under `TMUX_TMPDIR`, so keep the base
    // directory short enough to stay well below the platform socket-path limit.
    Ok(PathBuf::from("/tmp").join(format!("{prefix}-{}-{nanos}", std::process::id())))
}

pub(crate) fn init_git_repo(path: &Path) -> TestResult {
    std::fs::create_dir_all(path)?;

    let init_output = git_cmd().arg("init").arg(path).output()?;
    assert!(
        init_output.status.success(),
        "expected `git init` success; stderr={}",
        String::from_utf8_lossy(&init_output.stderr)
    );

    std::fs::write(path.join("README.md"), "test\n")?;

    let add_output = git_cmd().arg("-C").arg(path).arg("add").arg(".").output()?;
    assert!(
        add_output.status.success(),
        "expected `git add` success; stderr={}",
        String::from_utf8_lossy(&add_output.stderr)
    );

    let commit_output = git_cmd()
        .arg("-C")
        .arg(path)
        .arg("-c")
        .arg("user.name=ox-test")
        .arg("-c")
        .arg("user.email=ox-test@example.com")
        .arg("commit")
        .arg("-m")
        .arg("init")
        .output()?;
    assert!(
        commit_output.status.success(),
        "expected `git commit` success; stderr={}",
        String::from_utf8_lossy(&commit_output.stderr)
    );

    Ok(())
}

pub(crate) fn wait_for_tmux_path(
    env: &CrudTestEnv,
    session_name: &str,
    expected: &Path,
) -> TestResult {
    let expected = std::fs::canonicalize(expected)?;
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(3);
    loop {
        let output = env.run_tmux(&[
            "display-message",
            "-p",
            "-t",
            session_name,
            "#{pane_current_path}",
        ])?;
        if output.status.success() {
            let path = String::from_utf8_lossy(&output.stdout).trim().to_string();
            if let Ok(actual) = std::fs::canonicalize(&path)
                && actual == expected
            {
                return Ok(());
            }
        }
        if std::time::Instant::now() >= deadline {
            return Err(format!(
                "timed out waiting for tmux cwd to become {}",
                expected.display()
            )
            .into());
        }
        std::thread::sleep(std::time::Duration::from_millis(50));
    }
}

pub(crate) struct CrudTestEnv {
    pub(crate) temp_dir: PathBuf,
    pub(crate) home_dir: PathBuf,
    pub(crate) socket_dir: PathBuf,
    pub(crate) conf_path: PathBuf,
    _temp_dir_guard: TempDirGuard,
    _socket_dir_guard: TempDirGuard,
}

impl Drop for CrudTestEnv {
    fn drop(&mut self) {
        let _ = Command::new("tmux")
            .env("TMUX_TMPDIR", &self.socket_dir)
            .env_remove("TMUX")
            .arg("-f")
            .arg(&self.conf_path)
            .arg("kill-server")
            .output();
    }
}

struct TempDirGuard {
    path: PathBuf,
}

impl TempDirGuard {
    fn new(path: PathBuf) -> Self {
        Self { path }
    }
}

impl Drop for TempDirGuard {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.path);
    }
}

impl CrudTestEnv {
    pub(crate) fn new(prefix: &str) -> Result<Self, Box<dyn Error>> {
        let temp_dir = unique_temp_dir(prefix)?;
        std::fs::create_dir_all(&temp_dir)?;

        let socket_dir = unique_short_temp_dir("ox-tmux-socket")?;
        std::fs::create_dir_all(&socket_dir)?;

        let home_dir = temp_dir.join("home");
        std::fs::create_dir_all(&home_dir)?;
        let conf_path = home_dir.join(".config/ox/tmux.conf");
        Ok(Self {
            temp_dir: temp_dir.clone(),
            home_dir,
            socket_dir: socket_dir.clone(),
            conf_path,
            _temp_dir_guard: TempDirGuard::new(temp_dir),
            _socket_dir_guard: TempDirGuard::new(socket_dir),
        })
    }

    pub(crate) fn ox_cmd(&self) -> Command {
        let mut cmd = ox_bin();
        cmd.env("HOME", &self.home_dir)
            .env("TMUX_TMPDIR", &self.socket_dir)
            // Clear the inherited tmux client binding so test commands always
            // target the temp server rooted under `TMUX_TMPDIR`.
            .env_remove("TMUX");
        // Pre-commit hooks can export repo-specific Git env vars for the real
        // checkout. Test commands shell out into temp repos, so scrub those
        // globals to keep every temp repository self-contained.
        scrub_git_repo_env(&mut cmd);
        cmd
    }

    pub(crate) fn run_ox(&self, args: &[&str]) -> Result<Output, std::io::Error> {
        self.ox_cmd().args(args).output()
    }

    pub(crate) fn ox_child(&self, args: &[&str]) -> Command {
        let mut cmd = self.ox_cmd();
        cmd.args(args);
        cmd
    }

    pub(crate) fn run_agents(&self, args: &[&str]) -> Result<Output, std::io::Error> {
        let mut cmd = self.ox_cmd();
        cmd.arg("agents").args(args);
        cmd.output()
    }

    pub(crate) fn run_tmux(&self, args: &[&str]) -> Result<Output, std::io::Error> {
        Command::new("tmux")
            .env("TMUX_TMPDIR", &self.socket_dir)
            // Tests often run inside a real tmux client, so unset `TMUX`
            // before invoking the CLI directly to avoid leaking onto that
            // ambient server instead of the isolated temp socket.
            .env_remove("TMUX")
            .arg("-f")
            .arg(&self.conf_path)
            .args(args)
            .output()
    }

    pub(crate) fn tmux_has_session(&self, session_name: &str) -> Result<Output, std::io::Error> {
        self.run_tmux(&["has-session", "-t", session_name])
    }

    fn pinned_sessions_path(&self) -> PathBuf {
        self.home_dir.join(".local/state/ox/pinned_sessions.yaml")
    }

    pub(crate) fn write_pinned_sessions_yaml(&self, body: &str) -> Result<(), Box<dyn Error>> {
        let path = self.pinned_sessions_path();
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        std::fs::write(path, body)?;
        Ok(())
    }
}

pub(crate) fn assert_success(output: &Output, context: &str) {
    assert!(
        output.status.success(),
        "{context}; stderr={}",
        String::from_utf8_lossy(&output.stderr)
    );
}

pub(crate) fn assert_failure(output: &Output, context: &str) {
    assert!(!output.status.success(), "{context}");
}
