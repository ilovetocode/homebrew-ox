#![allow(missing_docs)]

use criterion::{Criterion, black_box, criterion_group, criterion_main};

fn bench_parse_sessions(c: &mut Criterion) {
    let raw = "work\t3\t1\nops\t1\t0\ndev\t5\t1\ntest\t2\t0\n";
    c.bench_function("parse_sessions", |b| {
        b.iter(|| ox::bench_api::parse_sessions(black_box(raw)));
    });
}

fn bench_parse_panes(c: &mut Criterion) {
    let raw = "work\t%1\t42\t/dev/ttys001\t1\t1\n\
               ops\t%2\t77\t/dev/ttys002\t0\t0\n\
               dev\t%3\t88\t/dev/ttys003\t1\t0\n";
    c.bench_function("parse_panes", |b| {
        b.iter(|| ox::bench_api::parse_panes(black_box(raw)));
    });
}

fn bench_parse_process_rows(c: &mut Criterion) {
    let raw = "50338 50338 50542 ttys013 claude --dangerously-skip-permissions\n\
               50313 50313 50448 ttys011 codex\n\
               50400 50400 50400 ttys012 -zsh\n\
               50500 50500 50500 ttys014 opencode --sandbox danger\n";
    c.bench_function("parse_process_rows", |b| {
        b.iter(|| ox::bench_api::parse_process_rows(black_box(raw)));
    });
}

fn bench_detect_active_agents(c: &mut Criterion) {
    let panes_raw = "dev\t%1\t101\t/dev/ttys001\t1\t1\n\
                     shell\t%2\t201\t/dev/ttys002\t1\t1\n\
                     ai\t%3\t300\t/dev/ttys003\t1\t1\n";
    let procs_raw = "101 101 150 ttys001 -zsh\n\
                     150 150 150 ttys001 codex\n\
                     151 150 150 ttys001 node /tmp/helper.js\n\
                     201 201 201 ttys002 -zsh\n\
                     300 300 300 ttys003 claude --dangerously-skip-permissions\n";
    c.bench_function("detect_active_agents", |b| {
        b.iter(|| ox::bench_api::detect_active_agents(black_box(panes_raw), black_box(procs_raw)));
    });
}

criterion_group!(
    benches,
    bench_parse_sessions,
    bench_parse_panes,
    bench_parse_process_rows,
    bench_detect_active_agents,
);
criterion_main!(benches);
