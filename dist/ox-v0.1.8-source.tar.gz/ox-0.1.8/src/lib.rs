//! Core CLI library for the `ox` binary.
//!
//! This crate owns argument parsing and command dispatch so integration tests
//! can exercise behavior through a stable public API.
//!
#![deny(missing_docs)]
#![deny(rustdoc::broken_intra_doc_links)]
#![deny(rustdoc::bare_urls)]
#![deny(rustdoc::invalid_codeblock_attributes)]
#![deny(rustdoc::invalid_html_tags)]
#![deny(rustdoc::private_intra_doc_links)]
#![deny(clippy::unwrap_used)]
#![deny(clippy::expect_used)]
#![deny(clippy::panic)]
#![deny(clippy::todo)]
#![deny(clippy::unimplemented)]
#![deny(clippy::dbg_macro)]
#![forbid(unsafe_code)]

mod application;
mod bootstrap;
mod domain;
mod error;
mod infrastructure;
mod interface;

/// Benchmark entry points for criterion. Not public API.
#[cfg(feature = "bench")]
#[doc(hidden)]
pub mod bench_api {
    #![allow(missing_docs, clippy::must_use_candidate)]

    /// Parse tmux session listing and return the row count.
    pub fn parse_sessions(raw: &str) -> usize {
        crate::infrastructure::tmux::bench::parse_sessions(raw)
    }

    /// Parse tmux pane listing and return the row count.
    pub fn parse_panes(raw: &str) -> usize {
        crate::infrastructure::tmux::bench::parse_panes(raw)
    }

    /// Parse `ps` process rows and return the row count.
    pub fn parse_process_rows(raw: &str) -> usize {
        crate::infrastructure::tmux::bench::parse_process_rows(raw)
    }

    /// Run the full agent-detection pipeline on raw inputs.
    pub fn detect_active_agents(panes_raw: &str, process_rows_raw: &str) -> usize {
        crate::infrastructure::tmux::bench::detect_active_agents(panes_raw, process_rows_raw)
    }
}

/// Parse CLI arguments and execute the requested `ox` command.
///
/// This is the crate's stable entrypoint for embedding or integration tests
/// that want to drive command behavior without invoking the binary wrapper.
///
/// # Errors
///
/// Returns an error if the selected subcommand fails, including terminal
/// initialization, rendering, input polling, or terminal restoration failures
/// while running the TUI.
///
/// # Examples
///
/// ```no_run
/// if let Err(err) = ox::run() {
///     eprintln!("{err}");
/// }
/// ```
pub fn run() -> Result<(), error::AppError> {
    interface::cli::run()
}
