use std::time::{SystemTime, UNIX_EPOCH};

pub(super) fn compact_path(path: &str) -> String {
    crate::interface::presentation::agents::compact_path(path)
}

pub(super) fn compact_age_from(now_unix_ms: u128, then_unix_ms: u128) -> String {
    if now_unix_ms == 0 || then_unix_ms == 0 || then_unix_ms > now_unix_ms {
        return "--".to_string();
    }
    let delta_ms = now_unix_ms - then_unix_ms;
    if delta_ms < 1_000 {
        return "now".to_string();
    }
    let seconds = delta_ms / 1_000;
    if seconds < 60 {
        return format!("{seconds}s");
    }
    let minutes = seconds / 60;
    if minutes < 60 {
        return format!("{minutes}m");
    }
    let hours = minutes / 60;
    if hours < 24 {
        return format!("{hours}h");
    }
    format!("{}d", hours / 24)
}

pub(super) fn now_unix_ms() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_millis())
}

#[cfg(test)]
mod tests {
    use super::{compact_age_from, compact_path};

    #[test]
    fn compact_path_shortens_worktree_paths() {
        assert_eq!(
            compact_path("/Users/testing/projects/ox/.worktrees/feature-ui"),
            "ox/.worktrees/feature-ui"
        );
    }

    #[test]
    fn compact_path_keeps_short_suffix_for_generic_paths() {
        assert_eq!(compact_path("/tmp/repo/service"), "repo/service");
    }

    #[test]
    fn compact_age_formats_human_readable_ranges() {
        assert_eq!(compact_age_from(30_000, 12_000), "18s");
        assert_eq!(compact_age_from(600_000, 120_000), "8m");
    }
}
