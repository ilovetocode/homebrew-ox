use std::time::Instant;

use crossterm::event::{KeyCode, KeyEvent, KeyEventKind, KeyModifiers};

use super::commands::TuiCommand;
use super::events::TuiEvent;
use super::messages::{
    MSG_AGENT_NAME_CANNOT_BE_EMPTY, MSG_AGENT_NAME_UNCHANGED, MSG_NEW_AGENT_CREATION_CANCELED,
    MSG_NO_AGENT_SELECTED, MSG_NO_PICKER_RESULT_SELECTED, MSG_PICKER_CANCELED,
    MSG_QUICK_SWITCH_HINT, MSG_REPO_ROOT_PICKER_HINT, MSG_RETURNED_TO_DASHBOARD, MSG_SEARCH_CLOSED,
    MSG_WORKTREE_BRANCH_CANNOT_BE_EMPTY, MSG_WORKTREE_SWITCH_CANCELED,
};
use super::model::{
    NewAgentField, PICKER_LATENCY_WARN_MS, PreviewPaneState, PromptFlow, ScreenState, TuiModel,
};
use super::picker::{PickerState, PickerTarget, quick_switch_items};
use crate::application::{AgentKind, TuiFleetSnapshot, WorkspaceBackend};
use crate::domain::AgentId;
use crate::interface::presentation::agent_kind::agent_kind_label;
use crate::interface::presentation::quick_switch::QuickSwitchTarget;
use crate::interface::shared::new_agent::build_create_agent_request;

const PREVIEW_SCROLL_STEP: u16 = 8;
const NEW_AGENT_KIND_ORDER: [AgentKind; 4] = [
    AgentKind::Shell,
    AgentKind::Codex,
    AgentKind::Opencode,
    AgentKind::Claude,
];

/// Result of mutating the TUI model for one incoming event.
pub(super) struct UpdateResult {
    pub(super) commands: Vec<TuiCommand>,
    pub(super) changed: bool,
}

pub(super) fn update(model: &mut TuiModel, event: TuiEvent) -> UpdateResult {
    match event {
        TuiEvent::Started => on_started(model),
        TuiEvent::Tick(now) => on_tick(model, now),
        TuiEvent::KeyPressed(key) => on_key_pressed(model, key),
        TuiEvent::Resized => changed_only(),
        TuiEvent::AgentsRefreshed {
            agents,
            refreshed_at_unix_ms,
            coalesced_updates,
        } => on_agents_refreshed(model, agents, refreshed_at_unix_ms, coalesced_updates),
        TuiEvent::AgentsRefreshFailed { message } => {
            let changed = replace_error(model, Some(message));
            UpdateResult {
                commands: Vec::new(),
                changed,
            }
        }
        TuiEvent::StatusLoaded { result } => on_status_loaded(model, result),
        TuiEvent::PreviewLoaded {
            agent_id,
            output,
            capture_ms: _,
        } => on_preview_loaded(model, &agent_id, output),
        TuiEvent::PreviewFailed {
            agent_id,
            message,
            capture_ms: _,
        } => on_preview_failed(model, &agent_id, message),
        TuiEvent::RepoRootPickerLoaded { result } => on_repo_root_picker_loaded(model, result),
        TuiEvent::AgentCreated {
            requested_name,
            agent_kind,
            create_worktree,
            result,
        } => on_agent_created(model, &requested_name, agent_kind, create_worktree, result),
        TuiEvent::AgentRenamed {
            id: _,
            old_name,
            new_name,
            result,
        } => on_agent_renamed(model, &old_name, &new_name, result),
        TuiEvent::AgentDeleted { id, name, result } => on_agent_deleted(model, &id, &name, result),
        TuiEvent::AgentWorktreeSwitched {
            id,
            name,
            branch,
            result,
        } => on_agent_worktree_switched(model, &id, &name, &branch, result),
        TuiEvent::AgentAttached {
            id,
            name,
            from_search_mode,
            result,
        } => on_agent_attached(model, &id, &name, from_search_mode, result),
        TuiEvent::PreviewKeySent { agent_id, result } => {
            on_preview_key_sent(model, &agent_id, result)
        }
        TuiEvent::RuntimeWarning { message } => {
            let changed = replace_status(model, Some(message));
            UpdateResult {
                commands: Vec::new(),
                changed,
            }
        }
    }
}

fn on_started(model: &mut TuiModel) -> UpdateResult {
    let mut commands = vec![TuiCommand::RefreshAgents];
    if matches!(model.screen, ScreenState::Status) {
        commands.push(TuiCommand::LoadStatus);
    }
    UpdateResult {
        commands,
        changed: true,
    }
}

fn on_tick(model: &mut TuiModel, now: Instant) -> UpdateResult {
    if !model.preview_refresh_eligible() {
        return unchanged();
    }

    let Some(agent_id) = model.active_agent_id() else {
        let changed = if model.preview == PreviewPaneState::default() {
            false
        } else {
            model.clear_preview();
            true
        };
        return UpdateResult {
            commands: Vec::new(),
            changed,
        };
    };

    let preview_due = model
        .runtime
        .last_preview_request_at
        .is_none_or(|last| now.duration_since(last) >= model.runtime.preview_refresh_interval);
    if !preview_due || model.runtime.pending_preview_agent_id.as_ref() == Some(&agent_id) {
        return unchanged();
    }

    model.mark_preview_request(now, agent_id.clone());
    UpdateResult {
        commands: vec![TuiCommand::RequestPreviewCapture {
            id: agent_id,
            lines: model.runtime.preview_capture_lines,
        }],
        changed: false,
    }
}

fn on_key_pressed(model: &mut TuiModel, key: KeyEvent) -> UpdateResult {
    if key.kind != KeyEventKind::Press {
        return unchanged();
    }

    if key.code == KeyCode::Char('c') && key.modifiers.contains(KeyModifiers::CONTROL) {
        return UpdateResult {
            commands: vec![TuiCommand::Quit],
            changed: false,
        };
    }

    if model.overlay.is_some() {
        return handle_picker_key(model, key);
    }

    if matches!(model.screen, ScreenState::Dashboard)
        && key.code == KeyCode::Char('r')
        && key.modifiers.contains(KeyModifiers::CONTROL)
    {
        return begin_quick_switch(model);
    }

    match &model.screen {
        ScreenState::Dashboard => handle_dashboard_key(model, key),
        ScreenState::Status => match key.code {
            KeyCode::Esc | KeyCode::Char('q') => {
                model.return_from_status_screen();
                changed_only()
            }
            _ => unchanged(),
        },
        ScreenState::Prompt(PromptFlow::NewAgent(_)) => handle_new_agent_key(model, key),
        ScreenState::Prompt(PromptFlow::Search(_)) => handle_search_key(model, key),
        ScreenState::Prompt(PromptFlow::Rename(_)) => handle_rename_key(model, key),
        ScreenState::Prompt(PromptFlow::Worktree(_)) => handle_worktree_key(model, key),
    }
}

fn handle_dashboard_key(model: &mut TuiModel, key: KeyEvent) -> UpdateResult {
    if model.preview.input_mode {
        if key.code == KeyCode::Esc {
            model.preview.input_mode = false;
            return changed_only();
        }
        let Some(token) = preview_key_token(key) else {
            return unchanged();
        };
        let Some(id) = model.active_agent_id() else {
            model.notifications.status_message = Some(MSG_NO_AGENT_SELECTED.to_string());
            return changed_only();
        };
        return UpdateResult {
            commands: vec![TuiCommand::SendPreviewKey { id, key: token }],
            changed: false,
        };
    }

    if key.code == KeyCode::Char('u') && key.modifiers.contains(KeyModifiers::CONTROL) {
        model.scroll_preview_up(PREVIEW_SCROLL_STEP);
        return changed_only();
    }
    if key.code == KeyCode::Char('d') && key.modifiers.contains(KeyModifiers::CONTROL) {
        model.scroll_preview_down(PREVIEW_SCROLL_STEP);
        return changed_only();
    }

    match key.code {
        KeyCode::Char('q') | KeyCode::Esc => UpdateResult {
            commands: vec![TuiCommand::Quit],
            changed: false,
        },
        KeyCode::Char('j') | KeyCode::Down => move_selection(model, true),
        KeyCode::Char('k') | KeyCode::Up => move_selection(model, false),
        KeyCode::Char('d') => delete_selected(model),
        KeyCode::Char('s') => {
            model.enter_status_screen();
            UpdateResult {
                commands: vec![TuiCommand::LoadStatus],
                changed: true,
            }
        }
        KeyCode::Char('n') => {
            model.enter_new_agent_prompt();
            changed_only()
        }
        KeyCode::Char('r') => {
            model.enter_rename_prompt_from_selection();
            changed_only()
        }
        KeyCode::Char('w') => {
            model.enter_worktree_prompt_from_selection();
            changed_only()
        }
        KeyCode::Char('/') => {
            model.enter_search_prompt();
            changed_only()
        }
        KeyCode::Char('l') | KeyCode::Enter => attach_selected(model),
        KeyCode::Char('i') => {
            model.preview.input_mode = true;
            changed_only()
        }
        _ => unchanged(),
    }
}

fn handle_new_agent_key(model: &mut TuiModel, key: KeyEvent) -> UpdateResult {
    match key.code {
        KeyCode::Esc => {
            model.enter_dashboard_with_status(MSG_NEW_AGENT_CREATION_CANCELED);
            changed_only()
        }
        KeyCode::Enter => submit_new_agent(model),
        KeyCode::Tab => {
            let ScreenState::Prompt(PromptFlow::NewAgent(form)) = &mut model.screen else {
                return unchanged();
            };
            form.focus_next();
            changed_only()
        }
        KeyCode::BackTab => {
            let ScreenState::Prompt(PromptFlow::NewAgent(form)) = &mut model.screen else {
                return unchanged();
            };
            form.focus_prev();
            changed_only()
        }
        KeyCode::Left => adjust_new_agent_field(model, false),
        KeyCode::Right | KeyCode::Char(' ') => adjust_new_agent_field(model, true),
        KeyCode::Char('p' | 'P') if key.modifiers.contains(KeyModifiers::CONTROL) => {
            let ScreenState::Prompt(PromptFlow::NewAgent(form)) = &mut model.screen else {
                return unchanged();
            };
            if !form.create_worktree {
                form.create_worktree = true;
            }
            UpdateResult {
                commands: vec![TuiCommand::LoadRepoRootPicker],
                changed: true,
            }
        }
        KeyCode::Backspace => {
            let ScreenState::Prompt(PromptFlow::NewAgent(form)) = &mut model.screen else {
                return unchanged();
            };
            if form.focused_field == NewAgentField::Name {
                form.name.pop();
                return changed_only();
            }
            unchanged()
        }
        KeyCode::Char(ch) => {
            let ScreenState::Prompt(PromptFlow::NewAgent(form)) = &mut model.screen else {
                return unchanged();
            };
            if form.focused_field == NewAgentField::Name {
                form.name.push(ch);
                return changed_only();
            }
            unchanged()
        }
        _ => unchanged(),
    }
}

fn handle_search_key(model: &mut TuiModel, key: KeyEvent) -> UpdateResult {
    match key.code {
        KeyCode::Esc | KeyCode::Char('q') => {
            model.enter_dashboard_with_status(MSG_SEARCH_CLOSED);
            changed_only()
        }
        KeyCode::Enter => attach_selected(model),
        KeyCode::Backspace => {
            let ScreenState::Prompt(PromptFlow::Search(search)) = &mut model.screen else {
                return unchanged();
            };
            search.draft.pop();
            changed_only()
        }
        KeyCode::Char(ch) => {
            let ScreenState::Prompt(PromptFlow::Search(search)) = &mut model.screen else {
                return unchanged();
            };
            search.draft.push(ch);
            changed_only()
        }
        _ => unchanged(),
    }
}

fn handle_rename_key(model: &mut TuiModel, key: KeyEvent) -> UpdateResult {
    match key.code {
        KeyCode::Esc => {
            model.enter_dashboard_with_status(super::messages::MSG_AGENT_RENAME_CANCELED);
            changed_only()
        }
        KeyCode::Enter => submit_rename(model),
        KeyCode::Backspace => {
            let ScreenState::Prompt(PromptFlow::Rename(prompt)) = &mut model.screen else {
                return unchanged();
            };
            prompt.draft.pop();
            changed_only()
        }
        KeyCode::Char(ch) => {
            let ScreenState::Prompt(PromptFlow::Rename(prompt)) = &mut model.screen else {
                return unchanged();
            };
            prompt.draft.push(ch);
            changed_only()
        }
        _ => unchanged(),
    }
}

fn handle_worktree_key(model: &mut TuiModel, key: KeyEvent) -> UpdateResult {
    match key.code {
        KeyCode::Esc => {
            model.enter_dashboard_with_status(MSG_WORKTREE_SWITCH_CANCELED);
            changed_only()
        }
        KeyCode::Enter => submit_worktree_switch(model),
        KeyCode::Backspace => {
            let ScreenState::Prompt(PromptFlow::Worktree(prompt)) = &mut model.screen else {
                return unchanged();
            };
            prompt.draft.pop();
            changed_only()
        }
        KeyCode::Char(ch) => {
            let ScreenState::Prompt(PromptFlow::Worktree(prompt)) = &mut model.screen else {
                return unchanged();
            };
            prompt.draft.push(ch);
            changed_only()
        }
        _ => unchanged(),
    }
}

fn handle_picker_key(model: &mut TuiModel, key: KeyEvent) -> UpdateResult {
    match key.code {
        KeyCode::Esc => {
            model.close_overlay();
            model.notifications.status_message = Some(MSG_PICKER_CANCELED.to_string());
            changed_only()
        }
        KeyCode::Enter => submit_picker(model),
        KeyCode::Char('j') | KeyCode::Down => {
            if let Some(picker) = model.picker_mut() {
                picker.select_next();
                return changed_only();
            }
            unchanged()
        }
        KeyCode::Char('k') | KeyCode::Up => {
            if let Some(picker) = model.picker_mut() {
                picker.select_prev();
                return changed_only();
            }
            unchanged()
        }
        KeyCode::Backspace => update_picker_query(model, PickerState::backspace_query),
        KeyCode::Char(ch) => update_picker_query(model, |picker| picker.append_query(ch)),
        _ => unchanged(),
    }
}

fn update_picker_query(model: &mut TuiModel, apply: impl FnOnce(&mut PickerState)) -> UpdateResult {
    let Some(picker) = model.picker_mut() else {
        return unchanged();
    };
    apply(picker);
    if picker.last_recompute_ms() > PICKER_LATENCY_WARN_MS {
        model.notifications.status_message = Some(format!(
            "Picker match latency high: {}ms.",
            picker.last_recompute_ms()
        ));
    }
    changed_only()
}

fn begin_quick_switch(model: &mut TuiModel) -> UpdateResult {
    model.open_picker(PickerState::new(
        "Quick Switch",
        "No matching target.",
        quick_switch_items(&model.dashboard.agents),
    ));
    model.notifications.status_message = Some(MSG_QUICK_SWITCH_HINT.to_string());
    changed_only()
}

fn submit_picker(model: &mut TuiModel) -> UpdateResult {
    let Some(target) = model
        .picker()
        .and_then(|picker| picker.selected_item().map(|item| item.target.clone()))
    else {
        model.notifications.status_message = Some(MSG_NO_PICKER_RESULT_SELECTED.to_string());
        model.close_overlay();
        return changed_only();
    };

    model.close_overlay();
    match target {
        PickerTarget::QuickSwitch(QuickSwitchTarget::Dashboard) => {
            model.enter_dashboard_with_status(MSG_RETURNED_TO_DASHBOARD);
            changed_only()
        }
        PickerTarget::QuickSwitch(QuickSwitchTarget::Agent { id, name }) => UpdateResult {
            commands: vec![TuiCommand::AttachAgent {
                id,
                name,
                from_search_mode: false,
            }],
            changed: true,
        },
        PickerTarget::RepoRoot(path) => {
            if let ScreenState::Prompt(PromptFlow::NewAgent(form)) = &mut model.screen {
                form.repo_root = Some(path.clone());
                form.create_worktree = true;
                form.normalize_focus();
                model.notifications.status_message = Some(format!("Repo root selected: {path}"));
                model.notifications.error_message = None;
            }
            changed_only()
        }
    }
}

fn move_selection(model: &mut TuiModel, forward: bool) -> UpdateResult {
    if !matches!(model.screen, ScreenState::Dashboard) || model.preview.input_mode {
        return unchanged();
    }
    if forward {
        model
            .dashboard
            .selection
            .select_next(model.dashboard.agents.len());
    } else {
        model
            .dashboard
            .selection
            .select_prev(model.dashboard.agents.len());
    }

    let mut commands = Vec::new();
    if let Some(id) = model.active_agent_id() {
        model.runtime.pending_preview_agent_id = None;
        commands.push(TuiCommand::RequestPreviewCapture {
            id,
            lines: model.runtime.preview_capture_lines,
        });
    } else {
        model.clear_preview();
    }
    UpdateResult {
        commands,
        changed: true,
    }
}

fn delete_selected(model: &mut TuiModel) -> UpdateResult {
    if model.is_search_prompt() {
        return unchanged();
    }
    let Some(active_agent) = model.active_agent() else {
        return unchanged();
    };
    UpdateResult {
        commands: vec![TuiCommand::DeleteAgent {
            id: active_agent.agent.id(),
            name: active_agent.agent.display_name().to_string(),
        }],
        changed: false,
    }
}

fn attach_selected(model: &mut TuiModel) -> UpdateResult {
    let Some(active_agent) = model.active_agent() else {
        model.notifications.status_message = Some(MSG_NO_AGENT_SELECTED.to_string());
        return changed_only();
    };
    UpdateResult {
        commands: vec![TuiCommand::AttachAgent {
            id: active_agent.agent.id(),
            name: active_agent.agent.display_name().to_string(),
            from_search_mode: model.is_search_prompt(),
        }],
        changed: false,
    }
}

fn adjust_new_agent_field(model: &mut TuiModel, forward: bool) -> UpdateResult {
    let ScreenState::Prompt(PromptFlow::NewAgent(form)) = &mut model.screen else {
        return unchanged();
    };
    match form.focused_field {
        NewAgentField::Name | NewAgentField::RepoRoot => {}
        NewAgentField::Kind => {
            let index = NEW_AGENT_KIND_ORDER
                .iter()
                .position(|value| *value == form.agent_kind)
                .unwrap_or(0);
            let next_index = if forward {
                (index + 1) % NEW_AGENT_KIND_ORDER.len()
            } else {
                (index + NEW_AGENT_KIND_ORDER.len() - 1) % NEW_AGENT_KIND_ORDER.len()
            };
            form.agent_kind = NEW_AGENT_KIND_ORDER[next_index];
        }
        NewAgentField::Worktree => {
            form.create_worktree = !form.create_worktree;
            form.normalize_focus();
        }
    }
    changed_only()
}

fn submit_new_agent(model: &mut TuiModel) -> UpdateResult {
    let ScreenState::Prompt(PromptFlow::NewAgent(form)) = &model.screen else {
        return unchanged();
    };
    let form = form.clone();
    let trimmed_name = form.name.trim().to_string();
    model.enter_dashboard();
    UpdateResult {
        commands: vec![TuiCommand::CreateAgent {
            request: build_create_agent_request(
                trimmed_name.clone(),
                form.agent_kind,
                if form.create_worktree {
                    WorkspaceBackend::LocalWorktree
                } else {
                    WorkspaceBackend::LocalCurrentTree
                },
                None,
                form.repo_root.clone(),
            ),
            requested_name: trimmed_name,
            agent_kind: form.agent_kind,
            create_worktree: form.create_worktree,
        }],
        changed: true,
    }
}

fn submit_rename(model: &mut TuiModel) -> UpdateResult {
    let ScreenState::Prompt(PromptFlow::Rename(prompt)) = &model.screen else {
        return unchanged();
    };
    let prompt = prompt.clone();
    let new_name = prompt.draft.trim().to_string();
    model.enter_dashboard();
    if new_name.is_empty() {
        model.notifications.status_message = Some(MSG_AGENT_NAME_CANNOT_BE_EMPTY.to_string());
        return changed_only();
    }
    if new_name == prompt.old_name {
        model.notifications.status_message = Some(MSG_AGENT_NAME_UNCHANGED.to_string());
        return changed_only();
    }
    UpdateResult {
        commands: vec![TuiCommand::RenameAgent {
            id: prompt.agent_id,
            old_name: prompt.old_name,
            new_name,
        }],
        changed: true,
    }
}

fn submit_worktree_switch(model: &mut TuiModel) -> UpdateResult {
    let ScreenState::Prompt(PromptFlow::Worktree(prompt)) = &model.screen else {
        return unchanged();
    };
    let prompt = prompt.clone();
    let branch = prompt.draft.trim().to_string();
    model.enter_dashboard();
    if branch.is_empty() {
        model.notifications.status_message = Some(MSG_WORKTREE_BRANCH_CANNOT_BE_EMPTY.to_string());
        return changed_only();
    }
    UpdateResult {
        commands: vec![TuiCommand::SwitchAgentToWorktreeShell {
            id: prompt.agent_id,
            name: prompt.agent_name,
            branch,
        }],
        changed: true,
    }
}

fn on_agents_refreshed(
    model: &mut TuiModel,
    agents: Vec<crate::application::AgentView>,
    refreshed_at_unix_ms: u128,
    coalesced_updates: u64,
) -> UpdateResult {
    model.replace_agents_preserving_selection(agents, refreshed_at_unix_ms, None);
    model.notifications.error_message = None;
    if coalesced_updates > model.runtime.last_seen_coalesced_refresh_updates {
        model.notifications.status_message = Some(format!(
            "Refresh load high: coalesced {coalesced_updates} stale updates."
        ));
        model.runtime.last_seen_coalesced_refresh_updates = coalesced_updates;
    }
    model.maybe_apply_deferred_rename_prompt();

    let mut commands = Vec::new();
    if model.preview_refresh_eligible() {
        if let Some(id) = model.active_agent_id() {
            model.runtime.pending_preview_agent_id = None;
            commands.push(TuiCommand::RequestPreviewCapture {
                id,
                lines: model.runtime.preview_capture_lines,
            });
        } else {
            model.clear_preview();
        }
    }

    UpdateResult {
        commands,
        changed: true,
    }
}

fn on_status_loaded(
    model: &mut TuiModel,
    result: Result<crate::application::StatusReport, String>,
) -> UpdateResult {
    match result {
        Ok(report) => {
            model.status.report = Some(report);
            model.notifications.error_message = None;
        }
        Err(err) => {
            model.status.report = None;
            model.notifications.error_message = Some(err);
        }
    }
    changed_only()
}

fn on_preview_loaded(model: &mut TuiModel, agent_id: &AgentId, output: String) -> UpdateResult {
    model.runtime.pending_preview_agent_id = None;
    if model.active_agent_id().as_ref() != Some(agent_id) {
        return unchanged();
    }
    model.set_preview_text(output);
    model.notifications.error_message = None;
    changed_only()
}

fn on_preview_failed(model: &mut TuiModel, agent_id: &AgentId, message: String) -> UpdateResult {
    model.runtime.pending_preview_agent_id = None;
    if model.active_agent_id().as_ref() != Some(agent_id) {
        return unchanged();
    }
    model.notifications.error_message = Some(message);
    changed_only()
}

fn on_repo_root_picker_loaded(
    model: &mut TuiModel,
    result: Result<Vec<super::picker::PickerItem>, String>,
) -> UpdateResult {
    match result {
        Ok(items) => {
            model.open_picker(PickerState::new(
                "Repository Root",
                "No matching directories.",
                items,
            ));
            model.notifications.status_message = Some(MSG_REPO_ROOT_PICKER_HINT.to_string());
            model.notifications.error_message = None;
        }
        Err(err) => {
            model.notifications.error_message =
                Some(format!("failed to load repository directories: {err}"));
        }
    }
    changed_only()
}

fn on_agent_created(
    model: &mut TuiModel,
    requested_name: &str,
    agent_kind: AgentKind,
    create_worktree: bool,
    result: Result<TuiFleetSnapshot, String>,
) -> UpdateResult {
    match result {
        Ok(snapshot) => {
            apply_mutation_snapshot(model, snapshot);
            let created_name = model
                .selected_agent_id()
                .and_then(|selected_id| {
                    model.dashboard.agents.iter().find_map(|agent| {
                        (agent.agent.id().as_str() == selected_id.as_str())
                            .then(|| agent.agent.display_name().to_string())
                    })
                })
                .unwrap_or_else(|| requested_name.to_string());
            model.notifications.status_message = Some(format!(
                "Created agent '{created_name}' ({}){}",
                agent_kind_label(agent_kind),
                if create_worktree {
                    " with git worktree"
                } else {
                    ""
                }
            ));
            model.notifications.error_message = None;
            let mut commands = Vec::new();
            if let Some(id) = model.active_agent_id() {
                model.runtime.pending_preview_agent_id = None;
                commands.push(TuiCommand::RequestPreviewCapture {
                    id,
                    lines: model.runtime.preview_capture_lines,
                });
            }
            return UpdateResult {
                commands,
                changed: true,
            };
        }
        Err(err) => {
            model.notifications.error_message = Some(err);
        }
    }
    changed_only()
}

fn on_agent_renamed(
    model: &mut TuiModel,
    old_name: &str,
    new_name: &str,
    result: Result<TuiFleetSnapshot, String>,
) -> UpdateResult {
    match result {
        Ok(snapshot) => {
            apply_mutation_snapshot(model, snapshot);
            model.notifications.status_message =
                Some(format!("Renamed agent '{old_name}' to '{new_name}'."));
            model.notifications.error_message = None;
            return changed_only();
        }
        Err(err) => model.notifications.error_message = Some(err),
    }
    changed_only()
}

fn on_agent_deleted(
    model: &mut TuiModel,
    id: &AgentId,
    name: &str,
    result: Result<TuiFleetSnapshot, String>,
) -> UpdateResult {
    match result {
        Ok(snapshot) => {
            let recycled = snapshot
                .agents
                .iter()
                .any(|agent| agent.agent.id().as_str() == id.as_str());
            apply_mutation_snapshot(model, snapshot);
            model.notifications.status_message = Some(if recycled {
                format!("Restarted pinned agent '{name}'.")
            } else {
                format!("Deleted agent '{name}'.")
            });
            model.notifications.error_message = None;
            return changed_only();
        }
        Err(err) => model.notifications.error_message = Some(err),
    }
    changed_only()
}

fn on_agent_worktree_switched(
    model: &mut TuiModel,
    id: &AgentId,
    name: &str,
    branch: &str,
    result: Result<TuiFleetSnapshot, String>,
) -> UpdateResult {
    match result {
        Ok(snapshot) => {
            apply_mutation_snapshot(model, snapshot);
            model.notifications.status_message = Some(format!(
                "Switched agent '{name}' to worktree branch '{branch}'."
            ));
            model.notifications.error_message = None;
            return UpdateResult {
                commands: vec![TuiCommand::AttachAgent {
                    id: id.clone(),
                    name: name.to_string(),
                    from_search_mode: false,
                }],
                changed: true,
            };
        }
        Err(err) => {
            model.notifications.error_message =
                Some(format!("failed to switch to worktree '{branch}': {err}"));
        }
    }
    changed_only()
}

fn on_agent_attached(
    model: &mut TuiModel,
    id: &AgentId,
    name: &str,
    from_search_mode: bool,
    result: Result<(), String>,
) -> UpdateResult {
    match result {
        Ok(()) => {
            model.set_selected_by_agent_id(id);
            if from_search_mode && model.is_search_prompt() {
                model.enter_dashboard();
            }
            model.notifications.status_message = Some(format!("Detached from agent '{name}'."));
            model.notifications.error_message = None;
        }
        Err(err) => {
            model.notifications.error_message = Some(format!("failed to attach: {err}"));
        }
    }
    changed_only()
}

fn on_preview_key_sent(
    model: &mut TuiModel,
    agent_id: &AgentId,
    result: Result<(), String>,
) -> UpdateResult {
    if model.active_agent_id().as_ref() != Some(agent_id) {
        return unchanged();
    }
    match result {
        Ok(()) => {
            model.notifications.error_message = None;
        }
        Err(err) => {
            model.notifications.error_message = Some(err);
        }
    }
    changed_only()
}

fn apply_mutation_snapshot(model: &mut TuiModel, snapshot: TuiFleetSnapshot) {
    let selected_agent_id = snapshot.selected_agent_id.clone();
    model.replace_agents_preserving_selection(
        snapshot.agents,
        model.dashboard.last_refresh_unix_ms,
        selected_agent_id,
    );
    model.maybe_apply_deferred_rename_prompt();
}

fn preview_key_token(key: KeyEvent) -> Option<String> {
    match key.code {
        KeyCode::Enter => Some("Enter".to_string()),
        KeyCode::Backspace => Some("BSpace".to_string()),
        KeyCode::Tab => Some("Tab".to_string()),
        KeyCode::Up => Some("Up".to_string()),
        KeyCode::Down => Some("Down".to_string()),
        KeyCode::Left => Some("Left".to_string()),
        KeyCode::Right => Some("Right".to_string()),
        KeyCode::Char(ch) => Some(ch.to_string()),
        _ => None,
    }
}

fn replace_error(model: &mut TuiModel, value: Option<String>) -> bool {
    let changed = model.notifications.error_message != value;
    model.notifications.error_message = value;
    changed
}

fn replace_status(model: &mut TuiModel, value: Option<String>) -> bool {
    let changed = model.notifications.status_message != value;
    model.notifications.status_message = value;
    changed
}

fn changed_only() -> UpdateResult {
    UpdateResult {
        commands: Vec::new(),
        changed: true,
    }
}

fn unchanged() -> UpdateResult {
    UpdateResult {
        commands: Vec::new(),
        changed: false,
    }
}

#[cfg(test)]
mod tests {
    use std::time::{Duration, Instant};

    use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};

    use super::{TuiCommand, TuiEvent, update};
    use crate::application::{AgentView, RuntimeStatus, TuiFleetSnapshot};
    use crate::domain::{Agent, AgentKind};
    use crate::interface::tui::model::{PromptFlow, ScreenState, TuiModel};
    use crate::interface::tui::startup::StartupScreen;

    fn model() -> TuiModel {
        TuiModel::new(StartupScreen::Dashboard, Duration::from_millis(1000))
    }

    fn sample_agent(name: &str) -> AgentView {
        AgentView {
            agent: Agent::new(name.to_string(), AgentKind::Shell, 0),
            runtime_status: RuntimeStatus::Running,
            attached: false,
            working_dir: None,
            git_root: None,
            git_worktree_path: None,
            git_branch: None,
            git_base_ref: None,
        }
    }

    #[test]
    fn started_requests_initial_refresh() {
        let mut model = model();
        let result = update(&mut model, TuiEvent::Started);
        assert_eq!(result.commands, vec![TuiCommand::RefreshAgents]);
    }

    #[test]
    fn rename_startup_waits_for_first_refresh() {
        let mut model = TuiModel::new(StartupScreen::Rename, Duration::from_millis(1000));
        let agent = sample_agent("alpha");
        update(
            &mut model,
            TuiEvent::AgentsRefreshed {
                agents: vec![agent],
                refreshed_at_unix_ms: 100,
                coalesced_updates: 0,
            },
        );
        assert!(matches!(
            model.screen,
            ScreenState::Prompt(PromptFlow::Rename(_))
        ));
    }

    #[test]
    fn search_enter_emits_attach_for_first_match() {
        let mut model = model();
        model.dashboard.agents = vec![sample_agent("alpha"), sample_agent("beta")];
        model.enter_search_prompt();
        if let ScreenState::Prompt(PromptFlow::Search(search)) = &mut model.screen {
            search.draft = "alp".to_string();
        }

        let result = update(
            &mut model,
            TuiEvent::KeyPressed(KeyEvent::new(KeyCode::Enter, KeyModifiers::NONE)),
        );
        assert!(matches!(
            result.commands.first(),
            Some(TuiCommand::AttachAgent {
                from_search_mode: true,
                ..
            })
        ));
    }

    #[test]
    fn dashboard_w_opens_worktree_prompt() {
        let mut model = model();
        let mut agent = sample_agent("alpha");
        agent.git_branch = Some("feature-a".to_string());
        model.dashboard.agents = vec![agent];

        let result = update(
            &mut model,
            TuiEvent::KeyPressed(KeyEvent::new(KeyCode::Char('w'), KeyModifiers::NONE)),
        );

        assert!(result.changed);
        assert!(matches!(
            model.screen,
            ScreenState::Prompt(PromptFlow::Worktree(_))
        ));
    }

    #[test]
    fn worktree_prompt_enter_emits_switch_command() {
        let mut model = model();
        model.dashboard.agents = vec![sample_agent("alpha")];
        model.enter_worktree_prompt_from_selection();
        if let ScreenState::Prompt(PromptFlow::Worktree(prompt)) = &mut model.screen {
            prompt.draft = "feature-b".to_string();
        }

        let result = update(
            &mut model,
            TuiEvent::KeyPressed(KeyEvent::new(KeyCode::Enter, KeyModifiers::NONE)),
        );

        assert!(matches!(
            result.commands.first(),
            Some(TuiCommand::SwitchAgentToWorktreeShell { branch, .. }) if branch == "feature-b"
        ));
    }

    #[test]
    fn worktree_prompt_escape_returns_dashboard() {
        let mut model = model();
        model.dashboard.agents = vec![sample_agent("alpha")];
        model.enter_worktree_prompt_from_selection();

        let result = update(
            &mut model,
            TuiEvent::KeyPressed(KeyEvent::new(KeyCode::Esc, KeyModifiers::NONE)),
        );

        assert!(result.changed);
        assert!(matches!(model.screen, ScreenState::Dashboard));
    }

    #[test]
    fn worktree_switch_success_reuses_attach_handoff() {
        let mut model = model();
        let agent = sample_agent("alpha");
        let agent_id = agent.agent.id();
        let result = update(
            &mut model,
            TuiEvent::AgentWorktreeSwitched {
                id: agent_id.clone(),
                name: "alpha".to_string(),
                branch: "feature-c".to_string(),
                result: Ok(TuiFleetSnapshot {
                    agents: vec![agent],
                    selected_agent_id: Some(agent_id.clone()),
                }),
            },
        );

        assert!(matches!(
            result.commands.first(),
            Some(TuiCommand::AttachAgent {
                id,
                name,
                from_search_mode: false
            }) if id.as_str() == agent_id.as_str() && name == "alpha"
        ));
    }

    #[test]
    fn preview_input_mode_sends_key_commands() {
        let mut model = model();
        model.dashboard.agents = vec![sample_agent("alpha")];
        model.preview.input_mode = true;

        let result = update(
            &mut model,
            TuiEvent::KeyPressed(KeyEvent::new(KeyCode::Char('x'), KeyModifiers::NONE)),
        );

        assert!(matches!(
            result.commands.first(),
            Some(TuiCommand::SendPreviewKey { key, .. }) if key == "x"
        ));
    }

    #[test]
    fn stale_preview_event_is_ignored() {
        let mut model = model();
        model.dashboard.agents = vec![sample_agent("alpha"), sample_agent("beta")];
        model.preview.text = "old preview".to_string();
        let stale_id = model.dashboard.agents[1].agent.id();

        let result = update(
            &mut model,
            TuiEvent::PreviewLoaded {
                agent_id: stale_id,
                output: "new preview".to_string(),
                capture_ms: 3,
            },
        );

        assert!(!result.changed);
        assert_eq!(model.preview.text, "old preview");
    }

    #[test]
    fn tick_requests_preview_when_due() {
        let mut model = model();
        model.dashboard.agents = vec![sample_agent("alpha")];
        let now = Instant::now();
        let result = update(&mut model, TuiEvent::Tick(now));
        assert!(matches!(
            result.commands.first(),
            Some(TuiCommand::RequestPreviewCapture { .. })
        ));
    }

    #[test]
    fn create_result_reconciles_fleet() {
        let mut model = model();
        let agent = sample_agent("alpha");
        let agent_id = agent.agent.id();
        let result = update(
            &mut model,
            TuiEvent::AgentCreated {
                requested_name: "alpha".to_string(),
                agent_kind: AgentKind::Shell,
                create_worktree: false,
                result: Ok(TuiFleetSnapshot {
                    agents: vec![agent],
                    selected_agent_id: Some(agent_id),
                }),
            },
        );
        assert!(result.changed);
        assert_eq!(model.dashboard.agents.len(), 1);
        assert!(model.notifications.status_message.is_some());
    }
}
