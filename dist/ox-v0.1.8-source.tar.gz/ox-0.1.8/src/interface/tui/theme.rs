use ratatui::style::{Color, Modifier, Style};

use crate::interface::tui::view::Tone;

pub(super) fn app_border() -> Style {
    Style::default().fg(Color::Rgb(72, 76, 86))
}

pub(super) fn title() -> Style {
    Style::default()
        .fg(Color::Rgb(229, 231, 235))
        .add_modifier(Modifier::BOLD)
}

pub(super) fn primary() -> Style {
    Style::default().fg(Color::Rgb(229, 231, 235))
}

pub(super) fn muted() -> Style {
    Style::default().fg(Color::Rgb(138, 145, 156))
}

pub(super) fn selection() -> Style {
    Style::default()
        .bg(Color::Rgb(28, 32, 38))
        .fg(Color::Rgb(239, 241, 245))
}

pub(super) fn tone(tone: Tone) -> Style {
    let color = match tone {
        Tone::Primary => Color::Rgb(229, 231, 235),
        Tone::Muted => Color::Rgb(138, 145, 156),
        Tone::Accent => Color::Rgb(125, 173, 224),
        Tone::Success => Color::Rgb(138, 190, 140),
        Tone::Warning => Color::Rgb(214, 176, 96),
        Tone::Danger => Color::Rgb(214, 112, 112),
    };
    Style::default().fg(color)
}
