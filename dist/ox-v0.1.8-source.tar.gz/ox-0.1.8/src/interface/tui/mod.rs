use std::io;
use std::sync::Arc;

use crate::application::TuiApi;

#[path = "state/activity.rs"]
mod activity;
mod commands;
mod events;
mod filter;
mod format;
mod messages;
mod model;
pub(crate) mod picker;
mod runtime;
#[path = "state/startup.rs"]
mod startup;
mod theme;
mod update;
mod view;
mod widgets;
mod worker;

pub(crate) use startup::StartupScreen;

/// Run the `ox` TUI loop.
///
/// # Errors
///
/// Returns an error if terminal setup, drawing, event polling, or terminal
/// restoration fails.
pub fn run(app: &Arc<dyn TuiApi>, startup: StartupScreen) -> io::Result<()> {
    runtime::run(app, startup)
}
