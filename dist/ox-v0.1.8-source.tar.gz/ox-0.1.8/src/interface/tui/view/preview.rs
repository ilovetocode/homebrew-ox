use crate::interface::tui::format::{compact_age_from, compact_path};
use crate::interface::tui::model::TuiModel;

use super::rows::AgentRowView;

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) struct PreviewView {
    pub(in crate::interface::tui) title: String,
    pub(in crate::interface::tui) text: String,
    pub(in crate::interface::tui) meta: String,
    pub(in crate::interface::tui) scroll_offset: u16,
    pub(in crate::interface::tui) follow_tail: bool,
    pub(in crate::interface::tui) input_mode: bool,
}

pub(super) fn present_preview(model: &TuiModel, rows: &[AgentRowView]) -> PreviewView {
    let preview_title = model
        .active_agent_name()
        .map_or_else(|| "Preview".to_string(), |name| format!("Preview  {name}"));
    let selected_detail = model
        .active_agent_index()
        .and_then(|index| rows.get(index).map(|row| row.detail.clone()));
    let preview_meta = model.active_agent().map_or_else(
        || "No agent selected".to_string(),
        |agent| {
            let preview_age = compact_age_from(
                model.dashboard.last_refresh_unix_ms,
                model.preview.last_changed_unix_ms,
            );
            let mut meta = format!(
                "{}  {}  {}  preview {}",
                agent.agent.kind().as_str(),
                agent.git_branch.clone().unwrap_or_else(|| "-".to_string()),
                agent
                    .git_worktree_path
                    .as_deref()
                    .map_or_else(|| "-".to_string(), compact_path),
                preview_age
            );
            if let Some(detail) = selected_detail.as_deref() {
                meta.push_str("  ");
                meta.push_str(detail);
            }
            meta
        },
    );

    PreviewView {
        title: preview_title,
        text: if rows.is_empty() {
            "(no agent selected)".to_string()
        } else if model.preview.text.trim().is_empty() {
            "(pane not available)".to_string()
        } else {
            model.preview.text.clone()
        },
        meta: preview_meta,
        scroll_offset: model.preview.scroll_offset,
        follow_tail: model.preview.follow_tail,
        input_mode: model.preview.input_mode,
    }
}
