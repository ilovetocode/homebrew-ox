use crate::application::RuntimeStatus;
use crate::interface::presentation::agent_kind::agent_kind_label;
use crate::interface::presentation::agents::compact_agent_repo;
use crate::interface::tui::format::{compact_age_from, compact_path};
use crate::interface::tui::model::TuiModel;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) enum Tone {
    Primary,
    Muted,
    Accent,
    Success,
    Warning,
    Danger,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) struct AgentRowView {
    pub(in crate::interface::tui) name: String,
    pub(in crate::interface::tui) kind: String,
    pub(in crate::interface::tui) runtime_label: String,
    pub(in crate::interface::tui) runtime_tone: Tone,
    pub(in crate::interface::tui) productivity_label: String,
    pub(in crate::interface::tui) productivity_tone: Tone,
    pub(in crate::interface::tui) activity_token: String,
    pub(in crate::interface::tui) git_summary: String,
    pub(in crate::interface::tui) git_tone: Tone,
    pub(in crate::interface::tui) branch: String,
    pub(in crate::interface::tui) path: String,
    pub(in crate::interface::tui) detail: String,
    pub(in crate::interface::tui) is_selected: bool,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) struct FleetSummaryView {
    pub(in crate::interface::tui) total: usize,
    pub(in crate::interface::tui) running: usize,
    pub(in crate::interface::tui) waiting: usize,
    pub(in crate::interface::tui) unknown: usize,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) struct StatusMetricView {
    pub(in crate::interface::tui) label: String,
    pub(in crate::interface::tui) value: String,
    pub(in crate::interface::tui) tone: Tone,
}

pub(super) fn present_rows(model: &TuiModel) -> Vec<AgentRowView> {
    let active_index = model.active_agent_index();
    let visible_indices = model.visible_agent_indices();
    let now_unix_ms = model.dashboard.last_refresh_unix_ms;

    visible_indices
        .into_iter()
        .map(|index| present_row(model, index, active_index, now_unix_ms))
        .collect()
}

pub(super) fn fleet_summary_from_agents(model: &TuiModel) -> FleetSummaryView {
    let rows = model
        .dashboard
        .agents
        .iter()
        .enumerate()
        .map(|(index, _)| {
            present_row(
                model,
                index,
                model.active_agent_index(),
                model.dashboard.last_refresh_unix_ms,
            )
        })
        .collect::<Vec<_>>();
    build_fleet_summary(&rows)
}

pub(super) fn status_metrics(model: &TuiModel, fleet: &FleetSummaryView) -> Vec<StatusMetricView> {
    let mut metrics = Vec::new();
    metrics.push(StatusMetricView {
        label: "tmux".to_string(),
        value: model
            .status
            .report
            .as_ref()
            .map_or("--", |report| {
                if report.tmux_available {
                    "ok"
                } else {
                    "missing"
                }
            })
            .to_string(),
        tone: if model
            .status
            .report
            .as_ref()
            .is_some_and(|report| report.tmux_available)
        {
            Tone::Success
        } else {
            Tone::Danger
        },
    });
    metrics.push(StatusMetricView {
        label: "fleet".to_string(),
        value: format!(
            "{} total  {} running  {} waiting  {} unknown",
            fleet.total, fleet.running, fleet.waiting, fleet.unknown
        ),
        tone: Tone::Primary,
    });
    if let Some(report) = &model.status.report {
        metrics.push(StatusMetricView {
            label: "sessions".to_string(),
            value: format!(
                "{} attached  {} managed",
                report.attached_agent_count, report.agent_count
            ),
            tone: Tone::Muted,
        });
        metrics.push(StatusMetricView {
            label: "config".to_string(),
            value: compact_path(&report.managed_tmux_conf),
            tone: if report.managed_tmux_conf_in_sync {
                Tone::Muted
            } else {
                Tone::Warning
            },
        });
    }
    metrics
}

fn present_row(
    model: &TuiModel,
    index: usize,
    active_index: Option<usize>,
    now_unix_ms: u128,
) -> AgentRowView {
    let agent = &model.dashboard.agents[index];
    let activity = model.dashboard.activity.get(agent.agent.id().as_str());
    let productivity = derive_productivity(agent.runtime_status, activity, now_unix_ms);
    let branch = agent.git_branch.clone().unwrap_or_else(|| "-".to_string());
    let path = compact_agent_repo(agent);
    let git_summary = format_git_summary(agent);
    let detail = format_detail(agent, activity, now_unix_ms);

    AgentRowView {
        name: if agent.attached {
            format!("@ {}", agent.agent.display_name())
        } else {
            agent.agent.display_name().to_string()
        },
        kind: agent_kind_label(agent.agent.kind()).to_string(),
        runtime_label: runtime_label(agent.runtime_status).to_string(),
        runtime_tone: runtime_tone(agent.runtime_status),
        productivity_label: productivity.label.to_string(),
        productivity_tone: productivity.tone,
        activity_token: productivity.activity_token,
        git_summary,
        git_tone: Tone::Muted,
        branch,
        path,
        detail,
        is_selected: Some(index) == active_index,
    }
}

fn runtime_label(status: RuntimeStatus) -> &'static str {
    match status {
        RuntimeStatus::Running => "RUN",
        RuntimeStatus::Waiting => "WAIT",
        RuntimeStatus::Unknown => "UNK",
    }
}

fn runtime_tone(status: RuntimeStatus) -> Tone {
    match status {
        RuntimeStatus::Running => Tone::Accent,
        RuntimeStatus::Waiting => Tone::Muted,
        RuntimeStatus::Unknown => Tone::Warning,
    }
}

fn format_git_summary(agent: &crate::application::AgentView) -> String {
    if agent.git_worktree_path.is_none() {
        return "--".to_string();
    }

    if let Some(base_ref) = agent.git_base_ref.as_deref() {
        return format!("base {base_ref}");
    }
    "tracked".to_string()
}

fn format_detail(
    agent: &crate::application::AgentView,
    activity: Option<&crate::interface::tui::activity::ActivityEntry>,
    now_unix_ms: u128,
) -> String {
    let kind = agent_kind_label(agent.agent.kind());
    let age = activity.map_or_else(
        || "--".to_string(),
        |entry| compact_age_from(now_unix_ms, entry.last_changed_unix_ms),
    );
    match (&agent.git_base_ref, &agent.git_worktree_path) {
        (Some(base_ref), Some(_)) => format!("{kind}  base {base_ref}  changed {age}"),
        (None, Some(_)) => format!("{kind}  worktree  changed {age}"),
        _ => format!("{kind}  changed {age}"),
    }
}

struct ProductivityView {
    label: &'static str,
    tone: Tone,
    activity_token: String,
}

fn derive_productivity(
    runtime_status: RuntimeStatus,
    activity: Option<&crate::interface::tui::activity::ActivityEntry>,
    now_unix_ms: u128,
) -> ProductivityView {
    let age = activity.map_or_else(
        || "--".to_string(),
        |entry| compact_age_from(now_unix_ms, entry.last_changed_unix_ms),
    );

    if runtime_status == RuntimeStatus::Unknown {
        return ProductivityView {
            label: "UNK",
            tone: Tone::Warning,
            activity_token: "--".to_string(),
        };
    }

    let stale = activity
        .is_some_and(|entry| now_unix_ms.saturating_sub(entry.last_changed_unix_ms) >= 300_000);
    if runtime_status == RuntimeStatus::Running && !stale {
        return ProductivityView {
            label: "ACT",
            tone: Tone::Accent,
            activity_token: format!("act {age}"),
        };
    }
    if runtime_status == RuntimeStatus::Running && stale {
        return ProductivityView {
            label: "DRIFT",
            tone: Tone::Warning,
            activity_token: format!("idle {age}"),
        };
    }

    ProductivityView {
        label: "WAIT",
        tone: Tone::Muted,
        activity_token: age,
    }
}

fn build_fleet_summary(rows: &[AgentRowView]) -> FleetSummaryView {
    let running = rows.iter().filter(|row| row.runtime_label == "RUN").count();
    let waiting = rows
        .iter()
        .filter(|row| row.runtime_label == "WAIT")
        .count();
    let unknown = rows.iter().filter(|row| row.runtime_label == "UNK").count();
    FleetSummaryView {
        total: rows.len(),
        running,
        waiting,
        unknown,
    }
}

#[cfg(test)]
mod tests {
    use super::{fleet_summary_from_agents, present_rows};
    use crate::application::{AgentView, RuntimeStatus};
    use crate::domain::{Agent, AgentKind};
    use crate::interface::tui::model::TuiModel;
    use crate::interface::tui::startup::StartupScreen;

    #[test]
    fn present_rows_shortens_worktree_paths() {
        let mut model = TuiModel::new(StartupScreen::Dashboard, std::time::Duration::from_secs(1));
        model.dashboard.agents = vec![AgentView {
            agent: Agent::new("alpha".to_string(), AgentKind::Codex, 0),
            runtime_status: RuntimeStatus::Running,
            attached: false,
            working_dir: None,
            git_root: None,
            git_worktree_path: Some("/tmp/repo/.worktrees/feature-ui".to_string()),
            git_branch: Some("feature/ui".to_string()),
            git_base_ref: Some("main".to_string()),
        }];
        model.dashboard.last_refresh_unix_ms = 1000;

        let rows = present_rows(&model);
        assert_eq!(rows[0].path, "repo/.worktrees/feature-ui");
    }

    #[test]
    fn fleet_summary_counts_runtime_statuses() {
        let mut model = TuiModel::new(StartupScreen::Dashboard, std::time::Duration::from_secs(1));
        model.dashboard.agents = vec![
            AgentView {
                agent: Agent::new("alpha".to_string(), AgentKind::Codex, 0),
                runtime_status: RuntimeStatus::Running,
                attached: false,
                working_dir: None,
                git_root: None,
                git_worktree_path: None,
                git_branch: None,
                git_base_ref: None,
            },
            AgentView {
                agent: Agent::new("beta".to_string(), AgentKind::Shell, 1),
                runtime_status: RuntimeStatus::Waiting,
                attached: false,
                working_dir: None,
                git_root: None,
                git_worktree_path: None,
                git_branch: None,
                git_base_ref: None,
            },
            AgentView {
                agent: Agent::new("gamma".to_string(), AgentKind::Claude, 2),
                runtime_status: RuntimeStatus::Unknown,
                attached: false,
                working_dir: None,
                git_root: None,
                git_worktree_path: None,
                git_branch: None,
                git_base_ref: None,
            },
        ];

        let fleet = fleet_summary_from_agents(&model);
        assert_eq!(fleet.total, 3);
        assert_eq!(fleet.running, 1);
        assert_eq!(fleet.waiting, 1);
        assert_eq!(fleet.unknown, 1);
    }
}
