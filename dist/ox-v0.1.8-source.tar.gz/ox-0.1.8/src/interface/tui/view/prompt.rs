use super::NotificationView;
use super::rows::{AgentRowView, present_rows};
use crate::interface::tui::model::{NewAgentField, PromptFlow, ScreenState, TuiModel};

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) struct PromptScreenView {
    pub(in crate::interface::tui) title: String,
    pub(in crate::interface::tui) body: PromptBodyView,
    pub(in crate::interface::tui) footer_hint: String,
    pub(in crate::interface::tui) notifications: NotificationView,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) enum PromptBodyView {
    Search {
        query: String,
        rows: Vec<AgentRowView>,
    },
    NewAgent {
        fields: Vec<FormFieldView>,
    },
    Rename {
        fields: Vec<FormFieldView>,
    },
    Worktree {
        fields: Vec<FormFieldView>,
    },
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) struct FormFieldView {
    pub(in crate::interface::tui) label: String,
    pub(in crate::interface::tui) value: String,
    pub(in crate::interface::tui) focused: bool,
}

pub(super) fn present_prompt(model: &TuiModel) -> PromptScreenView {
    let ScreenState::Prompt(prompt) = &model.screen else {
        unreachable!("prompt presenter requires prompt screen")
    };

    match prompt {
        PromptFlow::Search(search) => PromptScreenView {
            title: "Search Agents".to_string(),
            body: PromptBodyView::Search {
                query: search.draft.clone(),
                rows: present_rows(model),
            },
            footer_hint: "type filter  Enter attach first  Esc back".to_string(),
            notifications: NotificationView::from_model(model),
        },
        PromptFlow::NewAgent(form) => PromptScreenView {
            title: "New Agent".to_string(),
            body: PromptBodyView::NewAgent {
                fields: vec![
                    FormFieldView {
                        label: "Name".to_string(),
                        value: form.name.clone(),
                        focused: form.focused_field == NewAgentField::Name,
                    },
                    FormFieldView {
                        label: "Kind".to_string(),
                        value: [
                            format_option("shell", form.agent_kind.as_str() == "shell"),
                            format_option("codex", form.agent_kind.as_str() == "codex"),
                            format_option("opencode", form.agent_kind.as_str() == "opencode"),
                            format_option("claude", form.agent_kind.as_str() == "claude"),
                        ]
                        .join("  "),
                        focused: form.focused_field == NewAgentField::Kind,
                    },
                    FormFieldView {
                        label: "Worktree".to_string(),
                        value: if form.create_worktree {
                            "on".to_string()
                        } else {
                            "off".to_string()
                        },
                        focused: form.focused_field == NewAgentField::Worktree,
                    },
                    FormFieldView {
                        label: "Repo Root".to_string(),
                        value: form
                            .repo_root
                            .clone()
                            .unwrap_or_else(|| "(current repo)".to_string()),
                        focused: form.focused_field == NewAgentField::RepoRoot,
                    },
                ],
            },
            footer_hint:
                "Tab/Shift-Tab focus  Left/Right change  Ctrl-P repo root  Enter create  Esc cancel"
                    .to_string(),
            notifications: NotificationView::from_model(model),
        },
        PromptFlow::Rename(rename) => PromptScreenView {
            title: format!("Rename  {}", rename.old_name),
            body: PromptBodyView::Rename {
                fields: vec![
                    FormFieldView {
                        label: "Current".to_string(),
                        value: rename.old_name.clone(),
                        focused: false,
                    },
                    FormFieldView {
                        label: "New Name".to_string(),
                        value: rename.draft.clone(),
                        focused: true,
                    },
                ],
            },
            footer_hint: "Enter rename  Esc cancel".to_string(),
            notifications: NotificationView::from_model(model),
        },
        PromptFlow::Worktree(worktree) => PromptScreenView {
            title: format!("Worktree  {}", worktree.agent_name),
            body: PromptBodyView::Worktree {
                fields: vec![
                    FormFieldView {
                        label: "Agent".to_string(),
                        value: worktree.agent_name.clone(),
                        focused: false,
                    },
                    FormFieldView {
                        label: "Branch".to_string(),
                        value: worktree.draft.clone(),
                        focused: true,
                    },
                ],
            },
            footer_hint: "Enter recreate+attach  Esc cancel".to_string(),
            notifications: NotificationView::from_model(model),
        },
    }
}

fn format_option(label: &str, active: bool) -> String {
    if active {
        format!("[{label}]")
    } else {
        label.to_string()
    }
}
