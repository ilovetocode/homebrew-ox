use crate::interface::tui::model::{OverlayState, TuiModel};

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) struct PickerOverlayView {
    pub(in crate::interface::tui) title: String,
    pub(in crate::interface::tui) query: String,
    pub(in crate::interface::tui) rows: Vec<(String, String)>,
    pub(in crate::interface::tui) selected_index: usize,
    pub(in crate::interface::tui) total_rows: usize,
    pub(in crate::interface::tui) empty_message: String,
    pub(in crate::interface::tui) recompute_ms: u64,
}

const PICKER_MAX_VISIBLE_ROWS: usize = 12;

pub(super) fn present_picker(model: &TuiModel) -> Option<PickerOverlayView> {
    let Some(OverlayState::Picker(picker)) = &model.overlay else {
        return None;
    };
    let total_rows = picker.filtered_indices.len();
    let window_start = picker_window_start(total_rows, picker.selected_filtered_index);
    Some(PickerOverlayView {
        title: picker.title.clone(),
        query: picker.query.clone(),
        total_rows,
        rows: picker
            .filtered_indices
            .iter()
            .skip(window_start)
            .take(PICKER_MAX_VISIBLE_ROWS)
            .filter_map(|index| picker.items.get(*index))
            .map(|item| (item.label.clone(), item.detail.clone()))
            .collect(),
        selected_index: picker.selected_filtered_index.saturating_sub(window_start),
        empty_message: picker.empty_message.clone(),
        recompute_ms: picker.last_recompute_ms(),
    })
}

fn picker_window_start(total_rows: usize, selected_index: usize) -> usize {
    selected_index
        .saturating_sub(PICKER_MAX_VISIBLE_ROWS / 2)
        .min(total_rows.saturating_sub(PICKER_MAX_VISIBLE_ROWS))
}
