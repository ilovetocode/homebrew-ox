mod dashboard;
mod picker;
mod preview;
mod prompt;
mod rows;
mod status;

pub(in crate::interface::tui) use dashboard::DashboardScreenView;
pub(in crate::interface::tui) use picker::PickerOverlayView;
pub(in crate::interface::tui) use prompt::{PromptBodyView, PromptScreenView};
pub(in crate::interface::tui) use rows::{AgentRowView, Tone};
pub(in crate::interface::tui) use status::StatusScreenView;

use crate::interface::tui::model::{ScreenState, TuiModel};

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) struct NotificationView {
    pub(in crate::interface::tui) status_message: Option<String>,
    pub(in crate::interface::tui) error_message: Option<String>,
}

impl NotificationView {
    fn from_model(model: &TuiModel) -> Self {
        Self {
            status_message: model.notifications.status_message.clone(),
            error_message: model.notifications.error_message.clone(),
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) struct RenderTree {
    pub(in crate::interface::tui) screen: ScreenView,
    pub(in crate::interface::tui) overlay: Option<PickerOverlayView>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) enum ScreenView {
    Dashboard(DashboardScreenView),
    Status(StatusScreenView),
    Prompt(PromptScreenView),
}

pub(super) fn present(model: &TuiModel) -> RenderTree {
    let screen = match &model.screen {
        ScreenState::Dashboard => ScreenView::Dashboard(dashboard::present_dashboard(model)),
        ScreenState::Status => ScreenView::Status(status::present_status(model)),
        ScreenState::Prompt(_) => ScreenView::Prompt(prompt::present_prompt(model)),
    };
    RenderTree {
        screen,
        overlay: picker::present_picker(model),
    }
}
