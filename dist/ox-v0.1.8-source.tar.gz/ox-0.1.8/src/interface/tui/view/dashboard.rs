use super::NotificationView;
use super::preview::{PreviewView, present_preview};
use super::rows::{AgentRowView, FleetSummaryView, fleet_summary_from_agents, present_rows};
use crate::interface::tui::model::TuiModel;

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) struct DashboardScreenView {
    pub(in crate::interface::tui) rows: Vec<AgentRowView>,
    pub(in crate::interface::tui) fleet_summary: FleetSummaryView,
    pub(in crate::interface::tui) preview: PreviewView,
    pub(in crate::interface::tui) footer_hint: String,
    pub(in crate::interface::tui) notifications: NotificationView,
}

pub(super) fn present_dashboard(model: &TuiModel) -> DashboardScreenView {
    let rows = present_rows(model);
    DashboardScreenView {
        fleet_summary: fleet_summary_from_agents(model),
        preview: present_preview(model, &rows),
        rows,
        footer_hint:
            "j/k move  Enter attach  / search  n new  r rename  w worktree  i input  q quit"
                .to_string(),
        notifications: NotificationView::from_model(model),
    }
}
