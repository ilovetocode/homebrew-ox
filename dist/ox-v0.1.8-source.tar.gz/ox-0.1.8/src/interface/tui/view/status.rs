use super::NotificationView;
use super::rows::{FleetSummaryView, StatusMetricView, fleet_summary_from_agents, status_metrics};
use crate::interface::tui::model::TuiModel;

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::interface::tui) struct StatusScreenView {
    pub(in crate::interface::tui) metrics: Vec<StatusMetricView>,
    pub(in crate::interface::tui) footer_hint: String,
    pub(in crate::interface::tui) notifications: NotificationView,
}

pub(super) fn present_status(model: &TuiModel) -> StatusScreenView {
    let fleet: FleetSummaryView = fleet_summary_from_agents(model);
    StatusScreenView {
        metrics: status_metrics(model, &fleet),
        footer_hint: "q/Esc back  Ctrl-C quit".to_string(),
        notifications: NotificationView::from_model(model),
    }
}
