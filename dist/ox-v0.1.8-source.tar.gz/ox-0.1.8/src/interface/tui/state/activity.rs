use std::collections::HashMap;

use crate::application::AgentView;

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(in crate::interface::tui) struct ActivityEntry {
    pub(in crate::interface::tui) last_seen_unix_ms: u128,
    pub(in crate::interface::tui) last_changed_unix_ms: u128,
    fingerprint: String,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(in crate::interface::tui) struct ActivityLedger {
    entries: HashMap<String, ActivityEntry>,
}

impl ActivityLedger {
    pub(in crate::interface::tui) fn update(
        &mut self,
        agents: &[AgentView],
        refreshed_at_unix_ms: u128,
    ) {
        let active_ids = agents
            .iter()
            .map(|agent| agent.agent.id().as_str().to_string())
            .collect::<Vec<_>>();
        self.entries
            .retain(|agent_id, _| active_ids.iter().any(|active| active == agent_id));

        for agent in agents {
            let agent_id = agent.agent.id().as_str().to_string();
            let fingerprint = build_fingerprint(agent);
            let entry = self
                .entries
                .entry(agent_id)
                .or_insert_with(|| ActivityEntry {
                    last_seen_unix_ms: refreshed_at_unix_ms,
                    last_changed_unix_ms: refreshed_at_unix_ms,
                    fingerprint: fingerprint.clone(),
                });
            entry.last_seen_unix_ms = refreshed_at_unix_ms;
            if entry.fingerprint != fingerprint {
                entry.last_changed_unix_ms = refreshed_at_unix_ms;
                entry.fingerprint = fingerprint;
            }
        }
    }

    pub(in crate::interface::tui) fn get(&self, agent_id: &str) -> Option<&ActivityEntry> {
        self.entries.get(agent_id)
    }
}

fn build_fingerprint(agent: &AgentView) -> String {
    format!(
        "{:?}|{:?}|{}|{}|{}",
        agent.runtime_status,
        agent.agent.kind(),
        agent.git_branch.as_deref().unwrap_or_default(),
        agent.git_worktree_path.as_deref().unwrap_or_default(),
        agent.git_base_ref.as_deref().unwrap_or_default()
    )
}

#[cfg(test)]
mod tests {
    use super::ActivityLedger;
    use crate::application::{AgentView, RuntimeStatus};
    use crate::domain::{Agent, AgentKind};

    fn sample_agent() -> AgentView {
        AgentView {
            agent: Agent::new("alpha".to_string(), AgentKind::Codex, 0),
            runtime_status: RuntimeStatus::Running,
            attached: false,
            working_dir: None,
            git_root: None,
            git_worktree_path: Some("/tmp/repo/.worktrees/alpha".to_string()),
            git_branch: Some("feature/alpha".to_string()),
            git_base_ref: Some("main".to_string()),
        }
    }

    #[test]
    fn ledger_updates_last_changed_only_on_material_changes() {
        let agent = sample_agent();
        let agent_id = agent.agent.id().as_str().to_string();
        let mut ledger = ActivityLedger::default();

        ledger.update(std::slice::from_ref(&agent), 10);
        let first = ledger.get(&agent_id).cloned();
        assert!(first.is_some(), "missing initial activity entry");
        let first = first.unwrap_or_default();

        ledger.update(std::slice::from_ref(&agent), 20);
        let second = ledger.get(&agent_id).cloned();
        assert!(second.is_some(), "missing second activity entry");
        let second = second.unwrap_or_default();
        assert_eq!(second.last_changed_unix_ms, first.last_changed_unix_ms);

        let mut changed_agent = agent;
        changed_agent.git_base_ref = Some("develop".to_string());
        ledger.update(&[changed_agent], 30);
        let third = ledger.get(&agent_id).cloned();
        assert!(third.is_some(), "missing third activity entry");
        let third = third.unwrap_or_default();
        assert_eq!(third.last_changed_unix_ms, 30);
    }
}
