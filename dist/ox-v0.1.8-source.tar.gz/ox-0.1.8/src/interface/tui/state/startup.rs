/// Startup screen selected by CLI before entering the TUI loop.
#[derive(Clone, Copy, PartialEq, Eq)]
pub(crate) enum StartupScreen {
    Dashboard,
    Status,
    Search,
    NewAgent,
    Rename,
}
