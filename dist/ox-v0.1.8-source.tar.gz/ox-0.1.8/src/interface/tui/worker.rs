use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc::{Receiver, SyncSender, TrySendError};
use std::sync::{Mutex, MutexGuard};
use std::thread::JoinHandle;

/// Shared lifecycle handle for a background worker thread.
pub(super) struct BackgroundWorker {
    shutdown: Arc<AtomicBool>,
    handle: Option<JoinHandle<()>>,
}

impl BackgroundWorker {
    pub(super) fn new(shutdown: Arc<AtomicBool>, handle: JoinHandle<()>) -> Self {
        Self {
            shutdown,
            handle: Some(handle),
        }
    }

    pub(super) fn stop(mut self) {
        self.shutdown.store(true, Ordering::Relaxed);
        if let Some(handle) = self.handle.take() {
            let _ = handle.join();
        }
    }
}

/// Shared storage for "latest wins" background worker payloads.
pub(super) struct LatestMessage<T> {
    inner: Arc<Mutex<Option<T>>>,
}

impl<T> LatestMessage<T> {
    pub(super) fn new() -> Self {
        Self {
            inner: Arc::new(Mutex::new(None)),
        }
    }

    pub(super) fn worker_handle(&self) -> Self {
        Self {
            inner: Arc::clone(&self.inner),
        }
    }

    pub(super) fn replace(&self, message: T) {
        *self.lock() = Some(message);
    }

    pub(super) fn take_if_signaled(&self, signal_receiver: &Receiver<()>) -> Option<T> {
        let mut received_signal = false;
        while signal_receiver.try_recv().is_ok() {
            received_signal = true;
        }
        if !received_signal {
            return None;
        }
        self.lock().take()
    }

    fn lock(&self) -> MutexGuard<'_, Option<T>> {
        self.inner
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
    }
}

pub(super) fn try_signal(sender: &SyncSender<()>) -> Result<(), TrySendError<()>> {
    sender.try_send(())
}
