use crate::application::{AgentKind, CreateAgentRequest};
use crate::domain::AgentId;

/// Side effects requested by the pure TUI update function.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) enum TuiCommand {
    RefreshAgents,
    LoadStatus,
    LoadRepoRootPicker,
    CreateAgent {
        request: CreateAgentRequest,
        requested_name: String,
        agent_kind: AgentKind,
        create_worktree: bool,
    },
    RenameAgent {
        id: AgentId,
        old_name: String,
        new_name: String,
    },
    DeleteAgent {
        id: AgentId,
        name: String,
    },
    SwitchAgentToWorktreeShell {
        id: AgentId,
        name: String,
        branch: String,
    },
    AttachAgent {
        id: AgentId,
        name: String,
        from_search_mode: bool,
    },
    RequestPreviewCapture {
        id: AgentId,
        lines: u16,
    },
    SendPreviewKey {
        id: AgentId,
        key: String,
    },
    Quit,
}
