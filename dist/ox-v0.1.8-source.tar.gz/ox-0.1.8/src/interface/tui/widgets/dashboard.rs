use ratatui::Frame;
use ratatui::layout::{Constraint, Direction, Layout, Margin};
use ratatui::text::{Line, Span, Text};
use ratatui::widgets::{Block, Borders, Paragraph};

use super::super::theme;
use super::super::view::DashboardScreenView;
use super::{agent_rows_lines, fit_cell};

pub(super) fn draw(frame: &mut Frame, screen: &DashboardScreenView) {
    let area = frame.area();
    frame.render_widget(
        Block::default()
            .title(" ox ")
            .borders(Borders::ALL)
            .border_style(theme::app_border()),
        area,
    );

    let inner = area.inner(Margin {
        vertical: 1,
        horizontal: 1,
    });
    let vertical = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Length(1),
            Constraint::Min(8),
            Constraint::Length(2),
            Constraint::Length(1),
        ])
        .split(inner);

    frame.render_widget(Paragraph::new(header_line(screen)), vertical[0]);

    let body = if inner.width < 110 {
        Layout::default()
            .direction(Direction::Vertical)
            .constraints([Constraint::Percentage(48), Constraint::Percentage(52)])
            .split(vertical[1])
    } else {
        Layout::default()
            .direction(Direction::Horizontal)
            .constraints([Constraint::Percentage(60), Constraint::Percentage(40)])
            .split(vertical[1])
    };

    frame.render_widget(
        Paragraph::new(Text::from(agent_rows_lines(
            &screen.rows,
            body[0].width.saturating_sub(1) as usize,
        ))),
        body[0],
    );
    frame.render_widget(
        Paragraph::new(screen.preview.text.clone())
            .block(
                Block::default()
                    .title(screen.preview.title.as_str())
                    .borders(Borders::TOP)
                    .border_style(theme::app_border()),
            )
            .scroll((preview_scroll(screen, body[1].height.saturating_sub(2)), 0)),
        body[1],
    );

    frame.render_widget(
        Paragraph::new(Line::from(vec![
            Span::styled(screen.preview.meta.clone(), theme::muted()),
            Span::raw("  "),
            Span::styled(preview_mode(screen), theme::muted()),
        ])),
        vertical[2],
    );

    frame.render_widget(
        Paragraph::new(footer_line(screen)).style(theme::muted()),
        vertical[3],
    );
}

fn header_line(screen: &DashboardScreenView) -> Line<'static> {
    Line::from(vec![
        Span::styled("Agents", theme::title()),
        Span::raw("  "),
        Span::styled(
            format!(
                "{} total  {} running  {} waiting  {} unknown",
                screen.fleet_summary.total,
                screen.fleet_summary.running,
                screen.fleet_summary.waiting,
                screen.fleet_summary.unknown
            ),
            theme::muted(),
        ),
    ])
}

fn preview_scroll(screen: &DashboardScreenView, height: u16) -> u16 {
    if screen.preview.follow_tail {
        let lines = u16::try_from(screen.preview.text.lines().count()).unwrap_or(u16::MAX);
        lines.saturating_sub(height)
    } else {
        screen.preview.scroll_offset
    }
}

fn preview_mode(screen: &DashboardScreenView) -> String {
    let input = if screen.preview.input_mode {
        "input"
    } else {
        "read"
    };
    let tail = if screen.preview.follow_tail {
        "follow"
    } else {
        "scrolled"
    };
    format!("{input}  {tail}")
}

fn footer_line(screen: &DashboardScreenView) -> String {
    match (
        &screen.notifications.error_message,
        &screen.notifications.status_message,
    ) {
        (Some(error), _) => fit_cell(error, 120),
        (None, Some(status)) => format!("{}  {}", screen.footer_hint, fit_cell(status, 80)),
        (None, None) => screen.footer_hint.clone(),
    }
}
