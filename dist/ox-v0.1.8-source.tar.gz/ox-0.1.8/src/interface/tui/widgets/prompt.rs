use ratatui::Frame;
use ratatui::layout::{Constraint, Direction, Layout, Margin};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, Borders, Paragraph};

use super::super::theme;
use super::super::view::{PromptBodyView, PromptScreenView};
use super::agent_rows_lines;

pub(super) fn draw(frame: &mut Frame, screen: &PromptScreenView) {
    let area = frame.area();
    frame.render_widget(
        Block::default()
            .title(" ox ")
            .borders(Borders::ALL)
            .border_style(theme::app_border()),
        area,
    );
    let inner = area.inner(Margin {
        vertical: 1,
        horizontal: 1,
    });
    let sections = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Length(1),
            Constraint::Min(5),
            Constraint::Length(1),
        ])
        .split(inner);

    frame.render_widget(
        Paragraph::new(screen.title.clone()).style(theme::title()),
        sections[0],
    );
    frame.render_widget(Paragraph::new(prompt_body(screen)), sections[1]);
    frame.render_widget(
        Paragraph::new(
            screen
                .notifications
                .status_message
                .clone()
                .unwrap_or_else(|| screen.footer_hint.clone()),
        )
        .style(theme::muted()),
        sections[2],
    );
}

fn prompt_body(screen: &PromptScreenView) -> Vec<Line<'static>> {
    match &screen.body {
        PromptBodyView::Search { query, rows } => {
            let mut lines = vec![Line::from(vec![
                Span::styled("Query  ", theme::muted()),
                Span::styled(query.clone(), theme::primary()),
            ])];
            lines.push(Line::default());
            lines.extend(agent_rows_lines(rows.as_slice(), 100));
            lines
        }
        PromptBodyView::NewAgent { fields }
        | PromptBodyView::Rename { fields }
        | PromptBodyView::Worktree { fields } => fields
            .iter()
            .map(|field| field_line(&field.label, &field.value, field.focused))
            .collect(),
    }
}

fn field_line(label: &str, value: &str, focused: bool) -> Line<'static> {
    let value_style = if focused {
        theme::selection()
    } else {
        theme::primary()
    };
    Line::from(vec![
        Span::styled(format!("{label:<10}"), theme::muted()),
        Span::styled(value.to_string(), value_style),
    ])
}
