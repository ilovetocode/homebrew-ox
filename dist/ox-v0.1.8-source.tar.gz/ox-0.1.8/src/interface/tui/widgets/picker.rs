use ratatui::Frame;
use ratatui::layout::{Constraint, Direction, Layout, Margin, Rect};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, Borders, Clear, Paragraph};

use super::super::theme;
use super::super::view::PickerOverlayView;

pub(super) fn draw_overlay(frame: &mut Frame, picker: &PickerOverlayView) {
    let area = centered_rect(frame.area());
    frame.render_widget(Clear, area);
    frame.render_widget(
        Block::default()
            .title(picker.title.as_str())
            .borders(Borders::ALL)
            .border_style(theme::app_border()),
        area,
    );
    let inner = area.inner(Margin {
        vertical: 1,
        horizontal: 1,
    });
    let sections = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Length(1),
            Constraint::Min(3),
            Constraint::Length(1),
        ])
        .split(inner);

    frame.render_widget(
        Paragraph::new(Line::from(vec![
            Span::styled(format!("query  {}", picker.query), theme::muted()),
            Span::raw("  "),
            Span::styled(
                format!("{} results  {}ms", picker.total_rows, picker.recompute_ms),
                theme::muted(),
            ),
        ])),
        sections[0],
    );

    let rows = if picker.rows.is_empty() {
        vec![Line::from(Span::styled(
            picker.empty_message.clone(),
            theme::muted(),
        ))]
    } else {
        picker
            .rows
            .iter()
            .enumerate()
            .map(|(index, row): (usize, &(String, String))| {
                let (label, detail) = row;
                let selected = index == picker.selected_index;
                Line::from(vec![
                    Span::styled(
                        label.clone(),
                        if selected {
                            theme::selection()
                        } else {
                            theme::primary()
                        },
                    ),
                    Span::raw("  "),
                    Span::styled(
                        detail.clone(),
                        if selected {
                            theme::selection()
                        } else {
                            theme::muted()
                        },
                    ),
                ])
            })
            .collect::<Vec<_>>()
    };
    frame.render_widget(Paragraph::new(rows), sections[1]);
    frame.render_widget(
        Paragraph::new("Enter select  Esc cancel").style(theme::muted()),
        sections[2],
    );
}

fn centered_rect(area: Rect) -> Rect {
    let vertical = Layout::default()
        .direction(Direction::Vertical)
        .constraints([
            Constraint::Percentage(20),
            Constraint::Percentage(60),
            Constraint::Percentage(20),
        ])
        .split(area);

    Layout::default()
        .direction(Direction::Horizontal)
        .constraints([
            Constraint::Percentage(12),
            Constraint::Percentage(76),
            Constraint::Percentage(12),
        ])
        .split(vertical[1])[1]
}
