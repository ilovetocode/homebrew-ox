mod dashboard;
mod picker;
mod prompt;
mod status;

use ratatui::Frame;
use ratatui::text::{Line, Span};

use crate::interface::tui::theme;
use crate::interface::tui::view::{AgentRowView, RenderTree, ScreenView, Tone};

const NAME_MIN_WIDTH: usize = 12;
const KIND_WIDTH: usize = 8;
const RUNTIME_WIDTH: usize = 5;
const SIGNAL_WIDTH: usize = 10;
const GIT_WIDTH: usize = 16;
const BRANCH_MIN_WIDTH: usize = 14;
const PATH_MIN_WIDTH: usize = 12;

pub(super) fn draw(frame: &mut Frame, tree: &RenderTree) {
    match &tree.screen {
        ScreenView::Dashboard(screen) => dashboard::draw(frame, screen),
        ScreenView::Status(screen) => status::draw(frame, screen),
        ScreenView::Prompt(screen) => prompt::draw(frame, screen),
    }

    if let Some(picker_model) = &tree.overlay {
        picker::draw_overlay(frame, picker_model);
    }
}

pub(super) fn agent_rows_lines(rows: &[AgentRowView], total_width: usize) -> Vec<Line<'static>> {
    let layout = agent_table_layout(total_width);
    let mut lines = Vec::new();
    lines.push(Line::from(vec![
        Span::styled(fit_cell("NAME", layout.name), theme::muted()),
        Span::raw("  "),
        Span::styled(fit_cell("KIND", layout.kind), theme::muted()),
        Span::raw("  "),
        Span::styled(fit_cell("STATE", layout.runtime), theme::muted()),
        Span::raw("  "),
        Span::styled(fit_cell("SIGNAL", layout.signal), theme::muted()),
        Span::raw("  "),
        Span::styled(fit_cell("GIT", layout.git), theme::muted()),
        Span::raw("  "),
        Span::styled(fit_cell("BRANCH", layout.branch), theme::muted()),
        Span::raw("  "),
        Span::styled(fit_cell("PATH", layout.path), theme::muted()),
    ]));

    for row in rows {
        lines.push(agent_row_line(row, layout));
    }
    lines
}

#[derive(Clone, Copy)]
pub(super) struct AgentTableLayout {
    pub(super) name: usize,
    pub(super) kind: usize,
    pub(super) runtime: usize,
    pub(super) signal: usize,
    pub(super) git: usize,
    pub(super) branch: usize,
    pub(super) path: usize,
}

pub(super) fn agent_table_layout(total_width: usize) -> AgentTableLayout {
    let separators = 12;
    let fixed = KIND_WIDTH + RUNTIME_WIDTH + SIGNAL_WIDTH + GIT_WIDTH + separators;
    let remaining = total_width.saturating_sub(fixed);
    let mut name = (remaining * 26 / 100).max(NAME_MIN_WIDTH);
    let mut branch = (remaining * 38 / 100).max(BRANCH_MIN_WIDTH);
    let mut path = remaining.saturating_sub(name + branch).max(PATH_MIN_WIDTH);
    let target = fixed + name + branch + path;
    if target > total_width {
        let overflow = target - total_width;
        let reduce_branch = branch.saturating_sub(BRANCH_MIN_WIDTH).min(overflow);
        branch -= reduce_branch;
        let overflow = overflow.saturating_sub(reduce_branch);
        let reduce_name = name.saturating_sub(NAME_MIN_WIDTH).min(overflow);
        name -= reduce_name;
        let overflow = overflow.saturating_sub(reduce_name);
        let reduce_path = path.saturating_sub(PATH_MIN_WIDTH).min(overflow);
        path -= reduce_path;
    }
    AgentTableLayout {
        name,
        kind: KIND_WIDTH,
        runtime: RUNTIME_WIDTH,
        signal: SIGNAL_WIDTH,
        git: GIT_WIDTH,
        branch,
        path,
    }
}

fn agent_row_line(row: &AgentRowView, layout: AgentTableLayout) -> Line<'static> {
    let selection_style = if row.is_selected {
        theme::selection()
    } else {
        theme::primary()
    };
    let mut spans = vec![
        Span::styled(fit_cell(&row.name, layout.name), selection_style),
        Span::raw("  "),
        Span::styled(
            fit_cell(&row.kind, layout.kind),
            overlay(Tone::Muted, row.is_selected),
        ),
        Span::raw("  "),
        Span::styled(
            fit_cell(&row.runtime_label, layout.runtime),
            overlay(row.runtime_tone, row.is_selected),
        ),
        Span::raw("  "),
        Span::styled(
            fit_cell(&row.activity_token, layout.signal),
            overlay(row.productivity_tone, row.is_selected),
        ),
        Span::raw("  "),
        Span::styled(
            fit_cell(&row.git_summary, layout.git),
            overlay(row.git_tone, row.is_selected),
        ),
        Span::raw("  "),
        Span::styled(fit_cell(&row.branch, layout.branch), selection_style),
        Span::raw("  "),
        Span::styled(
            fit_cell(&row.path, layout.path),
            overlay(Tone::Muted, row.is_selected),
        ),
    ];
    if row.is_selected {
        for span in &mut spans {
            span.style = span.style.patch(theme::selection());
        }
    }
    Line::from(spans)
}

fn overlay(tone: Tone, selected: bool) -> ratatui::style::Style {
    let style = theme::tone(tone);
    if selected {
        style.patch(theme::selection())
    } else {
        style
    }
}

pub(super) fn fit_cell(value: &str, width: usize) -> String {
    let sanitized = value.replace('\n', " ");
    let char_count = sanitized.chars().count();
    if char_count <= width {
        return format!("{sanitized:<width$}");
    }
    if width <= 3 {
        return ".".repeat(width);
    }
    let truncated = sanitized.chars().take(width - 3).collect::<String>();
    format!("{truncated}...")
}

#[cfg(test)]
mod tests {
    use super::agent_table_layout;

    #[test]
    fn table_layout_reserves_kind_and_wider_git_columns() {
        let layout = agent_table_layout(120);
        assert_eq!(layout.kind, 8);
        assert_eq!(layout.git, 16);
    }
}
