use ratatui::Frame;
use ratatui::layout::{Constraint, Direction, Layout, Margin};
use ratatui::text::{Line, Span};
use ratatui::widgets::{Block, Borders, Paragraph};

use super::super::theme;
use super::super::view::StatusScreenView;

pub(super) fn draw(frame: &mut Frame, screen: &StatusScreenView) {
    let area = frame.area();
    frame.render_widget(
        Block::default()
            .title(" status ")
            .borders(Borders::ALL)
            .border_style(theme::app_border()),
        area,
    );
    let inner = area.inner(Margin {
        vertical: 1,
        horizontal: 1,
    });
    let sections = Layout::default()
        .direction(Direction::Vertical)
        .constraints([Constraint::Min(5), Constraint::Length(1)])
        .split(inner);

    let lines = screen
        .metrics
        .iter()
        .map(|metric| {
            Line::from(vec![
                Span::styled(format!("{:<12}", metric.label), theme::muted()),
                Span::styled(metric.value.clone(), theme::tone(metric.tone)),
            ])
        })
        .collect::<Vec<_>>();

    frame.render_widget(Paragraph::new(lines), sections[0]);
    frame.render_widget(
        Paragraph::new(
            screen
                .notifications
                .status_message
                .clone()
                .unwrap_or_else(|| screen.footer_hint.clone()),
        )
        .style(theme::muted()),
        sections[1],
    );
}
