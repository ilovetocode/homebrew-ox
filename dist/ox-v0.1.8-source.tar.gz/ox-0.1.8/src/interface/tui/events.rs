use std::time::Instant;

use crossterm::event::KeyEvent;

use super::picker::PickerItem;
use crate::application::{AgentKind, AgentView, StatusReport, TuiFleetSnapshot};
use crate::domain::AgentId;

/// Facts delivered into the pure TUI update function.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) enum TuiEvent {
    Started,
    Tick(Instant),
    KeyPressed(KeyEvent),
    Resized,
    AgentsRefreshed {
        agents: Vec<AgentView>,
        refreshed_at_unix_ms: u128,
        coalesced_updates: u64,
    },
    AgentsRefreshFailed {
        message: String,
    },
    StatusLoaded {
        result: Result<StatusReport, String>,
    },
    PreviewLoaded {
        agent_id: AgentId,
        output: String,
        capture_ms: u64,
    },
    PreviewFailed {
        agent_id: AgentId,
        message: String,
        capture_ms: u64,
    },
    RepoRootPickerLoaded {
        result: Result<Vec<PickerItem>, String>,
    },
    AgentCreated {
        requested_name: String,
        agent_kind: AgentKind,
        create_worktree: bool,
        result: Result<TuiFleetSnapshot, String>,
    },
    AgentRenamed {
        id: AgentId,
        old_name: String,
        new_name: String,
        result: Result<TuiFleetSnapshot, String>,
    },
    AgentDeleted {
        id: AgentId,
        name: String,
        result: Result<TuiFleetSnapshot, String>,
    },
    AgentWorktreeSwitched {
        id: AgentId,
        name: String,
        branch: String,
        result: Result<TuiFleetSnapshot, String>,
    },
    AgentAttached {
        id: AgentId,
        name: String,
        from_search_mode: bool,
        result: Result<(), String>,
    },
    PreviewKeySent {
        agent_id: AgentId,
        result: Result<(), String>,
    },
    RuntimeWarning {
        message: String,
    },
}
