use crate::application::AgentView;

/// Return agent indices visible for a search query.
///
/// Keeping this logic in one place ensures the presenter (what users see)
/// and intents (what Enter attaches to) always agree on which rows match.
pub(super) fn filtered_agent_indices(agents: &[AgentView], query: &str) -> Vec<usize> {
    if query.trim().is_empty() {
        return (0..agents.len()).collect();
    }

    let lowered_query = query.to_lowercase();
    agents
        .iter()
        .enumerate()
        .filter_map(|(index, agent)| {
            agent
                .agent
                .display_name()
                .to_lowercase()
                .contains(&lowered_query)
                .then_some(index)
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::filtered_agent_indices;
    use crate::application::{AgentView, RuntimeStatus};
    use crate::domain::{Agent, AgentKind};

    fn sample_agents() -> Vec<AgentView> {
        vec![
            AgentView {
                agent: Agent::new("work".to_string(), AgentKind::Shell, 0),
                runtime_status: RuntimeStatus::Unknown,
                attached: false,
                working_dir: None,
                git_root: None,
                git_worktree_path: None,
                git_branch: None,
                git_base_ref: None,
            },
            AgentView {
                agent: Agent::new("ops".to_string(), AgentKind::Shell, 0),
                runtime_status: RuntimeStatus::Unknown,
                attached: false,
                working_dir: None,
                git_root: None,
                git_worktree_path: None,
                git_branch: None,
                git_base_ref: None,
            },
        ]
    }

    #[test]
    fn empty_query_returns_all_indices() {
        let agents = sample_agents();
        assert_eq!(filtered_agent_indices(&agents, ""), vec![0, 1]);
    }

    #[test]
    fn query_filters_case_insensitively() {
        let agents = sample_agents();
        assert_eq!(filtered_agent_indices(&agents, "WO"), vec![0]);
    }

    #[test]
    fn first_filtered_is_none_when_no_match() {
        let agents = sample_agents();
        assert_eq!(
            filtered_agent_indices(&agents, "zzz").into_iter().next(),
            None
        );
    }
}
