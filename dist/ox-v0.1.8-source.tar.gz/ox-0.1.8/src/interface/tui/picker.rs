use std::ffi::OsStr;
use std::io;
use std::path::{Path, PathBuf};
use std::time::Instant;

use crate::application::AgentView;
use crate::interface::presentation::agent_kind::agent_kind_label;
use crate::interface::presentation::agents::compact_agent_repo;
use crate::interface::presentation::quick_switch::QuickSwitchTarget;
use crate::interface::shared::fuzzy::fuzzy_sort_indices;

const MAX_HOME_DIRS: usize = 50_000;
const MAX_HOME_DIR_DEPTH: usize = 4;
const MAX_HOME_DIR_ENTRIES_PER_DIR: usize = 300;

/// A typed picker destination selected by the user.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) enum PickerTarget {
    QuickSwitch(QuickSwitchTarget),
    RepoRoot(String),
}

/// One selectable row for the fuzzy picker.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct PickerItem {
    pub(crate) label: String,
    pub(crate) detail: String,
    pub(crate) target: PickerTarget,
}

/// In-memory picker model for ratatui rendering and keyboard interaction.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct PickerState {
    pub(crate) title: String,
    pub(crate) query: String,
    pub(crate) empty_message: String,
    pub(crate) items: Vec<PickerItem>,
    candidates: Vec<String>,
    pub(crate) filtered_indices: Vec<usize>,
    pub(crate) selected_filtered_index: usize,
    last_recompute_ms: u64,
}

impl PickerState {
    pub(crate) fn new(title: &str, empty_message: &str, items: Vec<PickerItem>) -> Self {
        let mut state = Self {
            title: title.to_string(),
            query: String::new(),
            empty_message: empty_message.to_string(),
            // Precompute fuzzy candidates once so per-keystroke matching
            // does not allocate transient "label detail" strings repeatedly.
            candidates: items
                .iter()
                .map(|item| format!("{} {}", item.label, item.detail))
                .collect(),
            items,
            filtered_indices: Vec::new(),
            selected_filtered_index: 0,
            last_recompute_ms: 0,
        };
        state.recompute_matches();
        state
    }

    pub(crate) fn append_query(&mut self, ch: char) {
        self.query.push(ch);
        self.recompute_matches();
    }

    pub(crate) fn backspace_query(&mut self) {
        self.query.pop();
        self.recompute_matches();
    }

    pub(crate) fn select_next(&mut self) {
        if self.filtered_indices.is_empty() {
            self.selected_filtered_index = 0;
            return;
        }
        self.selected_filtered_index =
            (self.selected_filtered_index + 1) % self.filtered_indices.len();
    }

    pub(crate) fn select_prev(&mut self) {
        if self.filtered_indices.is_empty() {
            self.selected_filtered_index = 0;
            return;
        }

        if self.selected_filtered_index == 0 {
            self.selected_filtered_index = self.filtered_indices.len() - 1;
        } else {
            self.selected_filtered_index -= 1;
        }
    }

    pub(crate) fn selected_item(&self) -> Option<&PickerItem> {
        let index = *self.filtered_indices.get(self.selected_filtered_index)?;
        self.items.get(index)
    }

    pub(crate) fn last_recompute_ms(&self) -> u64 {
        self.last_recompute_ms
    }

    fn recompute_matches(&mut self) {
        let started = Instant::now();
        self.filtered_indices = fuzzy_sort_indices(&self.query, &self.candidates);
        if self.selected_filtered_index >= self.filtered_indices.len() {
            self.selected_filtered_index = 0;
        }
        self.last_recompute_ms = u64::try_from(started.elapsed().as_millis()).unwrap_or(u64::MAX);
    }
}

pub(crate) fn quick_switch_items(agents: &[AgentView]) -> Vec<PickerItem> {
    let mut items = Vec::with_capacity(agents.len().saturating_add(1));
    items.push(PickerItem {
        label: "dashboard".to_string(),
        detail: "system return".to_string(),
        target: PickerTarget::QuickSwitch(QuickSwitchTarget::Dashboard),
    });

    for agent in agents {
        let status = agent.runtime_status.as_label();
        let attached = if agent.attached { "attached  " } else { "" };
        items.push(PickerItem {
            label: agent.agent.display_name().to_string(),
            detail: format!(
                "{attached}{}  {}  {}",
                agent_kind_label(agent.agent.kind()),
                status,
                compact_agent_repo(agent)
            ),
            target: PickerTarget::QuickSwitch(QuickSwitchTarget::Agent {
                id: agent.agent.id(),
                name: agent.agent.display_name().to_string(),
            }),
        });
    }

    items
}

pub(super) fn repo_root_items() -> io::Result<Vec<PickerItem>> {
    let home = resolve_home_dir()?;
    let mut directories = collect_visible_dirs(&home)?;
    directories.sort();

    Ok(directories
        .into_iter()
        .map(|path| PickerItem {
            label: path.clone(),
            detail: "directory".to_string(),
            target: PickerTarget::RepoRoot(path),
        })
        .collect())
}

fn resolve_home_dir() -> io::Result<PathBuf> {
    std::env::var("HOME")
        .map(PathBuf::from)
        .map_err(|_| io::Error::new(io::ErrorKind::NotFound, "HOME must be set"))
}

fn collect_visible_dirs(home: &Path) -> io::Result<Vec<String>> {
    let mut results = Vec::new();
    let mut stack = vec![(home.to_path_buf(), 0_usize)];

    while let Some((current, depth)) = stack.pop() {
        if current != home {
            results.push(current.to_string_lossy().to_string());
            if results.len() >= MAX_HOME_DIRS {
                break;
            }
        }

        if depth >= MAX_HOME_DIR_DEPTH {
            continue;
        }

        let entries = std::fs::read_dir(&current)?;
        for (index, entry) in entries.enumerate() {
            if index >= MAX_HOME_DIR_ENTRIES_PER_DIR {
                break;
            }
            let entry = entry?;
            let path = entry.path();
            if !path.is_dir() {
                continue;
            }
            if is_hidden_name(path.file_name()) {
                continue;
            }
            stack.push((path, depth + 1));
        }
    }

    Ok(results)
}

fn is_hidden_name(name: Option<&OsStr>) -> bool {
    name.and_then(OsStr::to_str)
        .is_some_and(|value| value.starts_with('.'))
}

#[cfg(test)]
mod tests {
    use std::ffi::OsStr;

    use super::{PickerState, PickerTarget, is_hidden_name, quick_switch_items};
    use crate::application::AgentView;
    use crate::domain::{Agent, AgentKind};
    use crate::interface::presentation::quick_switch::QuickSwitchTarget;

    #[test]
    fn picker_state_filters_and_selects() {
        let items = vec![
            super::PickerItem {
                label: "alpha".to_string(),
                detail: "shell".to_string(),
                target: PickerTarget::RepoRoot("/tmp/alpha".to_string()),
            },
            super::PickerItem {
                label: "beta".to_string(),
                detail: "shell".to_string(),
                target: PickerTarget::RepoRoot("/tmp/beta".to_string()),
            },
        ];

        let mut state = PickerState::new("Pick", "none", items);
        state.append_query('b');

        let selected = state.selected_item();
        assert!(selected.is_some());
        assert_eq!(selected.map(|item| item.label.as_str()), Some("beta"));
    }

    #[test]
    fn quick_switch_items_starts_with_dashboard() {
        let agents = vec![AgentView {
            agent: Agent::new("dev".to_string(), AgentKind::Codex, 0),
            runtime_status: crate::application::RuntimeStatus::Running,
            attached: true,
            working_dir: None,
            git_root: None,
            git_worktree_path: None,
            git_branch: None,
            git_base_ref: None,
        }];

        let items = quick_switch_items(&agents);
        assert!(matches!(
            items.first().map(|item| &item.target),
            Some(PickerTarget::QuickSwitch(QuickSwitchTarget::Dashboard))
        ));
        assert_eq!(items.len(), 2);
    }

    #[test]
    fn hidden_name_detection_matches_dot_prefix() {
        assert!(is_hidden_name(Some(OsStr::new(".git"))));
        assert!(!is_hidden_name(Some(OsStr::new("work"))));
    }
}
