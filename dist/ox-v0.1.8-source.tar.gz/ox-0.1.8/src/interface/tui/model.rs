use std::time::{Duration, Instant};

use crate::application::{AgentKind, AgentView, StatusReport};
use crate::domain::AgentId;

use super::activity::ActivityLedger;
use super::filter::filtered_agent_indices;
use super::messages::{
    MSG_BACK_TO_AGENTS, MSG_CREATE_NEW_SESSION_HINT, MSG_EDIT_AGENT_NAME_HINT,
    MSG_EDIT_WORKTREE_BRANCH_HINT, MSG_NO_AGENT_SELECTED, MSG_STATUS_OVERVIEW_LOADED,
    MSG_TYPE_TO_FILTER_AGENTS,
};
use super::picker::PickerState;
use super::startup::StartupScreen;

pub(super) const PREVIEW_CAPTURE_LINES: u16 = 200;
pub(super) const PICKER_LATENCY_WARN_MS: u64 = 20;

/// Long-lived TUI state owned by the event loop.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct TuiModel {
    pub(super) dashboard: DashboardState,
    pub(super) screen: ScreenState,
    pub(super) overlay: Option<OverlayState>,
    pub(super) preview: PreviewPaneState,
    pub(super) notifications: NotificationState,
    pub(super) status: StatusScreenState,
    pub(super) runtime: RuntimeHints,
}

impl TuiModel {
    pub(super) fn new(startup: StartupScreen, refresh_interval: Duration) -> Self {
        let mut model = Self {
            dashboard: DashboardState::default(),
            screen: ScreenState::Dashboard,
            overlay: None,
            preview: PreviewPaneState::default(),
            notifications: NotificationState::default(),
            status: StatusScreenState::default(),
            runtime: RuntimeHints::new(refresh_interval),
        };
        model.apply_startup(startup);
        model
    }

    fn apply_startup(&mut self, startup: StartupScreen) {
        match startup {
            StartupScreen::Dashboard => {}
            StartupScreen::Status => self.enter_status_screen(),
            StartupScreen::Search => self.enter_search_prompt(),
            StartupScreen::NewAgent => self.enter_new_agent_prompt(),
            StartupScreen::Rename => {
                self.runtime.defer_rename_prompt = true;
            }
        }
    }

    pub(super) fn visible_agent_indices(&self) -> Vec<usize> {
        match &self.screen {
            ScreenState::Prompt(PromptFlow::Search(search)) => {
                filtered_agent_indices(&self.dashboard.agents, &search.draft)
            }
            ScreenState::Status => Vec::new(),
            ScreenState::Dashboard | ScreenState::Prompt(_) => {
                (0..self.dashboard.agents.len()).collect()
            }
        }
    }

    pub(super) fn active_agent_index(&self) -> Option<usize> {
        match &self.screen {
            ScreenState::Prompt(PromptFlow::Search(_)) => {
                self.visible_agent_indices().into_iter().next()
            }
            ScreenState::Status => None,
            ScreenState::Dashboard | ScreenState::Prompt(_) => {
                self.dashboard
                    .agents
                    .get(self.dashboard.selection.selected_index())?;
                Some(self.dashboard.selection.selected_index())
            }
        }
    }

    pub(super) fn active_agent(&self) -> Option<&AgentView> {
        let index = self.active_agent_index()?;
        self.dashboard.agents.get(index)
    }

    pub(super) fn active_agent_id(&self) -> Option<AgentId> {
        self.active_agent().map(|agent| agent.agent.id())
    }

    pub(super) fn active_agent_name(&self) -> Option<String> {
        self.active_agent()
            .map(|agent| agent.agent.display_name().to_string())
    }

    pub(super) fn is_search_prompt(&self) -> bool {
        matches!(self.screen, ScreenState::Prompt(PromptFlow::Search(_)))
    }

    pub(super) fn preview_refresh_eligible(&self) -> bool {
        matches!(self.screen, ScreenState::Dashboard) && self.overlay.is_none()
    }

    pub(super) fn enter_dashboard(&mut self) {
        self.screen = ScreenState::Dashboard;
    }

    pub(super) fn enter_dashboard_with_status(&mut self, message: impl Into<String>) {
        self.enter_dashboard();
        self.notifications.status_message = Some(message.into());
    }

    pub(super) fn enter_status_screen(&mut self) {
        self.preview.input_mode = false;
        self.screen = ScreenState::Status;
        self.notifications.status_message = Some(MSG_STATUS_OVERVIEW_LOADED.to_string());
    }

    pub(super) fn return_from_status_screen(&mut self) {
        if matches!(self.screen, ScreenState::Status) {
            self.enter_dashboard_with_status(MSG_BACK_TO_AGENTS);
        }
    }

    pub(super) fn enter_new_agent_prompt(&mut self) {
        self.preview.input_mode = false;
        self.screen = ScreenState::Prompt(PromptFlow::NewAgent(NewAgentForm::new()));
        self.notifications.status_message = Some(MSG_CREATE_NEW_SESSION_HINT.to_string());
    }

    pub(super) fn enter_search_prompt(&mut self) {
        self.preview.input_mode = false;
        self.screen = ScreenState::Prompt(PromptFlow::Search(SearchPromptState::default()));
        self.notifications.status_message = Some(MSG_TYPE_TO_FILTER_AGENTS.to_string());
    }

    pub(super) fn enter_rename_prompt_from_selection(&mut self) -> bool {
        self.preview.input_mode = false;
        let Some(active_agent) = self.active_agent() else {
            self.notifications.status_message = Some(MSG_NO_AGENT_SELECTED.to_string());
            return false;
        };
        let old_name = active_agent.agent.display_name().to_string();
        self.screen = ScreenState::Prompt(PromptFlow::Rename(RenamePromptState {
            agent_id: active_agent.agent.id(),
            old_name: old_name.clone(),
            draft: old_name,
        }));
        self.notifications.status_message = Some(MSG_EDIT_AGENT_NAME_HINT.to_string());
        true
    }

    pub(super) fn enter_worktree_prompt_from_selection(&mut self) -> bool {
        self.preview.input_mode = false;
        let Some(active_agent) = self.active_agent() else {
            self.notifications.status_message = Some(MSG_NO_AGENT_SELECTED.to_string());
            return false;
        };
        self.screen = ScreenState::Prompt(PromptFlow::Worktree(WorktreePromptState {
            agent_id: active_agent.agent.id(),
            agent_name: active_agent.agent.display_name().to_string(),
            draft: active_agent.git_branch.clone().unwrap_or_default(),
        }));
        self.notifications.status_message = Some(MSG_EDIT_WORKTREE_BRANCH_HINT.to_string());
        true
    }

    pub(super) fn maybe_apply_deferred_rename_prompt(&mut self) {
        if self.runtime.defer_rename_prompt {
            self.runtime.defer_rename_prompt = false;
            let _ = self.enter_rename_prompt_from_selection();
        }
    }

    pub(super) fn close_overlay(&mut self) {
        self.overlay = None;
    }

    pub(super) fn open_picker(&mut self, picker: PickerState) {
        self.preview.input_mode = false;
        self.overlay = Some(OverlayState::Picker(picker));
    }

    pub(super) fn picker_mut(&mut self) -> Option<&mut PickerState> {
        let Some(OverlayState::Picker(picker)) = &mut self.overlay else {
            return None;
        };
        Some(picker)
    }

    pub(super) fn picker(&self) -> Option<&PickerState> {
        let Some(OverlayState::Picker(picker)) = &self.overlay else {
            return None;
        };
        Some(picker)
    }

    pub(super) fn clear_preview(&mut self) {
        self.preview = PreviewPaneState::default();
    }

    pub(super) fn set_preview_text(&mut self, text: String) {
        if self.preview.text != text {
            self.preview.last_changed_unix_ms = self.dashboard.last_refresh_unix_ms;
        }
        self.preview.text = text;
        if self.preview.follow_tail {
            self.preview.scroll_offset = 0;
        }
    }

    pub(super) fn scroll_preview_up(&mut self, amount: u16) {
        self.preview.follow_tail = false;
        self.preview.scroll_offset = self.preview.scroll_offset.saturating_add(amount);
    }

    pub(super) fn scroll_preview_down(&mut self, amount: u16) {
        self.preview.scroll_offset = self.preview.scroll_offset.saturating_sub(amount);
        if self.preview.scroll_offset == 0 {
            self.preview.follow_tail = true;
        }
    }

    pub(super) fn mark_preview_request(&mut self, when: Instant, agent_id: AgentId) {
        self.runtime.last_preview_request_at = Some(when);
        self.runtime.pending_preview_agent_id = Some(agent_id);
    }

    pub(super) fn replace_agents_preserving_selection(
        &mut self,
        agents: Vec<AgentView>,
        refreshed_at_unix_ms: u128,
        preferred_selected_id: Option<AgentId>,
    ) {
        let previous_selected_id = preferred_selected_id.or_else(|| self.selected_agent_id());
        self.dashboard.agents = agents;
        self.dashboard.last_refresh_unix_ms = refreshed_at_unix_ms;
        self.dashboard
            .activity
            .update(&self.dashboard.agents, refreshed_at_unix_ms);
        if let Some(id) = previous_selected_id.as_ref() {
            self.set_selected_by_agent_id(id);
        }
        self.dashboard
            .selection
            .clamp_to_item_count(self.dashboard.agents.len());
    }

    pub(super) fn set_selected_by_agent_id(&mut self, id: &AgentId) {
        if let Some(index) = self
            .dashboard
            .agents
            .iter()
            .position(|agent| agent.agent.id().as_str() == id.as_str())
        {
            self.dashboard.selection.set_selected_index(index);
        }
    }

    pub(super) fn selected_agent_id(&self) -> Option<AgentId> {
        self.dashboard
            .agents
            .get(self.dashboard.selection.selected_index())
            .map(|agent| agent.agent.id())
    }
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(super) struct DashboardState {
    pub(super) agents: Vec<AgentView>,
    pub(super) selection: SelectionState,
    pub(super) activity: ActivityLedger,
    pub(super) last_refresh_unix_ms: u128,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(super) struct StatusScreenState {
    pub(super) report: Option<StatusReport>,
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(super) struct NotificationState {
    pub(super) status_message: Option<String>,
    pub(super) error_message: Option<String>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct PreviewPaneState {
    pub(super) text: String,
    pub(super) scroll_offset: u16,
    pub(super) follow_tail: bool,
    pub(super) input_mode: bool,
    pub(super) last_changed_unix_ms: u128,
}

impl Default for PreviewPaneState {
    fn default() -> Self {
        Self {
            text: String::new(),
            scroll_offset: 0,
            follow_tail: true,
            input_mode: false,
            last_changed_unix_ms: 0,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct RuntimeHints {
    pub(super) refresh_interval: Duration,
    pub(super) preview_refresh_interval: Duration,
    pub(super) last_preview_request_at: Option<Instant>,
    pub(super) pending_preview_agent_id: Option<AgentId>,
    pub(super) preview_capture_lines: u16,
    pub(super) last_seen_coalesced_refresh_updates: u64,
    pub(super) defer_rename_prompt: bool,
}

impl RuntimeHints {
    fn new(refresh_interval: Duration) -> Self {
        Self {
            refresh_interval,
            preview_refresh_interval: Duration::from_millis(500),
            last_preview_request_at: None,
            pending_preview_agent_id: None,
            preview_capture_lines: PREVIEW_CAPTURE_LINES,
            last_seen_coalesced_refresh_updates: 0,
            defer_rename_prompt: false,
        }
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) enum ScreenState {
    Dashboard,
    Status,
    Prompt(PromptFlow),
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) enum PromptFlow {
    NewAgent(NewAgentForm),
    Rename(RenamePromptState),
    Search(SearchPromptState),
    Worktree(WorktreePromptState),
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) enum OverlayState {
    Picker(PickerState),
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(super) struct SearchPromptState {
    pub(super) draft: String,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct RenamePromptState {
    pub(super) agent_id: AgentId,
    pub(super) old_name: String,
    pub(super) draft: String,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct WorktreePromptState {
    pub(super) agent_id: AgentId,
    pub(super) agent_name: String,
    pub(super) draft: String,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct NewAgentForm {
    pub(super) name: String,
    pub(super) agent_kind: AgentKind,
    pub(super) create_worktree: bool,
    pub(super) repo_root: Option<String>,
    pub(super) focused_field: NewAgentField,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum NewAgentField {
    Name,
    Kind,
    Worktree,
    RepoRoot,
}

impl NewAgentForm {
    pub(super) fn new() -> Self {
        Self {
            name: String::new(),
            agent_kind: AgentKind::Shell,
            create_worktree: false,
            repo_root: None,
            focused_field: NewAgentField::Name,
        }
    }

    pub(super) fn focus_next(&mut self) {
        self.focused_field = match self.focused_field {
            NewAgentField::Name => NewAgentField::Kind,
            NewAgentField::Kind => NewAgentField::Worktree,
            NewAgentField::Worktree => {
                if self.create_worktree {
                    NewAgentField::RepoRoot
                } else {
                    NewAgentField::Name
                }
            }
            NewAgentField::RepoRoot => NewAgentField::Name,
        };
    }

    pub(super) fn focus_prev(&mut self) {
        self.focused_field = match self.focused_field {
            NewAgentField::Name => {
                if self.create_worktree {
                    NewAgentField::RepoRoot
                } else {
                    NewAgentField::Worktree
                }
            }
            NewAgentField::Kind => NewAgentField::Name,
            NewAgentField::Worktree => NewAgentField::Kind,
            NewAgentField::RepoRoot => NewAgentField::Worktree,
        };
    }

    pub(super) fn normalize_focus(&mut self) {
        if !self.create_worktree && self.focused_field == NewAgentField::RepoRoot {
            self.focused_field = NewAgentField::Name;
        }
    }
}

#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(super) struct SelectionState {
    selected_index: usize,
}

impl SelectionState {
    pub(super) fn select_next(&mut self, item_count: usize) {
        if item_count == 0 {
            return;
        }
        self.selected_index = (self.selected_index + 1) % item_count;
    }

    pub(super) fn select_prev(&mut self, item_count: usize) {
        if item_count == 0 {
            return;
        }
        if self.selected_index == 0 {
            self.selected_index = item_count - 1;
        } else {
            self.selected_index -= 1;
        }
    }

    pub(super) fn clamp_to_item_count(&mut self, item_count: usize) {
        if item_count == 0 {
            self.selected_index = 0;
            return;
        }
        if self.selected_index >= item_count {
            self.selected_index = item_count - 1;
        }
    }

    pub(super) fn selected_index(&self) -> usize {
        self.selected_index
    }

    pub(super) fn set_selected_index(&mut self, index: usize) {
        self.selected_index = index;
    }
}
