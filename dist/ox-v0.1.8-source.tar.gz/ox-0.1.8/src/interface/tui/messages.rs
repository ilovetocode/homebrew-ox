pub(super) const MSG_STATUS_OVERVIEW_LOADED: &str = "Status overview loaded.";
pub(super) const MSG_TYPE_TO_FILTER_AGENTS: &str = "Type to filter agents.";
pub(super) const MSG_CREATE_NEW_SESSION_HINT: &str =
    "Create a new session with Tab/Shift+Tab to move fields.";
pub(super) const MSG_EDIT_AGENT_NAME_HINT: &str = "Edit agent name and press Enter.";
pub(super) const MSG_EDIT_WORKTREE_BRANCH_HINT: &str =
    "Enter a branch name and press Enter to recreate this session in a worktree.";
pub(super) const MSG_NO_AGENT_SELECTED: &str = "No agent selected.";
pub(super) const MSG_NEW_AGENT_CREATION_CANCELED: &str = "New agent creation canceled.";
pub(super) const MSG_AGENT_RENAME_CANCELED: &str = "Agent rename canceled.";
pub(super) const MSG_WORKTREE_SWITCH_CANCELED: &str = "Worktree switch canceled.";
pub(super) const MSG_SEARCH_CLOSED: &str = "Search closed.";
pub(super) const MSG_PICKER_CANCELED: &str = "Picker canceled.";
pub(super) const MSG_BACK_TO_AGENTS: &str = "Back to agents.";
pub(super) const MSG_QUICK_SWITCH_HINT: &str = "Type to fuzzy-search sessions and dashboard.";
pub(super) const MSG_NO_PICKER_RESULT_SELECTED: &str = "No picker result selected.";
pub(super) const MSG_RETURNED_TO_DASHBOARD: &str = "Returned to dashboard.";
pub(super) const MSG_AGENT_NAME_CANNOT_BE_EMPTY: &str = "Agent name cannot be empty.";
pub(super) const MSG_AGENT_NAME_UNCHANGED: &str = "Agent name is unchanged.";
pub(super) const MSG_WORKTREE_BRANCH_CANNOT_BE_EMPTY: &str = "Branch name cannot be empty.";
pub(super) const MSG_REPO_ROOT_PICKER_HINT: &str = "Type to fuzzy-search directories under HOME.";
