use std::collections::VecDeque;
use std::time::{Duration, Instant};

const FRAME_REDRAW_WARN_MS: u64 = 50;
const PREVIEW_CAPTURE_WARN_MS: u64 = 100;
const PERF_WARN_COOLDOWN_MS: u64 = 2_000;

pub(super) struct RuntimePerf {
    frame_ms: RollingWindow,
    preview_capture_ms: RollingWindow,
    last_warn_at: Option<Instant>,
}

impl RuntimePerf {
    pub(super) fn new() -> Self {
        Self {
            frame_ms: RollingWindow::new(64),
            preview_capture_ms: RollingWindow::new(64),
            last_warn_at: None,
        }
    }

    pub(super) fn record_frame_ms(&mut self, value: u64) {
        self.frame_ms.push(value);
    }

    pub(super) fn record_preview_capture_ms(&mut self, value: u64) {
        self.preview_capture_ms.push(value);
    }

    pub(super) fn maybe_warn(&mut self) -> Option<String> {
        if self
            .last_warn_at
            .is_some_and(|at| at.elapsed() < Duration::from_millis(PERF_WARN_COOLDOWN_MS))
        {
            return None;
        }

        let preview_p95 = self.preview_capture_ms.p95();
        if preview_p95.is_some_and(|p95| p95 > PREVIEW_CAPTURE_WARN_MS) {
            self.last_warn_at = Some(Instant::now());
            return Some(format!(
                "Preview capture latency high: p95={}ms.",
                preview_p95.unwrap_or_default()
            ));
        }

        let frame_p95 = self.frame_ms.p95();
        if frame_p95.is_some_and(|p95| p95 > FRAME_REDRAW_WARN_MS) {
            self.last_warn_at = Some(Instant::now());
            return Some(format!(
                "TUI redraw latency high: p95={}ms.",
                frame_p95.unwrap_or_default()
            ));
        }

        None
    }
}

struct RollingWindow {
    values: VecDeque<u64>,
    max_len: usize,
}

impl RollingWindow {
    fn new(max_len: usize) -> Self {
        Self {
            values: VecDeque::with_capacity(max_len),
            max_len,
        }
    }

    fn push(&mut self, value: u64) {
        if self.values.len() >= self.max_len {
            self.values.pop_front();
        }
        self.values.push_back(value);
    }

    fn p95(&self) -> Option<u64> {
        let values = self.values.iter().copied().collect::<Vec<_>>();
        percentile(&values, 95)
    }
}

fn percentile(values: &[u64], percentile: u8) -> Option<u64> {
    if values.is_empty() {
        return None;
    }
    let mut sorted = values.to_vec();
    sorted.sort_unstable();
    let index = ((sorted.len() - 1) * usize::from(percentile)) / 100;
    sorted.get(index).copied()
}

#[cfg(test)]
mod tests {
    use super::{RollingWindow, percentile};

    #[test]
    fn percentile_returns_none_for_empty_values() {
        assert_eq!(percentile(&[], 95), None);
    }

    #[test]
    fn percentile_returns_expected_rank_value() {
        assert_eq!(percentile(&[10, 20, 30, 40, 50], 95), Some(40));
    }

    #[test]
    fn rolling_window_keeps_latest_values() {
        let mut window = RollingWindow::new(3);
        window.push(10);
        window.push(20);
        window.push(30);
        window.push(40);
        assert_eq!(window.p95(), Some(30));
    }
}
