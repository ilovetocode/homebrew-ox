use std::collections::VecDeque;
use std::io;
use std::sync::Arc;
use std::time::{Duration, Instant};
use std::time::{SystemTime, UNIX_EPOCH};

use crossterm::event::{self, Event};

use super::perf::RuntimePerf;
use super::services::RuntimeServices;
use super::{TuiTerminal, restore_terminal, setup_terminal};
use crate::application::TuiApi;
use crate::domain::AgentId;
use crate::interface::tui::commands::TuiCommand;
use crate::interface::tui::events::TuiEvent;
use crate::interface::tui::model::TuiModel;
use crate::interface::tui::picker::repo_root_items;
use crate::interface::tui::startup::StartupScreen;
use crate::interface::tui::update::{self, UpdateResult};
use crate::interface::tui::{view, widgets};

const MIN_REFRESH_INTERVAL_MS: u64 = 500;
const EVENT_POLL_INTERVAL_MS: u64 = 10;

pub(super) fn run(app: &Arc<dyn TuiApi>, startup: StartupScreen) -> io::Result<()> {
    let mut terminal = setup_terminal()?;
    let refresh_interval =
        Duration::from_millis(app.tui_refresh_interval_ms().max(MIN_REFRESH_INTERVAL_MS));
    let mut model = TuiModel::new(startup, refresh_interval);
    let services = RuntimeServices::start(Arc::clone(app), refresh_interval);
    let mut perf = RuntimePerf::new();
    let app_result = run_loop(
        &mut model,
        app.as_ref(),
        &services,
        &mut terminal,
        &mut perf,
    );

    services.stop();
    let cleanup_result = restore_terminal(&mut terminal);
    app_result.and(cleanup_result)
}

fn run_loop(
    model: &mut TuiModel,
    app: &dyn TuiApi,
    services: &RuntimeServices,
    terminal: &mut TuiTerminal,
    perf: &mut RuntimePerf,
) -> io::Result<()> {
    let mut should_redraw = true;

    let started = dispatch_event(model, TuiEvent::Started, app, services, terminal, perf)?;
    should_redraw |= started.changed;
    if started.should_quit {
        return Ok(());
    }

    loop {
        if handle_background_events(model, app, services, terminal, perf, &mut should_redraw)? {
            return Ok(());
        }

        if handle_runtime_warning(model, app, services, terminal, perf, &mut should_redraw)? {
            return Ok(());
        }

        if handle_tick(model, app, services, terminal, perf, &mut should_redraw)? {
            return Ok(());
        }

        draw_if_needed(model, terminal, perf, &mut should_redraw)?;

        if handle_input(model, app, services, terminal, perf, &mut should_redraw)? {
            break;
        }
    }

    Ok(())
}

struct DispatchOutcome {
    changed: bool,
    should_quit: bool,
}

fn dispatch_event(
    model: &mut TuiModel,
    event: TuiEvent,
    app: &dyn TuiApi,
    services: &RuntimeServices,
    terminal: &mut TuiTerminal,
    perf: &mut RuntimePerf,
) -> io::Result<DispatchOutcome> {
    let mut queue = VecDeque::from([event]);
    let mut changed = false;
    let mut should_quit = false;

    while let Some(next_event) = queue.pop_front() {
        let UpdateResult {
            commands,
            changed: model_changed,
        } = update::update(model, next_event);
        changed |= model_changed;

        for command in commands {
            let command_outcome = execute_command(model, command, app, services, terminal, perf)?;
            changed |= command_outcome.changed;
            should_quit |= command_outcome.should_quit;
            queue.extend(command_outcome.follow_up_events);
        }
    }

    Ok(DispatchOutcome {
        changed,
        should_quit,
    })
}

#[derive(Default)]
struct CommandOutcome {
    follow_up_events: Vec<TuiEvent>,
    changed: bool,
    should_quit: bool,
}

trait AttachTerminal {
    fn restore_for_attach(&mut self) -> io::Result<()>;
    fn resume_after_attach(&mut self) -> io::Result<()>;
}

struct LiveAttachTerminal<'a> {
    terminal: &'a mut TuiTerminal,
}

impl AttachTerminal for LiveAttachTerminal<'_> {
    fn restore_for_attach(&mut self) -> io::Result<()> {
        restore_terminal(self.terminal)
    }

    fn resume_after_attach(&mut self) -> io::Result<()> {
        *self.terminal = setup_terminal()?;
        Ok(())
    }
}

fn execute_command(
    model: &mut TuiModel,
    command: TuiCommand,
    app: &dyn TuiApi,
    services: &RuntimeServices,
    terminal: &mut TuiTerminal,
    _perf: &mut RuntimePerf,
) -> io::Result<CommandOutcome> {
    if let Some(outcome) = execute_mutation_command(app, command.clone()) {
        return Ok(outcome);
    }

    let outcome = match command {
        TuiCommand::RefreshAgents => {
            services.request_agents_refresh();
            CommandOutcome::default()
        }
        TuiCommand::LoadStatus => CommandOutcome {
            follow_up_events: vec![TuiEvent::StatusLoaded {
                result: app.tui_status_report().map_err(|err| err.to_string()),
            }],
            changed: false,
            should_quit: false,
        },
        TuiCommand::LoadRepoRootPicker => CommandOutcome {
            follow_up_events: vec![TuiEvent::RepoRootPickerLoaded {
                result: repo_root_items().map_err(|err| err.to_string()),
            }],
            changed: false,
            should_quit: false,
        },
        TuiCommand::AttachAgent {
            id,
            name,
            from_search_mode,
        } => attach_agent(
            &mut LiveAttachTerminal { terminal },
            app,
            &id,
            name,
            from_search_mode,
        )?,
        TuiCommand::RequestPreviewCapture { id, lines } => {
            model.mark_preview_request(Instant::now(), id.clone());
            services.request_preview_capture(id, lines);
            CommandOutcome::default()
        }
        TuiCommand::SendPreviewKey { id, key } => CommandOutcome {
            follow_up_events: vec![TuiEvent::PreviewKeySent {
                agent_id: id.clone(),
                result: app
                    .tui_send_key_to_agent(&id, &key)
                    .map_err(|err| err.to_string()),
            }],
            changed: false,
            should_quit: false,
        },
        // The mutation commands are handled by `execute_mutation_command`
        // above so this match can stay focused on runtime/terminal side
        // effects without duplicating those branches here.
        TuiCommand::CreateAgent { .. }
        | TuiCommand::RenameAgent { .. }
        | TuiCommand::DeleteAgent { .. }
        | TuiCommand::SwitchAgentToWorktreeShell { .. } => unreachable!("handled earlier"),
        TuiCommand::Quit => CommandOutcome {
            follow_up_events: Vec::new(),
            changed: false,
            should_quit: true,
        },
    };
    Ok(outcome)
}

fn execute_mutation_command(app: &dyn TuiApi, command: TuiCommand) -> Option<CommandOutcome> {
    let outcome = match command {
        TuiCommand::CreateAgent {
            request,
            requested_name,
            agent_kind,
            create_worktree,
        } => CommandOutcome {
            follow_up_events: vec![TuiEvent::AgentCreated {
                requested_name,
                agent_kind,
                create_worktree,
                result: app.tui_create_agent(request).map_err(|err| err.to_string()),
            }],
            changed: false,
            should_quit: false,
        },
        TuiCommand::RenameAgent {
            id,
            old_name,
            new_name,
        } => CommandOutcome {
            follow_up_events: vec![TuiEvent::AgentRenamed {
                id: id.clone(),
                old_name,
                new_name: new_name.clone(),
                result: app
                    .tui_rename_agent(&id, &new_name)
                    .map_err(|err| err.to_string()),
            }],
            changed: false,
            should_quit: false,
        },
        TuiCommand::DeleteAgent { id, name } => CommandOutcome {
            follow_up_events: vec![TuiEvent::AgentDeleted {
                id: id.clone(),
                name,
                result: app.tui_delete_agent(&id).map_err(|err| err.to_string()),
            }],
            changed: false,
            should_quit: false,
        },
        TuiCommand::SwitchAgentToWorktreeShell { id, name, branch } => CommandOutcome {
            follow_up_events: vec![TuiEvent::AgentWorktreeSwitched {
                id: id.clone(),
                name,
                branch: branch.clone(),
                result: app
                    .tui_switch_agent_to_worktree_shell(&id, &branch)
                    .map_err(|err| err.to_string()),
            }],
            changed: false,
            should_quit: false,
        },
        _ => return None,
    };
    Some(outcome)
}

fn attach_agent(
    terminal: &mut impl AttachTerminal,
    app: &dyn TuiApi,
    id: &AgentId,
    name: String,
    from_search_mode: bool,
) -> io::Result<CommandOutcome> {
    let attach_started_at_unix_ms = unix_time_ms();
    terminal.restore_for_attach()?;
    let attach_result = app.tui_connect_agent(id).map_err(|err| err.to_string());
    let attach_return = attach_result.as_ref().ok().and_then(|()| {
        app.tui_resolve_attach_return(id, attach_started_at_unix_ms)
            .ok()
    });
    terminal.resume_after_attach()?;
    let attached_id = attach_return
        .as_ref()
        .map_or_else(|| id.clone(), |target| target.id.clone());
    let attached_name = attach_return.map_or(name, |target| target.name);
    Ok(CommandOutcome {
        follow_up_events: vec![TuiEvent::AgentAttached {
            id: attached_id,
            name: attached_name,
            from_search_mode,
            result: attach_result,
        }],
        changed: true,
        should_quit: false,
    })
}

fn unix_time_ms() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_millis())
}

fn handle_background_events(
    model: &mut TuiModel,
    app: &dyn TuiApi,
    services: &RuntimeServices,
    terminal: &mut TuiTerminal,
    perf: &mut RuntimePerf,
    should_redraw: &mut bool,
) -> io::Result<bool> {
    for event in services.drain_events() {
        if let TuiEvent::PreviewLoaded { capture_ms, .. }
        | TuiEvent::PreviewFailed { capture_ms, .. } = &event
        {
            perf.record_preview_capture_ms(*capture_ms);
        }

        let outcome = dispatch_event(model, event, app, services, terminal, perf)?;
        *should_redraw |= outcome.changed;
        if outcome.should_quit {
            return Ok(true);
        }
    }

    Ok(false)
}

fn handle_runtime_warning(
    model: &mut TuiModel,
    app: &dyn TuiApi,
    services: &RuntimeServices,
    terminal: &mut TuiTerminal,
    perf: &mut RuntimePerf,
    should_redraw: &mut bool,
) -> io::Result<bool> {
    let Some(message) = perf.maybe_warn() else {
        return Ok(false);
    };

    let outcome = dispatch_event(
        model,
        TuiEvent::RuntimeWarning { message },
        app,
        services,
        terminal,
        perf,
    )?;
    *should_redraw |= outcome.changed;
    Ok(outcome.should_quit)
}

fn handle_tick(
    model: &mut TuiModel,
    app: &dyn TuiApi,
    services: &RuntimeServices,
    terminal: &mut TuiTerminal,
    perf: &mut RuntimePerf,
    should_redraw: &mut bool,
) -> io::Result<bool> {
    let outcome = dispatch_event(
        model,
        TuiEvent::Tick(Instant::now()),
        app,
        services,
        terminal,
        perf,
    )?;
    *should_redraw |= outcome.changed;
    Ok(outcome.should_quit)
}

fn draw_if_needed(
    model: &TuiModel,
    terminal: &mut TuiTerminal,
    perf: &mut RuntimePerf,
    should_redraw: &mut bool,
) -> io::Result<()> {
    if !*should_redraw {
        return Ok(());
    }

    let frame_started = Instant::now();
    let tree = view::present(model);
    terminal.draw(|frame| widgets::draw(frame, &tree))?;
    let frame_ms = u64::try_from(frame_started.elapsed().as_millis()).unwrap_or(u64::MAX);
    perf.record_frame_ms(frame_ms);
    *should_redraw = false;
    Ok(())
}

fn handle_input(
    model: &mut TuiModel,
    app: &dyn TuiApi,
    services: &RuntimeServices,
    terminal: &mut TuiTerminal,
    perf: &mut RuntimePerf,
    should_redraw: &mut bool,
) -> io::Result<bool> {
    if !event::poll(Duration::from_millis(EVENT_POLL_INTERVAL_MS))? {
        return Ok(false);
    }

    match event::read()? {
        Event::Key(key) => {
            let outcome = dispatch_event(
                model,
                TuiEvent::KeyPressed(key),
                app,
                services,
                terminal,
                perf,
            )?;
            *should_redraw |= outcome.changed;
            Ok(outcome.should_quit)
        }
        Event::Resize(_, _) => {
            *should_redraw |=
                dispatch_event(model, TuiEvent::Resized, app, services, terminal, perf)?.changed;
            Ok(false)
        }
        _ => Ok(false),
    }
}

#[cfg(test)]
mod tests {
    use std::io;
    use std::sync::{Mutex, MutexGuard};

    use crate::application::{
        AgentView, CreateAgentRequest, StatusReport, TuiApi, TuiAttachReturn, TuiFleetSnapshot,
    };
    use crate::domain::{Agent, AgentId, AgentKind};
    use crate::error::AppError;
    use crate::interface::tui::events::TuiEvent;

    use super::{AttachTerminal, attach_agent};

    fn lock<T>(mutex: &Mutex<T>) -> MutexGuard<'_, T> {
        match mutex.lock() {
            Ok(guard) => guard,
            Err(poisoned) => poisoned.into_inner(),
        }
    }

    struct FakeTerminal {
        restored: usize,
        resumed: usize,
    }

    impl AttachTerminal for FakeTerminal {
        fn restore_for_attach(&mut self) -> io::Result<()> {
            self.restored += 1;
            Ok(())
        }

        fn resume_after_attach(&mut self) -> io::Result<()> {
            self.resumed += 1;
            Ok(())
        }
    }

    struct FakeTuiApp {
        connect_calls: Mutex<Vec<String>>,
        connect_error: Mutex<Option<String>>,
        attach_return: Mutex<Option<TuiAttachReturn>>,
    }

    impl FakeTuiApp {
        fn with_connect_error(message: impl Into<String>) -> Self {
            Self {
                connect_calls: Mutex::new(Vec::new()),
                connect_error: Mutex::new(Some(message.into())),
                attach_return: Mutex::new(None),
            }
        }

        fn with_attach_return(attach_return: TuiAttachReturn) -> Self {
            Self {
                connect_calls: Mutex::new(Vec::new()),
                connect_error: Mutex::new(None),
                attach_return: Mutex::new(Some(attach_return)),
            }
        }
    }

    impl Default for FakeTuiApp {
        fn default() -> Self {
            Self {
                connect_calls: Mutex::new(Vec::new()),
                connect_error: Mutex::new(None),
                attach_return: Mutex::new(None),
            }
        }
    }

    impl TuiApi for FakeTuiApp {
        fn tui_refresh_interval_ms(&self) -> u64 {
            500
        }

        fn tui_list_agents(&self) -> Result<Vec<AgentView>, AppError> {
            Ok(Vec::new())
        }

        fn tui_status_report(&self) -> Result<StatusReport, AppError> {
            Ok(StatusReport {
                tmux_available: true,
                managed_tmux_conf: "/tmp/tmux.conf".to_string(),
                managed_tmux_conf_in_sync: true,
                sqlite_db_path: "/tmp/ox.sqlite".to_string(),
                config_path: "/tmp/config.json".to_string(),
                agent_count: 0,
                attached_agent_count: 0,
            })
        }

        fn tui_create_agent(
            &self,
            _request: CreateAgentRequest,
        ) -> Result<TuiFleetSnapshot, AppError> {
            unreachable!("not used in attach test")
        }

        fn tui_rename_agent(
            &self,
            _id: &AgentId,
            _new_display_name: &str,
        ) -> Result<TuiFleetSnapshot, AppError> {
            unreachable!("not used in attach test")
        }

        fn tui_delete_agent(&self, _id: &AgentId) -> Result<TuiFleetSnapshot, AppError> {
            unreachable!("not used in attach test")
        }

        fn tui_switch_agent_to_worktree_shell(
            &self,
            _id: &AgentId,
            _branch_name: &str,
        ) -> Result<TuiFleetSnapshot, AppError> {
            unreachable!("not used in attach test")
        }

        fn tui_connect_agent(&self, id: &AgentId) -> Result<(), AppError> {
            lock(&self.connect_calls).push(id.as_str().to_string());
            if let Some(message) = lock(&self.connect_error).clone() {
                Err(AppError::InvalidInput { message })
            } else {
                Ok(())
            }
        }

        fn tui_resolve_attach_return(
            &self,
            requested_id: &AgentId,
            _attach_started_at_unix_ms: u128,
        ) -> Result<TuiAttachReturn, AppError> {
            Ok(lock(&self.attach_return)
                .clone()
                .unwrap_or_else(|| TuiAttachReturn {
                    id: requested_id.clone(),
                    name: "alpha".to_string(),
                }))
        }

        fn tui_capture_agent_output(&self, _id: &AgentId, _lines: u16) -> Result<String, AppError> {
            unreachable!("not used in attach test")
        }

        fn tui_send_key_to_agent(&self, _id: &AgentId, _key: &str) -> Result<(), AppError> {
            unreachable!("not used in attach test")
        }
    }

    fn sample_agent_id() -> AgentId {
        Agent::new("alpha".to_string(), AgentKind::Shell, 0).id()
    }

    #[test]
    fn attach_agent_restores_and_resumes_terminal_on_success() -> io::Result<()> {
        let app = FakeTuiApp::default();
        let mut terminal = FakeTerminal {
            restored: 0,
            resumed: 0,
        };
        let id = sample_agent_id();

        let outcome = attach_agent(&mut terminal, &app, &id, "alpha".to_string(), false)?;

        assert_eq!(terminal.restored, 1);
        assert_eq!(terminal.resumed, 1);
        assert!(outcome.changed);
        assert_eq!(
            lock(&app.connect_calls).as_slice(),
            &[id.as_str().to_string()]
        );
        assert!(matches!(
            outcome.follow_up_events.as_slice(),
            [TuiEvent::AgentAttached {
                id: attached_id,
                result: Ok(()),
                ..
            }] if attached_id.as_str() == id.as_str()
        ));
        Ok(())
    }

    #[test]
    fn attach_agent_resumes_terminal_even_when_connect_fails() -> io::Result<()> {
        let app = FakeTuiApp::with_connect_error("boom");
        let mut terminal = FakeTerminal {
            restored: 0,
            resumed: 0,
        };
        let id = sample_agent_id();

        let outcome = attach_agent(&mut terminal, &app, &id, "alpha".to_string(), true)?;

        assert_eq!(terminal.restored, 1);
        assert_eq!(terminal.resumed, 1);
        assert!(matches!(
            outcome.follow_up_events.as_slice(),
            [TuiEvent::AgentAttached {
                from_search_mode: true,
                result: Err(message),
                ..
            }] if message == "invalid input: boom"
        ));
        Ok(())
    }

    #[test]
    fn attach_agent_uses_resolved_return_target_after_quick_switch() -> io::Result<()> {
        let requested_id = sample_agent_id();
        let resolved_id = Agent::new("beta".to_string(), AgentKind::Shell, 0).id();
        let app = FakeTuiApp::with_attach_return(TuiAttachReturn {
            id: resolved_id.clone(),
            name: "beta".to_string(),
        });
        let mut terminal = FakeTerminal {
            restored: 0,
            resumed: 0,
        };

        let outcome = attach_agent(
            &mut terminal,
            &app,
            &requested_id,
            "alpha".to_string(),
            false,
        )?;

        assert_eq!(
            lock(&app.connect_calls).as_slice(),
            &[requested_id.as_str().to_string()]
        );
        assert!(matches!(
            outcome.follow_up_events.as_slice(),
            [TuiEvent::AgentAttached {
                id,
                name,
                result: Ok(()),
                ..
            }] if id.as_str() == resolved_id.as_str() && name == "beta"
        ));
        Ok(())
    }
}
