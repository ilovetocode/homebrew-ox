use std::sync::Arc;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
use std::sync::mpsc::{self, Receiver, RecvTimeoutError, SyncSender, TrySendError};
use std::thread;
use std::time::Duration;

use crate::application::{AgentView, TuiApi};
use crate::domain::AgentId;
use crate::interface::tui::events::TuiEvent;
use crate::interface::tui::format::now_unix_ms;
use crate::interface::tui::worker::{BackgroundWorker, LatestMessage, try_signal};

pub(super) struct RuntimeServices {
    refresh: RefreshService,
    preview: PreviewService,
}

impl RuntimeServices {
    pub(super) fn start(app: Arc<dyn TuiApi>, refresh_interval: Duration) -> Self {
        Self {
            refresh: RefreshService::start(Arc::clone(&app), refresh_interval),
            preview: PreviewService::start(app),
        }
    }

    pub(super) fn request_agents_refresh(&self) {
        self.refresh.request_refresh();
    }

    pub(super) fn request_preview_capture(&self, agent_id: AgentId, lines: u16) {
        self.preview.request_capture(agent_id, lines);
    }

    pub(super) fn drain_events(&self) -> Vec<TuiEvent> {
        let mut events = Vec::new();
        if let Some(event) = self.refresh.take_event() {
            events.push(event);
        }
        if let Some(event) = self.preview.take_event() {
            events.push(event);
        }
        events
    }

    pub(super) fn stop(self) {
        self.refresh.stop();
        self.preview.stop();
    }
}

struct RefreshService {
    signal_receiver: Receiver<()>,
    request_sender: SyncSender<()>,
    latest_message: LatestMessage<RefreshMessage>,
    worker: BackgroundWorker,
    coalesced_updates: Arc<AtomicU64>,
}

impl RefreshService {
    fn start(app: Arc<dyn TuiApi>, interval: Duration) -> Self {
        let (signal_sender, signal_receiver) = mpsc::sync_channel(1);
        let (request_sender, request_receiver) = mpsc::sync_channel(1);
        let latest_message = LatestMessage::new();
        let shutdown = Arc::new(AtomicBool::new(false));
        let worker_shutdown = Arc::clone(&shutdown);
        let worker_latest_message = latest_message.worker_handle();
        let coalesced_updates = Arc::new(AtomicU64::new(0));
        let worker_coalesced_updates = Arc::clone(&coalesced_updates);

        let handle = thread::spawn(move || {
            while !worker_shutdown.load(Ordering::Relaxed) {
                let message = match app.tui_list_agents() {
                    Ok(agents) => RefreshMessage::Snapshot {
                        agents,
                        refreshed_at_unix_ms: now_unix_ms(),
                    },
                    Err(err) => RefreshMessage::Error(err.to_string()),
                };
                worker_latest_message.replace(message);

                match try_signal(&signal_sender) {
                    Ok(()) => {}
                    Err(TrySendError::Full(())) => {
                        worker_coalesced_updates.fetch_add(1, Ordering::Relaxed);
                    }
                    Err(TrySendError::Disconnected(())) => break,
                }

                if let Err(RecvTimeoutError::Disconnected) = request_receiver.recv_timeout(interval)
                {
                    break;
                }
            }
        });

        Self {
            signal_receiver,
            request_sender,
            latest_message,
            worker: BackgroundWorker::new(shutdown, handle),
            coalesced_updates,
        }
    }

    fn request_refresh(&self) {
        let _ = self.request_sender.try_send(());
    }

    fn take_event(&self) -> Option<TuiEvent> {
        match self
            .latest_message
            .take_if_signaled(&self.signal_receiver)?
        {
            RefreshMessage::Snapshot {
                agents,
                refreshed_at_unix_ms,
            } => Some(TuiEvent::AgentsRefreshed {
                agents,
                refreshed_at_unix_ms,
                coalesced_updates: self.coalesced_updates.load(Ordering::Relaxed),
            }),
            RefreshMessage::Error(message) => Some(TuiEvent::AgentsRefreshFailed { message }),
        }
    }

    fn stop(self) {
        let _ = self.request_sender.try_send(());
        self.worker.stop();
    }
}

enum RefreshMessage {
    Snapshot {
        agents: Vec<AgentView>,
        refreshed_at_unix_ms: u128,
    },
    Error(String),
}

struct PreviewService {
    signal_receiver: Receiver<()>,
    request_sender: SyncSender<PreviewRequest>,
    latest_message: LatestMessage<PreviewMessage>,
    worker: BackgroundWorker,
}

impl PreviewService {
    fn start(app: Arc<dyn TuiApi>) -> Self {
        let (signal_sender, signal_receiver) = mpsc::sync_channel(1);
        let (request_sender, request_receiver) = mpsc::sync_channel(1);
        let latest_message = LatestMessage::new();
        let shutdown = Arc::new(AtomicBool::new(false));
        let worker_shutdown = Arc::clone(&shutdown);
        let worker_latest = latest_message.worker_handle();

        let handle = thread::spawn(move || {
            while !worker_shutdown.load(Ordering::Relaxed) {
                let request = match request_receiver.recv_timeout(Duration::from_millis(200)) {
                    Ok(request) => request,
                    Err(RecvTimeoutError::Timeout) => continue,
                    Err(RecvTimeoutError::Disconnected) => break,
                };

                let PreviewRequest::Capture { agent_id, lines } = request;
                let started = std::time::Instant::now();
                let message = match app.tui_capture_agent_output(&agent_id, lines) {
                    Ok(output) => PreviewMessage::Snapshot {
                        agent_id,
                        output,
                        capture_ms: u64::try_from(started.elapsed().as_millis())
                            .unwrap_or(u64::MAX),
                    },
                    Err(err) => PreviewMessage::Error {
                        agent_id,
                        message: format!("preview unavailable: {err}"),
                        capture_ms: u64::try_from(started.elapsed().as_millis())
                            .unwrap_or(u64::MAX),
                    },
                };

                worker_latest.replace(message);
                match signal_sender.try_send(()) {
                    Ok(()) | Err(TrySendError::Full(())) => {}
                    Err(TrySendError::Disconnected(())) => break,
                }
            }
        });

        Self {
            signal_receiver,
            request_sender,
            latest_message,
            worker: BackgroundWorker::new(shutdown, handle),
        }
    }

    fn request_capture(&self, agent_id: AgentId, lines: u16) {
        let _ = self
            .request_sender
            .try_send(PreviewRequest::Capture { agent_id, lines });
    }

    fn take_event(&self) -> Option<TuiEvent> {
        match self
            .latest_message
            .take_if_signaled(&self.signal_receiver)?
        {
            PreviewMessage::Snapshot {
                agent_id,
                output,
                capture_ms,
            } => Some(TuiEvent::PreviewLoaded {
                agent_id,
                output,
                capture_ms,
            }),
            PreviewMessage::Error {
                agent_id,
                message,
                capture_ms,
            } => Some(TuiEvent::PreviewFailed {
                agent_id,
                message,
                capture_ms,
            }),
        }
    }

    fn stop(self) {
        self.worker.stop();
    }
}

enum PreviewRequest {
    Capture { agent_id: AgentId, lines: u16 },
}

enum PreviewMessage {
    Snapshot {
        agent_id: AgentId,
        output: String,
        capture_ms: u64,
    },
    Error {
        agent_id: AgentId,
        message: String,
        capture_ms: u64,
    },
}

#[cfg(test)]
mod tests {
    use std::sync::{Arc, Mutex, MutexGuard};
    use std::thread;
    use std::time::{Duration, Instant};

    use crate::application::{
        CreateAgentRequest, RuntimeStatus, StatusReport, TuiApi, TuiAttachReturn, TuiFleetSnapshot,
    };
    use crate::domain::{Agent, AgentId, AgentKind};
    use crate::error::AppError;
    use crate::interface::tui::events::TuiEvent;

    use super::RuntimeServices;

    fn lock<T>(mutex: &Mutex<T>) -> MutexGuard<'_, T> {
        match mutex.lock() {
            Ok(guard) => guard,
            Err(poisoned) => poisoned.into_inner(),
        }
    }

    struct FakeTuiApp {
        preview_output: Mutex<String>,
        preview_error: Mutex<Option<String>>,
    }

    impl FakeTuiApp {
        fn with_preview_result(result: Result<String, AppError>) -> Self {
            match result {
                Ok(output) => Self {
                    preview_output: Mutex::new(output),
                    preview_error: Mutex::new(None),
                },
                Err(err) => Self {
                    preview_output: Mutex::new(String::new()),
                    preview_error: Mutex::new(Some(err.to_string())),
                },
            }
        }
    }

    impl Default for FakeTuiApp {
        fn default() -> Self {
            Self {
                preview_output: Mutex::new("preview text".to_string()),
                preview_error: Mutex::new(None),
            }
        }
    }

    impl TuiApi for FakeTuiApp {
        fn tui_refresh_interval_ms(&self) -> u64 {
            5
        }

        fn tui_list_agents(&self) -> Result<Vec<crate::application::AgentView>, AppError> {
            Ok(vec![crate::application::AgentView {
                agent: Agent::new("alpha".to_string(), AgentKind::Shell, 0),
                runtime_status: RuntimeStatus::Running,
                attached: false,
                working_dir: None,
                git_root: None,
                git_worktree_path: None,
                git_branch: None,
                git_base_ref: None,
            }])
        }

        fn tui_status_report(&self) -> Result<StatusReport, AppError> {
            Ok(StatusReport {
                tmux_available: true,
                managed_tmux_conf: "/tmp/tmux.conf".to_string(),
                managed_tmux_conf_in_sync: true,
                sqlite_db_path: "/tmp/ox.sqlite".to_string(),
                config_path: "/tmp/config.json".to_string(),
                agent_count: 1,
                attached_agent_count: 0,
            })
        }

        fn tui_create_agent(
            &self,
            _request: CreateAgentRequest,
        ) -> Result<TuiFleetSnapshot, AppError> {
            unreachable!("not used in runtime services test")
        }

        fn tui_rename_agent(
            &self,
            _id: &AgentId,
            _new_display_name: &str,
        ) -> Result<TuiFleetSnapshot, AppError> {
            unreachable!("not used in runtime services test")
        }

        fn tui_delete_agent(&self, _id: &AgentId) -> Result<TuiFleetSnapshot, AppError> {
            unreachable!("not used in runtime services test")
        }

        fn tui_switch_agent_to_worktree_shell(
            &self,
            _id: &AgentId,
            _branch_name: &str,
        ) -> Result<TuiFleetSnapshot, AppError> {
            unreachable!("not used in runtime services test")
        }

        fn tui_connect_agent(&self, _id: &AgentId) -> Result<(), AppError> {
            unreachable!("not used in runtime services test")
        }

        fn tui_resolve_attach_return(
            &self,
            _requested_id: &AgentId,
            _attach_started_at_unix_ms: u128,
        ) -> Result<TuiAttachReturn, AppError> {
            unreachable!("not used in runtime services test")
        }

        fn tui_capture_agent_output(&self, _id: &AgentId, _lines: u16) -> Result<String, AppError> {
            if let Some(message) = lock(&self.preview_error).clone() {
                Err(AppError::InvalidInput { message })
            } else {
                Ok(lock(&self.preview_output).clone())
            }
        }

        fn tui_send_key_to_agent(&self, _id: &AgentId, _key: &str) -> Result<(), AppError> {
            unreachable!("not used in runtime services test")
        }
    }

    fn wait_for_event(
        services: &RuntimeServices,
        timeout: Duration,
        predicate: impl Fn(&TuiEvent) -> bool,
    ) -> Option<TuiEvent> {
        let started = Instant::now();
        while started.elapsed() < timeout {
            for event in services.drain_events() {
                if predicate(&event) {
                    return Some(event);
                }
            }
            thread::sleep(Duration::from_millis(5));
        }
        None
    }

    #[test]
    fn refresh_service_reports_coalesced_updates() -> Result<(), String> {
        let app: Arc<dyn TuiApi> = Arc::new(FakeTuiApp::default());
        let services = RuntimeServices::start(app, Duration::from_millis(5));

        thread::sleep(Duration::from_millis(40));
        let event = wait_for_event(&services, Duration::from_millis(40), |event| {
            matches!(event, TuiEvent::AgentsRefreshed { .. })
        })
        .ok_or_else(|| "timed out waiting for refresh event".to_string())?;
        services.stop();

        match event {
            TuiEvent::AgentsRefreshed {
                coalesced_updates, ..
            } => {
                assert!(coalesced_updates > 0);
                Ok(())
            }
            _ => Err("expected agent refresh event".to_string()),
        }
    }

    #[test]
    fn preview_service_emits_loaded_event() -> Result<(), String> {
        let app: Arc<dyn TuiApi> = Arc::new(FakeTuiApp::with_preview_result(Ok(
            "preview text".to_string()
        )));
        let services = RuntimeServices::start(app, Duration::from_millis(50));
        let agent_id = Agent::new("alpha".to_string(), AgentKind::Shell, 0).id();

        services.request_preview_capture(agent_id.clone(), 32);
        let event = wait_for_event(&services, Duration::from_millis(80), |event| {
            matches!(event, TuiEvent::PreviewLoaded { .. })
        })
        .ok_or_else(|| "timed out waiting for preview event".to_string())?;
        services.stop();

        if matches!(
            event,
            TuiEvent::PreviewLoaded {
                agent_id: loaded_id,
                output,
                ..
            } if loaded_id.as_str() == agent_id.as_str() && output == "preview text"
        ) {
            Ok(())
        } else {
            Err("expected loaded preview event".to_string())
        }
    }
}
