use std::io;
use std::sync::Arc;

use crate::application::TuiApi;

mod event_loop;
mod perf;
mod services;
mod terminal;

pub(super) use terminal::{TuiTerminal, restore_terminal, setup_terminal};

pub(super) fn run(app: &Arc<dyn TuiApi>, startup: super::StartupScreen) -> io::Result<()> {
    event_loop::run(app, startup)
}
