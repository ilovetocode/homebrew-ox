use serde_json::Value;
use serde_json::json;

/// Build a stable JSON error envelope for CLI command failures.
pub(crate) fn render_error_json(message: &str) -> Value {
    json!({
        "ok": false,
        "error": {
            "message": message,
        }
    })
}

#[cfg(test)]
mod tests {
    use super::render_error_json;

    #[test]
    fn render_error_json_wraps_message() {
        let payload = render_error_json("boom");
        assert_eq!(payload["ok"].as_bool(), Some(false));
        assert_eq!(payload["error"]["message"].as_str(), Some("boom"));
    }
}
