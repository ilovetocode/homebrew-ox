use serde_json::Value;
use serde_json::json;

use crate::application::ConversationMessage;

/// Render-ready row for one `ox agents read` target outcome.
pub(crate) struct ReadOutcomeRow {
    pub(crate) id: String,
    pub(crate) name: String,
    pub(crate) agent_kind: String,
    pub(crate) has_worktree: bool,
    pub(crate) ok: bool,
    pub(crate) messages: Vec<ConversationMessage>,
    pub(crate) source: Option<String>,
    pub(crate) partial: bool,
    pub(crate) error: Option<String>,
}

/// Convert one normalized conversation message to output JSON.
pub(crate) fn conversation_message_json(message: &ConversationMessage) -> Value {
    json!({
        "message_id": message.message_id,
        "role": message.role,
        "created_at_unix_ms": message.created_at_unix_ms,
        "completed_at_unix_ms": message.completed_at_unix_ms,
        "text": message.text,
        "tool_names": message.tool_names,
        "patch_files": message.patch_files,
        "finish_reason": message.finish_reason,
        "synthesized_text": message.synthesized_text,
    })
}

/// Build JSON payload for bulk `ox agents read` output.
pub(crate) fn render_read_json(rows: &[ReadOutcomeRow], mode: &str, ok: bool) -> Value {
    let targets = rows
        .iter()
        .map(|row| {
            let messages = row
                .messages
                .iter()
                .map(conversation_message_json)
                .collect::<Vec<_>>();
            json!({
                "id": row.id,
                "name": row.name,
                "agent_kind": row.agent_kind,
                "has_worktree": row.has_worktree,
                "ok": row.ok,
                "source": row.source,
                "partial": row.partial,
                "error": row.error,
                "messages": messages,
            })
        })
        .collect::<Vec<_>>();

    json!({
        "action": "agents_read",
        "mode": mode,
        "targets": targets,
        "ok": ok,
    })
}

/// Build line-oriented output for bulk `ox agents read` output.
pub(crate) fn render_read_lines(rows: &[ReadOutcomeRow]) -> Vec<String> {
    let mut lines = Vec::new();
    for row in rows {
        let source = row.source.as_deref().unwrap_or("-");
        lines.push(format!(
            "== {} ({}, source={source}, partial={}) ==",
            row.name, row.agent_kind, row.partial
        ));
        if row.ok {
            if row.messages.is_empty() {
                lines.push("(no messages)".to_string());
            } else {
                for message in &row.messages {
                    lines.push(format!("[{}] {}", message.role, message.text));
                }
            }
        } else {
            lines.push(format!(
                "(error) {}",
                row.error.as_deref().unwrap_or("unknown error")
            ));
        }
    }
    lines
}

#[cfg(test)]
mod tests {
    use super::{ReadOutcomeRow, conversation_message_json, render_read_json, render_read_lines};
    use crate::application::ConversationMessage;

    fn sample_message() -> ConversationMessage {
        ConversationMessage {
            message_id: "msg_1".to_string(),
            role: "assistant".to_string(),
            created_at_unix_ms: 1,
            completed_at_unix_ms: Some(2),
            text: "hello".to_string(),
            tool_names: vec!["bash".to_string()],
            patch_files: vec!["src/main.rs".to_string()],
            finish_reason: Some("stop".to_string()),
            synthesized_text: true,
        }
    }

    #[test]
    fn conversation_message_json_includes_expected_fields() {
        let payload = conversation_message_json(&sample_message());
        assert_eq!(payload["message_id"].as_str(), Some("msg_1"));
        assert_eq!(payload["role"].as_str(), Some("assistant"));
        assert_eq!(payload["synthesized_text"].as_bool(), Some(true));
    }

    #[test]
    fn render_read_json_includes_mode_and_targets() {
        let payload = render_read_json(
            &[ReadOutcomeRow {
                id: "ag_1".to_string(),
                name: "dev".to_string(),
                agent_kind: "opencode".to_string(),
                has_worktree: true,
                ok: true,
                messages: vec![sample_message()],
                source: Some("opencode_session".to_string()),
                partial: false,
                error: None,
            }],
            "last",
            true,
        );

        assert_eq!(payload["action"].as_str(), Some("agents_read"));
        assert_eq!(payload["mode"].as_str(), Some("last"));
        assert_eq!(payload["ok"].as_bool(), Some(true));
        assert_eq!(
            payload["targets"][0]["agent_kind"].as_str(),
            Some("opencode")
        );
        assert_eq!(payload["targets"][0]["has_worktree"].as_bool(), Some(true));
        assert_eq!(payload["targets"][0]["name"].as_str(), Some("dev"));
        assert_eq!(
            payload["targets"][0]["messages"][0]["text"].as_str(),
            Some("hello")
        );
        assert_eq!(
            payload["targets"][0]["source"].as_str(),
            Some("opencode_session")
        );
        assert_eq!(payload["targets"][0]["partial"].as_bool(), Some(false));
    }

    #[test]
    fn render_read_lines_formats_no_messages_and_errors() {
        let lines = render_read_lines(&[
            ReadOutcomeRow {
                id: "ag_1".to_string(),
                name: "alpha".to_string(),
                agent_kind: "opencode".to_string(),
                has_worktree: false,
                ok: true,
                messages: Vec::new(),
                source: Some("codex_rollout".to_string()),
                partial: true,
                error: None,
            },
            ReadOutcomeRow {
                id: "ag_2".to_string(),
                name: "beta".to_string(),
                agent_kind: "shell".to_string(),
                has_worktree: false,
                ok: false,
                messages: Vec::new(),
                source: None,
                partial: false,
                error: Some("boom".to_string()),
            },
        ]);

        assert_eq!(
            lines[0],
            "== alpha (opencode, source=codex_rollout, partial=true) =="
        );
        assert_eq!(lines[1], "(no messages)");
        assert_eq!(lines[2], "== beta (shell, source=-, partial=false) ==");
        assert_eq!(lines[3], "(error) boom");
    }
}
