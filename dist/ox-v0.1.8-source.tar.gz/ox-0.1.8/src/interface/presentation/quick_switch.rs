use crate::domain::AgentId;

/// Structured quick-switch targets returned from picker selections.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) enum QuickSwitchTarget {
    /// Synthetic destination that maps to "return to dashboard context".
    Dashboard,
    Agent {
        id: AgentId,
        name: String,
    },
}
