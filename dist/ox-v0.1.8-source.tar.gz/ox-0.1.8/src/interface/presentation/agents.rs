use crate::application::AgentView;
use crate::interface::presentation::agent_kind::agent_kind_label;
use crate::interface::presentation::quick_switch::QuickSwitchTarget;
use serde_json::Value;
use serde_json::json;

/// One renderable column for compact `ox agents list` rows.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum AgentsListColumn {
    Position,
    Name,
    Kind,
    Status,
    Branch,
    Repo,
    Worktree,
    Attached,
    Id,
}

/// Human-oriented rendering options for `ox agents list`.
#[derive(Clone, Debug, Default)]
pub(crate) struct AgentsListRenderOptions {
    pub(crate) long: bool,
    pub(crate) columns: Vec<AgentsListColumn>,
}

/// Build the JSON payload for `ox agents list`.
pub(crate) fn render_agents_list_json(agents: &[AgentView]) -> Value {
    let agents_json = agents
        .iter()
        .enumerate()
        .map(|(index, agent)| {
            json!({
                "position": index + 1,
                "name": agent.agent.display_name(),
                "id": agent.agent.id().as_str(),
                "agent_kind": agent_kind_label(agent.agent.kind()),
                "runtime_status": agent.runtime_status.as_label(),
                "attached": agent.attached,
                "working_dir": agent.working_dir,
                "git_root": agent.git_root,
                "git_worktree_path": agent.git_worktree_path,
                "git_branch": agent.git_branch,
                "git_base_ref": agent.git_base_ref
            })
        })
        .collect::<Vec<_>>();

    json!({
        "action": "agents_list",
        "summary": summary_json(agents),
        "agents": agents_json,
        "ok": true,
    })
}

/// Build line-oriented output for `ox agents list`.
pub(crate) fn render_agents_list_lines(
    agents: &[AgentView],
    options: &AgentsListRenderOptions,
) -> Vec<String> {
    let mut lines = vec![render_agents_summary(agents)];
    if options.long {
        lines.extend(render_agents_long_lines(agents));
    } else {
        lines.extend(render_agents_compact_lines(agents, options));
    }
    lines
}

/// Build JSON payload for `ox agents pick`.
pub(crate) fn render_pick_json(selected: Option<QuickSwitchTarget>) -> Value {
    match selected {
        Some(QuickSwitchTarget::Dashboard) => {
            json!({
                "action": "agents_pick",
                "target": "dashboard",
                "ok": true
            })
        }
        Some(QuickSwitchTarget::Agent { name, id }) => {
            json!({
                "action": "agents_pick",
                "target": "agent",
                "id": id.as_str(),
                "name": name,
                "ok": true
            })
        }
        None => {
            json!({
                "action": "agents_pick",
                "target": null,
                "ok": true
            })
        }
    }
}

/// Return a compact human-facing repo/worktree label for one agent.
pub(crate) fn compact_agent_repo(agent: &AgentView) -> String {
    agent
        .git_worktree_path
        .as_deref()
        .or(agent.git_root.as_deref())
        .or(agent.working_dir.as_deref())
        .map_or_else(|| "-".to_string(), compact_path)
}

/// Shorten long filesystem paths for scan-friendly list and picker output.
pub(crate) fn compact_path(path: &str) -> String {
    let components = path
        .split('/')
        .filter(|component| !component.is_empty())
        .collect::<Vec<_>>();
    if components.is_empty() {
        return "-".to_string();
    }

    if let Some(index) = components
        .iter()
        .position(|component| *component == ".worktrees")
        && index > 0
        && index + 1 < components.len()
    {
        return format!(
            "{}/{}/{}",
            components[index - 1],
            components[index],
            components[index + 1]
        );
    }

    match components.as_slice() {
        [last] => (*last).to_string(),
        [.., prev, last] => format!("{prev}/{last}"),
        _ => path.to_string(),
    }
}

fn summary_json(agents: &[AgentView]) -> Value {
    json!({
        "total": agents.len(),
        "attached": agents.iter().filter(|agent| agent.attached).count(),
        "running": count_by_status(agents, "running"),
        "waiting": count_by_status(agents, "waiting"),
        "unknown": count_by_status(agents, "unknown"),
    })
}

fn count_by_status(agents: &[AgentView], status: &str) -> usize {
    agents
        .iter()
        .filter(|agent| agent.runtime_status.as_label() == status)
        .count()
}

fn render_agents_summary(agents: &[AgentView]) -> String {
    format!(
        "{} agents  {} attached  {} running  {} waiting  {} unknown",
        agents.len(),
        agents.iter().filter(|agent| agent.attached).count(),
        count_by_status(agents, "running"),
        count_by_status(agents, "waiting"),
        count_by_status(agents, "unknown"),
    )
}

fn render_agents_compact_lines(
    agents: &[AgentView],
    options: &AgentsListRenderOptions,
) -> Vec<String> {
    let columns = if options.columns.is_empty() {
        vec![
            AgentsListColumn::Kind,
            AgentsListColumn::Status,
            AgentsListColumn::Branch,
            AgentsListColumn::Repo,
        ]
    } else {
        options.columns.clone()
    };

    agents
        .iter()
        .enumerate()
        .map(|(index, agent)| {
            let attached_marker = if agent.attached { "@" } else { " " };
            let rendered_columns = columns
                .iter()
                .map(|column| render_column(*column, agent, index))
                .collect::<Vec<_>>()
                .join("  ");
            format!(
                "{}. {attached_marker}{}  {rendered_columns}",
                render_position(agent, index),
                agent.agent.display_name(),
            )
        })
        .collect()
}

fn render_agents_long_lines(agents: &[AgentView]) -> Vec<String> {
    let mut lines = Vec::new();
    for (index, agent) in agents.iter().enumerate() {
        lines.push(format!(
            "{}. {} ({})  kind={}  attached={}",
            render_position(agent, index),
            agent.agent.display_name(),
            agent.agent.id().as_str(),
            agent_kind_label(agent.agent.kind()),
            agent.attached
        ));
        lines.push(format!(
            "    status={}  branch={}  repo={}  worktree={}",
            agent.runtime_status.as_label(),
            agent.git_branch.as_deref().unwrap_or("-"),
            compact_agent_repo(agent),
            agent
                .git_worktree_path
                .as_deref()
                .map_or_else(|| "-".to_string(), compact_path)
        ));
        lines.push(format!(
            "    working_dir={}  git_root={}  base_ref={}",
            agent.working_dir.as_deref().unwrap_or("-"),
            agent.git_root.as_deref().unwrap_or("-"),
            agent.git_base_ref.as_deref().unwrap_or("-"),
        ));
    }
    lines
}

fn render_column(column: AgentsListColumn, agent: &AgentView, index: usize) -> String {
    match column {
        AgentsListColumn::Position => format!("position:{}", render_position(agent, index)),
        AgentsListColumn::Name => format!("name:{}", agent.agent.display_name()),
        AgentsListColumn::Kind => format!("kind:{}", agent_kind_label(agent.agent.kind())),
        AgentsListColumn::Status => format!("status:{}", agent.runtime_status.as_label()),
        AgentsListColumn::Branch => {
            format!("branch:{}", agent.git_branch.as_deref().unwrap_or("-"))
        }
        AgentsListColumn::Repo => format!("repo:{}", compact_agent_repo(agent)),
        AgentsListColumn::Worktree => format!(
            "worktree:{}",
            agent
                .git_worktree_path
                .as_deref()
                .map_or_else(|| "-".to_string(), compact_path)
        ),
        AgentsListColumn::Attached => format!("attached:{}", agent.attached),
        AgentsListColumn::Id => format!("id:{}", agent.agent.id().as_str()),
    }
}

fn render_position(agent: &AgentView, index: usize) -> usize {
    usize::try_from(agent.agent.display_order())
        .ok()
        .filter(|position| *position > 0)
        .unwrap_or(index + 1)
}

#[cfg(test)]
mod tests {
    use serde_json::Value;

    use super::{
        AgentsListColumn, AgentsListRenderOptions, render_agents_list_json,
        render_agents_list_lines, render_pick_json,
    };
    use crate::application::AgentView;
    use crate::application::RuntimeStatus;
    use crate::domain::{Agent, AgentKind};
    use crate::interface::presentation::quick_switch::QuickSwitchTarget;

    fn sample_agent(name: &str, status: RuntimeStatus) -> AgentView {
        AgentView {
            agent: Agent::new(name.to_string(), AgentKind::Shell, 0),
            runtime_status: status,
            attached: false,
            working_dir: None,
            git_root: None,
            git_worktree_path: None,
            git_branch: None,
            git_base_ref: None,
        }
    }

    #[test]
    fn json_empty_agents_returns_empty_array() {
        let payload = render_agents_list_json(&[]);
        assert_eq!(payload["action"].as_str(), Some("agents_list"));
        assert_eq!(payload["ok"].as_bool(), Some(true));
        let agents = payload.get("agents").and_then(Value::as_array);
        assert_eq!(agents.map(Vec::len), Some(0));
        assert_eq!(payload["summary"]["total"].as_u64(), Some(0));
    }

    #[test]
    fn json_includes_name_runtime_status_and_attached_fields() {
        let agents = vec![sample_agent("dev", RuntimeStatus::Running)];
        let payload = render_agents_list_json(&agents);
        let first = &payload["agents"][0];
        assert_eq!(first["position"].as_i64(), Some(1));
        assert_eq!(first["name"].as_str(), Some("dev"));
        assert_eq!(first["runtime_status"].as_str(), Some("running"));
        assert_eq!(first["agent_kind"].as_str(), Some("shell"));
        assert_eq!(first["attached"].as_bool(), Some(false));
    }

    #[test]
    fn json_includes_git_fields_as_null_when_absent() {
        let agents = vec![sample_agent("a", RuntimeStatus::Unknown)];
        let payload = render_agents_list_json(&agents);
        let first = &payload["agents"][0];
        assert!(first["working_dir"].is_null());
        assert!(first["git_root"].is_null());
        assert!(first["git_worktree_path"].is_null());
        assert!(first["git_branch"].is_null());
        assert!(first["git_base_ref"].is_null());
    }

    #[test]
    fn lines_empty_agents_returns_summary_only() {
        let lines = render_agents_list_lines(&[], &AgentsListRenderOptions::default());
        assert_eq!(
            lines,
            vec!["0 agents  0 attached  0 running  0 waiting  0 unknown".to_string()]
        );
    }

    #[test]
    fn lines_include_compact_fields() {
        let agents = vec![sample_agent("ops", RuntimeStatus::Unknown)];
        let lines = render_agents_list_lines(&agents, &AgentsListRenderOptions::default());
        assert_eq!(lines.len(), 2);
        assert!(lines[1].starts_with("1.  ops"));
        assert!(lines[1].contains("status:unknown"));
    }

    #[test]
    fn lines_render_branch_dash_when_none() {
        let agents = vec![sample_agent("x", RuntimeStatus::Unknown)];
        let lines = render_agents_list_lines(&agents, &AgentsListRenderOptions::default());
        assert!(lines[1].contains("branch:-"));
    }

    #[test]
    fn lines_honor_custom_columns() {
        let agents = vec![sample_agent("x", RuntimeStatus::Waiting)];
        let lines = render_agents_list_lines(
            &agents,
            &AgentsListRenderOptions {
                long: false,
                columns: vec![AgentsListColumn::Name, AgentsListColumn::Status],
            },
        );
        assert!(lines[1].contains("name:x"));
        assert!(lines[1].contains("status:waiting"));
    }

    #[test]
    fn pick_json_dashboard_target() {
        let payload = render_pick_json(Some(QuickSwitchTarget::Dashboard));
        assert_eq!(payload["target"].as_str(), Some("dashboard"));
        assert_eq!(payload["ok"].as_bool(), Some(true));
    }

    #[test]
    fn pick_json_none_target() {
        let payload = render_pick_json(None);
        assert!(payload["target"].is_null());
        assert_eq!(payload["ok"].as_bool(), Some(true));
    }

    #[test]
    fn pick_json_agent_target() {
        let id = crate::domain::AgentId::parse("agent_test123");
        let Some(id) = id else { return };
        let payload = render_pick_json(Some(QuickSwitchTarget::Agent {
            id,
            name: "dev".to_string(),
        }));
        assert_eq!(payload["target"].as_str(), Some("agent"));
        assert_eq!(payload["name"].as_str(), Some("dev"));
    }
}
