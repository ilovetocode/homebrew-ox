use crate::application::AgentKind;

/// Shared user-facing label for one agent kind.
pub(crate) fn agent_kind_label(agent_kind: AgentKind) -> &'static str {
    agent_kind.as_str()
}

#[cfg(test)]
mod tests {
    use super::agent_kind_label;
    use crate::application::AgentKind;

    #[test]
    fn shell_label() {
        assert_eq!(agent_kind_label(AgentKind::Shell), "shell");
    }

    #[test]
    fn codex_label() {
        assert_eq!(agent_kind_label(AgentKind::Codex), "codex");
    }

    #[test]
    fn opencode_label() {
        assert_eq!(agent_kind_label(AgentKind::Opencode), "opencode");
    }

    #[test]
    fn claude_label() {
        assert_eq!(agent_kind_label(AgentKind::Claude), "claude");
    }
}
