use serde_json::Value;
use serde_json::json;

/// Render-ready row for one `ox agents send` target outcome.
pub(crate) struct SendOutcomeRow {
    pub(crate) id: String,
    pub(crate) name: String,
    pub(crate) agent_kind: String,
    pub(crate) has_worktree: bool,
    pub(crate) ok: bool,
    pub(crate) dispatch_id: Option<String>,
    pub(crate) error: Option<String>,
}

/// Build JSON payload for bulk `ox agents send` output.
pub(crate) fn render_send_json(rows: &[SendOutcomeRow], enter: bool, ok: bool) -> Value {
    let targets = rows
        .iter()
        .map(|row| {
            json!({
                "id": row.id,
                "name": row.name,
                "agent_kind": row.agent_kind,
                "has_worktree": row.has_worktree,
                "ok": row.ok,
                "dispatch_id": row.dispatch_id,
                "error": row.error,
            })
        })
        .collect::<Vec<_>>();

    json!({
        "action": "agents_send",
        "mode": "bulk",
        "enter": enter,
        "targets": targets,
        "ok": ok,
    })
}

/// Build line-oriented output for bulk `ox agents send` output.
pub(crate) fn render_send_lines(rows: &[SendOutcomeRow]) -> Vec<String> {
    rows.iter()
        .map(|row| {
            if row.ok {
                match row.dispatch_id.as_deref() {
                    Some(dispatch_id) => format!("{}\tok\tdispatch_id={dispatch_id}", row.name),
                    None => format!("{}\tok", row.name),
                }
            } else {
                format!(
                    "{}\terror\t{}",
                    row.name,
                    row.error.as_deref().unwrap_or("unknown error")
                )
            }
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::{SendOutcomeRow, render_send_json, render_send_lines};

    #[test]
    fn render_send_json_includes_target_rows() {
        let payload = render_send_json(
            &[SendOutcomeRow {
                id: "ag_1".to_string(),
                name: "dev".to_string(),
                agent_kind: "opencode".to_string(),
                has_worktree: true,
                ok: true,
                dispatch_id: Some("dispatch_1".to_string()),
                error: None,
            }],
            true,
            true,
        );

        assert_eq!(payload["action"].as_str(), Some("agents_send"));
        assert_eq!(payload["enter"].as_bool(), Some(true));
        assert_eq!(payload["ok"].as_bool(), Some(true));
        assert_eq!(
            payload["targets"][0]["agent_kind"].as_str(),
            Some("opencode")
        );
        assert_eq!(payload["targets"][0]["has_worktree"].as_bool(), Some(true));
        assert_eq!(payload["targets"][0]["id"].as_str(), Some("ag_1"));
        assert_eq!(
            payload["targets"][0]["dispatch_id"].as_str(),
            Some("dispatch_1")
        );
    }

    #[test]
    fn render_send_lines_formats_success_and_error_rows() {
        let lines = render_send_lines(&[
            SendOutcomeRow {
                id: "ag_1".to_string(),
                name: "alpha".to_string(),
                agent_kind: "opencode".to_string(),
                has_worktree: false,
                ok: true,
                dispatch_id: None,
                error: None,
            },
            SendOutcomeRow {
                id: "ag_2".to_string(),
                name: "beta".to_string(),
                agent_kind: "shell".to_string(),
                has_worktree: false,
                ok: false,
                dispatch_id: None,
                error: Some("boom".to_string()),
            },
        ]);

        assert_eq!(lines[0], "alpha\tok");
        assert_eq!(lines[1], "beta\terror\tboom");
    }
}
