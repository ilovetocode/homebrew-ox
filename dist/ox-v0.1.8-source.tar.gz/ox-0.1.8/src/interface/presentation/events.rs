use crate::application::{EventOutcome, LoggedEvent};
use serde_json::Value;
use serde_json::json;

/// Build the JSON payload for `ox events`.
pub(crate) fn render_events_json(events: &[LoggedEvent]) -> Value {
    let events_json = events
        .iter()
        .map(|event| {
            json!({
                "timestamp_unix_ms": event.timestamp_unix_ms,
                "timestamp": format_timestamp(event.timestamp_unix_ms),
                "op_id": event.op_id,
                "feature": event.feature,
                "action": event.action,
                "target": event.target,
                "outcome": outcome_label(&event.outcome),
                "detail": event.detail
            })
        })
        .collect::<Vec<_>>();
    json!({
        "action": "events",
        "events": events_json,
        "ok": true,
    })
}

/// Build line-oriented output for `ox events`.
pub(crate) fn render_events_lines(events: &[LoggedEvent], verbose: bool) -> Vec<String> {
    events
        .iter()
        .map(|event| {
            let target = event.target.as_deref().unwrap_or("-");
            let detail = event.detail.as_deref().unwrap_or("");
            let op_id = if verbose {
                format!("  {}", event.op_id)
            } else {
                String::new()
            };
            let detail_suffix = if detail.is_empty() {
                String::new()
            } else {
                format!("  {detail}")
            };
            format!(
                "{}{}  {}/{}  {}  {}{}",
                format_timestamp(event.timestamp_unix_ms),
                op_id,
                event.feature,
                event.action,
                target,
                outcome_label(&event.outcome),
                detail_suffix
            )
        })
        .collect()
}

fn outcome_label(outcome: &EventOutcome) -> &'static str {
    match outcome {
        EventOutcome::Success => "success",
        EventOutcome::Failure => "failure",
    }
}

fn format_timestamp(timestamp_unix_ms: u128) -> String {
    let total_seconds = i64::try_from(timestamp_unix_ms / 1_000).unwrap_or(i64::MAX);
    let days = total_seconds.div_euclid(86_400);
    let seconds_of_day = total_seconds.rem_euclid(86_400);
    let (year, month, day) = civil_from_days(days);
    let hour = seconds_of_day / 3_600;
    let minute = (seconds_of_day % 3_600) / 60;
    let second = seconds_of_day % 60;
    format!("{year:04}-{month:02}-{day:02} {hour:02}:{minute:02}:{second:02}Z")
}

fn civil_from_days(days_since_unix_epoch: i64) -> (i64, u32, u32) {
    // Howard Hinnant's civil-date conversion keeps time formatting dependency-free.
    let z = days_since_unix_epoch + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
    let doe = z - era * 146_097;
    let yoe = (doe - doe / 1_460 + doe / 36_524 - doe / 146_096) / 365;
    let mut year = yoe + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let day = doy - (153 * mp + 2) / 5 + 1;
    let month = mp + if mp < 10 { 3 } else { -9 };
    if month <= 2 {
        year += 1;
    }
    (
        year,
        u32::try_from(month).unwrap_or(1),
        u32::try_from(day).unwrap_or(1),
    )
}

#[cfg(test)]
mod tests {
    use serde_json::Value;

    use super::{outcome_label, render_events_json, render_events_lines};
    use crate::application::{EventOutcome, LoggedEvent};

    fn sample_event(action: &str, outcome: EventOutcome) -> LoggedEvent {
        LoggedEvent {
            timestamp_unix_ms: 1_700_000_000_000,
            op_id: "op_1".to_string(),
            feature: "agents".to_string(),
            action: action.to_string(),
            target: Some("dev".to_string()),
            outcome,
            detail: None,
        }
    }

    #[test]
    fn outcome_label_success() {
        assert_eq!(outcome_label(&EventOutcome::Success), "success");
    }

    #[test]
    fn outcome_label_failure() {
        assert_eq!(outcome_label(&EventOutcome::Failure), "failure");
    }

    #[test]
    fn json_empty_events_returns_empty_array() {
        let payload = render_events_json(&[]);
        assert_eq!(payload["action"].as_str(), Some("events"));
        assert_eq!(payload["ok"].as_bool(), Some(true));
        let events = payload.get("events").and_then(Value::as_array);
        assert_eq!(events.map(Vec::len), Some(0));
    }

    #[test]
    fn json_includes_all_fields() {
        let events = vec![sample_event("create", EventOutcome::Success)];
        let payload = render_events_json(&events);
        let first = &payload["events"][0];
        assert_eq!(first["feature"].as_str(), Some("agents"));
        assert_eq!(first["action"].as_str(), Some("create"));
        assert_eq!(first["target"].as_str(), Some("dev"));
        assert_eq!(first["outcome"].as_str(), Some("success"));
        assert!(first["detail"].is_null());
    }

    #[test]
    fn json_failure_event_includes_outcome() {
        let events = vec![sample_event("delete", EventOutcome::Failure)];
        let payload = render_events_json(&events);
        assert_eq!(payload["events"][0]["outcome"].as_str(), Some("failure"));
    }

    #[test]
    fn lines_empty_events_returns_empty_vec() {
        let lines = render_events_lines(&[], false);
        assert!(lines.is_empty());
    }

    #[test]
    fn lines_include_human_timestamp_and_core_fields() {
        let events = vec![sample_event("create", EventOutcome::Success)];
        let lines = render_events_lines(&events, false);
        assert_eq!(lines.len(), 1);
        assert!(lines[0].contains("agents/create"));
        assert!(lines[0].contains("dev"));
        assert!(lines[0].contains("success"));
    }

    #[test]
    fn lines_render_dash_for_none_target() {
        let mut event = sample_event("list", EventOutcome::Success);
        event.target = None;
        let lines = render_events_lines(&[event], false);
        assert!(lines[0].contains(" - "));
    }
}
