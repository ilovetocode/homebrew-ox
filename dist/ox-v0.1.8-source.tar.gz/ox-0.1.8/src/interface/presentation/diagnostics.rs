use crate::application::{DoctorReport, StatusReport};
use serde_json::Value;
use serde_json::json;

/// Build JSON output for `ox status`.
pub(crate) fn render_status_json(report: &StatusReport) -> Value {
    json!({
        "action": "status",
        "summary": render_status_summary(report),
        "status": {
            "tmux_available": report.tmux_available,
            "managed_tmux_conf": report.managed_tmux_conf,
            "managed_tmux_conf_in_sync": report.managed_tmux_conf_in_sync,
            "sqlite_db_path": report.sqlite_db_path,
            "config_path": report.config_path,
            "agent_count": report.agent_count,
            "attached_agent_count": report.attached_agent_count
        },
        "ok": true,
    })
}

/// Render status report into line-oriented output.
pub(crate) fn render_status_lines(report: &StatusReport, verbose: bool) -> Vec<String> {
    let mut lines = vec![render_status_summary(report)];
    lines.push(format!(
        "tmux config: {} ({})",
        report.managed_tmux_conf,
        if report.managed_tmux_conf_in_sync {
            "in sync"
        } else {
            "out of sync"
        }
    ));
    lines.push(format!(
        "storage: sqlite={}  config={}",
        report.sqlite_db_path, report.config_path
    ));
    if verbose {
        lines.push(format!(
            "details: tmux_available={}  managed_tmux_conf_in_sync={}",
            report.tmux_available, report.managed_tmux_conf_in_sync
        ));
    }
    lines
}

/// Build JSON output for `ox doctor`.
pub(crate) fn render_doctor_json(report: &DoctorReport) -> Value {
    let failures = report.checks.iter().filter(|check| !check.ok).count();
    let checks = report
        .checks
        .iter()
        .map(|check| {
            json!({
                "name": check.name,
                "ok": check.ok,
                "detail": check.detail
            })
        })
        .collect::<Vec<_>>();
    json!({
        "action": "doctor",
        "summary": {
            "failing_checks": failures,
            "passing_checks": report.checks.len().saturating_sub(failures),
        },
        "checks": checks,
        "ok": true,
    })
}

/// Render doctor checks into line-oriented output.
pub(crate) fn render_doctor_lines(report: &DoctorReport, verbose: bool) -> Vec<String> {
    let failures = report
        .checks
        .iter()
        .filter(|check| !check.ok)
        .collect::<Vec<_>>();
    let passes = report
        .checks
        .iter()
        .filter(|check| check.ok)
        .collect::<Vec<_>>();

    let mut lines = vec![format!(
        "doctor: {} failing  {} passing",
        failures.len(),
        passes.len()
    )];
    lines.extend(
        failures
            .iter()
            .map(|check| format_check(check.name, check.ok, &check.detail)),
    );
    if verbose || failures.is_empty() {
        lines.extend(
            passes
                .iter()
                .map(|check| format_check(check.name, check.ok, &check.detail)),
        );
    } else if !passes.is_empty() {
        lines.push(format!(
            "{} passing checks hidden; rerun with --verbose to inspect them",
            passes.len()
        ));
    }
    lines
}

fn format_check(name: &str, ok: bool, detail: &str) -> String {
    let status = if ok { "PASS" } else { "FAIL" };
    if detail.is_empty() {
        format!("[{status}] {name}")
    } else {
        format!("[{status}] {name}: {detail}")
    }
}

fn render_status_summary(report: &StatusReport) -> String {
    format!(
        "tmux {}  {} managed agents  {} attached  config {}",
        if report.tmux_available {
            "ok"
        } else {
            "missing"
        },
        report.agent_count,
        report.attached_agent_count,
        if report.managed_tmux_conf_in_sync {
            "in sync"
        } else {
            "out of sync"
        }
    )
}

#[cfg(test)]
mod tests {
    use super::{render_doctor_json, render_doctor_lines, render_status_json, render_status_lines};
    use crate::application::{CheckResult, DoctorReport, StatusReport};

    fn sample_status_report() -> StatusReport {
        StatusReport {
            tmux_available: true,
            managed_tmux_conf: "/tmp/tmux.conf".to_string(),
            managed_tmux_conf_in_sync: true,
            sqlite_db_path: "/tmp/ox/ox.db".to_string(),
            config_path: "/tmp/ox/config.json".to_string(),
            agent_count: 3,
            attached_agent_count: 1,
        }
    }

    #[test]
    fn status_renderer_shows_counts_when_present() {
        let report = sample_status_report();
        let lines = render_status_lines(&report, false);
        assert!(lines[0].contains("3 managed agents"));
        assert!(lines[0].contains("1 attached"));
    }

    #[test]
    fn status_json_includes_all_fields() {
        let report = sample_status_report();
        let json = render_status_json(&report);
        assert_eq!(json["action"].as_str(), Some("status"));
        assert_eq!(json["ok"].as_bool(), Some(true));
        assert_eq!(json["status"]["tmux_available"].as_bool(), Some(true));
        assert_eq!(
            json["status"]["sqlite_db_path"].as_str(),
            Some("/tmp/ox/ox.db")
        );
        assert_eq!(
            json["status"]["config_path"].as_str(),
            Some("/tmp/ox/config.json")
        );
        assert_eq!(json["status"]["agent_count"].as_u64(), Some(3));
        assert_eq!(json["status"]["attached_agent_count"].as_u64(), Some(1));
    }

    #[test]
    fn doctor_json_includes_checks() {
        let report = DoctorReport {
            checks: vec![
                CheckResult {
                    name: "tmux",
                    ok: true,
                    detail: "found".to_string(),
                },
                CheckResult {
                    name: "db",
                    ok: false,
                    detail: "missing".to_string(),
                },
            ],
        };
        let json = render_doctor_json(&report);
        let checks = json["checks"].as_array();
        let Some(checks) = checks else {
            return;
        };
        assert_eq!(json["action"].as_str(), Some("doctor"));
        assert_eq!(json["ok"].as_bool(), Some(true));
        assert_eq!(checks.len(), 2);
        assert_eq!(checks[0]["name"].as_str(), Some("tmux"));
        assert_eq!(checks[0]["ok"].as_bool(), Some(true));
        assert_eq!(checks[1]["ok"].as_bool(), Some(false));
        assert_eq!(checks[1]["detail"].as_str(), Some("missing"));
    }

    #[test]
    fn doctor_json_empty_checks() {
        let report = DoctorReport { checks: Vec::new() };
        let json = render_doctor_json(&report);
        let checks = json["checks"].as_array();
        assert_eq!(checks.map(Vec::len), Some(0));
    }

    #[test]
    fn doctor_renderer_formats_pass_and_fail_checks() {
        let report = DoctorReport { checks: Vec::new() };
        let lines = render_doctor_lines(&report, false);
        assert_eq!(lines[0], "doctor: 0 failing  0 passing");

        assert_eq!(
            super::format_check("tmux binary available", true, ""),
            "[PASS] tmux binary available"
        );
        assert_eq!(
            super::format_check("agent query", false, "tmux failed"),
            "[FAIL] agent query: tmux failed"
        );
    }

    #[test]
    fn doctor_lines_with_populated_checks() {
        let report = DoctorReport {
            checks: vec![
                CheckResult {
                    name: "tmux",
                    ok: true,
                    detail: String::new(),
                },
                CheckResult {
                    name: "db",
                    ok: false,
                    detail: "file not found".to_string(),
                },
            ],
        };
        let lines = render_doctor_lines(&report, true);
        assert_eq!(lines.len(), 3);
        assert_eq!(lines[0], "doctor: 1 failing  1 passing");
        assert_eq!(lines[1], "[FAIL] db: file not found");
        assert_eq!(lines[2], "[PASS] tmux");
    }
}
