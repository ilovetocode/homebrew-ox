use crate::application::{
    AgentKind, AgentView, CreateAgentRequest, WorkspaceBackend, WorkspaceSpec,
};
use crate::domain::AgentId;

/// Build a shared create-agent request for CLI and TUI call-sites.
///
/// Keeping this in the interface layer ensures both interfaces map user input
/// into identical application requests.
pub(crate) fn build_create_agent_request(
    display_name: String,
    agent_kind: AgentKind,
    workspace_backend: WorkspaceBackend,
    workspace_name: Option<String>,
    workspace_repo_root: Option<String>,
) -> CreateAgentRequest {
    let workspace = WorkspaceSpec {
        backend: workspace_backend,
        name: workspace_name,
        repo_root: workspace_repo_root,
        base_ref: None,
    };
    CreateAgentRequest::new(display_name, agent_kind).with_workspace(workspace)
}

/// Resolve the display name of a just-created agent from a refreshed snapshot.
///
/// The fallback keeps status text stable if the created row is unexpectedly
/// missing from the provided list.
pub(crate) fn resolve_created_agent_name(
    agents: &[AgentView],
    created_id: &AgentId,
    fallback: &str,
) -> String {
    agents
        .iter()
        .find(|agent| agent.agent.id() == *created_id)
        .map_or_else(
            || fallback.to_string(),
            |agent| agent.agent.display_name().to_string(),
        )
}

#[cfg(test)]
mod tests {
    use super::{build_create_agent_request, resolve_created_agent_name};
    use crate::application::{AgentView, RuntimeStatus, WorkspaceBackend};
    use crate::domain::{Agent, AgentKind};

    fn make_agent_view(name: &str) -> AgentView {
        let agent = Agent::new(name.to_string(), AgentKind::Shell, 0);
        AgentView {
            agent,
            runtime_status: RuntimeStatus::Unknown,
            attached: false,
            working_dir: None,
            git_root: None,
            git_worktree_path: None,
            git_branch: None,
            git_base_ref: None,
        }
    }

    #[test]
    fn build_create_agent_request_without_worktree_sets_none_spec() {
        let request = build_create_agent_request(
            "dev".to_string(),
            AgentKind::Shell,
            WorkspaceBackend::LocalCurrentTree,
            None,
            Some("/tmp/project".to_string()),
        );

        assert_eq!(request.display_name, "dev");
        assert_eq!(
            request.workspace.backend,
            WorkspaceBackend::LocalCurrentTree
        );
        assert_eq!(request.workspace.name, None);
        assert_eq!(request.workspace.repo_root.as_deref(), Some("/tmp/project"));
        assert!(request.state_spec.git_worktree.is_none());
    }

    #[test]
    fn build_create_agent_request_with_worktree_sets_label_and_repo_root() {
        let request = build_create_agent_request(
            String::new(),
            AgentKind::Claude,
            WorkspaceBackend::LocalWorktree,
            Some("feature-x".to_string()),
            Some("/tmp/repo".to_string()),
        );

        assert_eq!(request.workspace.backend, WorkspaceBackend::LocalWorktree);
        assert_eq!(request.workspace.name.as_deref(), Some("feature-x"));
        assert_eq!(request.workspace.repo_root.as_deref(), Some("/tmp/repo"));
    }

    #[test]
    fn resolve_created_agent_name_prefers_persisted_name() {
        let created = make_agent_view("shell-1");
        let created_id = created.agent.id();
        let agents = vec![created];

        let name = resolve_created_agent_name(&agents, &created_id, "");
        assert_eq!(name, "shell-1");
    }

    #[test]
    fn resolve_created_agent_name_falls_back_when_missing() {
        let created_id = make_agent_view("created").agent.id();
        let agents = vec![make_agent_view("other")];

        let name = resolve_created_agent_name(&agents, &created_id, "requested");
        assert_eq!(name, "requested");
    }
}
