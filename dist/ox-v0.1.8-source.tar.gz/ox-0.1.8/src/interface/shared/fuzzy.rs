/// Return a fuzzy score when `query` matches `candidate` as a subsequence.
///
/// Higher scores are better. `None` means no match.
///
/// The scoring is intentionally simple and stable:
/// - base points for each matched character
/// - bonus for contiguous runs
/// - bonus when a match starts at a word boundary or near the front
pub(crate) fn fuzzy_score(query: &str, candidate: &str) -> Option<i64> {
    let query = query.trim();
    if query.is_empty() {
        return Some(0);
    }

    let query_chars = query.chars().collect::<Vec<_>>();
    let candidate_chars = candidate.chars().collect::<Vec<_>>();

    let mut query_index = 0_usize;
    let mut score = 0_i64;
    let mut last_match_index: Option<usize> = None;

    for (candidate_index, candidate_char) in candidate_chars.iter().enumerate() {
        if query_index >= query_chars.len() {
            break;
        }

        if !candidate_char.eq_ignore_ascii_case(&query_chars[query_index]) {
            continue;
        }

        score += 10;

        if candidate_index == 0 {
            score += 8;
        } else if is_word_boundary(candidate_chars[candidate_index - 1]) {
            score += 5;
        }

        if let Some(previous_index) = last_match_index
            && candidate_index == previous_index + 1
        {
            score += 6;
        }

        // Earlier matches rank above late matches when all else is equal.
        score += (40_i64 - i64::try_from(candidate_index).unwrap_or(40)).max(0);

        last_match_index = Some(candidate_index);
        query_index += 1;
    }

    if query_index == query_chars.len() {
        Some(score)
    } else {
        None
    }
}

fn is_word_boundary(ch: char) -> bool {
    !ch.is_ascii_alphanumeric()
}

/// Sort and filter candidate indices by fuzzy score for `query`.
pub(crate) fn fuzzy_sort_indices(query: &str, candidates: &[String]) -> Vec<usize> {
    if query.trim().is_empty() {
        return (0..candidates.len()).collect();
    }

    let mut scored = candidates
        .iter()
        .enumerate()
        .filter_map(|(index, candidate)| fuzzy_score(query, candidate).map(|score| (index, score)))
        .collect::<Vec<_>>();

    scored.sort_by(|(left_index, left_score), (right_index, right_score)| {
        right_score
            .cmp(left_score)
            .then_with(|| left_index.cmp(right_index))
    });

    scored.into_iter().map(|(index, _)| index).collect()
}

#[cfg(test)]
mod tests {
    use super::{fuzzy_score, fuzzy_sort_indices};

    #[test]
    fn fuzzy_score_matches_subsequence() {
        assert!(fuzzy_score("abc", "a_b_c").is_some());
        assert!(fuzzy_score("abc", "acb").is_none());
    }

    #[test]
    fn fuzzy_score_prefers_contiguous_runs() {
        let contiguous = fuzzy_score("abc", "abc").unwrap_or_default();
        let split = fuzzy_score("abc", "a-b-c").unwrap_or_default();
        assert!(contiguous > split);
    }

    #[test]
    fn fuzzy_score_is_case_insensitive() {
        assert!(fuzzy_score("OX", "ox dashboard").is_some());
        assert!(fuzzy_score("tui", "TUI prompt").is_some());
    }

    #[test]
    fn fuzzy_sort_indices_returns_ranked_matches() {
        let candidates = vec![
            "repo alpha".to_string(),
            "repo beta".to_string(),
            "alpha".to_string(),
        ];
        let ranked = fuzzy_sort_indices("alp", &candidates);
        assert_eq!(ranked, vec![2, 0]);
    }
}
