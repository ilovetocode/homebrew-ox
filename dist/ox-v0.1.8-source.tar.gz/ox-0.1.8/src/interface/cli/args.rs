use clap::{ArgGroup, Args, Parser, Subcommand, ValueEnum};

use crate::application::{AgentKind, RuntimeStatus, WorkspaceBackend};
use crate::interface::cli::commands::agents::filter_policy::{
    AGENTS_READ_AFTER_HELP, AGENTS_SEND_AFTER_HELP,
};
use crate::interface::cli::help_text::{
    AGENTS_AFTER_HELP, AGENTS_ATTACH_AFTER_HELP, AGENTS_CREATE_AFTER_HELP,
    AGENTS_DELETE_AFTER_HELP, AGENTS_LIST_AFTER_HELP, AGENTS_PICK_AFTER_HELP,
    AGENTS_RECONCILE_PINNED_AFTER_HELP, AGENTS_UPDATE_AFTER_HELP, AGENTS_WORKTREE_AFTER_HELP,
    DOCTOR_AFTER_HELP, EVENTS_AFTER_HELP, STATUS_AFTER_HELP, TOP_LEVEL_AFTER_HELP,
    TOP_LEVEL_LONG_ABOUT, TUI_AFTER_HELP,
};

/// Top-level CLI arguments for the `ox` binary.
///
/// `#[derive(Parser)]` asks clap to generate argument parsing code for this
/// struct at compile time. In Rust, this code-generation pattern is called a
/// "derive macro".
#[derive(Parser, Debug)]
#[command(
    author,
    version,
    about = "ox CLI",
    long_about = TOP_LEVEL_LONG_ABOUT,
    after_help = TOP_LEVEL_AFTER_HELP,
    arg_required_else_help = true
)]
pub(crate) struct Cli {
    /// Emit structured JSON output for commands that print results.
    ///
    /// This flag is global so users can pass it before or after subcommands,
    /// for example: `ox --json status` or `ox agents list --json`.
    #[arg(long, global = true)]
    pub(crate) json: bool,

    /// Optional subcommand to run.
    ///
    /// `Option<Command>` means:
    /// - `Some(...)` when the user passed a subcommand (for example: `ox tui`)
    /// - `None` when no subcommand was provided (for example: `ox`)
    #[command(subcommand)]
    pub(crate) command: Option<Command>,
}

/// Supported `ox` subcommands.
///
/// `Subcommand` is another derive macro that generates the glue between enum
/// variants and CLI subcommand names.
#[derive(Subcommand, Debug)]
pub(crate) enum Command {
    /// Launch the text user interface (requires tmux and a valid tmux config path).
    #[command(after_help = TUI_AFTER_HELP)]
    Tui {
        /// Optional TUI screen to open directly on startup.
        #[command(subcommand)]
        screen: Option<TuiScreenCommand>,
    },
    /// Print a quick health summary of tmux + managed ox state (tmux required).
    #[command(after_help = STATUS_AFTER_HELP)]
    Status {
        /// Include raw paths and boolean fields after the human summary.
        #[arg(long)]
        verbose: bool,
    },
    /// Run deeper diagnostics for tmux + managed ox state (tmux required).
    #[command(after_help = DOCTOR_AFTER_HELP)]
    Doctor {
        /// Attempt safe auto-fixes for managed config drift.
        #[arg(long)]
        fix: bool,
        /// Also print passing checks and lower-signal detail.
        #[arg(long)]
        verbose: bool,
    },
    /// Print recent application events from the local event log (tmux required).
    #[command(after_help = EVENTS_AFTER_HELP)]
    Events {
        /// Maximum number of events to print.
        ///
        /// When omitted, ox uses `events_default_limit` from `config.json`.
        #[arg(long)]
        limit: Option<usize>,
        /// Show only failed events.
        #[arg(long)]
        failed: bool,
        /// Restrict output to one agent target.
        #[arg(long = "agent", value_name = "TARGET")]
        agent: Option<String>,
        /// Poll for new matching events until interrupted.
        #[arg(long)]
        follow: bool,
        /// Include opaque operation IDs in line output.
        #[arg(long)]
        verbose: bool,
    },
    /// Commands for working with tmux agents (tmux required).
    #[command(after_help = AGENTS_AFTER_HELP)]
    Agents {
        #[command(subcommand)]
        command: AgentsCommand,
    },
}

/// Optional startup screens under `ox tui`.
#[derive(Subcommand, Debug, Clone, Copy)]
pub(crate) enum TuiScreenCommand {
    /// Open directly on the status screen.
    Status,
    /// Open directly on the search screen.
    Search,
    /// Open directly on the create-agent screen.
    Create,
    /// Open directly on the rename-agent screen.
    Rename,
}

/// Subcommands under `ox agents`.
#[derive(Subcommand, Debug)]
pub(crate) enum AgentsCommand {
    /// List current tmux agents.
    #[command(after_help = AGENTS_LIST_AFTER_HELP)]
    List {
        #[command(flatten)]
        filters: AgentListArgs,
    },
    /// Reconcile pinned sessions (create/heal/reorder) immediately.
    #[command(after_help = AGENTS_RECONCILE_PINNED_AFTER_HELP)]
    ReconcilePinned,
    /// Create a new detached tmux agent by name.
    #[command(after_help = AGENTS_CREATE_AFTER_HELP)]
    Create {
        /// Optional agent name passed to `tmux new-session -d -s <NAME>`.
        ///
        /// When omitted, ox auto-generates `<agent-kind>-<N>` where `N` is the
        /// smallest available positive integer for that kind.
        name: Option<String>,
        /// Agent kind for initial window behavior.
        ///
        /// Defaults to `opencode`. `shell` keeps default tmux behavior (no
        /// explicit command). `codex`, `opencode`, and `claude` execute a
        /// command when the agent starts.
        #[arg(long = "agent-kind", value_enum, default_value_t = AgentKindArg::Opencode)]
        agent_kind: AgentKindArg,
        /// Workspace backend for the agent checkout.
        ///
        /// `local-current-tree` starts in an existing checkout path.
        /// `local-worktree` creates a managed git worktree checkout.
        #[arg(
            long = "workspace-backend",
            value_enum,
            default_value_t = WorkspaceBackendArg::LocalCurrentTree
        )]
        workspace_backend: WorkspaceBackendArg,
        /// Optional workspace name.
        ///
        /// For `local-worktree`, this is used as the worktree/branch label.
        #[arg(long = "workspace-name", value_name = "NAME")]
        workspace_name: Option<String>,
        /// Repository path used as workspace root/context.
        ///
        /// When omitted, ox uses the current process working directory.
        #[arg(long = "repo", value_name = "PATH")]
        repo: Option<String>,
        /// Attach to the created session after provisioning succeeds.
        #[arg(long)]
        attach: bool,
    },
    /// Delete (kill) an existing tmux agent by name.
    #[command(after_help = AGENTS_DELETE_AFTER_HELP)]
    Delete {
        /// Agent selector (`<name>` or `id:<AGENT_ID>`).
        selector: String,
    },
    /// Update a tmux agent (rename or reorder).
    #[command(after_help = AGENTS_UPDATE_AFTER_HELP)]
    Update {
        /// Existing agent selector to update (`<name>` or `id:<AGENT_ID>`).
        selector: String,
        /// New display name for the agent.
        new_name: Option<String>,
        /// Move this agent to the given visual position (swap with occupant).
        #[arg(long = "position")]
        position: Option<i64>,
    },
    /// Attach this terminal to an existing tmux agent.
    #[command(after_help = AGENTS_ATTACH_AFTER_HELP)]
    Attach {
        /// Agent selector (`<name>` or `id:<AGENT_ID>`).
        selector: String,
    },
    /// Recreate an agent as a shell rooted in a managed git worktree.
    #[command(after_help = AGENTS_WORKTREE_AFTER_HELP)]
    Worktree {
        /// Agent selector (`<name>` or `id:<AGENT_ID>`).
        selector: String,
        /// Branch name to create or reuse for the managed worktree.
        branch: String,
        /// Do not attach after the worktree handoff succeeds.
        #[arg(long)]
        detach: bool,
    },
    /// Send one message or opencode slash command to an existing agent.
    #[command(group(
        ArgGroup::new("send_input")
            .args(["input", "message", "file", "stdin"])
            .required(true)
            .multiple(false)
    ))]
    #[command(after_help = AGENTS_SEND_AFTER_HELP)]
    Send {
        #[command(flatten)]
        target: AgentTargetArgs,
        /// Positional message text or opencode slash command input.
        ///
        /// Input that starts with `/` is treated as an opencode slash command.
        /// Any other input is treated as a normal message.
        input: Option<String>,
        /// Literal message text to send.
        ///
        /// Wrap this in quotes when it contains spaces.
        #[arg(long = "message", value_name = "TEXT")]
        message: Option<String>,
        /// Read message text from a file instead of positional `<MESSAGE>`.
        #[arg(long, value_name = "PATH")]
        file: Option<std::path::PathBuf>,
        /// Read message text from standard input (pipe-friendly).
        #[arg(long)]
        stdin: bool,
        /// Also send `Enter` after the message so interactive tools submit it.
        #[arg(long)]
        enter: bool,
    },
    /// Read messages from an agent conversation transcript.
    #[command(after_help = AGENTS_READ_AFTER_HELP)]
    Read {
        #[command(flatten)]
        target: AgentTargetArgs,
        #[command(flatten)]
        read_mode: AgentReadModeArgs,
    },
    /// Open a fuzzy picker and either attach to an agent or choose dashboard.
    #[command(after_help = AGENTS_PICK_AFTER_HELP)]
    Pick,
}

/// Shared target selection arguments used by multi-agent commands.
#[derive(Args, Debug)]
#[command(group(
    ArgGroup::new("target")
        .args(["target_agent", "filter_exprs", "all_targets"])
        .required(true)
        .multiple(false)
))]
pub(crate) struct AgentTargetArgs {
    /// One exact target (`<name>` or `id:<AGENT_ID>`).
    #[arg(long = "agent", value_name = "TARGET", group = "target")]
    pub(crate) target_agent: Option<String>,
    /// Filter expression (for example `name:opencode-*`, `kind:opencode`).
    ///
    /// In command terminology this is a `filter` over many agents, not a
    /// single-agent selector.
    #[arg(
        long = "filter",
        visible_alias = "selector",
        alias = "match",
        value_name = "EXPR",
        group = "target"
    )]
    pub(crate) filter_exprs: Vec<String>,
    /// Target all managed agents returned by `ox agents list`.
    #[arg(long = "all", group = "target")]
    pub(crate) all_targets: bool,
}

/// Filter, sort, and output options for `ox agents list`.
#[derive(Args, Debug, Default)]
pub(crate) struct AgentListArgs {
    /// Filter expression. Repeat to combine filters with AND semantics.
    #[arg(
        long = "filter",
        visible_alias = "selector",
        alias = "match",
        value_name = "EXPR"
    )]
    pub(crate) filter_exprs: Vec<String>,
    /// Restrict the list to agents rooted in the current working repository.
    #[arg(long)]
    pub(crate) current_repo: bool,
    /// Restrict the list to one repository path.
    #[arg(long, value_name = "PATH")]
    pub(crate) repo: Option<String>,
    /// Restrict the list to one runtime-observed agent kind.
    #[arg(long, value_enum)]
    pub(crate) kind: Option<AgentKindArg>,
    /// Restrict the list to one runtime status.
    #[arg(long, value_enum)]
    pub(crate) status: Option<RuntimeStatusArg>,
    /// Restrict the list to currently attached tmux sessions.
    #[arg(long)]
    pub(crate) attached: bool,
    /// Print the expanded multi-line view for each row.
    #[arg(long)]
    pub(crate) long: bool,
    /// Override the default compact column set.
    #[arg(long, value_enum, value_delimiter = ',')]
    pub(crate) columns: Vec<AgentListColumnArg>,
    /// Sort the filtered rows before rendering.
    #[arg(long, value_enum, default_value_t = AgentListSortArg::Position)]
    pub(crate) sort: AgentListSortArg,
}

/// Shared output shape arguments for `ox agents read`.
#[derive(Args, Debug)]
#[command(group(ArgGroup::new("read_mode").args(["last", "full"]).multiple(false)))]
pub(crate) struct AgentReadModeArgs {
    /// Print only the last assistant message.
    #[arg(long, group = "read_mode")]
    pub(crate) last: bool,
    /// Print the full conversation transcript.
    #[arg(long, group = "read_mode")]
    pub(crate) full: bool,
}

/// CLI-only enum for parsing `--agent-kind` values.
#[derive(Debug, Clone, Copy, ValueEnum)]
pub(crate) enum AgentKindArg {
    Shell,
    Codex,
    Opencode,
    Claude,
}

/// CLI-only enum for parsing `--workspace-backend` values.
#[derive(Debug, Clone, Copy, ValueEnum)]
#[value(rename_all = "kebab-case")]
pub(crate) enum WorkspaceBackendArg {
    LocalCurrentTree,
    LocalWorktree,
}

/// CLI-only enum for parsing `--status` values.
#[derive(Debug, Clone, Copy, ValueEnum)]
pub(crate) enum RuntimeStatusArg {
    Running,
    Waiting,
    Unknown,
}

/// CLI-only enum for parsing `ox agents list --sort`.
#[derive(Debug, Clone, Copy, Default, ValueEnum)]
pub(crate) enum AgentListSortArg {
    #[default]
    Position,
    Name,
    Kind,
    Status,
    Repo,
}

/// CLI-only enum for parsing `ox agents list --columns`.
#[derive(Debug, Clone, Copy, PartialEq, Eq, ValueEnum)]
pub(crate) enum AgentListColumnArg {
    Position,
    Name,
    Kind,
    Status,
    Branch,
    Repo,
    Worktree,
    Attached,
    Id,
}

impl From<AgentKindArg> for AgentKind {
    fn from(value: AgentKindArg) -> Self {
        match value {
            AgentKindArg::Shell => AgentKind::Shell,
            AgentKindArg::Codex => AgentKind::Codex,
            AgentKindArg::Opencode => AgentKind::Opencode,
            AgentKindArg::Claude => AgentKind::Claude,
        }
    }
}

impl From<WorkspaceBackendArg> for WorkspaceBackend {
    fn from(value: WorkspaceBackendArg) -> Self {
        match value {
            WorkspaceBackendArg::LocalCurrentTree => WorkspaceBackend::LocalCurrentTree,
            WorkspaceBackendArg::LocalWorktree => WorkspaceBackend::LocalWorktree,
        }
    }
}

impl From<RuntimeStatusArg> for RuntimeStatus {
    fn from(value: RuntimeStatusArg) -> Self {
        match value {
            RuntimeStatusArg::Running => RuntimeStatus::Running,
            RuntimeStatusArg::Waiting => RuntimeStatus::Waiting,
            RuntimeStatusArg::Unknown => RuntimeStatus::Unknown,
        }
    }
}
