mod args;
mod commands;
mod dispatch;
mod help_text;
mod output;
mod picker;

pub(crate) use dispatch::run;
