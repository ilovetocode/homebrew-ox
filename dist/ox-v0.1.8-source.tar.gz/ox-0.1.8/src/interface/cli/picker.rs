use std::io::{self, IsTerminal, Write};

use crate::application::AgentView;
use crate::error::AppError;
use crate::interface::presentation::quick_switch::QuickSwitchTarget;
use crate::interface::tui::picker::{PickerState, PickerTarget, quick_switch_items};
use crossterm::cursor::{Hide, MoveTo, Show};
use crossterm::event::{self, Event, KeyCode, KeyEventKind};
use crossterm::execute;
use crossterm::style::{Attribute, Print, SetAttribute};
use crossterm::terminal::{
    self, Clear, ClearType, EnterAlternateScreen, LeaveAlternateScreen, disable_raw_mode,
    enable_raw_mode,
};

/// Open the built-in quick-switch picker in the current terminal.
pub(super) fn pick_quick_switch_target(
    agents: &[AgentView],
) -> Result<Option<QuickSwitchTarget>, AppError> {
    if !io::stdin().is_terminal() || !io::stdout().is_terminal() {
        return Err(AppError::InvalidInput {
            message: "quick switch requires an interactive TTY".to_string(),
        });
    }

    let mut picker = PickerTerminal::enter()?;
    let mut state = PickerState::new(
        "Quick Switch",
        "no matching agents",
        quick_switch_items(agents),
    );

    loop {
        render_picker(&mut picker.stdout, &state)?;
        match event::read()? {
            Event::Key(key) if key.kind == KeyEventKind::Press => match key.code {
                KeyCode::Esc => return Ok(None),
                KeyCode::Char('c')
                    if key
                        .modifiers
                        .contains(crossterm::event::KeyModifiers::CONTROL) =>
                {
                    return Ok(None);
                }
                KeyCode::Enter => {
                    let Some(item) = state.selected_item() else {
                        return Ok(None);
                    };
                    return Ok(selected_target(item));
                }
                KeyCode::Up | KeyCode::BackTab => state.select_prev(),
                KeyCode::Down | KeyCode::Tab => state.select_next(),
                KeyCode::Backspace => state.backspace_query(),
                KeyCode::Char(ch) => state.append_query(ch),
                _ => {}
            },
            _ => {}
        }
    }
}

fn selected_target(item: &crate::interface::tui::picker::PickerItem) -> Option<QuickSwitchTarget> {
    match &item.target {
        PickerTarget::QuickSwitch(target) => Some(target.clone()),
        PickerTarget::RepoRoot(_) => None,
    }
}

fn render_picker(stdout: &mut io::Stdout, state: &PickerState) -> io::Result<()> {
    let (_, height) = terminal::size()?;
    let list_rows = usize::from(height.saturating_sub(4)).max(1);
    let total_rows = state.filtered_indices.len();
    let selected_index = state
        .selected_filtered_index
        .min(total_rows.saturating_sub(1));
    let start = selected_index.saturating_sub(list_rows / 2);
    let end = total_rows.min(start + list_rows);

    execute!(stdout, MoveTo(0, 0), Clear(ClearType::All))?;
    execute!(
        stdout,
        Print(format!(
            "{}\nquery: {}\n\n",
            state.title,
            if state.query.is_empty() {
                "(type to filter)"
            } else {
                state.query.as_str()
            }
        ))
    )?;

    if total_rows == 0 {
        execute!(stdout, Print(format!("{}\n", state.empty_message)))?;
        stdout.flush()?;
        return Ok(());
    }

    for (visible_offset, item_index) in state.filtered_indices[start..end].iter().enumerate() {
        let Some(item) = state.items.get(*item_index) else {
            continue;
        };
        let is_selected = start + visible_offset == selected_index;
        if is_selected {
            execute!(stdout, SetAttribute(Attribute::Reverse))?;
        }
        execute!(
            stdout,
            Print(format!(
                "{} {:<24} {}\n",
                if is_selected { ">" } else { " " },
                item.label,
                item.detail
            ))
        )?;
        if is_selected {
            execute!(stdout, SetAttribute(Attribute::NoReverse))?;
        }
    }

    execute!(
        stdout,
        Print(format!(
            "\n{} matches  filter {}ms  Enter select  Esc cancel",
            total_rows,
            state.last_recompute_ms()
        ))
    )?;
    stdout.flush()?;
    Ok(())
}

struct PickerTerminal {
    stdout: io::Stdout,
}

impl PickerTerminal {
    fn enter() -> Result<Self, AppError> {
        enable_raw_mode()?;
        let mut stdout = io::stdout();
        execute!(stdout, EnterAlternateScreen, Hide)?;
        Ok(Self { stdout })
    }
}

impl Drop for PickerTerminal {
    fn drop(&mut self) {
        let _ = disable_raw_mode();
        let _ = execute!(self.stdout, Show, LeaveAlternateScreen);
    }
}

#[cfg(test)]
mod tests {
    use super::selected_target;
    use crate::domain::AgentId;
    use crate::interface::presentation::quick_switch::QuickSwitchTarget;
    use crate::interface::tui::picker::{PickerItem, PickerTarget};

    #[test]
    fn selected_target_extracts_quick_switch_target() {
        let Some(id) = AgentId::parse("ag_picker") else {
            return;
        };
        let item = PickerItem {
            label: "alpha".to_string(),
            detail: "codex".to_string(),
            target: PickerTarget::QuickSwitch(QuickSwitchTarget::Agent {
                id,
                name: "alpha".to_string(),
            }),
        };

        assert!(matches!(
            selected_target(&item),
            Some(QuickSwitchTarget::Agent { name, .. }) if name == "alpha"
        ));
    }
}
