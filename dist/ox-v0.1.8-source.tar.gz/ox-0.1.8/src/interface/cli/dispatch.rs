use clap::Parser;
use std::ffi::{OsStr, OsString};
use std::sync::Arc;

use crate::application::{AppApi, TuiApi};
use crate::bootstrap::AppFactory;
use crate::error::AppError;
use crate::interface::cli::args::{Cli, Command, TuiScreenCommand};
use crate::interface::cli::commands::{agents, diagnostics, events};
use crate::interface::presentation::error::render_error_json;
use crate::interface::tui::StartupScreen;

/// Parse CLI arguments and run the command dispatch path.
///
/// # Errors
///
/// Returns an error if the selected subcommand fails, including terminal
/// initialization, rendering, input polling, or terminal restoration failures
/// while running the TUI.
pub(crate) fn run() -> Result<(), AppError> {
    // `Cli::parse()`:
    // - `Cli` is the type (struct) name.
    // - `::` means "associated function on this type" (like a static method).
    // - `parse()` reads command-line args and fills our `Cli` struct.
    // clap also auto-implements `--help` and `--version` based on attributes above.
    let cli = Cli::parse_from(normalize_help_args());
    let Cli { json, command } = cli;
    // `match` is Rust's pattern matching:
    // - compare `command` against patterns
    // - run the code in the matching branch
    //
    // `Some(Command::Tui { .. })` means:
    // - the `Option` has a value (`Some`)
    // - that value is the `Tui` enum variant (optionally with startup screen)
    let result = match command {
        Some(command) => {
            // Build one shared application context per CLI invocation so all
            // command paths use the same configured dependencies and startup
            // preflight checks.
            let app = AppFactory::build()?;
            run_command(command, app, json)
        }
        // No subcommand: do nothing and return success.
        // `Ok(())` means "successful result with unit value".
        None => Ok(()),
    };

    match result {
        Ok(()) => Ok(()),
        Err(err) => {
            if json && !matches!(err, AppError::AlreadyReported) {
                eprintln!("{}", render_error_json(&err.to_string()));
                return Err(AppError::AlreadyReported);
            }
            Err(err)
        }
    }
}

fn normalize_help_args() -> Vec<OsString> {
    let mut args = std::env::args_os().collect::<Vec<_>>();
    let program = args
        .first()
        .cloned()
        .unwrap_or_else(|| OsString::from("ox"));
    let mut tokens = if args.len() > 1 {
        args.split_off(1)
    } else {
        Vec::new()
    };

    // Make bare `ox` behave like `ox --help` for first-time users.
    if tokens.is_empty() {
        append_help_flag(&mut tokens);
    }

    // Accept novice-friendly top-level aliases like `ox h` and `ox assist`.
    if let Some(first) = tokens.first_mut()
        && matches!(first.to_str(), Some("h" | "?" | "assist"))
    {
        *first = OsString::from("help");
    }

    // Support prefix style: `ox help agents send` => `ox agents send --help`.
    if let Some(first) = tokens.first()
        && is_token(first, "help")
    {
        tokens.remove(0);
        append_help_flag(&mut tokens);
    }

    // Support postfix help for common wonky invocations like:
    // - `ox agents help`
    // - `ox agents send help`
    // - `ox tui help`
    // - `ox status help`
    if is_postfix_help_shape(&tokens) {
        tokens.pop();
        append_help_flag(&mut tokens);
    }

    let mut normalized = Vec::with_capacity(tokens.len() + 1);
    normalized.push(program);
    normalized.extend(tokens);
    normalized
}

fn append_help_flag(tokens: &mut Vec<OsString>) {
    tokens.push(OsString::from("--help"));
}

fn is_token(value: &OsStr, expected: &str) -> bool {
    value
        .to_str()
        .is_some_and(|raw| raw.eq_ignore_ascii_case(expected))
}

fn is_postfix_help_shape(tokens: &[OsString]) -> bool {
    if tokens.len() < 2 {
        return false;
    }
    if has_explicit_help_flag(tokens) {
        return false;
    }
    if !tokens.last().is_some_and(|token| is_token(token, "help")) {
        return false;
    }

    let words = tokens
        .iter()
        .filter_map(|token| token.to_str())
        .filter(|token| !token.starts_with('-'))
        .collect::<Vec<_>>();

    matches!(
        words.as_slice(),
        ["agents" | "tui" | "status" | "doctor" | "events", "help"]
            | [
                "agents",
                "list"
                    | "reconcile-pinned"
                    | "create"
                    | "delete"
                    | "update"
                    | "attach"
                    | "worktree"
                    | "send"
                    | "read"
                    | "pick",
                "help"
            ]
            | ["tui", "status" | "search" | "create" | "rename", "help"]
    )
}

fn has_explicit_help_flag(tokens: &[OsString]) -> bool {
    tokens
        .iter()
        .any(|token| is_token(token, "-h") || is_token(token, "--help"))
}

fn run_tui(app: Arc<dyn AppApi>, screen: Option<TuiScreenCommand>) -> Result<(), AppError> {
    let startup = match screen {
        Some(TuiScreenCommand::Status) => StartupScreen::Status,
        Some(TuiScreenCommand::Search) => StartupScreen::Search,
        Some(TuiScreenCommand::Create) => StartupScreen::NewAgent,
        Some(TuiScreenCommand::Rename) => StartupScreen::Rename,
        None => StartupScreen::Dashboard,
    };
    let tui_app: Arc<dyn TuiApi> = app;
    crate::interface::tui::run(&tui_app, startup).map_err(AppError::Io)
}

fn run_command(command: Command, app: Arc<dyn AppApi>, json: bool) -> Result<(), AppError> {
    match command {
        Command::Tui { screen } => run_tui(app, screen),
        Command::Status { verbose } => diagnostics::run_status(app.as_ref(), json, verbose),
        Command::Doctor { fix, verbose } => {
            diagnostics::run_doctor(app.as_ref(), fix, json, verbose)
        }
        Command::Events {
            limit,
            failed,
            agent,
            follow,
            verbose,
        } => events::run_events(
            app.as_ref(),
            &events::EventsArgs {
                limit,
                outcome_filter: if failed {
                    events::EventOutcomeFilter::FailedOnly
                } else {
                    events::EventOutcomeFilter::All
                },
                agent_selector: agent.as_deref(),
                stream_mode: if follow {
                    events::EventsStreamMode::Follow
                } else {
                    events::EventsStreamMode::Once
                },
                output_mode: if json {
                    events::EventsOutputMode::Json
                } else {
                    events::EventsOutputMode::Lines { verbose }
                },
            },
        ),
        Command::Agents { command } => agents::run(app.as_ref(), command, json),
    }
}
