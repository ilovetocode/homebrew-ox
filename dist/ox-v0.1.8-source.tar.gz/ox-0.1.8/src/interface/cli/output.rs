use serde_json::Value;

/// Print one JSON payload when `json_output` is enabled.
pub(crate) fn print_json_if(json_output: bool, payload: &Value) {
    if json_output {
        println!("{payload}");
    }
}

/// Print either structured JSON or line-oriented human output.
pub(crate) fn print_json_or_lines(
    json_output: bool,
    json_payload: &Value,
    lines: impl IntoIterator<Item = String>,
) {
    if json_output {
        println!("{json_payload}");
        return;
    }

    for line in lines {
        println!("{line}");
    }
}
