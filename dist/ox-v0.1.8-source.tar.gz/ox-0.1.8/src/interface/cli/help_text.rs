pub(super) const TOP_LEVEL_LONG_ABOUT: &str = r#"ox CLI

Start here:
  1) List running agents:      ox agents list
  2) Create an agent:          ox agents create my-agent
  3) Send a prompt:            ox agents send --agent my-agent --message "summarize this repo" --enter
  4) Read the latest reply:    ox agents read --agent my-agent --last

All ox commands require tmux to be installed and available on PATH."#;

pub(super) const TOP_LEVEL_AFTER_HELP: &str = r"Examples:
  ox --help
  ox help
  ox h
  ox ?
  ox assist
  ox help agents send
  ox agents send help
  ox agents list --json
  ox agents create api-worker --repo . --workspace-backend local-worktree
  ox agents create feature-a --repo . --workspace-backend local-worktree --workspace-name feature-a

See also:
  ox agents --help
  ox tui --help
  ox doctor --help";

pub(super) const TUI_AFTER_HELP: &str = r"Examples:
  ox tui
  ox tui status
  ox tui search
  ox tui create
  ox tui rename

See also:
  ox status --help
  ox agents --help";

pub(super) const STATUS_AFTER_HELP: &str = r"Examples:
  ox status
  ox status --verbose
  ox status --json

See also:
  ox doctor --help
  ox events --help";

pub(super) const DOCTOR_AFTER_HELP: &str = r"Examples:
  ox doctor
  ox doctor --fix
  ox doctor --verbose
  ox doctor --json

See also:
  ox status --help
  ox events --help";

pub(super) const EVENTS_AFTER_HELP: &str = r"Examples:
  ox events
  ox events --limit 100
  ox events --failed
  ox events --agent @last-attached
  ox events --follow
  ox events --json

See also:
  ox status --help
  ox doctor --help";

pub(super) const AGENTS_AFTER_HELP: &str = r#"Examples:
  ox agents list
  ox agents create my-agent
  ox agents worktree my-agent feature-x
  ox agents send --agent my-agent --message "hello" --enter
  ox agents read --agent my-agent --last

See also:
  ox help agents send
  ox help agents read
  ox agents pick --help"#;

pub(super) const AGENTS_LIST_AFTER_HELP: &str = r"Examples:
  ox agents list
  ox agents list --current-repo
  ox agents list --kind codex --status waiting
  ox agents list --filter repo:current --filter attached:true
  ox agents list --long --sort name
  ox agents list --json

See also:
  ox agents create --help
  ox agents send --help
  ox agents read --help";

pub(super) const AGENTS_RECONCILE_PINNED_AFTER_HELP: &str = r"Examples:
  ox agents reconcile-pinned
  ox agents reconcile-pinned --json

See also:
  ox agents list --help";

pub(super) const AGENTS_CREATE_AFTER_HELP: &str = r"Examples:
  ox agents create my-agent
  ox agents create my-agent --attach
  ox agents create reviewer
  ox agents create api-worker --repo . --workspace-backend local-worktree
  ox agents create feature-a --repo . --workspace-backend local-worktree --workspace-name feature-a

Advanced:
  ox agents create codex-fix --agent-kind codex --repo ./repo --workspace-backend local-worktree --workspace-name bugfix-123

See also:
  ox agents list --help
  ox agents attach --help
  ox agents pick --help";

pub(super) const AGENTS_DELETE_AFTER_HELP: &str = r"Examples:
  ox agents delete my-agent
  ox agents delete id:ag_123

See also:
  ox agents list --help
  ox agents update --help";

pub(super) const AGENTS_UPDATE_AFTER_HELP: &str = r"Examples:
  ox agents update my-agent new-name
  ox agents update id:ag_123 --position 3
  ox agents update my-agent new-name --position 1

See also:
  ox agents list --help
  ox agents delete --help";

pub(super) const AGENTS_ATTACH_AFTER_HELP: &str = r"Examples:
  ox agents attach my-agent
  ox agents attach id:ag_123

See also:
  ox agents pick --help
  ox agents list --help";

pub(super) const AGENTS_WORKTREE_AFTER_HELP: &str = r"Examples:
  ox agents worktree my-agent feature-x
  ox agents worktree id:ag_123 fix-landing
  ox agents worktree my-agent feature-x --detach

See also:
  ox agents create --help
  ox agents attach --help
  ox tui --help";

pub(super) const AGENTS_PICK_AFTER_HELP: &str = r"Examples:
  ox agents pick

See also:
  ox agents attach --help
  ox agents list --help";
