use std::path::{Path, PathBuf};

use crate::application::{AgentView, AppApi, RuntimeStatus};
use crate::domain::{AgentId, AgentKind};
use crate::error::AppError;
use crate::interface::presentation::agent_kind::agent_kind_label;
use std::collections::HashSet;

use super::filter_policy::{
    FilterKey, parse_filter_attached_bool, parse_filter_key_value, parse_filter_kind,
    parse_filter_status, parse_filter_worktree_bool,
};

#[derive(Debug, Clone)]
pub(crate) enum AgentTargetInput {
    Agent(String),
    Filter(Vec<AgentFilterExpr>),
    All,
}

#[derive(Debug, Clone)]
pub(crate) enum AgentFilterExpr {
    NameGlob(String),
    Kind(AgentKind),
    Worktree(bool),
    Repo(RepoFilter),
    Status(RuntimeStatus),
    Attached(bool),
}

#[derive(Debug, Clone)]
pub(crate) enum RepoFilter {
    Current,
    ExactPath(String),
    Glob(String),
}

#[derive(Debug, Clone)]
pub(crate) struct ResolvedTarget {
    pub(crate) id: AgentId,
    pub(crate) name: String,
    pub(crate) kind: AgentKind,
    pub(crate) has_worktree: bool,
}

pub(crate) fn build_target_input(
    target_agent: Option<String>,
    filter_exprs: &[String],
    all_targets: bool,
) -> Result<AgentTargetInput, AppError> {
    if let Some(raw_target) = target_agent {
        return Ok(AgentTargetInput::Agent(raw_target));
    }
    if !filter_exprs.is_empty() {
        return Ok(AgentTargetInput::Filter(parse_filter_exprs(filter_exprs)?));
    }
    if all_targets {
        return Ok(AgentTargetInput::All);
    }
    Err(AppError::InvalidInput {
        message: "target selection requires one of --agent, --filter/--selector/--match, or --all"
            .to_string(),
    })
}

pub(crate) fn parse_filter_exprs(raw_filters: &[String]) -> Result<Vec<AgentFilterExpr>, AppError> {
    raw_filters
        .iter()
        .map(|raw| parse_filter_expr(raw))
        .collect::<Result<Vec<_>, _>>()
}

pub(crate) fn resolve_targets(
    app: &dyn AppApi,
    input: &AgentTargetInput,
) -> Result<Vec<ResolvedTarget>, AppError> {
    let agents = app.list_agents()?;
    let match_context = build_match_context(match input {
        AgentTargetInput::Filter(filters) => filters.as_slice(),
        _ => &[],
    })?;
    let mut selected = match input {
        AgentTargetInput::Agent(raw_target) => {
            vec![resolve_single_agent_target(app, raw_target, &agents)?]
        }
        AgentTargetInput::Filter(expr) => agents
            .iter()
            .filter(|agent| matches_filters(agent, expr, &match_context))
            .map(to_resolved_target)
            .collect(),
        AgentTargetInput::All => agents.iter().map(to_resolved_target).collect(),
    };

    let mut seen = HashSet::new();
    selected.retain(|target| seen.insert(target.id.as_str().to_string()));

    if selected.is_empty() {
        let scope = target_scope_label(input);
        return Err(AppError::InvalidInput {
            message: format!("no agents matched target scope {scope}"),
        });
    }

    Ok(selected)
}

fn resolve_single_agent_target(
    app: &dyn AppApi,
    raw_target: &str,
    agents: &[AgentView],
) -> Result<ResolvedTarget, AppError> {
    if let Some(shortcut) = raw_target.strip_prefix('@') {
        return resolve_shortcut_target(app, shortcut, agents);
    }

    let id = app.resolve_agent_selector(raw_target)?;
    let Some(agent) = agents
        .iter()
        .find(|agent| agent.agent.id().as_str() == id.as_str())
    else {
        return Err(crate::error::AppError::Agent(
            crate::error::AgentError::NotFound,
        ));
    };
    Ok(to_resolved_target(agent))
}

fn resolve_shortcut_target(
    app: &dyn AppApi,
    shortcut: &str,
    agents: &[AgentView],
) -> Result<ResolvedTarget, AppError> {
    match shortcut {
        "attached" => {
            resolve_one_filtered_target(agents, &[AgentFilterExpr::Attached(true)], "@attached")
        }
        "current-repo" => resolve_one_filtered_target(
            agents,
            &[AgentFilterExpr::Repo(RepoFilter::Current)],
            "@current-repo",
        ),
        "last-attached" => resolve_last_attached_target(app, agents),
        _ => Err(AppError::InvalidInput {
            message: format!(
                "unknown reserved agent shortcut '@{shortcut}'; expected one of: @attached, @last-attached, @current-repo"
            ),
        }),
    }
}

fn resolve_last_attached_target(
    app: &dyn AppApi,
    agents: &[AgentView],
) -> Result<ResolvedTarget, AppError> {
    let recent_events = app.recent_events(200)?;
    let Some(last_connect_target) = recent_events.iter().find_map(|event| {
        (event.feature == "agents"
            && event.action == "connect"
            && matches!(event.outcome, crate::application::EventOutcome::Success))
        .then_some(event.target.as_deref())
        .flatten()
    }) else {
        return Err(AppError::InvalidInput {
            message: "reserved target '@last-attached' has no successful attach history yet"
                .to_string(),
        });
    };

    let Some(agent_id) = AgentId::parse(last_connect_target) else {
        return Err(AppError::InvalidInput {
            message: "reserved target '@last-attached' points to an invalid stored agent id"
                .to_string(),
        });
    };
    let Some(agent) = agents
        .iter()
        .find(|agent| agent.agent.id().as_str() == agent_id.as_str())
    else {
        return Err(AppError::InvalidInput {
            message: "reserved target '@last-attached' points to an agent that no longer exists"
                .to_string(),
        });
    };

    Ok(to_resolved_target(agent))
}

fn resolve_one_filtered_target(
    agents: &[AgentView],
    filters: &[AgentFilterExpr],
    label: &str,
) -> Result<ResolvedTarget, AppError> {
    let context = build_match_context(filters)?;
    let matches = agents
        .iter()
        .filter(|agent| matches_filters(agent, filters, &context))
        .collect::<Vec<_>>();
    match matches.as_slice() {
        [agent] => Ok(to_resolved_target(agent)),
        [] => Err(AppError::InvalidInput {
            message: format!("reserved target '{label}' did not match any agents"),
        }),
        _ => Err(AppError::InvalidInput {
            message: format!(
                "reserved target '{label}' matched more than one agent; candidates: {}",
                format_agents_for_error(&matches)
            ),
        }),
    }
}

fn target_scope_label(input: &AgentTargetInput) -> String {
    match input {
        AgentTargetInput::Agent(target) => format!("--agent {target}"),
        AgentTargetInput::Filter(exprs) => {
            format!(
                "filter '{}'",
                exprs
                    .iter()
                    .map(filter_expr_label)
                    .collect::<Vec<_>>()
                    .join(" + ")
            )
        }
        AgentTargetInput::All => "--all".to_string(),
    }
}

fn to_resolved_target(agent: &AgentView) -> ResolvedTarget {
    ResolvedTarget {
        id: agent.agent.id(),
        name: agent.agent.display_name().to_string(),
        kind: agent.agent.kind(),
        has_worktree: agent.git_worktree_path.is_some(),
    }
}

fn filter_expr_label(expr: &AgentFilterExpr) -> String {
    match expr {
        AgentFilterExpr::NameGlob(glob) => format!("name:{glob}"),
        AgentFilterExpr::Kind(kind) => format!("agent_kind:{}", agent_kind_label(*kind)),
        AgentFilterExpr::Worktree(value) => format!("worktree:{value}"),
        AgentFilterExpr::Repo(RepoFilter::Current) => "repo:current".to_string(),
        AgentFilterExpr::Repo(RepoFilter::ExactPath(path)) => format!("repo:{path}"),
        AgentFilterExpr::Repo(RepoFilter::Glob(glob)) => format!("repo:{glob}"),
        AgentFilterExpr::Status(status) => format!("status:{}", status.as_label()),
        AgentFilterExpr::Attached(value) => format!("attached:{value}"),
    }
}

fn parse_filter_expr(raw: &str) -> Result<AgentFilterExpr, AppError> {
    let (key, value) = parse_filter_key_value(raw)?;
    match key {
        FilterKey::Name => Ok(AgentFilterExpr::NameGlob(value.to_string())),
        FilterKey::Kind => parse_filter_kind(value).map(AgentFilterExpr::Kind),
        FilterKey::Worktree => parse_filter_worktree_bool(value).map(AgentFilterExpr::Worktree),
        FilterKey::Repo => Ok(AgentFilterExpr::Repo(parse_repo_filter(value))),
        FilterKey::Status => parse_filter_status(value).map(AgentFilterExpr::Status),
        FilterKey::Attached => parse_filter_attached_bool(value).map(AgentFilterExpr::Attached),
    }
}

pub(crate) fn matches_filters(
    agent: &AgentView,
    filters: &[AgentFilterExpr],
    context: &MatchContext,
) -> bool {
    filters
        .iter()
        .all(|expr| matches_filter(agent, expr, context))
}

#[derive(Debug, Default)]
pub(crate) struct MatchContext {
    current_dir: Option<PathBuf>,
}

pub(crate) fn build_match_context(filters: &[AgentFilterExpr]) -> Result<MatchContext, AppError> {
    if filters
        .iter()
        .any(|expr| matches!(expr, AgentFilterExpr::Repo(RepoFilter::Current)))
    {
        let current_dir = std::env::current_dir().map_err(|source| AppError::InvalidInput {
            message: format!(
                "could not resolve current working directory for repo filter: {source}"
            ),
        })?;
        return Ok(MatchContext {
            current_dir: Some(current_dir),
        });
    }
    Ok(MatchContext::default())
}

fn matches_filter(agent: &AgentView, expr: &AgentFilterExpr, context: &MatchContext) -> bool {
    match expr {
        AgentFilterExpr::NameGlob(pattern) => wildcard_match(pattern, agent.agent.display_name()),
        AgentFilterExpr::Kind(kind) => agent.agent.kind() == *kind,
        AgentFilterExpr::Worktree(enabled) => agent.git_worktree_path.is_some() == *enabled,
        AgentFilterExpr::Repo(repo_filter) => matches_repo_filter(agent, repo_filter, context),
        AgentFilterExpr::Status(status) => agent.runtime_status == *status,
        AgentFilterExpr::Attached(attached) => agent.attached == *attached,
    }
}

fn parse_repo_filter(value: &str) -> RepoFilter {
    if value.eq_ignore_ascii_case("current") {
        RepoFilter::Current
    } else if value.contains('*') {
        RepoFilter::Glob(value.to_string())
    } else {
        RepoFilter::ExactPath(value.to_string())
    }
}

fn matches_repo_filter(
    agent: &AgentView,
    repo_filter: &RepoFilter,
    context: &MatchContext,
) -> bool {
    match repo_filter {
        RepoFilter::Current => context
            .current_dir
            .as_deref()
            .is_some_and(|current_dir| agent_matches_current_repo(agent, current_dir)),
        RepoFilter::ExactPath(path) => agent_repo_candidates(agent)
            .into_iter()
            .any(|candidate| same_or_canonical_path(path, candidate)),
        RepoFilter::Glob(pattern) => agent_repo_candidates(agent)
            .into_iter()
            .any(|candidate| wildcard_match(pattern, candidate)),
    }
}

fn agent_repo_candidates(agent: &AgentView) -> Vec<&str> {
    let mut values = Vec::new();
    if let Some(root) = agent.git_root.as_deref() {
        values.push(root);
    }
    if let Some(worktree) = agent.git_worktree_path.as_deref() {
        values.push(worktree);
    }
    if let Some(working_dir) = agent.working_dir.as_deref() {
        values.push(working_dir);
    }
    values
}

fn agent_matches_current_repo(agent: &AgentView, current_dir: &Path) -> bool {
    agent_repo_candidates(agent).into_iter().any(|candidate| {
        let Ok(candidate_path) = std::fs::canonicalize(candidate) else {
            return false;
        };
        current_dir.starts_with(&candidate_path) || candidate_path.starts_with(current_dir)
    })
}

fn same_or_canonical_path(left: &str, right: &str) -> bool {
    if left == right {
        return true;
    }
    match (
        std::fs::canonicalize(left).ok(),
        std::fs::canonicalize(right).ok(),
    ) {
        (Some(left), Some(right)) => left == right,
        _ => false,
    }
}

fn format_agents_for_error(agents: &[&AgentView]) -> String {
    agents
        .iter()
        .take(5)
        .map(|agent| {
            format!(
                "{} (id:{})",
                agent.agent.display_name(),
                agent.agent.id().as_str()
            )
        })
        .collect::<Vec<_>>()
        .join(", ")
}

fn wildcard_match(pattern: &str, text: &str) -> bool {
    if !pattern.contains('*') {
        return pattern == text;
    }

    let parts = pattern.split('*').collect::<Vec<_>>();
    if parts.is_empty() {
        return true;
    }

    let mut idx = 0usize;
    if let Some(first) = parts.first()
        && !first.is_empty()
    {
        if !text.starts_with(first) {
            return false;
        }
        idx = first.len();
    }

    for part in parts.iter().skip(1).take(parts.len().saturating_sub(2)) {
        if part.is_empty() {
            continue;
        }
        let tail = &text[idx..];
        let Some(found) = tail.find(part) else {
            return false;
        };
        idx += found + part.len();
    }

    if let Some(last) = parts.last()
        && !last.is_empty()
    {
        return text[idx..].ends_with(last);
    }

    true
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_filter_expr_accepts_name_glob() {
        let parsed = parse_filter_expr("name:opencode-*");
        assert!(
            matches!(parsed, Ok(AgentFilterExpr::NameGlob(_))),
            "expected name glob filter variant"
        );
        if let Ok(AgentFilterExpr::NameGlob(value)) = parsed {
            assert_eq!(value, "opencode-*");
        }
    }

    #[test]
    fn parse_filter_expr_accepts_kind() {
        let parsed = parse_filter_expr("kind:opencode");
        assert!(
            matches!(parsed, Ok(AgentFilterExpr::Kind(_))),
            "expected kind filter variant"
        );
        if let Ok(AgentFilterExpr::Kind(kind)) = parsed {
            assert_eq!(kind, AgentKind::Opencode);
        }
    }

    #[test]
    fn parse_filter_expr_accepts_agent_kind() {
        let parsed = parse_filter_expr("agent_kind:opencode");
        assert!(
            matches!(parsed, Ok(AgentFilterExpr::Kind(_))),
            "expected kind filter variant"
        );
        if let Ok(AgentFilterExpr::Kind(kind)) = parsed {
            assert_eq!(kind, AgentKind::Opencode);
        }
    }

    #[test]
    fn filter_expr_label_uses_agent_kind_key() {
        let label = filter_expr_label(&AgentFilterExpr::Kind(AgentKind::Shell));
        assert_eq!(label, "agent_kind:shell");
    }

    #[test]
    fn parse_filter_expr_accepts_worktree_true() {
        let parsed = parse_filter_expr("worktree:true");
        assert!(
            matches!(parsed, Ok(AgentFilterExpr::Worktree(_))),
            "expected worktree filter variant"
        );
        if let Ok(AgentFilterExpr::Worktree(value)) = parsed {
            assert!(value);
        }
    }

    #[test]
    fn parse_filter_expr_rejects_missing_colon() {
        let parsed = parse_filter_expr("name");
        assert!(parsed.is_err(), "expected parse error for missing colon");
    }

    #[test]
    fn parse_filter_expr_rejects_unknown_key() {
        let parsed = parse_filter_expr("foo:bar");
        assert!(parsed.is_err(), "expected parse error for unknown key");
    }

    #[test]
    fn parse_filter_expr_rejects_invalid_worktree_bool() {
        let parsed = parse_filter_expr("worktree:maybe");
        assert!(
            parsed.is_err(),
            "expected parse error for invalid worktree bool"
        );
    }

    #[test]
    fn parse_filter_expr_rejects_invalid_kind() {
        let parsed = parse_filter_expr("kind:python");
        assert!(parsed.is_err(), "expected parse error for invalid kind");
    }

    #[test]
    fn wildcard_match_without_star_is_exact() {
        assert!(wildcard_match("abc", "abc"));
        assert!(!wildcard_match("abc", "abcd"));
    }

    #[test]
    fn wildcard_match_with_prefix_suffix_works() {
        assert!(wildcard_match("open*code", "opencode"));
        assert!(wildcard_match("open*code", "open-source-code"));
        assert!(!wildcard_match("open*code", "code-open"));
    }
}
