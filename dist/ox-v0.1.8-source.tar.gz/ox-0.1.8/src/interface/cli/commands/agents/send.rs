use crate::application::AppApi;
use crate::application::normalize_slash_command;
use crate::domain::AgentKind;
use crate::error::AppError;
use crate::interface::cli::output::print_json_or_lines;
use crate::interface::presentation::agent_kind::agent_kind_label;
use crate::interface::presentation::agents_send::{
    SendOutcomeRow, render_send_json, render_send_lines,
};
use std::io::Read;
use std::path::Path;
use std::thread;
use std::time::Duration;

use super::opencode_policy::{
    slash_command_requires_opencode_error, unsupported_non_opencode_targets,
};
use super::targeting::ResolvedTarget;
use super::{bulk, bulk::BulkOutcome};

pub(super) struct SendArgs<'a> {
    pub(super) targets: &'a [ResolvedTarget],
    pub(super) input: &'a SendInput,
    pub(super) enter: bool,
    pub(super) json_output: bool,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(super) enum SendInput {
    Message(String),
    SlashCommand(String),
}

#[derive(Debug, Clone)]
pub(super) struct SendDispatchOutcome {
    target: ResolvedTarget,
    ok: bool,
    dispatch_id: Option<String>,
    error: Option<String>,
}

impl BulkOutcome for SendDispatchOutcome {
    fn ok(&self) -> bool {
        self.ok
    }
}

pub(super) fn run_send_bulk(app: &dyn AppApi, args: &SendArgs<'_>) -> Result<(), AppError> {
    match args.input {
        SendInput::Message(message) if message.is_empty() => {
            return Err(AppError::InvalidInput {
                message: "message cannot be empty".to_string(),
            });
        }
        SendInput::SlashCommand(_) if args.enter => {
            return Err(AppError::InvalidInput {
                message: "--enter is not supported with slash-command input".to_string(),
            });
        }
        SendInput::SlashCommand(_) => {
            let unsupported = unsupported_non_opencode_targets(
                args.targets
                    .iter()
                    .map(|target| (&target.kind, target.name.as_str())),
            );
            if !unsupported.is_empty() {
                return Err(slash_command_requires_opencode_error(&unsupported));
            }
        }
        SendInput::Message(_) => {}
    }

    bulk::run_bulk(
        args.targets,
        |target| send_to_target(app, target, args.input, args.enter),
        |outcomes| render_send_outcomes(outcomes, args.enter, args.json_output),
        "one or more target operations failed",
    )
}

fn send_to_target(
    app: &dyn AppApi,
    target: &ResolvedTarget,
    input: &SendInput,
    enter: bool,
) -> SendDispatchOutcome {
    let send_result = match input {
        SendInput::SlashCommand(command) => app
            .send_slash_command_to_agent(&target.id, command)
            .map(|result| Some(result.dispatch_id)),
        SendInput::Message(message) if target.kind == AgentKind::Opencode => app
            .send_message_to_agent(&target.id, message)
            .map(|result| Some(result.dispatch_id)),
        SendInput::Message(message) => app
            .send_key_to_agent(&target.id, message)
            .and_then(|()| {
                if !enter {
                    return Ok(());
                }
                if target.kind == AgentKind::Codex {
                    app.send_key_to_agent(&target.id, "Enter")?;
                    thread::sleep(Duration::from_millis(120));
                    app.send_key_to_agent(&target.id, "Enter")?;
                } else {
                    app.send_key_to_agent(&target.id, "Enter")?;
                }
                Ok(())
            })
            .map(|()| None),
    };

    match send_result {
        Ok(dispatch_id) => SendDispatchOutcome {
            target: target.clone(),
            ok: true,
            dispatch_id,
            error: None,
        },
        Err(err) => SendDispatchOutcome {
            target: target.clone(),
            ok: false,
            dispatch_id: None,
            error: Some(err.to_string()),
        },
    }
}

fn render_send_outcomes(outcomes: &[SendDispatchOutcome], enter: bool, json_output: bool) {
    let has_failure = outcomes.iter().any(|outcome| !outcome.ok);
    let rows = outcomes
        .iter()
        .map(|outcome| SendOutcomeRow {
            id: outcome.target.id.as_str().to_string(),
            name: outcome.target.name.clone(),
            agent_kind: agent_kind_label(outcome.target.kind).to_string(),
            has_worktree: outcome.target.has_worktree,
            ok: outcome.ok,
            dispatch_id: outcome.dispatch_id.clone(),
            error: outcome.error.clone(),
        })
        .collect::<Vec<_>>();

    print_json_or_lines(
        json_output,
        &render_send_json(&rows, enter, !has_failure),
        render_send_lines(&rows),
    );
}

pub(super) fn read_send_input(
    input: Option<String>,
    message: Option<String>,
    file: Option<&Path>,
    stdin: bool,
) -> Result<SendInput, AppError> {
    let mut specified_modes = 0;
    if input.is_some() {
        specified_modes += 1;
    }
    if message.is_some() {
        specified_modes += 1;
    }
    if file.is_some() {
        specified_modes += 1;
    }
    if stdin {
        specified_modes += 1;
    }
    if specified_modes != 1 {
        return Err(AppError::InvalidInput {
            message:
                "exactly one input mode is required: <INPUT>, --message <TEXT>, --file <PATH>, or --stdin"
                    .to_string(),
        });
    }

    if let Some(input) = input {
        let trimmed = input.trim();
        if trimmed.starts_with('/') {
            let normalized = normalize_slash_command(trimmed)?;
            return Ok(SendInput::SlashCommand(normalized));
        }
        return Ok(SendInput::Message(input));
    }

    if let Some(message) = message {
        return Ok(SendInput::Message(message));
    }

    if let Some(path) = file {
        return std::fs::read_to_string(path)
            .map(SendInput::Message)
            .map_err(|source| AppError::InvalidInput {
                message: format!("failed to read message file '{}': {source}", path.display()),
            });
    }

    if stdin {
        let mut buffer = String::new();
        std::io::stdin()
            .read_to_string(&mut buffer)
            .map_err(|source| AppError::InvalidInput {
                message: format!("failed to read message from stdin: {source}"),
            })?;
        return Ok(SendInput::Message(buffer));
    }

    Err(AppError::InvalidInput {
        message: "exactly one input mode is required: <INPUT>, --message <TEXT>, --file <PATH>, or --stdin"
            .to_string(),
    })
}

#[cfg(test)]
mod tests {
    use super::{SendInput, read_send_input};

    #[test]
    fn read_send_input_treats_positional_slash_as_slash_command() {
        let input = read_send_input(Some("/consistency".to_string()), None, None, false);
        assert!(matches!(
            input,
            Ok(SendInput::SlashCommand(ref command)) if command == "consistency"
        ));
    }

    #[test]
    fn read_send_input_treats_positional_text_as_message() {
        let input = read_send_input(Some("hello".to_string()), None, None, false);
        assert!(matches!(
            input,
            Ok(SendInput::Message(ref message)) if message == "hello"
        ));
    }

    #[test]
    fn read_send_input_rejects_positional_empty_slash_command() {
        let result = read_send_input(Some("/".to_string()), None, None, false);
        assert!(matches!(
            result,
            Err(ref err) if err.to_string().contains("slash command cannot be empty")
        ));
    }

    #[test]
    fn read_send_input_rejects_conflicting_modes() {
        let result = read_send_input(
            Some("hello".to_string()),
            Some("also-hello".to_string()),
            None,
            false,
        );
        assert!(matches!(
            result,
            Err(ref err) if err
                .to_string()
                .contains("exactly one input mode is required")
        ));
    }
}
