use crate::error::AppError;

pub(super) fn run_bulk<T, O, E, R>(
    targets: &[T],
    execute: E,
    render: R,
    failure_message: &'static str,
) -> Result<(), AppError>
where
    E: Fn(&T) -> O,
    R: Fn(&[O]),
    O: BulkOutcome,
{
    let outcomes = targets.iter().map(execute).collect::<Vec<_>>();
    let has_failure = outcomes.iter().any(|outcome| !outcome.ok());
    render(&outcomes);

    if has_failure {
        return Err(AppError::InvalidInput {
            message: failure_message.to_string(),
        });
    }

    Ok(())
}

pub(super) trait BulkOutcome {
    fn ok(&self) -> bool;
}
