use crate::application::RuntimeStatus;
use crate::domain::{AGENT_KIND_VALUES_CSV, AgentKind};
use crate::error::AppError;

pub(super) const FILTER_KEYS_LIST: &str =
    "name, agent_kind, kind, worktree, repo, status, attached";
pub(super) const FILTER_SYNTAX_BRIEF: &str = "name:<glob>, agent_kind:<kind>, worktree:<true|false>, repo:<glob|current>, status:<status>, attached:<true|false>";

pub(crate) const AGENTS_SEND_AFTER_HELP: &str = r#"Examples:
  ox agents send --agent my-agent "summarize this diff" --enter
  ox agents send --agent my-agent --file ./prompt.txt --enter
  cat ./prompt.txt | ox agents send --agent my-agent --stdin --enter
  ox agents send --agent slash-test /consistency
  ox agents send --agent slash-test "summarize this repo"
  ox agents send --filter "name:feature-*" --message "run tests" --enter
  ox agents send --filter "agent_kind:opencode" --message "report status" --enter
  ox agents send --agent @current-repo --message "report status" --enter
  ox agents send --all --message "sync up" --enter

Filter syntax:
  name:<glob>                 Example: name:opencode-*
  agent_kind:<kind>           shell|codex|opencode|claude
  kind:<kind>                 alias for agent_kind
  worktree:<true|false>       Example: worktree:true
  repo:<glob|current>         Example: repo:current
  status:<status>             running|waiting|unknown
  attached:<true|false>       Example: attached:true

See also:
  ox agents read --help
  ox agents list --help"#;

pub(crate) const AGENTS_READ_AFTER_HELP: &str = r#"Examples:
  ox agents read --agent my-agent --last
  ox agents read --agent my-agent --full
  ox agents read --filter "agent_kind:opencode" --last
  ox agents read --filter "name:feature-*" --full --json
  ox agents read --agent @last-attached --last

Filter syntax:
  name:<glob>                 Example: name:opencode-*
  agent_kind:<kind>           shell|codex|opencode|claude
  kind:<kind>                 alias for agent_kind
  worktree:<true|false>       Example: worktree:true
  repo:<glob|current>         Example: repo:current
  status:<status>             running|waiting|unknown
  attached:<true|false>       Example: attached:true

See also:
  ox agents send --help
  ox agents list --help"#;

pub(super) enum FilterKey {
    Name,
    Kind,
    Worktree,
    Repo,
    Status,
    Attached,
}

pub(super) fn parse_filter_key_value(raw: &str) -> Result<(FilterKey, &str), AppError> {
    let trimmed = raw.trim();
    let Some((raw_key, raw_value)) = trimmed.split_once(':') else {
        return Err(AppError::InvalidInput {
            message: format!(
                "invalid filter '{trimmed}'; expected key:value ({FILTER_SYNTAX_BRIEF})"
            ),
        });
    };

    let key = parse_filter_key(raw_key)?;
    let value = raw_value.trim();
    if value.is_empty() {
        return Err(AppError::InvalidInput {
            message: format!("invalid filter '{trimmed}'; value cannot be empty"),
        });
    }
    Ok((key, value))
}

pub(super) fn parse_filter_kind(value: &str) -> Result<AgentKind, AppError> {
    AgentKind::parse_user_input(value).ok_or_else(|| AppError::InvalidInput {
        message: format!(
            "invalid kind filter value '{value}'; expected one of: {AGENT_KIND_VALUES_CSV}"
        ),
    })
}

pub(super) fn parse_filter_worktree_bool(value: &str) -> Result<bool, AppError> {
    parse_bool_filter("worktree", value)
}

pub(super) fn parse_filter_attached_bool(value: &str) -> Result<bool, AppError> {
    parse_bool_filter("attached", value)
}

pub(super) fn parse_filter_status(value: &str) -> Result<RuntimeStatus, AppError> {
    match value.to_ascii_lowercase().as_str() {
        "running" => Ok(RuntimeStatus::Running),
        "waiting" => Ok(RuntimeStatus::Waiting),
        "unknown" => Ok(RuntimeStatus::Unknown),
        _ => Err(AppError::InvalidInput {
            message: format!(
                "invalid status filter value '{value}'; expected one of: running, waiting, unknown"
            ),
        }),
    }
}

fn parse_bool_filter(label: &str, value: &str) -> Result<bool, AppError> {
    match value.to_ascii_lowercase().as_str() {
        "true" => Ok(true),
        "false" => Ok(false),
        _ => Err(AppError::InvalidInput {
            message: format!("invalid {label} filter value '{value}'; expected true or false"),
        }),
    }
}

fn parse_filter_key(raw_key: &str) -> Result<FilterKey, AppError> {
    let key = raw_key.trim().to_ascii_lowercase();
    match key.as_str() {
        "name" => Ok(FilterKey::Name),
        "agent_kind" | "kind" => Ok(FilterKey::Kind),
        "worktree" => Ok(FilterKey::Worktree),
        "repo" => Ok(FilterKey::Repo),
        "status" => Ok(FilterKey::Status),
        "attached" => Ok(FilterKey::Attached),
        _ => Err(AppError::InvalidInput {
            message: format!("invalid filter key '{key}'; expected one of: {FILTER_KEYS_LIST}"),
        }),
    }
}
