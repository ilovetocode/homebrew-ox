use crate::application::AppApi;
use crate::error::AppError;
use crate::interface::cli::args::{AgentKindArg, WorkspaceBackendArg};
use crate::interface::cli::output::print_json_if;
use crate::interface::presentation::agent_kind::agent_kind_label;
use crate::interface::shared::new_agent::{build_create_agent_request, resolve_created_agent_name};
use serde_json::json;

pub(super) struct CreateAgentArgs {
    pub(super) name: Option<String>,
    pub(super) agent_kind: AgentKindArg,
    pub(super) workspace_backend: WorkspaceBackendArg,
    pub(super) workspace_name: Option<String>,
    pub(super) repo: Option<String>,
    pub(super) attach: bool,
    pub(super) json_output: bool,
}

pub(super) fn run_create(app: &dyn AppApi, args: CreateAgentArgs) -> Result<(), AppError> {
    let CreateAgentArgs {
        name,
        agent_kind,
        workspace_backend,
        workspace_name,
        repo,
        attach,
        json_output,
    } = args;

    let requested_name = name.unwrap_or_default();
    let request = build_create_agent_request(
        requested_name,
        agent_kind.into(),
        workspace_backend.into(),
        workspace_name,
        repo,
    );

    let created_id = app.create_agent(request)?;
    if attach {
        app.connect_agent(&created_id)?;
    }
    let created_agents = app.list_agents()?;
    let created_name = resolve_created_agent_name(&created_agents, &created_id, "");
    print_json_if(
        json_output,
        &json!({
            "action": "create",
            "id": created_id.as_str(),
            "name": created_name,
            "agent_kind": agent_kind_label(agent_kind.into()),
            "workspace_backend": workspace_backend_label(workspace_backend),
            "attached": attach,
            "ok": true
        }),
    );

    Ok(())
}

pub(super) fn run_delete(
    app: &dyn AppApi,
    selector: &str,
    json_output: bool,
) -> Result<(), AppError> {
    let id = app.resolve_agent_selector(selector)?;
    app.delete_agent(&id)?;
    print_json_if(
        json_output,
        &json!({ "action": "delete", "selector": selector, "ok": true }),
    );

    Ok(())
}

pub(super) fn run_update(
    app: &dyn AppApi,
    selector: &str,
    new_name: Option<&str>,
    position: Option<i64>,
    json_output: bool,
) -> Result<(), AppError> {
    let id = app.resolve_agent_selector(selector)?;
    if let Some(new_name) = new_name {
        app.rename_agent(&id, new_name)?;
    }
    if let Some(pos) = position {
        // Re-resolve in case rename changed the name; id is stable.
        app.reorder_agent(&id, pos)?;
    }
    print_json_if(
        json_output,
        &json!({
            "action": "update",
            "selector": selector,
            "new_name": new_name,
            "position": position,
            "ok": true
        }),
    );

    Ok(())
}

pub(super) fn run_attach(
    app: &dyn AppApi,
    selector: &str,
    json_output: bool,
) -> Result<(), AppError> {
    let id = app.resolve_agent_selector(selector)?;
    app.connect_agent(&id)?;
    print_json_if(
        json_output,
        &json!({ "action": "attach", "selector": selector, "ok": true }),
    );

    Ok(())
}

pub(super) fn run_worktree(
    app: &dyn AppApi,
    selector: &str,
    branch: &str,
    detach: bool,
    json_output: bool,
) -> Result<(), AppError> {
    let id = app.resolve_agent_selector(selector)?;
    app.switch_agent_to_worktree_shell(&id, branch)?;
    if !detach {
        app.connect_agent(&id)?;
    }
    print_json_if(
        json_output,
        &json!({
            "action": "worktree",
            "selector": selector,
            "branch": branch,
            "attached": !detach,
            "ok": true
        }),
    );

    Ok(())
}

fn workspace_backend_label(backend: WorkspaceBackendArg) -> &'static str {
    match backend {
        WorkspaceBackendArg::LocalCurrentTree => "local-current-tree",
        WorkspaceBackendArg::LocalWorktree => "local-worktree",
    }
}
