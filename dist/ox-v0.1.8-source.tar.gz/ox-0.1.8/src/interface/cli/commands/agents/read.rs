use crate::application::{AppApi, ConversationMessage, ConversationReadSource};
use crate::error::AppError;
use crate::interface::cli::output::print_json_or_lines;
use crate::interface::presentation::agents_read::{
    ReadOutcomeRow, render_read_json, render_read_lines,
};

use super::targeting::ResolvedTarget;
use super::{bulk, bulk::BulkOutcome};
use crate::interface::presentation::agent_kind::agent_kind_label;

#[derive(Debug, Clone, Copy)]
pub(super) enum ReadMode {
    Last,
    Full,
}

pub(super) struct ReadArgs<'a> {
    pub(super) targets: &'a [ResolvedTarget],
    pub(super) mode: ReadMode,
    pub(super) json_output: bool,
}

#[derive(Debug, Clone)]
struct ReadDispatchOutcome {
    target: ResolvedTarget,
    ok: bool,
    messages: Vec<ConversationMessage>,
    source: Option<ConversationReadSource>,
    partial: bool,
    error: Option<String>,
}

impl BulkOutcome for ReadDispatchOutcome {
    fn ok(&self) -> bool {
        self.ok
    }
}

pub(super) fn parse_read_mode(last: bool, full: bool) -> ReadMode {
    match (last, full) {
        (_, true) => ReadMode::Full,
        _ => ReadMode::Last,
    }
}

pub(super) fn run_read_bulk(app: &dyn AppApi, args: &ReadArgs<'_>) -> Result<(), AppError> {
    bulk::run_bulk(
        args.targets,
        |target| read_from_target(app, target, args.mode),
        |outcomes| render_read_outcomes(outcomes, args.mode, args.json_output),
        "one or more target operations failed",
    )
}

fn read_from_target(
    app: &dyn AppApi,
    target: &ResolvedTarget,
    mode: ReadMode,
) -> ReadDispatchOutcome {
    let read_result = match mode {
        ReadMode::Last => app.read_last_message_from_agent(&target.id),
        ReadMode::Full => app.read_full_conversation_from_agent(&target.id),
    };

    match read_result {
        Ok(result) => ReadDispatchOutcome {
            target: target.clone(),
            ok: true,
            messages: result.messages,
            source: Some(result.source),
            partial: result.partial,
            error: None,
        },
        Err(err) => ReadDispatchOutcome {
            target: target.clone(),
            ok: false,
            messages: Vec::new(),
            source: None,
            partial: false,
            error: Some(err.to_string()),
        },
    }
}

fn read_mode_label(mode: ReadMode) -> &'static str {
    match mode {
        ReadMode::Last => "last",
        ReadMode::Full => "full",
    }
}

fn render_read_outcomes(outcomes: &[ReadDispatchOutcome], mode: ReadMode, json_output: bool) {
    let has_failure = outcomes.iter().any(|outcome| !outcome.ok);
    let rows = outcomes
        .iter()
        .map(|outcome| ReadOutcomeRow {
            id: outcome.target.id.as_str().to_string(),
            name: outcome.target.name.clone(),
            agent_kind: agent_kind_label(outcome.target.kind).to_string(),
            has_worktree: outcome.target.has_worktree,
            ok: outcome.ok,
            messages: outcome.messages.clone(),
            source: outcome.source.map(|source| source.as_label().to_string()),
            partial: outcome.partial,
            error: outcome.error.clone(),
        })
        .collect::<Vec<_>>();

    print_json_or_lines(
        json_output,
        &render_read_json(&rows, read_mode_label(mode), !has_failure),
        render_read_lines(&rows),
    );
}

#[cfg(test)]
mod tests {
    use serde_json::json;

    use super::*;

    #[test]
    fn parse_read_mode_prefers_full_when_requested() {
        assert!(matches!(parse_read_mode(false, true), ReadMode::Full));
        assert!(matches!(parse_read_mode(true, true), ReadMode::Full));
    }

    #[test]
    fn parse_read_mode_defaults_to_last() {
        assert!(matches!(parse_read_mode(true, false), ReadMode::Last));
        assert!(matches!(parse_read_mode(false, false), ReadMode::Last));
    }

    #[test]
    fn message_to_json_includes_structured_turn_fields() {
        let message = ConversationMessage {
            message_id: "msg_1".to_string(),
            role: "assistant".to_string(),
            created_at_unix_ms: 1,
            completed_at_unix_ms: Some(2),
            text: "[tool calls: bash]".to_string(),
            tool_names: vec!["bash".to_string()],
            patch_files: vec!["src/main.rs".to_string()],
            finish_reason: Some("tool-calls".to_string()),
            synthesized_text: true,
        };

        assert_eq!(
            crate::interface::presentation::agents_read::conversation_message_json(&message),
            json!({
                "message_id": "msg_1",
                "role": "assistant",
                "created_at_unix_ms": 1,
                "completed_at_unix_ms": 2,
                "text": "[tool calls: bash]",
                "tool_names": ["bash"],
                "patch_files": ["src/main.rs"],
                "finish_reason": "tool-calls",
                "synthesized_text": true,
            })
        );
    }
}
