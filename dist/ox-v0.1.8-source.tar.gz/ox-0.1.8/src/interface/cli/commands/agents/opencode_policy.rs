use crate::domain::AgentKind;
use crate::error::AppError;

pub(super) fn unsupported_non_opencode_targets<'a, I>(targets: I) -> Vec<String>
where
    I: IntoIterator<Item = (&'a AgentKind, &'a str)>,
{
    targets
        .into_iter()
        .filter_map(|(kind, name)| (*kind != AgentKind::Opencode).then_some(name.to_string()))
        .collect()
}

pub(super) fn slash_command_requires_opencode_error(unsupported_names: &[String]) -> AppError {
    AppError::InvalidInput {
        message: format!(
            "slash commands are only supported for opencode agents; unsupported targets: {}",
            unsupported_names.join(", ")
        ),
    }
}
