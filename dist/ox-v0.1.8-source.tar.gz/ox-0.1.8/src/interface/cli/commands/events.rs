use std::collections::HashSet;
use std::thread;
use std::time::Duration;

use crate::application::{AppApi, EventOutcome};
use crate::error::AppError;
use crate::interface::cli::commands::agents::targeting;
use crate::interface::cli::output::print_json_or_lines;
use crate::interface::presentation::events::{render_events_json, render_events_lines};

#[derive(Clone, Debug)]
struct EventTargetMatch {
    id: String,
    name: String,
}

/// Parsed `ox events` execution settings.
pub(crate) struct EventsArgs<'a> {
    pub(crate) limit: Option<usize>,
    pub(crate) outcome_filter: EventOutcomeFilter,
    pub(crate) agent_selector: Option<&'a str>,
    pub(crate) stream_mode: EventsStreamMode,
    pub(crate) output_mode: EventsOutputMode,
}

pub(crate) enum EventOutcomeFilter {
    All,
    FailedOnly,
}

pub(crate) enum EventsStreamMode {
    Once,
    Follow,
}

pub(crate) enum EventsOutputMode {
    Json,
    Lines { verbose: bool },
}

/// Execute `ox events` and print recent persisted app events.
pub(crate) fn run_events(app: &dyn AppApi, args: &EventsArgs<'_>) -> Result<(), AppError> {
    if matches!(args.stream_mode, EventsStreamMode::Follow)
        && matches!(args.output_mode, EventsOutputMode::Json)
    {
        return Err(AppError::InvalidInput {
            message: "--follow is not supported together with --json".to_string(),
        });
    }

    let limit = args.limit.unwrap_or_else(|| app.events_default_limit());
    let event_target = resolve_event_target(app, args.agent_selector)?;
    let failed_only = matches!(args.outcome_filter, EventOutcomeFilter::FailedOnly);

    if matches!(args.stream_mode, EventsStreamMode::Follow) {
        let verbose = match args.output_mode {
            EventsOutputMode::Json => false,
            EventsOutputMode::Lines { verbose } => verbose,
        };
        return follow_events(app, limit, failed_only, event_target.as_ref(), verbose);
    }

    let events = load_filtered_events(app, limit, failed_only, event_target.as_ref())?;
    match args.output_mode {
        EventsOutputMode::Json => {
            print_json_or_lines(true, &render_events_json(&events), Vec::new());
        }
        EventsOutputMode::Lines { verbose } => {
            print_json_or_lines(
                false,
                &render_events_json(&events),
                render_events_lines(&events, verbose),
            );
        }
    }
    Ok(())
}

fn resolve_event_target(
    app: &dyn AppApi,
    agent_selector: Option<&str>,
) -> Result<Option<EventTargetMatch>, AppError> {
    let Some(agent_selector) = agent_selector else {
        return Ok(None);
    };
    let target_input = targeting::build_target_input(Some(agent_selector.to_string()), &[], false)?;
    let targets = targeting::resolve_targets(app, &target_input)?;
    let Some(target) = targets.into_iter().next() else {
        return Ok(None);
    };
    Ok(Some(EventTargetMatch {
        id: target.id.as_str().to_string(),
        name: target.name,
    }))
}

fn load_filtered_events(
    app: &dyn AppApi,
    limit: usize,
    failed_only: bool,
    event_target: Option<&EventTargetMatch>,
) -> Result<Vec<crate::application::LoggedEvent>, AppError> {
    let events = app.recent_events(limit)?;
    Ok(events
        .into_iter()
        .filter(|event| !failed_only || matches!(event.outcome, EventOutcome::Failure))
        .filter(|event| {
            event_target.is_none_or(|target| {
                event
                    .target
                    .as_deref()
                    .is_some_and(|value| value == target.id || value == target.name)
            })
        })
        .collect())
}

fn follow_events(
    app: &dyn AppApi,
    limit: usize,
    failed_only: bool,
    event_target: Option<&EventTargetMatch>,
    verbose: bool,
) -> Result<(), AppError> {
    let mut seen = HashSet::new();
    let initial = load_filtered_events(app, limit, failed_only, event_target)?;
    if initial.is_empty() {
        println!("waiting for matching events...");
    } else {
        print_event_lines(&initial, &mut seen, verbose);
    }

    loop {
        let events = load_filtered_events(app, limit, failed_only, event_target)?;
        print_event_lines(&events, &mut seen, verbose);
        thread::sleep(Duration::from_millis(1_000));
    }
}

fn print_event_lines(
    events: &[crate::application::LoggedEvent],
    seen: &mut HashSet<String>,
    verbose: bool,
) {
    let fresh = events
        .iter()
        .filter(|event| seen.insert(format!("{}:{}", event.timestamp_unix_ms, event.op_id)))
        .cloned()
        .collect::<Vec<_>>();
    for line in render_events_lines(&fresh, verbose) {
        println!("{line}");
    }
}
