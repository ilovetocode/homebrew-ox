use crate::application::AppDiagnostics;
use crate::error::AppError;
use crate::interface::cli::output::print_json_or_lines;
use crate::interface::presentation::diagnostics::{
    render_doctor_json, render_doctor_lines, render_status_json, render_status_lines,
};

/// Execute `ox status` and print a quick tmux + managed-state summary.
pub(crate) fn run_status(
    app: &dyn AppDiagnostics,
    json_output: bool,
    verbose: bool,
) -> Result<(), AppError> {
    let report = app.status_report()?;
    print_json_or_lines(
        json_output,
        &render_status_json(&report),
        render_status_lines(&report, verbose),
    );
    Ok(())
}

/// Execute `ox doctor` and print detailed tmux + managed-state diagnostics.
pub(crate) fn run_doctor(
    app: &dyn AppDiagnostics,
    fix: bool,
    json_output: bool,
    verbose: bool,
) -> Result<(), AppError> {
    let report = app.doctor_report(fix)?;
    print_json_or_lines(
        json_output,
        &render_doctor_json(&report),
        render_doctor_lines(&report, verbose),
    );
    Ok(())
}
