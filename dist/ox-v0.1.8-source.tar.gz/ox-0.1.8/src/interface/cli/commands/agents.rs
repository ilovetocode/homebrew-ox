mod bulk;
pub(crate) mod filter_policy;
mod lifecycle;
mod opencode_policy;
mod read;
mod send;
pub(crate) mod targeting;

use crate::application::AppApi;
use crate::error::AppError;
use crate::interface::cli::args::{
    AgentListArgs, AgentListColumnArg, AgentListSortArg, AgentReadModeArgs, AgentTargetArgs,
    AgentsCommand,
};
use crate::interface::cli::output::{print_json_if, print_json_or_lines};
use crate::interface::cli::picker::pick_quick_switch_target;
use crate::interface::presentation::agents::{
    AgentsListColumn, AgentsListRenderOptions, render_agents_list_json, render_agents_list_lines,
    render_pick_json,
};
use crate::interface::presentation::quick_switch::QuickSwitchTarget;
use serde_json::json;

/// Execute `ox agents ...` subcommands using the shared runtime context.
pub(crate) fn run(
    app: &dyn AppApi,
    command: AgentsCommand,
    json_output: bool,
) -> Result<(), AppError> {
    match command {
        AgentsCommand::List { filters } => run_list(app, filters, json_output),
        AgentsCommand::ReconcilePinned => run_reconcile_pinned(app, json_output),
        AgentsCommand::Create {
            name,
            agent_kind,
            workspace_backend,
            workspace_name,
            repo,
            attach,
        } => lifecycle::run_create(
            app,
            lifecycle::CreateAgentArgs {
                name,
                agent_kind,
                workspace_backend,
                workspace_name,
                repo,
                attach,
                json_output,
            },
        ),
        AgentsCommand::Delete { selector } => lifecycle::run_delete(app, &selector, json_output),
        AgentsCommand::Update {
            selector,
            new_name,
            position,
        } => {
            if new_name.is_none() && position.is_none() {
                return Err(AppError::InvalidInput {
                    message: "at least one of <NEW_NAME> or --position must be provided"
                        .to_string(),
                });
            }
            lifecycle::run_update(app, &selector, new_name.as_deref(), position, json_output)
        }
        AgentsCommand::Attach { selector } => lifecycle::run_attach(app, &selector, json_output),
        AgentsCommand::Worktree {
            selector,
            branch,
            detach,
        } => lifecycle::run_worktree(app, &selector, &branch, detach, json_output),
        AgentsCommand::Send {
            target,
            input,
            message,
            file,
            stdin,
            enter,
        } => {
            let input = send::read_send_input(input, message, file.as_deref(), stdin)?;
            let target_input = build_target_input(target)?;
            let targets = targeting::resolve_targets(app, &target_input)?;
            send::run_send_bulk(
                app,
                &send::SendArgs {
                    targets: &targets,
                    input: &input,
                    enter,
                    json_output,
                },
            )
        }
        AgentsCommand::Read { target, read_mode } => {
            let target_input = build_target_input(target)?;
            let targets = targeting::resolve_targets(app, &target_input)?;
            let mode = parse_read_mode(&read_mode);
            read::run_read_bulk(
                app,
                &read::ReadArgs {
                    targets: &targets,
                    mode,
                    json_output,
                },
            )
        }
        AgentsCommand::Pick => run_pick(app, json_output),
    }
}

fn build_target_input(target: AgentTargetArgs) -> Result<targeting::AgentTargetInput, AppError> {
    targeting::build_target_input(
        target.target_agent,
        &target.filter_exprs,
        target.all_targets,
    )
}

fn parse_read_mode(read_mode: &AgentReadModeArgs) -> read::ReadMode {
    read::parse_read_mode(read_mode.last, read_mode.full)
}

fn run_list(app: &dyn AppApi, list_args: AgentListArgs, json_output: bool) -> Result<(), AppError> {
    let mut agents = app.list_agents()?;
    let filters = build_list_filters(&list_args)?;
    let match_context = targeting::build_match_context(&filters)?;
    agents.retain(|agent| targeting::matches_filters(agent, &filters, &match_context));
    sort_list_agents(&mut agents, list_args.sort);

    print_json_or_lines(
        json_output,
        &render_agents_list_json(&agents),
        render_agents_list_lines(
            &agents,
            &AgentsListRenderOptions {
                long: list_args.long,
                columns: list_args.columns.into_iter().map(map_list_column).collect(),
            },
        ),
    );

    Ok(())
}

fn map_list_column(column: AgentListColumnArg) -> AgentsListColumn {
    match column {
        AgentListColumnArg::Position => AgentsListColumn::Position,
        AgentListColumnArg::Name => AgentsListColumn::Name,
        AgentListColumnArg::Kind => AgentsListColumn::Kind,
        AgentListColumnArg::Status => AgentsListColumn::Status,
        AgentListColumnArg::Branch => AgentsListColumn::Branch,
        AgentListColumnArg::Repo => AgentsListColumn::Repo,
        AgentListColumnArg::Worktree => AgentsListColumn::Worktree,
        AgentListColumnArg::Attached => AgentsListColumn::Attached,
        AgentListColumnArg::Id => AgentsListColumn::Id,
    }
}

fn build_list_filters(
    list_args: &AgentListArgs,
) -> Result<Vec<targeting::AgentFilterExpr>, AppError> {
    let mut filters = targeting::parse_filter_exprs(&list_args.filter_exprs)?;
    if list_args.current_repo {
        filters.push(targeting::AgentFilterExpr::Repo(
            targeting::RepoFilter::Current,
        ));
    }
    if let Some(repo) = &list_args.repo {
        filters.push(targeting::AgentFilterExpr::Repo(
            targeting::RepoFilter::ExactPath(repo.clone()),
        ));
    }
    if let Some(kind) = list_args.kind {
        filters.push(targeting::AgentFilterExpr::Kind(kind.into()));
    }
    if let Some(status) = list_args.status {
        filters.push(targeting::AgentFilterExpr::Status(status.into()));
    }
    if list_args.attached {
        filters.push(targeting::AgentFilterExpr::Attached(true));
    }
    Ok(filters)
}

fn sort_list_agents(agents: &mut [crate::application::AgentView], sort: AgentListSortArg) {
    match sort {
        AgentListSortArg::Position => {
            agents.sort_by_key(|agent| agent.agent.display_order());
        }
        AgentListSortArg::Name => {
            agents.sort_by(|left, right| left.agent.display_name().cmp(right.agent.display_name()));
        }
        AgentListSortArg::Kind => {
            agents.sort_by(|left, right| {
                crate::interface::presentation::agent_kind::agent_kind_label(left.agent.kind())
                    .cmp(
                        crate::interface::presentation::agent_kind::agent_kind_label(
                            right.agent.kind(),
                        ),
                    )
                    .then_with(|| left.agent.display_name().cmp(right.agent.display_name()))
            });
        }
        AgentListSortArg::Status => {
            agents.sort_by(|left, right| {
                left.runtime_status
                    .as_label()
                    .cmp(right.runtime_status.as_label())
                    .then_with(|| left.agent.display_name().cmp(right.agent.display_name()))
            });
        }
        AgentListSortArg::Repo => {
            agents.sort_by(|left, right| {
                left.git_root
                    .as_deref()
                    .or(left.git_worktree_path.as_deref())
                    .unwrap_or("")
                    .cmp(
                        right
                            .git_root
                            .as_deref()
                            .or(right.git_worktree_path.as_deref())
                            .unwrap_or(""),
                    )
                    .then_with(|| left.agent.display_name().cmp(right.agent.display_name()))
            });
        }
    }
}

fn run_reconcile_pinned(app: &dyn AppApi, json_output: bool) -> Result<(), AppError> {
    app.reconcile_pinned_sessions()?;
    print_json_if(
        json_output,
        &json!({ "action": "reconcile-pinned", "ok": true }),
    );
    Ok(())
}

fn run_pick(app: &dyn AppApi, json_output: bool) -> Result<(), AppError> {
    let agents = app.list_agents_for_picker()?;
    let selected = pick_quick_switch_target(&agents)?;
    if let Some(target) = &selected {
        match target {
            QuickSwitchTarget::Dashboard => app.disconnect_to_dashboard()?,
            QuickSwitchTarget::Agent { id, .. } => app.connect_agent(id)?,
        }
    }

    print_json_if(json_output, &render_pick_json(selected));

    Ok(())
}
