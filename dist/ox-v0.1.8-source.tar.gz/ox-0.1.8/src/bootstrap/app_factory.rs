use std::sync::Arc;

use crate::application::{
    AgentConversationPort, AgentConversationService, AgentInteractionService,
    AgentLifecycleService, AgentRuntimePort, AgentStorePort, AppApi, AppEventLogs, AppService,
    AppStoragePaths, AppTmuxPort, AuxSessionPort, CodexThreadPort, DiagnosticsService,
    EventLogPort, MessageDispatchPort, OpencodeProvisioning, OpencodeSessionBootstrapPort,
    RuntimePort, SessionStatePort,
};
use crate::error::AppError;
use crate::infrastructure::codex::CodexAppServerAdapter;
use crate::infrastructure::git::GitWorktreeAdapter;
use crate::infrastructure::opencode::{OpencodeApiAdapter, OpencodeSessionBootstrapAdapter};
use crate::infrastructure::storage::{
    SqliteStore, StoragePaths, StoredConfig, StoredPinnedSessions,
};
use crate::infrastructure::tmux::{TmuxAdapter, TmuxAuxSessionAdapter, TmuxConfig};

/// Composition root for wiring application dependencies.
pub(crate) struct AppFactory;

impl AppFactory {
    /// Build an `AppService` from concrete adapters.
    pub(crate) fn build() -> Result<Arc<dyn AppApi>, AppError> {
        let tmux_config = Arc::new(TmuxConfig::resolve()?);
        let storage = StoragePaths::resolve()?;
        let settings = StoredConfig::load_or_create(&storage.config_path)?.into_app_settings();
        let pinned_sessions = StoredPinnedSessions::load_or_create(&storage.pinned_sessions_path)?
            .into_pinned_specs()?;
        let codex_port: Arc<dyn CodexThreadPort> = Arc::new(CodexAppServerAdapter);
        let dispatch_port: Arc<dyn MessageDispatchPort> =
            Arc::new(OpencodeApiAdapter::new(settings.opencode.clone()));
        let aux_session_port: Arc<dyn AuxSessionPort> =
            Arc::new(TmuxAuxSessionAdapter::new(tmux_config.clone()));
        let opencode_session_bootstrap_port: Arc<dyn OpencodeSessionBootstrapPort> =
            Arc::new(OpencodeSessionBootstrapAdapter::new(
                settings.opencode.clone(),
                dispatch_port.clone(),
                aux_session_port.clone(),
            ));
        let adapter = Arc::new(TmuxAdapter::new(tmux_config));
        let sqlite_store = Arc::new(SqliteStore::open(&storage.sqlite_db_path)?);

        // Run startup preflight before entering command flows.
        adapter.ensure_tmux_on_path()?;

        // Keep the same concrete adapter instance while narrowing each dependency
        // to the minimum trait needed by the receiving service.
        let runtime_port: Arc<dyn AgentRuntimePort> = adapter.clone();
        let app_tmux_port: Arc<dyn AppTmuxPort> = adapter;
        let agent_store_port: Arc<dyn AgentStorePort> = sqlite_store.clone();
        let event_log_port: Arc<dyn EventLogPort> = sqlite_store.clone();
        let event_logs = AppEventLogs::new(event_log_port);
        let session_state_port: Arc<dyn SessionStatePort> = sqlite_store;
        let worktree_port = Arc::new(GitWorktreeAdapter);
        let agents = AgentLifecycleService::new(
            agent_store_port.clone(),
            runtime_port.clone(),
            worktree_port.clone(),
            codex_port,
            dispatch_port.clone(),
            OpencodeProvisioning::new(opencode_session_bootstrap_port.clone()),
            pinned_sessions,
        );
        // Startup should not block on runtime healing. We launch one best-effort
        // pass in the background so missing tmux sessions are recreated early.
        agents.spawn_background_tmux_runtime_heal();
        let runtime_agents =
            AgentInteractionService::new(agent_store_port.clone(), runtime_port.clone());
        let conversation_agents = Arc::new(AgentConversationService::new(
            agent_store_port.clone(),
            runtime_port.clone(),
            Arc::new(CodexAppServerAdapter),
            dispatch_port.clone(),
            settings.opencode.conversation_page_size,
        ));
        let conversation_port: Arc<dyn AgentConversationPort> = conversation_agents.clone();
        let diagnostics = DiagnosticsService::new(
            app_tmux_port.clone(),
            session_state_port.clone(),
            AppStoragePaths {
                sqlite_db_path: storage.sqlite_db_path.display().to_string(),
                config_path: storage.config_path.display().to_string(),
            },
        );

        Ok(Arc::new(AppService::new(
            agents,
            runtime_agents,
            conversation_port,
            diagnostics,
            event_logs,
            settings,
            agent_store_port,
        )))
    }
}
