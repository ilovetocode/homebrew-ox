use std::sync::Arc;

use crate::application::ports::{AppTmuxPort, SessionStatePort};
use crate::application::types::{AppStoragePaths, HostSessionSnapshot};
use crate::error::{AppError, StartupError};

/// Pure status snapshot returned by the diagnostics use-case.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct StatusReport {
    pub(crate) tmux_available: bool,
    pub(crate) managed_tmux_conf: String,
    pub(crate) managed_tmux_conf_in_sync: bool,
    pub(crate) sqlite_db_path: String,
    pub(crate) config_path: String,
    pub(crate) agent_count: usize,
    pub(crate) attached_agent_count: usize,
}

/// A single doctor check row with stable fields for interface rendering.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct CheckResult {
    pub(crate) name: &'static str,
    pub(crate) ok: bool,
    pub(crate) detail: String,
}

/// Pure doctor snapshot returned by the diagnostics use-case.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct DoctorReport {
    pub(crate) checks: Vec<CheckResult>,
}

/// Service that owns diagnostics probing against runtime/config/storage context.
pub(crate) struct DiagnosticsService {
    tmux: Arc<dyn AppTmuxPort>,
    session_state: Arc<dyn SessionStatePort>,
    storage_paths: AppStoragePaths,
}

impl DiagnosticsService {
    /// Build diagnostics service from injected runtime/config dependencies.
    pub(crate) fn new(
        tmux: Arc<dyn AppTmuxPort>,
        session_state: Arc<dyn SessionStatePort>,
        storage_paths: AppStoragePaths,
    ) -> Self {
        Self {
            tmux,
            session_state,
            storage_paths,
        }
    }

    /// Build `ox status` data without doing any CLI rendering.
    pub(crate) fn status_report(&self) -> Result<StatusReport, AppError> {
        let tmux_available = self.tmux.tmux_available();
        let managed_tmux_conf = self.tmux.tmux_conf_path();
        let managed_tmux_conf_in_sync = self.tmux.is_in_sync();
        let (agent_count, attached_agent_count) = self.probe_sessions(tmux_available)?;

        Ok(StatusReport {
            tmux_available,
            managed_tmux_conf,
            managed_tmux_conf_in_sync,
            sqlite_db_path: self.storage_paths.sqlite_db_path.clone(),
            config_path: self.storage_paths.config_path.clone(),
            agent_count,
            attached_agent_count,
        })
    }

    /// Build `ox doctor` data without doing any CLI rendering.
    pub(crate) fn doctor_report(&self, fix: bool) -> Result<DoctorReport, AppError> {
        let tmux_ok = self.tmux.tmux_available();
        if !tmux_ok {
            return Err(AppError::Startup(StartupError::MissingTmux));
        }
        let tmux_conf_path = self.tmux.tmux_conf_path();
        let mut checks = Vec::new();

        checks.push(CheckResult {
            name: "tmux binary available",
            ok: tmux_ok,
            detail: String::new(),
        });

        let mut tmux_conf_in_sync = self.tmux.is_in_sync();
        checks.push(CheckResult {
            name: "managed tmux config in sync",
            ok: tmux_conf_in_sync,
            detail: format!("path={tmux_conf_path}"),
        });

        if fix && !tmux_conf_in_sync {
            self.tmux.reconcile()?;
            tmux_conf_in_sync = self.tmux.is_in_sync();
            checks.push(CheckResult {
                name: "managed tmux config repaired",
                ok: tmux_conf_in_sync,
                detail: String::new(),
            });
        }

        match self.probe_sessions(tmux_ok) {
            Ok((sessions, attached)) => {
                checks.push(CheckResult {
                    name: "session query",
                    ok: true,
                    detail: format!("sessions={sessions} attached={attached}"),
                });
            }
            Err(error) => {
                checks.push(CheckResult {
                    name: "session query",
                    ok: false,
                    detail: error.to_string(),
                });
            }
        }

        Ok(DoctorReport { checks })
    }

    fn probe_sessions(&self, tmux_available: bool) -> Result<(usize, usize), AppError> {
        // `AppFactory` preflight already enforces tmux availability globally.
        // Returning `MissingTmux` here keeps this service strict and coherent
        // when instantiated directly in tests or alternate compositions.
        if !tmux_available {
            return Err(AppError::Startup(StartupError::MissingTmux));
        }

        match self.tmux.list_sessions() {
            Ok(sessions) => {
                self.persist_session_snapshot(&sessions);
                let attached = sessions.iter().filter(|session| session.attached).count();
                Ok((sessions.len(), attached))
            }
            Err(error) => Err(error),
        }
    }

    fn persist_session_snapshot(&self, sessions: &[HostSessionSnapshot]) {
        // Session-state persistence is best-effort and must not break primary
        // command behavior when local storage is unavailable.
        let _ = self.session_state.replace_sessions(sessions);
    }
}

#[cfg(test)]
mod tests {
    use std::sync::Arc;
    use std::sync::Mutex;
    use std::sync::atomic::{AtomicUsize, Ordering};

    use crate::application::DiagnosticsService;
    use crate::application::ports::{ConfigPort, RuntimePort, SessionPort, SessionStatePort};
    use crate::application::types::{AppStoragePaths, HostSessionSnapshot};
    use crate::domain::AgentKind;
    use crate::error::{AppError, StartupError};

    enum SessionBehavior {
        Ok(Vec<HostSessionSnapshot>),
        Err(String),
    }

    struct FakeTmux {
        tmux_available: bool,
        tmux_conf_path: String,
        tmux_conf_in_sync: Mutex<bool>,
        sessions: SessionBehavior,
    }

    impl SessionPort for FakeTmux {
        fn list_sessions(&self) -> Result<Vec<HostSessionSnapshot>, AppError> {
            match &self.sessions {
                SessionBehavior::Ok(sessions) => Ok(sessions.clone()),
                SessionBehavior::Err(message) => Err(AppError::InvalidInput {
                    message: message.clone(),
                }),
            }
        }
    }

    impl RuntimePort for FakeTmux {
        fn ensure_tmux_on_path(&self) -> Result<(), StartupError> {
            Ok(())
        }

        fn tmux_available(&self) -> bool {
            self.tmux_available
        }
    }

    impl ConfigPort for FakeTmux {
        fn tmux_conf_path(&self) -> String {
            self.tmux_conf_path.clone()
        }

        fn is_in_sync(&self) -> bool {
            *self
                .tmux_conf_in_sync
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner)
        }

        fn reconcile(&self) -> Result<(), AppError> {
            *self
                .tmux_conf_in_sync
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner) = true;
            Ok(())
        }
    }

    struct FakeSessionState {
        replace_calls: AtomicUsize,
    }

    impl SessionStatePort for FakeSessionState {
        fn replace_sessions(&self, _sessions: &[HostSessionSnapshot]) -> Result<(), AppError> {
            self.replace_calls.fetch_add(1, Ordering::Relaxed);
            Ok(())
        }
    }

    fn build_service(tmux: FakeTmux, state: Arc<FakeSessionState>) -> DiagnosticsService {
        DiagnosticsService::new(
            Arc::new(tmux),
            state,
            AppStoragePaths {
                sqlite_db_path: "/tmp/ox.db".to_string(),
                config_path: "/tmp/config.json".to_string(),
            },
        )
    }

    fn shell_session(name: &str, attached: bool) -> HostSessionSnapshot {
        HostSessionSnapshot {
            name: name.to_string(),
            windows: 1,
            attached,
            agent_kind: AgentKind::Shell,
            runtime_status: crate::application::RuntimeStatus::Running,
        }
    }

    #[test]
    fn status_report_without_tmux_returns_missing_tmux_error() {
        let state = Arc::new(FakeSessionState {
            replace_calls: AtomicUsize::new(0),
        });
        let service = build_service(
            FakeTmux {
                tmux_available: false,
                tmux_conf_path: "/tmp/tmux.conf".to_string(),
                tmux_conf_in_sync: Mutex::new(true),
                sessions: SessionBehavior::Ok(vec![]),
            },
            Arc::clone(&state),
        );

        let report = service.status_report();
        assert!(report.is_err(), "status report should fail without tmux");
        assert!(matches!(
            report,
            Err(AppError::Startup(StartupError::MissingTmux))
        ));
        assert_eq!(state.replace_calls.load(Ordering::Relaxed), 0);
    }

    #[test]
    fn status_report_propagates_session_query_errors() {
        let state = Arc::new(FakeSessionState {
            replace_calls: AtomicUsize::new(0),
        });
        let service = build_service(
            FakeTmux {
                tmux_available: true,
                tmux_conf_path: "/tmp/tmux.conf".to_string(),
                tmux_conf_in_sync: Mutex::new(true),
                sessions: SessionBehavior::Err("session probe failed".to_string()),
            },
            Arc::clone(&state),
        );

        let result = service.status_report();
        assert!(result.is_err(), "status report should fail on query error");
        assert_eq!(state.replace_calls.load(Ordering::Relaxed), 0);
    }

    #[test]
    fn doctor_report_uses_probe_counts_and_persists_sessions() {
        let state = Arc::new(FakeSessionState {
            replace_calls: AtomicUsize::new(0),
        });
        let service = build_service(
            FakeTmux {
                tmux_available: true,
                tmux_conf_path: "/tmp/tmux.conf".to_string(),
                tmux_conf_in_sync: Mutex::new(true),
                sessions: SessionBehavior::Ok(vec![
                    shell_session("a", true),
                    shell_session("b", false),
                ]),
            },
            Arc::clone(&state),
        );

        let report = service.doctor_report(false);
        assert!(report.is_ok(), "doctor report should succeed");
        if let Ok(report) = report {
            let query_check = report
                .checks
                .iter()
                .find(|check| check.name == "session query");
            assert!(
                query_check.is_some(),
                "session query check should be present in doctor report"
            );
            assert_eq!(
                query_check.map(|check| check.ok),
                Some(true),
                "session query should be marked healthy"
            );
            assert_eq!(
                query_check.map(|check| check.detail.as_str()),
                Some("sessions=2 attached=1")
            );
        }
        assert_eq!(state.replace_calls.load(Ordering::Relaxed), 1);
    }

    #[test]
    fn doctor_report_without_tmux_returns_missing_tmux_error() {
        let state = Arc::new(FakeSessionState {
            replace_calls: AtomicUsize::new(0),
        });
        let service = build_service(
            FakeTmux {
                tmux_available: false,
                tmux_conf_path: "/tmp/tmux.conf".to_string(),
                tmux_conf_in_sync: Mutex::new(false),
                sessions: SessionBehavior::Ok(vec![]),
            },
            Arc::clone(&state),
        );

        let report = service.doctor_report(true);
        assert!(report.is_err(), "doctor report should fail without tmux");
        assert!(matches!(
            report,
            Err(AppError::Startup(StartupError::MissingTmux))
        ));
    }
}
