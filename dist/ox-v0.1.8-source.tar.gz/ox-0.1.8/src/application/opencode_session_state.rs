use serde::Deserialize;

use crate::application::MessageDispatchSessionRef;
use crate::domain::{
    Agent, AgentStateBinding, AgentStateKind, AgentStateProvider, PRIMARY_STATE_BINDING_KEY,
};

const OPENCODE_SESSION_BINDING_KEY: &str = PRIMARY_STATE_BINDING_KEY;

/// Persisted `OpenCode` session binding metadata used by provider-backed dispatch.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct OpencodeSessionState {
    pub(crate) server_url: String,
    pub(crate) session_id: String,
    pub(crate) auth_mode: String,
    pub(crate) directory: Option<String>,
}

/// Build a durable `OpenCode` provider session state binding owned by `ox`.
pub(crate) fn build_opencode_session_state_binding(
    agent: &Agent,
    server_url: &str,
    session_id: &str,
    auth_mode: &str,
    directory: Option<&str>,
    now_unix_ms: u128,
) -> AgentStateBinding {
    let metadata = serde_json::json!({
        "managed": true,
        "server_url": server_url,
        "session_id": session_id,
        "directory": directory,
        "created_by": "ox",
        "auth_mode": auth_mode,
    });
    AgentStateBinding::new(
        agent.id(),
        AgentStateKind::OpencodeSession,
        AgentStateProvider::Opencode,
        OPENCODE_SESSION_BINDING_KEY.to_string(),
        format!("{server_url}::{session_id}"),
        metadata.to_string(),
        now_unix_ms,
    )
}

/// Return an updated binding that points at a repaired `OpenCode` session.
pub(crate) fn rebind_opencode_session_state_binding(
    existing: &AgentStateBinding,
    session: &MessageDispatchSessionRef,
    auth_mode: &str,
    now_unix_ms: u128,
) -> AgentStateBinding {
    let metadata = serde_json::json!({
        "managed": true,
        "server_url": session.server_url,
        "session_id": session.session_id,
        "directory": session.directory,
        "created_by": "ox",
        "auth_mode": auth_mode,
    });
    AgentStateBinding {
        id: existing.id.clone(),
        agent_id: existing.agent_id.clone(),
        state_kind: existing.state_kind,
        provider: existing.provider,
        binding_key: existing.binding_key.clone(),
        external_ref: format!("{}::{}", session.server_url, session.session_id),
        metadata_json: metadata.to_string(),
        version: existing.version.saturating_add(1),
        last_seen_at_unix_ms: Some(now_unix_ms),
        created_at_unix_ms: existing.created_at_unix_ms,
        updated_at_unix_ms: now_unix_ms,
    }
}

/// Resolve canonical `OpenCode` session metadata from persisted state bindings.
pub(crate) fn find_opencode_session_state(
    states: &[AgentStateBinding],
) -> Option<OpencodeSessionState> {
    let state = states
        .iter()
        .find(|state| state.state_kind == AgentStateKind::OpencodeSession)?;

    if let Ok(metadata) = serde_json::from_str::<OpencodeSessionMetadata>(&state.metadata_json)
        && let (Some(server_url), Some(session_id)) = (metadata.server_url, metadata.session_id)
        && !server_url.trim().is_empty()
        && !session_id.trim().is_empty()
    {
        return Some(OpencodeSessionState {
            server_url,
            session_id,
            auth_mode: metadata.auth_mode.unwrap_or_else(|| "none".to_string()),
            directory: metadata.directory,
        });
    }

    let mut parts = state.external_ref.splitn(2, "::");
    let server_url = parts.next().unwrap_or_default().trim();
    let session_id = parts.next().unwrap_or_default().trim();
    if server_url.is_empty() || session_id.is_empty() {
        return None;
    }

    Some(OpencodeSessionState {
        server_url: server_url.to_string(),
        session_id: session_id.to_string(),
        auth_mode: "none".to_string(),
        directory: None,
    })
}

#[derive(Deserialize)]
struct OpencodeSessionMetadata {
    server_url: Option<String>,
    session_id: Option<String>,
    auth_mode: Option<String>,
    directory: Option<String>,
}
