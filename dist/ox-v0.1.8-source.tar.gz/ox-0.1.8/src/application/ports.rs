use std::collections::HashMap;

use crate::application::{
    AppEvent, CodexThreadBootstrap, CodexThreadStartRequest, ConversationMessage,
    ConversationReadResult, HostSessionSnapshot, LoggedEvent, MessageDispatchCreateSessionRequest,
    MessageDispatchCreateSessionResult, MessageDispatchResult, MessageDispatchSendRequest,
    MessageDispatchSessionRef, MessageDispatchSessionSummary, MessageDispatchSlashCommandRequest,
    MessageReadRequest, ResolvedGitWorktreeSpec, RuntimeProbeResult, RuntimeStartRequest,
    RuntimeStatus,
};
use crate::domain::{
    Agent, AgentId, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding, AgentStateKind,
};
use crate::error::{AppError, StartupError};

/// Boundary trait for tmux-backed session commands.
pub(crate) trait SessionPort: Send + Sync {
    fn list_sessions(&self) -> Result<Vec<HostSessionSnapshot>, AppError>;
}

/// Boundary trait for tmux runtime probing and startup checks.
pub(crate) trait RuntimePort: Send + Sync {
    fn ensure_tmux_on_path(&self) -> Result<(), StartupError>;
    fn tmux_available(&self) -> bool;
}

/// Boundary trait for managed tmux config file state.
pub(crate) trait ConfigPort: Send + Sync {
    fn tmux_conf_path(&self) -> String;
    fn is_in_sync(&self) -> bool;
    fn reconcile(&self) -> Result<(), AppError>;
}

/// Boundary trait for non-agent tmux sessions used by helper workflows and
/// infrastructure sidecars.
pub(crate) trait AuxSessionPort: Send + Sync {
    /// Return whether one named tmux session exists.
    fn session_exists(&self, session_name: &str) -> Result<bool, AppError>;

    /// Ensure one detached named tmux session is running a command argv.
    ///
    /// Implementations must treat "already exists" as success.
    fn ensure_detached_command_session(
        &self,
        session_name: &str,
        working_dir: Option<&str>,
        argv: &[String],
    ) -> Result<(), AppError>;

    /// Stop one named tmux session.
    fn kill_session(&self, session_name: &str) -> Result<(), AppError>;
}

/// Composite application seam used by diagnostics.
pub(crate) trait AppTmuxPort: SessionPort + RuntimePort + ConfigPort {}

impl<T> AppTmuxPort for T where T: SessionPort + RuntimePort + ConfigPort {}

/// Boundary trait for native Codex thread lifecycle operations.
pub(crate) trait CodexThreadPort: Send + Sync {
    /// Start a new Codex thread through the protocol adapter.
    fn start_thread(
        &self,
        request: &CodexThreadStartRequest,
    ) -> Result<CodexThreadBootstrap, AppError>;

    /// Read statuses for many thread IDs in one adapter round-trip.
    ///
    /// Implementations should prefer provider-native batching to avoid one
    /// subprocess or network call per thread where possible.
    fn read_thread_statuses(
        &self,
        thread_ids: &[String],
    ) -> Result<HashMap<String, RuntimeStatus>, AppError>;

    /// Read one Codex rollout-backed transcript by managed thread ID.
    fn read_thread_conversation(
        &self,
        thread_id: &str,
        limit: Option<usize>,
    ) -> Result<ConversationReadResult, AppError>;
}

/// Boundary trait for persistent application event logging.
pub(crate) trait EventLogPort: Send + Sync {
    fn append(&self, event: &AppEvent) -> Result<(), AppError>;
    fn read_recent(&self, limit: usize) -> Result<Vec<LoggedEvent>, AppError>;
}

/// Aggregate persistence boundary for agents and their runtime bindings.
///
/// This keeps agent lifecycle and binding state behind one repository contract so
/// use-cases do not need to manually stitch two repositories together.
pub(crate) trait AgentStorePort: Send + Sync {
    fn insert_agent_with_binding(
        &self,
        agent: &Agent,
        binding: &AgentRuntimeBinding,
        state_bindings: &[AgentStateBinding],
    ) -> Result<(), AppError>;
    fn list_agent_runtime_records(&self) -> Result<Vec<AgentRuntimeRecord>, AppError>;
    fn find_agent_runtime_record_by_id(
        &self,
        id: AgentId,
    ) -> Result<Option<AgentRuntimeRecord>, AppError>;
    fn list_state_bindings_by_agent_id(
        &self,
        id: AgentId,
    ) -> Result<Vec<AgentStateBinding>, AppError>;
    fn list_state_bindings_by_agent_ids(
        &self,
        ids: &[AgentId],
    ) -> Result<Vec<AgentStateBinding>, AppError>;
    fn upsert_state_binding(&self, binding: &AgentStateBinding) -> Result<(), AppError>;
    fn find_agent_by_display_name(&self, display_name: &str) -> Result<Option<Agent>, AppError>;
    fn update_agent(&self, updated: &Agent, expected_version: i64) -> Result<(), AppError>;
    fn upsert_binding(&self, binding: &AgentRuntimeBinding) -> Result<(), AppError>;
    /// Apply one runtime/workspace handoff atomically.
    ///
    /// This keeps persisted agent kind, runtime binding, and external-state
    /// bindings consistent when lifecycle flows replace one workspace context
    /// with another.
    #[allow(dead_code)]
    #[allow(dead_code)]
    fn update_agent_runtime_context(
        &self,
        updated: &Agent,
        expected_version: i64,
        binding: &AgentRuntimeBinding,
        upsert_state_bindings: &[AgentStateBinding],
        delete_state_kinds: &[AgentStateKind],
    ) -> Result<(), AppError>;
    fn delete_agent(&self, id: AgentId) -> Result<(), AppError>;
    fn next_display_order(&self) -> Result<i64, AppError>;
    fn swap_display_order(
        &self,
        a: &Agent,
        a_expected_version: i64,
        b: &Agent,
        b_expected_version: i64,
    ) -> Result<(), AppError>;
}

/// Boundary trait for persisting known tmux session snapshots.
pub(crate) trait SessionStatePort: Send + Sync {
    fn replace_sessions(&self, sessions: &[HostSessionSnapshot]) -> Result<(), AppError>;
}

/// Boundary trait for runtime operations keyed by agent binding.
pub(crate) trait AgentRuntimePort: Send + Sync {
    fn start(
        &self,
        request: &RuntimeStartRequest,
        binding: Option<&AgentRuntimeBinding>,
    ) -> Result<AgentRuntimeBinding, AppError>;

    fn stop(&self, binding: &AgentRuntimeBinding) -> Result<(), AppError>;

    fn attach(&self, binding: &AgentRuntimeBinding) -> Result<(), AppError>;

    /// Detach the current tmux client when possible.
    ///
    /// This is intentionally a best-effort operation: callers use it for the
    /// "dashboard" quick-switch target, where "not currently in tmux" should
    /// behave like a no-op instead of a hard failure.
    fn detach_client(&self) -> Result<(), AppError>;

    fn probe(&self, bindings: &[AgentRuntimeBinding]) -> Result<Vec<RuntimeProbeResult>, AppError>;

    /// Capture recent terminal output for one runtime binding.
    ///
    /// `lines` is the maximum history depth to request from the backend.
    fn capture_output(&self, binding: &AgentRuntimeBinding, lines: u16)
    -> Result<String, AppError>;

    /// Send one key token to the runtime associated with this binding.
    ///
    /// The `key` token follows backend key naming (for example `Enter`, `Up`,
    /// `BSpace`, or a single printable character).
    fn send_key(&self, binding: &AgentRuntimeBinding, key: &str) -> Result<(), AppError>;

    /// Rename the runtime session backing this binding.
    ///
    /// Backends should tolerate the old session not existing (e.g. already
    /// stopped) and treat that as a no-op.
    fn rename(&self, binding: &AgentRuntimeBinding, new_external_ref: &str)
    -> Result<(), AppError>;
}

/// Boundary trait for API-first message dispatch (`OpenCode` and future providers).
///
/// This replaces tmux key injection for agents whose provider exposes a
/// structured HTTP API. The adapter is responsible for HTTP transport,
/// authentication, and mapping provider responses into domain types.
pub(crate) trait MessageDispatchPort: Send + Sync {
    /// Create a new provider session and return the session reference.
    fn create_session(
        &self,
        request: &MessageDispatchCreateSessionRequest,
    ) -> Result<MessageDispatchCreateSessionResult, AppError>;

    /// List all known provider sessions on one server.
    fn list_sessions(
        &self,
        server_url: &str,
    ) -> Result<Vec<MessageDispatchSessionSummary>, AppError>;

    /// List direct child sessions for one provider session when available.
    fn list_child_sessions(
        &self,
        session: &MessageDispatchSessionRef,
    ) -> Result<Vec<MessageDispatchSessionSummary>, AppError>;

    /// Send a user message to an existing provider session.
    fn send_message(
        &self,
        request: &MessageDispatchSendRequest,
    ) -> Result<MessageDispatchResult, AppError>;

    /// Send one provider-native slash command to an existing provider session.
    fn send_slash_command(
        &self,
        request: &MessageDispatchSlashCommandRequest,
    ) -> Result<MessageDispatchResult, AppError>;

    /// Read the most recent assistant message from a session.
    fn read_last_message(
        &self,
        request: &MessageReadRequest,
    ) -> Result<Option<ConversationMessage>, AppError>;

    /// Read the full conversation history from a session.
    fn read_full_conversation(
        &self,
        request: &MessageReadRequest,
    ) -> Result<ConversationReadResult, AppError>;

    /// Probe provider session status mapped to `RuntimeStatus`.
    fn read_session_status(
        &self,
        session: &MessageDispatchSessionRef,
    ) -> Result<RuntimeStatus, AppError>;
}

/// Boundary trait for provider-backed agent conversation operations.
pub(crate) trait AgentConversationPort: Send + Sync {
    /// Send a user message to one managed agent conversation.
    fn send_message_to_agent(
        &self,
        id: &AgentId,
        message: &str,
    ) -> Result<MessageDispatchResult, AppError>;

    /// Send one provider-native slash command to one managed agent conversation.
    fn send_slash_command_to_agent(
        &self,
        id: &AgentId,
        command: &str,
    ) -> Result<MessageDispatchResult, AppError>;

    /// Read the last normalized provider message for one managed agent.
    fn read_last_message_from_agent(
        &self,
        id: &AgentId,
    ) -> Result<ConversationReadResult, AppError>;

    /// Read the full normalized provider transcript for one managed agent.
    fn read_full_conversation_from_agent(
        &self,
        id: &AgentId,
    ) -> Result<ConversationReadResult, AppError>;
}

/// Boundary trait for provisioning `OpenCode` sessions with directory affinity.
///
/// This keeps sidecar process selection and one-time retry logic behind a
/// dedicated application-facing port instead of spreading it across services.
pub(crate) trait OpencodeSessionBootstrapPort: Send + Sync {
    /// Ensure one `OpenCode` session exists for the requested directory.
    fn ensure_session_for_directory(
        &self,
        directory: &str,
    ) -> Result<MessageDispatchSessionRef, AppError>;
}

/// Boundary trait for git worktree lifecycle used by agent state orchestration.
pub(crate) trait WorktreePort: Send + Sync {
    fn create_worktree(
        &self,
        agent: &Agent,
        spec: &ResolvedGitWorktreeSpec,
    ) -> Result<AgentStateBinding, AppError>;

    fn delete_worktree(&self, state: &AgentStateBinding) -> Result<(), AppError>;

    /// Return the current branch for a worktree path when available.
    ///
    /// Backends should return `Ok(None)` for detached HEAD or when branch
    /// detection is unavailable, so list views can degrade gracefully.
    fn current_branch(&self, worktree_path: &str) -> Result<Option<String>, AppError>;

    /// Resolve the current checkout ref for an arbitrary path.
    ///
    /// Implementations should return the checked-out branch name when one is
    /// available, and otherwise fall back to the exact `HEAD` commit SHA so
    /// callers can branch from detached checkouts without guessing.
    #[allow(dead_code)]
    #[allow(dead_code)]
    fn resolve_base_ref(&self, path: &str) -> Result<Option<String>, AppError>;

    /// Return the parent git root for a path when one exists.
    ///
    /// Backends should return `Ok(None)` when the path is outside any git
    /// repository so callers can treat git metadata as optional.
    fn parent_git_root(&self, path: &str) -> Result<Option<String>, AppError>;
}
