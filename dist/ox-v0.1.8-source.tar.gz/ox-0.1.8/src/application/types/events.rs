/// Outcome for one application action persisted to the event log.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) enum EventOutcome {
    Success,
    Failure,
}

/// Structured application event written to local persistent storage.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct AppEvent {
    pub(crate) op_id: String,
    pub(crate) feature: String,
    pub(crate) action: String,
    pub(crate) target: Option<String>,
    pub(crate) outcome: EventOutcome,
    pub(crate) detail: Option<String>,
}

/// One persisted event row returned for `ox events`.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct LoggedEvent {
    pub(crate) timestamp_unix_ms: u128,
    pub(crate) op_id: String,
    pub(crate) feature: String,
    pub(crate) action: String,
    pub(crate) target: Option<String>,
    pub(crate) outcome: EventOutcome,
    pub(crate) detail: Option<String>,
}

impl AppEvent {
    /// Build a successful event row for one action.
    pub(crate) fn success(feature: &str, action: &str, target: Option<String>) -> Self {
        Self {
            op_id: new_opaque_id("op"),
            feature: feature.to_string(),
            action: action.to_string(),
            target,
            outcome: EventOutcome::Success,
            detail: None,
        }
    }

    /// Build a failed event row for one action with error details.
    pub(crate) fn failure(
        feature: &str,
        action: &str,
        target: Option<String>,
        detail: String,
    ) -> Self {
        Self {
            op_id: new_opaque_id("op"),
            feature: feature.to_string(),
            action: action.to_string(),
            target,
            outcome: EventOutcome::Failure,
            detail: Some(detail),
        }
    }
}

fn new_opaque_id(prefix: &str) -> String {
    use std::sync::atomic::{AtomicU64, Ordering};
    use std::time::{SystemTime, UNIX_EPOCH};

    static NEXT_ID: AtomicU64 = AtomicU64::new(1);
    let counter = NEXT_ID.fetch_add(1, Ordering::Relaxed);
    let now_nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_nanos());
    let pid = std::process::id();
    format!("{prefix}_{now_nanos}_{pid}_{counter}")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn app_event_success_sets_outcome() {
        let event = AppEvent::success("agents", "create", Some("dev".to_string()));
        assert_eq!(event.outcome, EventOutcome::Success);
        assert_eq!(event.feature, "agents");
        assert_eq!(event.action, "create");
        assert_eq!(event.target.as_deref(), Some("dev"));
        assert!(event.detail.is_none());
    }

    #[test]
    fn app_event_failure_captures_detail() {
        let event = AppEvent::failure("agents", "delete", None, "tmux error".to_string());
        assert_eq!(event.outcome, EventOutcome::Failure);
        assert_eq!(event.detail.as_deref(), Some("tmux error"));
        assert!(event.target.is_none());
    }

    #[test]
    fn opaque_ids_are_unique() {
        let id1 = new_opaque_id("test");
        let id2 = new_opaque_id("test");
        assert_ne!(id1, id2, "sequential IDs must be unique");
    }

    #[test]
    fn opaque_id_starts_with_prefix() {
        let id = new_opaque_id("bind");
        assert!(id.starts_with("bind_"), "id should start with prefix");
    }
}
