use std::path::PathBuf;

use crate::domain::{Agent, AgentId, AgentKind};

/// Configured pinned agent session that should always exist and keep a fixed
/// visual position in list output.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct PinnedSessionSpec {
    pub(crate) name: String,
    pub(crate) position: usize,
    pub(crate) agent_kind: AgentKind,
    /// Optional startup directory applied when the pinned session is first
    /// created. Existing sessions keep their persisted working-directory state.
    pub(crate) working_dir: Option<String>,
}

/// Runtime turn activity for one detected agent process.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum RuntimeStatus {
    /// Agent is actively processing work.
    Running,
    /// Agent is ready for input or blocked on a user confirmation/approval.
    Waiting,
    /// `ox` cannot determine a trustworthy managed runtime state.
    Unknown,
}

impl RuntimeStatus {
    pub(crate) fn as_label(self) -> &'static str {
        match self {
            Self::Running => "running",
            Self::Waiting => "waiting",
            Self::Unknown => "unknown",
        }
    }

    pub(crate) fn is_running(self) -> bool {
        matches!(self, Self::Running)
    }
}

/// Snapshot of one host runtime session discovered from tmux.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct HostSessionSnapshot {
    pub(crate) name: String,
    pub(crate) windows: u32,
    pub(crate) attached: bool,
    pub(crate) agent_kind: AgentKind,
    /// Runtime status observed from live probe data.
    pub(crate) runtime_status: RuntimeStatus,
}

/// Structured create request shared by CLI and TUI for one agent.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct CreateAgentRequest {
    pub(crate) display_name: String,
    pub(crate) agent_kind: AgentKind,
    pub(crate) workspace: WorkspaceSpec,
    pub(crate) working_dir: Option<String>,
    pub(crate) state_spec: AgentStateSpec,
}

impl CreateAgentRequest {
    /// Build a create request without optional external state.
    pub(crate) fn new(display_name: String, agent_kind: AgentKind) -> Self {
        Self {
            display_name,
            agent_kind,
            workspace: WorkspaceSpec::default(),
            working_dir: None,
            state_spec: AgentStateSpec::default(),
        }
    }

    /// Attach one explicit working directory path to the request.
    pub(crate) fn with_working_dir(mut self, working_dir: Option<String>) -> Self {
        self.workspace.repo_root.clone_from(&working_dir);
        self.working_dir = working_dir;
        self
    }

    /// Attach one git worktree create spec to the request.
    pub(crate) fn with_git_worktree(mut self, worktree: GitWorktreeCreateSpec) -> Self {
        let workspace_name = worktree
            .worktree_name
            .clone()
            .or_else(|| worktree.branch_name.clone())
            .filter(|value| !value.trim().is_empty());
        self.workspace.backend = WorkspaceBackend::LocalWorktree;
        self.workspace.name = workspace_name;
        self.workspace.base_ref.clone_from(&worktree.base_ref);
        self.workspace.repo_root.clone_from(&worktree.repo_root);
        self.state_spec.git_worktree = Some(worktree);
        self
    }

    /// Attach one workspace specification as the primary create target.
    pub(crate) fn with_workspace(mut self, workspace: WorkspaceSpec) -> Self {
        self.working_dir.clone_from(&workspace.repo_root);
        self.state_spec.git_worktree = None;
        if workspace.backend == WorkspaceBackend::LocalWorktree {
            let mut spec = GitWorktreeCreateSpec::simple(workspace.name.clone());
            spec.base_ref.clone_from(&workspace.base_ref);
            spec.repo_root.clone_from(&workspace.repo_root);
            self = self.with_git_worktree(spec);
        }
        self.workspace = workspace;
        self
    }
}

/// Provisioning backend for the primary workspace attached to a new agent.
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub(crate) enum WorkspaceBackend {
    #[default]
    LocalCurrentTree,
    LocalWorktree,
}

/// First-class workspace request attached to one create-agent operation.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(crate) struct WorkspaceSpec {
    pub(crate) backend: WorkspaceBackend,
    pub(crate) name: Option<String>,
    pub(crate) repo_root: Option<String>,
    pub(crate) base_ref: Option<String>,
}

/// Optional external-state settings for agent creation.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(crate) struct AgentStateSpec {
    pub(crate) git_worktree: Option<GitWorktreeCreateSpec>,
}

/// Input settings for creating one managed git worktree state.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct GitWorktreeCreateSpec {
    pub(crate) worktree_name: Option<String>,
    pub(crate) branch_name: Option<String>,
    pub(crate) base_ref: Option<String>,
    pub(crate) repo_root: Option<String>,
}

impl GitWorktreeCreateSpec {
    /// Build a "simple path" spec where one optional label can name both
    /// branch + worktree directory.
    pub(crate) fn simple(worktree_label: Option<String>) -> Self {
        Self {
            worktree_name: worktree_label.clone(),
            branch_name: worktree_label,
            base_ref: None,
            repo_root: None,
        }
    }
}

/// Fully resolved worktree settings after application-layer defaulting.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct ResolvedGitWorktreeSpec {
    pub(crate) worktree_label: String,
    pub(crate) base_ref: String,
    pub(crate) repo_root: Option<String>,
}

/// Runtime startup request for creating/refreshing the tmux session state.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct RuntimeStartRequest {
    pub(crate) agent_id: AgentId,
    pub(crate) session_name: String,
    pub(crate) agent_kind: AgentKind,
    pub(crate) working_dir: Option<PathBuf>,
    /// Managed Codex thread ID to resume when launching a Codex runtime.
    ///
    /// Non-Codex agents keep this `None`.
    pub(crate) codex_thread_id: Option<String>,
    /// `OpenCode` server URL for agents that attach to a running `opencode serve`.
    ///
    /// Non-OpenCode agents keep this `None`.
    pub(crate) opencode_server_url: Option<String>,
    /// `OpenCode` session ID to attach the TUI to.
    ///
    /// Non-OpenCode agents keep this `None`.
    pub(crate) opencode_session_id: Option<String>,
}

/// Request payload for creating a fresh Codex thread through the native
/// app-server protocol.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct CodexThreadStartRequest {
    /// Working directory to apply when opening the thread runtime context.
    pub(crate) working_dir: Option<PathBuf>,
}

/// Result payload returned by Codex thread lifecycle operations.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct CodexThreadBootstrap {
    /// Active thread identifier after start/resume succeeds.
    pub(crate) thread_id: String,
    /// Number of non-response JSON-RPC events observed during bootstrap.
    pub(crate) event_count: usize,
}

/// Runtime probe result for one binding.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct RuntimeProbeResult {
    pub(crate) binding_id: String,
    pub(crate) runtime_status: RuntimeStatus,
    /// Whether tmux currently reports one attached client for this session.
    ///
    /// This is a host-runtime property rather than provider state, so it lives
    /// on the probe alongside the live pane cwd/status snapshot.
    pub(crate) attached: bool,
    /// Live runtime classification observed during probe.
    ///
    /// This may differ from the persisted agent row kind when a session that
    /// was created as `shell` is currently running a coding agent child
    /// process (for example `codex`).
    pub(crate) agent_kind: AgentKind,
    /// Live current path for the session's active pane when tmux can provide it.
    ///
    /// This allows `agents list` to show up-to-date cwd/git context even when the
    /// user manually `cd`s after session startup.
    pub(crate) current_working_dir: Option<String>,
    pub(crate) observed_at_unix_ms: u128,
}

/// Primary app read model used by CLI and TUI.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct AgentView {
    pub(crate) agent: Agent,
    pub(crate) runtime_status: RuntimeStatus,
    pub(crate) attached: bool,
    pub(crate) working_dir: Option<String>,
    pub(crate) git_root: Option<String>,
    pub(crate) git_worktree_path: Option<String>,
    pub(crate) git_branch: Option<String>,
    pub(crate) git_base_ref: Option<String>,
}

/// Resolved persistent storage locations used by the application.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct AppStoragePaths {
    pub(crate) sqlite_db_path: String,
    pub(crate) config_path: String,
}

/// App-level settings loaded from `config.json`.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct AppSettings {
    pub(crate) events_default_limit: usize,
    pub(crate) tui_refresh_interval_ms: u64,
    pub(crate) opencode: OpencodeSettings,
}

/// `OpenCode` provider settings loaded from `config.json`.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct OpencodeSettings {
    pub(crate) server_url: String,
    pub(crate) username_env: String,
    pub(crate) password_env: String,
    pub(crate) request_timeout_ms: u64,
    pub(crate) read_request_timeout_ms: u64,
    pub(crate) status_poll_interval_ms: u64,
    pub(crate) conversation_page_size: usize,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::domain::AgentKind;

    #[test]
    fn create_agent_request_new_defaults_to_no_worktree() {
        let req = CreateAgentRequest::new("dev".to_string(), AgentKind::Shell);
        assert_eq!(req.display_name, "dev");
        assert_eq!(req.agent_kind, AgentKind::Shell);
        assert_eq!(req.workspace.backend, WorkspaceBackend::LocalCurrentTree);
        assert!(req.working_dir.is_none());
        assert!(req.state_spec.git_worktree.is_none());
    }

    #[test]
    fn create_agent_request_with_git_worktree_attaches_spec() {
        let req = CreateAgentRequest::new("dev".to_string(), AgentKind::Claude)
            .with_git_worktree(GitWorktreeCreateSpec::simple(Some("feature-x".to_string())));
        let Some(wt) = req.state_spec.git_worktree.as_ref() else {
            return;
        };
        assert_eq!(wt.worktree_name.as_deref(), Some("feature-x"));
        assert_eq!(wt.branch_name.as_deref(), Some("feature-x"));
        assert!(wt.base_ref.is_none());
        assert!(wt.repo_root.is_none());
        assert_eq!(req.workspace.backend, WorkspaceBackend::LocalWorktree);
        assert_eq!(req.workspace.name.as_deref(), Some("feature-x"));
    }

    #[test]
    fn git_worktree_spec_simple_none_label() {
        let spec = GitWorktreeCreateSpec::simple(None);
        assert!(spec.worktree_name.is_none());
        assert!(spec.branch_name.is_none());
        assert!(spec.repo_root.is_none());
        assert!(spec.base_ref.is_none());
    }
}
