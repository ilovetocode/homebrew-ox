/// Provider identity for provider-backed message dispatch.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum MessageDispatchProvider {
    Opencode,
}

/// Provider session coordinates used by message dispatch adapters.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct MessageDispatchSessionRef {
    pub(crate) provider: MessageDispatchProvider,
    pub(crate) server_url: String,
    pub(crate) session_id: String,
    pub(crate) directory: Option<String>,
}

/// Provider session inventory row returned by session-listing APIs.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct MessageDispatchSessionSummary {
    pub(crate) session: MessageDispatchSessionRef,
    pub(crate) title: Option<String>,
    pub(crate) slug: Option<String>,
    pub(crate) parent_session_id: Option<String>,
    pub(crate) updated_at_unix_ms: Option<u128>,
}

/// Request to allocate a provider conversation/session.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct MessageDispatchCreateSessionRequest {
    pub(crate) provider: MessageDispatchProvider,
    pub(crate) server_url: String,
    pub(crate) directory: Option<String>,
}

/// Result for provider conversation/session creation.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct MessageDispatchCreateSessionResult {
    pub(crate) session: MessageDispatchSessionRef,
}

/// Request to dispatch one message into a provider conversation.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct MessageDispatchSendRequest {
    pub(crate) session: MessageDispatchSessionRef,
    pub(crate) message: String,
}

/// Request to invoke one provider-native slash command on a conversation.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct MessageDispatchSlashCommandRequest {
    pub(crate) session: MessageDispatchSessionRef,
    pub(crate) command: String,
    pub(crate) arguments: String,
}

/// Result for one provider-dispatched message.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct MessageDispatchResult {
    pub(crate) dispatch_id: String,
    pub(crate) accepted_at_unix_ms: u128,
    pub(crate) provider_message_id: Option<String>,
}

/// Request to read provider conversation history.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct MessageReadRequest {
    pub(crate) session: MessageDispatchSessionRef,
    pub(crate) limit: Option<usize>,
}

/// One normalized conversation message row returned by read APIs.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct ConversationMessage {
    pub(crate) message_id: String,
    pub(crate) role: String,
    pub(crate) created_at_unix_ms: u128,
    pub(crate) completed_at_unix_ms: Option<u128>,
    pub(crate) text: String,
    pub(crate) tool_names: Vec<String>,
    pub(crate) patch_files: Vec<String>,
    pub(crate) finish_reason: Option<String>,
    pub(crate) synthesized_text: bool,
}

/// Source used to build one normalized conversation transcript response.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum ConversationReadSource {
    OpencodeSession,
    CodexRollout,
}

impl ConversationReadSource {
    pub(crate) fn as_label(self) -> &'static str {
        match self {
            Self::OpencodeSession => "opencode_session",
            Self::CodexRollout => "codex_rollout",
        }
    }
}

/// Full normalized conversation transcript response.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct ConversationReadResult {
    pub(crate) messages: Vec<ConversationMessage>,
    pub(crate) source: ConversationReadSource,
    pub(crate) partial: bool,
}
