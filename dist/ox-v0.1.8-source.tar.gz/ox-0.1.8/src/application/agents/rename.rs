use crate::application::clock::unix_time_ms;
use crate::application::pinned_session_guard::PinnedSessionGuard;
use crate::application::ports::{AgentRuntimePort, AgentStorePort};
use crate::domain::{AgentId, RuntimeProvider};
use crate::error::{AgentError, AppError};

use super::ordering::validate_display_name;

pub(super) fn rename_agent(
    store: &dyn AgentStorePort,
    runtime: &dyn AgentRuntimePort,
    id: &AgentId,
    new_display_name: &str,
    pinned_guard: &PinnedSessionGuard<'_>,
) -> Result<(), AppError> {
    let current = store
        .find_agent_runtime_record_by_id(id.clone())?
        .ok_or(AppError::Agent(AgentError::NotFound))?;

    pinned_guard.reject_if_pinned(current.agent.display_name(), "renamed")?;

    validate_display_name(new_display_name)?;
    if let Some(existing) = store.find_agent_by_display_name(new_display_name)?
        && existing.id().as_str() != current.agent.id().as_str()
    {
        return Err(AppError::Agent(AgentError::DisplayNameTaken));
    }

    // Rename tmux first so a runtime failure cannot leave persisted state ahead.
    if let Some(binding) = current.binding.as_ref()
        && binding.provider == RuntimeProvider::Tmux
    {
        runtime.rename(binding, new_display_name)?;
        let mut updated_binding = binding.clone();
        updated_binding.external_ref = new_display_name.to_string();
        updated_binding.updated_at_unix_ms = unix_time_ms();
        store.upsert_binding(&updated_binding)?;
    }

    let updated = current
        .agent
        .renamed(new_display_name.to_string(), unix_time_ms());
    store.update_agent(&updated, current.agent.version())
}
