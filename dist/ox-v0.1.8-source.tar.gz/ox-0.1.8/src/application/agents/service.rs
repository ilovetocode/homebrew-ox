use std::sync::Arc;
use std::thread;

use crate::application::pinned_session_guard::PinnedSessionGuard;
use crate::application::pinned_session_reconciler::PinnedSessionReconciler;
use crate::application::ports::{
    AgentRuntimePort, AgentStorePort, CodexThreadPort, MessageDispatchPort,
    OpencodeSessionBootstrapPort, WorktreePort,
};
use crate::application::runtime_binding_manager::{
    RuntimeBindingManager, is_retryable_missing_tmux,
};
use crate::application::{
    AgentProvisioningService, AgentView, CreateAgentRequest, PinnedSessionSpec,
};
use crate::domain::{AgentId, RuntimeProvider};
use crate::error::AppError;

use super::{delete, listing, ordering, rename, worktree};

/// Layer order contract: `AppApi` -> `AppService` -> `AgentLifecycleService` ->
/// `AgentInteractionService`. Keep lifecycle orchestration in this service and
/// keep interactive runtime operations in `AgentInteractionService`.
///
/// Service that orchestrates agent lifecycle workflows.
pub(crate) struct AgentLifecycleService {
    store: Arc<dyn AgentStorePort>,
    runtime: Arc<dyn AgentRuntimePort>,
    worktree: Arc<dyn WorktreePort>,
    codex_threads: Arc<dyn CodexThreadPort>,
    dispatch: Arc<dyn MessageDispatchPort>,
    opencode_provisioning: OpencodeProvisioning,
    pinned_sessions: Vec<PinnedSessionSpec>,
}

/// OpenCode-specific provisioning dependencies grouped to keep service
/// construction signatures compact and explicit.
pub(crate) struct OpencodeProvisioning {
    session_bootstrap: Arc<dyn OpencodeSessionBootstrapPort>,
}

impl OpencodeProvisioning {
    pub(crate) fn new(session_bootstrap: Arc<dyn OpencodeSessionBootstrapPort>) -> Self {
        Self { session_bootstrap }
    }
}

impl AgentLifecycleService {
    /// Build agent service from persistence + runtime ports.
    pub(crate) fn new(
        store: Arc<dyn AgentStorePort>,
        runtime: Arc<dyn AgentRuntimePort>,
        worktree: Arc<dyn WorktreePort>,
        codex_threads: Arc<dyn CodexThreadPort>,
        dispatch: Arc<dyn MessageDispatchPort>,
        opencode_provisioning: OpencodeProvisioning,
        pinned_sessions: Vec<PinnedSessionSpec>,
    ) -> Self {
        Self {
            store,
            runtime,
            worktree,
            codex_threads,
            dispatch,
            opencode_provisioning,
            pinned_sessions,
        }
    }

    /// Return full merged agent snapshots.
    pub(crate) fn list_agents(&self) -> Result<Vec<AgentView>, AppError> {
        listing::list_agents(
            self.store.as_ref(),
            self.runtime.as_ref(),
            self.worktree.as_ref(),
            self.codex_threads.as_ref(),
            self.dispatch.as_ref(),
        )
    }

    /// Return a minimized agent list for quick-switch picker startup.
    ///
    /// This path intentionally skips runtime probing and provider status
    /// enrichment so interactive picker startup stays responsive.
    pub(crate) fn list_agents_for_picker(&self) -> Result<Vec<AgentView>, AppError> {
        listing::list_agents_for_picker(self.store.as_ref())
    }

    /// Enforce pinned-session policy outside the list hot path.
    pub(crate) fn reconcile_pinned_sessions(&self) -> Result<(), AppError> {
        PinnedSessionReconciler::new(
            self.store.as_ref(),
            self.runtime.as_ref(),
            self.worktree.as_ref(),
            self.codex_threads.as_ref(),
            self.opencode_provisioning.session_bootstrap.as_ref(),
            &self.pinned_sessions,
        )
        .reconcile()
    }

    /// Start a best-effort background pass that recreates missing tmux sessions.
    ///
    /// This pass is intentionally non-blocking and non-fatal for startup. It
    /// attempts to heal only agents that already have tmux runtime bindings and
    /// whose backing tmux session is missing.
    pub(crate) fn spawn_background_tmux_runtime_heal(&self) {
        let store = self.store.clone();
        let runtime = self.runtime.clone();
        let _ = thread::Builder::new()
            .name("ox-tmux-runtime-heal".to_string())
            .spawn(move || {
                let Ok(records) = store.list_agent_runtime_records() else {
                    return;
                };
                for record in records {
                    let Some(binding) = record.binding.as_ref() else {
                        continue;
                    };
                    if binding.provider != RuntimeProvider::Tmux {
                        continue;
                    }
                    match runtime.capture_output(binding, 1) {
                        Err(err) if is_retryable_missing_tmux(&err) => {
                            let manager = RuntimeBindingManager::new(&*store, &*runtime);
                            let _ = manager.ensure_binding(&record);
                        }
                        Ok(_) | Err(_) => {}
                    }
                }
            });
    }

    /// Create one agent and eagerly provision configured external states.
    pub(crate) fn create_agent(&self, request: CreateAgentRequest) -> Result<AgentId, AppError> {
        AgentProvisioningService::new(
            self.store.as_ref(),
            self.runtime.as_ref(),
            self.worktree.as_ref(),
            self.codex_threads.as_ref(),
            self.opencode_provisioning.session_bootstrap.as_ref(),
        )
        .provision(request)
    }

    /// Rename an existing agent.
    pub(crate) fn rename_agent(
        &self,
        id: &AgentId,
        new_display_name: &str,
    ) -> Result<(), AppError> {
        let pinned_guard = PinnedSessionGuard::new(&self.pinned_sessions);
        rename::rename_agent(
            self.store.as_ref(),
            self.runtime.as_ref(),
            id,
            new_display_name,
            &pinned_guard,
        )
    }

    /// Swap the visual position of an agent with whatever is at `target_visual_position`.
    pub(crate) fn reorder_agent(
        &self,
        id: &AgentId,
        target_visual_position: i64,
    ) -> Result<(), AppError> {
        let pinned_guard = PinnedSessionGuard::new(&self.pinned_sessions);
        ordering::reorder_agent(
            self.store.as_ref(),
            id,
            target_visual_position,
            &pinned_guard,
        )
    }

    /// Hard-delete one agent and its runtime binding.
    pub(crate) fn delete_agent(&self, id: &AgentId) -> Result<(), AppError> {
        let pinned_guard = PinnedSessionGuard::new(&self.pinned_sessions);
        delete::delete_agent(
            self.store.as_ref(),
            self.runtime.as_ref(),
            self.worktree.as_ref(),
            id,
            &pinned_guard,
        )
    }

    /// Recreate an existing agent as a shell rooted in a managed worktree.
    pub(crate) fn switch_agent_to_worktree_shell(
        &self,
        id: &AgentId,
        branch_name: &str,
    ) -> Result<(), AppError> {
        worktree::switch_agent_to_worktree_shell(
            self.store.as_ref(),
            self.runtime.as_ref(),
            self.worktree.as_ref(),
            id,
            branch_name,
        )
    }
}

#[cfg(test)]
mod tests {
    use super::is_retryable_missing_tmux;
    use crate::error::{AppError, TmuxError};

    #[test]
    fn retryable_missing_tmux_detects_cant_find_session() {
        let err = AppError::Tmux(TmuxError::CommandFailed {
            stderr: "can't find session: planner".to_string(),
        });
        assert!(is_retryable_missing_tmux(&err));
    }

    #[test]
    fn retryable_missing_tmux_rejects_other_tmux_errors() {
        let err = AppError::Tmux(TmuxError::CommandFailed {
            stderr: "permission denied".to_string(),
        });
        assert!(!is_retryable_missing_tmux(&err));
    }

    #[test]
    fn retryable_missing_tmux_detects_cant_find_pane() {
        let err = AppError::Tmux(TmuxError::CommandFailed {
            stderr: "can't find pane: n5".to_string(),
        });
        assert!(is_retryable_missing_tmux(&err));
    }
}
