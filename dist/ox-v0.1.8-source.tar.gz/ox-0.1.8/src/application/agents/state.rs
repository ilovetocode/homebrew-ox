use std::path::{Path, PathBuf};

use serde::Deserialize;

use crate::application::RuntimeProbeResult;
use crate::application::ports::WorktreePort;
use crate::domain::{AgentStateBinding, AgentStateKind};

/// Canonical file-system and git context resolved for one agent.
#[derive(Clone, Debug, Default, PartialEq, Eq)]
pub(crate) struct AgentFsContext {
    pub(crate) working_dir: Option<String>,
    pub(crate) git_root: Option<String>,
    pub(crate) worktree_path: Option<String>,
    pub(crate) branch: Option<String>,
    pub(crate) base_ref: Option<String>,
}

impl AgentFsContext {
    /// Convert the resolved working directory to `PathBuf` for runtime start requests.
    pub(crate) fn working_dir_path_buf(&self) -> Option<PathBuf> {
        self.working_dir.as_deref().map(PathBuf::from)
    }
}

/// Layer order contract: `AppApi` -> `AppService` -> `AgentLifecycleService` ->
/// `AgentInteractionService`. This helper centralizes agent state binding
/// interpretation so runtime and view paths use one precedence model.
pub(crate) struct AgentFsContextResolver;

impl AgentFsContextResolver {
    /// Resolve one canonical file-system path from a state binding.
    pub(crate) fn state_binding_path(state: &AgentStateBinding) -> Option<String> {
        if let Ok(metadata) = serde_json::from_str::<PathStateMetadata>(&state.metadata_json)
            && let Some(path) = metadata.path
            && !path.trim().is_empty()
        {
            return Some(path);
        }
        if state.external_ref.trim().is_empty() {
            return None;
        }
        Some(state.external_ref.clone())
    }

    /// Resolve create-time file-system context from persisted state only.
    pub(crate) fn resolve_from_states(states: &[AgentStateBinding]) -> AgentFsContext {
        let worktree_state = states
            .iter()
            .find(|state| state.state_kind == AgentStateKind::GitWorktree);
        let working_dir = states
            .iter()
            .find(|state| state.state_kind == AgentStateKind::WorkingDirectory)
            .and_then(Self::state_binding_path);
        let git_root = states
            .iter()
            .find(|state| state.state_kind == AgentStateKind::GitRoot)
            .and_then(Self::state_binding_path);

        let metadata = worktree_state.and_then(|state| {
            serde_json::from_str::<GitWorktreeMetadata>(&state.metadata_json).ok()
        });

        AgentFsContext {
            working_dir: working_dir
                .clone()
                .or_else(|| worktree_state.map(|state| state.external_ref.clone())),
            git_root: git_root.clone().or_else(|| {
                metadata
                    .as_ref()
                    .and_then(|metadata| metadata.repo_root.clone())
            }),
            worktree_path: worktree_state.map(|state| state.external_ref.clone()),
            branch: metadata
                .as_ref()
                .and_then(|metadata| metadata.worktree_label.clone()),
            base_ref: metadata.and_then(|metadata| metadata.base_ref),
        }
    }

    /// Resolve the full context used by list/view flows.
    pub(crate) fn resolve_for_view(
        worktree: &dyn WorktreePort,
        states: &[AgentStateBinding],
        runtime_probe: Option<&RuntimeProbeResult>,
    ) -> AgentFsContext {
        let mut context = Self::resolve_from_states(states);
        Self::hydrate_git_context(worktree, &mut context);
        Self::apply_live_runtime_context(worktree, &mut context, runtime_probe);
        context
    }

    fn hydrate_git_context(worktree: &dyn WorktreePort, context: &mut AgentFsContext) {
        if context.git_root.is_none()
            && let Some(working_dir) = context.working_dir.as_deref()
            && let Ok(Some(derived_root)) = worktree.parent_git_root(working_dir)
        {
            context.git_root = Some(derived_root);
        }

        if let Some(git_root) = context.git_root.as_deref()
            && let Ok(Some(current_branch)) = worktree.current_branch(git_root)
        {
            context.branch = Some(current_branch);
        }
    }

    fn apply_live_runtime_context(
        worktree: &dyn WorktreePort,
        context: &mut AgentFsContext,
        runtime_probe: Option<&RuntimeProbeResult>,
    ) {
        let Some(runtime_working_dir) = runtime_probe
            .and_then(|probe| probe.current_working_dir.as_deref())
            .map(str::trim)
            .filter(|path| !path.is_empty())
        else {
            return;
        };

        // Runtime path is authoritative for list views because users may `cd`
        // after startup. Persisted state remains create-time intent only.
        context.working_dir = Some(runtime_working_dir.to_string());

        if let Ok(Some(git_root)) = worktree.parent_git_root(runtime_working_dir) {
            let is_inside_managed_worktree =
                context
                    .worktree_path
                    .as_deref()
                    .is_some_and(|worktree_path| {
                        Path::new(runtime_working_dir).starts_with(Path::new(worktree_path))
                    });
            if !(is_inside_managed_worktree && context.git_root.is_some()) {
                context.git_root = Some(git_root);
            }
            // Branch should reflect the directory the user is currently in.
            context.branch = worktree.current_branch(runtime_working_dir).ok().flatten();
        } else {
            context.git_root = None;
            context.branch = None;
        }
    }
}

#[derive(Deserialize)]
struct PathStateMetadata {
    path: Option<String>,
}

#[derive(Deserialize)]
struct GitWorktreeMetadata {
    repo_root: Option<String>,
    worktree_label: Option<String>,
    base_ref: Option<String>,
}

#[cfg(test)]
mod tests {
    use super::AgentFsContextResolver;
    use crate::application::{
        ResolvedGitWorktreeSpec, RuntimeProbeResult, RuntimeStatus, WorktreePort,
    };
    use crate::domain::{
        Agent, AgentId, AgentKind, AgentStateBinding, AgentStateKind, AgentStateProvider,
        PRIMARY_STATE_BINDING_KEY,
    };
    use crate::error::AppError;

    #[derive(Default)]
    struct FakeWorktree {
        parent_git_root: Option<String>,
        current_branch: Option<String>,
    }

    impl WorktreePort for FakeWorktree {
        fn create_worktree(
            &self,
            _agent: &Agent,
            _spec: &ResolvedGitWorktreeSpec,
        ) -> Result<AgentStateBinding, AppError> {
            Err(AppError::InvalidInput {
                message: "not used in this test".to_string(),
            })
        }

        fn delete_worktree(&self, _state: &AgentStateBinding) -> Result<(), AppError> {
            Ok(())
        }

        fn current_branch(&self, _worktree_path: &str) -> Result<Option<String>, AppError> {
            Ok(self.current_branch.clone())
        }

        fn resolve_base_ref(&self, _path: &str) -> Result<Option<String>, AppError> {
            Ok(self.current_branch.clone())
        }

        fn parent_git_root(&self, _path: &str) -> Result<Option<String>, AppError> {
            Ok(self.parent_git_root.clone())
        }
    }

    #[test]
    fn resolve_from_states_prefers_working_directory_binding() {
        let agent_id = AgentId::new();
        let working_dir_state = AgentStateBinding::new(
            agent_id.clone(),
            AgentStateKind::WorkingDirectory,
            AgentStateProvider::Git,
            PRIMARY_STATE_BINDING_KEY.to_string(),
            "opaque-ref".to_string(),
            serde_json::json!({ "path": "/tmp/work" }).to_string(),
            1,
        );
        let worktree_state = AgentStateBinding::new(
            agent_id,
            AgentStateKind::GitWorktree,
            AgentStateProvider::Git,
            PRIMARY_STATE_BINDING_KEY.to_string(),
            "/tmp/worktree".to_string(),
            "{}".to_string(),
            1,
        );

        let context =
            AgentFsContextResolver::resolve_from_states(&[working_dir_state, worktree_state]);
        assert_eq!(context.working_dir.as_deref(), Some("/tmp/work"));
    }

    #[test]
    fn resolve_for_view_uses_runtime_working_dir_and_branch() {
        let worktree = FakeWorktree {
            parent_git_root: Some("/repo".to_string()),
            current_branch: Some("feature/live".to_string()),
        };
        let probe = RuntimeProbeResult {
            binding_id: "binding-1".to_string(),
            runtime_status: RuntimeStatus::Running,
            attached: false,
            agent_kind: AgentKind::Shell,
            current_working_dir: Some("/repo/subdir".to_string()),
            observed_at_unix_ms: 1,
        };

        let context = AgentFsContextResolver::resolve_for_view(&worktree, &[], Some(&probe));
        assert_eq!(context.working_dir.as_deref(), Some("/repo/subdir"));
        assert_eq!(context.git_root.as_deref(), Some("/repo"));
        assert_eq!(context.branch.as_deref(), Some("feature/live"));
    }
}
