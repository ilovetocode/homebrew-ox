use std::collections::HashMap;

use crate::application::ports::{
    AgentRuntimePort, AgentStorePort, CodexThreadPort, MessageDispatchPort, WorktreePort,
};
use crate::application::{AgentView, RuntimeProbeResult, RuntimeStatus};
use crate::domain::{AgentId, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding};
use crate::error::AppError;

use super::status;
use super::view::project_agent_view;

/// Read-model snapshot used by the agent list pipeline.
///
/// Keeping observed and effective probes separate makes it easier to layer
/// provider status over the raw runtime probe without losing the original
/// observation.
#[derive(Clone)]
pub(super) struct LoadedAgentSnapshot {
    pub(super) record: AgentRuntimeRecord,
    pub(super) states: Vec<AgentStateBinding>,
    pub(super) observed_probe: Option<RuntimeProbeResult>,
    pub(super) effective_probe: Option<RuntimeProbeResult>,
}

pub(super) fn list_agents(
    store: &dyn AgentStorePort,
    runtime: &dyn AgentRuntimePort,
    worktree: &dyn WorktreePort,
    codex_threads: &dyn CodexThreadPort,
    dispatch: &dyn MessageDispatchPort,
) -> Result<Vec<AgentView>, AppError> {
    let mut snapshots = load_agent_snapshots(store, runtime)?;
    if snapshots.is_empty() {
        return Ok(Vec::new());
    }

    status::apply_effective_statuses(store, runtime, codex_threads, dispatch, &mut snapshots);

    let mut agents = snapshots
        .into_iter()
        .map(|snapshot| {
            project_agent_view(
                worktree,
                &snapshot.record,
                &snapshot.states,
                snapshot.effective_probe.as_ref(),
            )
        })
        .collect::<Vec<_>>();
    agents.sort_by_key(|agent| agent.agent.display_order());
    Ok(agents)
}

pub(super) fn list_agents_for_picker(
    store: &dyn AgentStorePort,
) -> Result<Vec<AgentView>, AppError> {
    let records = store.list_agent_runtime_records()?;
    if records.is_empty() {
        return Ok(Vec::new());
    }

    let mut agents = records
        .into_iter()
        .map(|record| AgentView {
            agent: record.agent,
            runtime_status: RuntimeStatus::Unknown,
            attached: false,
            working_dir: None,
            git_root: None,
            git_worktree_path: None,
            git_branch: None,
            git_base_ref: None,
        })
        .collect::<Vec<_>>();
    agents.sort_by_key(|agent| agent.agent.display_order());
    Ok(agents)
}

fn load_agent_snapshots(
    store: &dyn AgentStorePort,
    runtime: &dyn AgentRuntimePort,
) -> Result<Vec<LoadedAgentSnapshot>, AppError> {
    let records = store.list_agent_runtime_records()?;
    if records.is_empty() {
        return Ok(Vec::new());
    }

    let agent_ids = records
        .iter()
        .map(|record| record.agent.id())
        .collect::<Vec<_>>();
    let state_bindings = store.list_state_bindings_by_agent_ids(&agent_ids)?;
    let mut states_by_agent_id = HashMap::<AgentId, Vec<AgentStateBinding>>::new();
    for state in state_bindings {
        states_by_agent_id
            .entry(state.agent_id.clone())
            .or_default()
            .push(state);
    }

    let bindings = records
        .iter()
        .filter_map(|record| record.binding.clone())
        .collect::<Vec<AgentRuntimeBinding>>();
    let probes = runtime.probe(&bindings)?;
    let probes_by_binding_id = probes
        .into_iter()
        .map(|probe| (probe.binding_id.clone(), probe))
        .collect::<HashMap<_, _>>();

    Ok(records
        .into_iter()
        .map(|record| {
            let observed_probe = record
                .binding
                .as_ref()
                .and_then(|binding| probes_by_binding_id.get(&binding.id).cloned());
            let effective_probe = observed_probe.clone();
            let states = states_by_agent_id
                .remove(&record.agent.id())
                .unwrap_or_default();
            LoadedAgentSnapshot {
                record,
                states,
                observed_probe,
                effective_probe,
            }
        })
        .collect())
}
