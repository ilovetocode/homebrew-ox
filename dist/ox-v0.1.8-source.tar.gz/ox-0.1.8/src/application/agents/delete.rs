use crate::application::pinned_session_guard::PinnedSessionGuard;
use crate::application::ports::{AgentRuntimePort, AgentStorePort, WorktreePort};
use crate::application::runtime_binding_manager::{
    RuntimeBindingManager, is_retryable_missing_tmux,
};
use crate::domain::{
    AgentId, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding, AgentStateKind,
};
use crate::error::{AgentError, AppError};

#[derive(Clone, Copy)]
enum DeleteMode {
    RecyclePinned,
    Delete,
}

struct DeletionPlan {
    mode: DeleteMode,
    binding_to_stop: Option<AgentRuntimeBinding>,
    worktree_states: Vec<AgentStateBinding>,
}

pub(super) fn delete_agent(
    store: &dyn AgentStorePort,
    runtime: &dyn AgentRuntimePort,
    worktree: &dyn WorktreePort,
    id: &AgentId,
    pinned_guard: &PinnedSessionGuard<'_>,
) -> Result<(), AppError> {
    let current = store
        .find_agent_runtime_record_by_id(id.clone())?
        .ok_or(AppError::Agent(AgentError::NotFound))?;

    let plan = build_deletion_plan(store, &current, pinned_guard)?;
    execute_deletion_plan(store, runtime, worktree, id, &current, &plan)
}

fn build_deletion_plan(
    store: &dyn AgentStorePort,
    record: &AgentRuntimeRecord,
    pinned_guard: &PinnedSessionGuard<'_>,
) -> Result<DeletionPlan, AppError> {
    // Pinned sessions are policy-managed identities. A delete request should
    // give users a clean slate by restarting runtime state, not removing the
    // persisted row from storage.
    if pinned_guard.is_pinned_name(record.agent.display_name()) {
        return Ok(DeletionPlan {
            mode: DeleteMode::RecyclePinned,
            binding_to_stop: record.binding.clone(),
            worktree_states: Vec::new(),
        });
    }

    let state_bindings = store.list_state_bindings_by_agent_id(record.agent.id())?;
    let worktree_states = state_bindings
        .into_iter()
        .filter(|state| state.state_kind == AgentStateKind::GitWorktree)
        .collect::<Vec<_>>();

    Ok(DeletionPlan {
        mode: DeleteMode::Delete,
        binding_to_stop: record.binding.clone(),
        worktree_states,
    })
}

fn execute_deletion_plan(
    store: &dyn AgentStorePort,
    runtime: &dyn AgentRuntimePort,
    worktree: &dyn WorktreePort,
    id: &AgentId,
    record: &AgentRuntimeRecord,
    plan: &DeletionPlan,
) -> Result<(), AppError> {
    match plan.mode {
        DeleteMode::RecyclePinned => {
            recycle_pinned_agent(store, runtime, record, plan.binding_to_stop.as_ref())
        }
        DeleteMode::Delete => {
            if let Some(binding) = plan.binding_to_stop.as_ref() {
                runtime.stop(binding)?;
            }

            // Delete external states before deleting the parent row to avoid orphaning state.
            for state in &plan.worktree_states {
                worktree.delete_worktree(state)?;
            }

            store.delete_agent(id.clone())
        }
    }
}

fn recycle_pinned_agent(
    store: &dyn AgentStorePort,
    runtime: &dyn AgentRuntimePort,
    record: &AgentRuntimeRecord,
    binding_to_stop: Option<&AgentRuntimeBinding>,
) -> Result<(), AppError> {
    if let Some(binding) = binding_to_stop {
        // If tmux already lost the session in the background, treat stop as
        // best-effort and continue with binding recreation.
        match runtime.stop(binding) {
            Ok(()) => {}
            Err(err) if is_retryable_missing_tmux(&err) => {}
            Err(err) => return Err(err),
        }
    }

    RuntimeBindingManager::new(store, runtime)
        .ensure_binding(record)
        .map(|_| ())
}

#[cfg(test)]
mod tests {
    use std::sync::atomic::{AtomicUsize, Ordering};

    use super::delete_agent;
    use crate::application::PinnedSessionSpec;
    use crate::application::pinned_session_guard::PinnedSessionGuard;
    use crate::application::ports::{AgentRuntimePort, AgentStorePort, WorktreePort};
    use crate::application::{ResolvedGitWorktreeSpec, RuntimeProbeResult, RuntimeStartRequest};
    use crate::domain::{
        Agent, AgentId, AgentKind, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding,
        AgentStateKind, AgentStateProvider, PRIMARY_STATE_BINDING_KEY, RuntimeProvider,
    };
    use crate::error::{AgentError, AppError};

    fn stub_error(op: &str) -> AppError {
        AppError::Agent(AgentError::Unavailable {
            message: format!("stubbed method called: {op}"),
        })
    }

    struct StoreStub {
        record: Option<AgentRuntimeRecord>,
        states: Vec<AgentStateBinding>,
        upsert_binding_calls: AtomicUsize,
        delete_agent_calls: AtomicUsize,
    }

    impl StoreStub {
        fn with_record_and_states(
            record: AgentRuntimeRecord,
            states: Vec<AgentStateBinding>,
        ) -> Self {
            Self {
                record: Some(record),
                states,
                upsert_binding_calls: AtomicUsize::new(0),
                delete_agent_calls: AtomicUsize::new(0),
            }
        }
    }

    impl AgentStorePort for StoreStub {
        fn insert_agent_with_binding(
            &self,
            _agent: &Agent,
            _binding: &AgentRuntimeBinding,
            _state_bindings: &[AgentStateBinding],
        ) -> Result<(), AppError> {
            Err(stub_error("insert_agent_with_binding"))
        }

        fn list_agent_runtime_records(&self) -> Result<Vec<AgentRuntimeRecord>, AppError> {
            Err(stub_error("list_agent_runtime_records"))
        }

        fn find_agent_runtime_record_by_id(
            &self,
            id: AgentId,
        ) -> Result<Option<AgentRuntimeRecord>, AppError> {
            Ok(self
                .record
                .as_ref()
                .filter(|record| record.agent.id().as_str() == id.as_str())
                .cloned())
        }

        fn list_state_bindings_by_agent_id(
            &self,
            id: AgentId,
        ) -> Result<Vec<AgentStateBinding>, AppError> {
            Ok(self
                .states
                .iter()
                .filter(|state| state.agent_id.as_str() == id.as_str())
                .cloned()
                .collect())
        }

        fn list_state_bindings_by_agent_ids(
            &self,
            _ids: &[AgentId],
        ) -> Result<Vec<AgentStateBinding>, AppError> {
            Err(stub_error("list_state_bindings_by_agent_ids"))
        }

        fn upsert_state_binding(&self, _binding: &AgentStateBinding) -> Result<(), AppError> {
            Err(stub_error("upsert_state_binding"))
        }

        fn find_agent_by_display_name(
            &self,
            _display_name: &str,
        ) -> Result<Option<Agent>, AppError> {
            Err(stub_error("find_agent_by_display_name"))
        }

        fn update_agent(&self, _updated: &Agent, _expected_version: i64) -> Result<(), AppError> {
            Err(stub_error("update_agent"))
        }

        fn upsert_binding(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
            self.upsert_binding_calls.fetch_add(1, Ordering::Relaxed);
            Ok(())
        }

        fn update_agent_runtime_context(
            &self,
            _updated: &Agent,
            _expected_version: i64,
            _binding: &AgentRuntimeBinding,
            _upsert_state_bindings: &[AgentStateBinding],
            _delete_state_kinds: &[AgentStateKind],
        ) -> Result<(), AppError> {
            Err(stub_error("update_agent_runtime_context"))
        }

        fn delete_agent(&self, _id: AgentId) -> Result<(), AppError> {
            self.delete_agent_calls.fetch_add(1, Ordering::Relaxed);
            Ok(())
        }

        fn next_display_order(&self) -> Result<i64, AppError> {
            Err(stub_error("next_display_order"))
        }

        fn swap_display_order(
            &self,
            _a: &Agent,
            _a_expected_version: i64,
            _b: &Agent,
            _b_expected_version: i64,
        ) -> Result<(), AppError> {
            Err(stub_error("swap_display_order"))
        }
    }

    struct RuntimeStub {
        start_calls: AtomicUsize,
        stop_calls: AtomicUsize,
    }

    impl RuntimeStub {
        fn new() -> Self {
            Self {
                start_calls: AtomicUsize::new(0),
                stop_calls: AtomicUsize::new(0),
            }
        }
    }

    impl AgentRuntimePort for RuntimeStub {
        fn start(
            &self,
            request: &RuntimeStartRequest,
            _binding: Option<&AgentRuntimeBinding>,
        ) -> Result<AgentRuntimeBinding, AppError> {
            self.start_calls.fetch_add(1, Ordering::Relaxed);
            Ok(AgentRuntimeBinding::new(
                request.agent_id.clone(),
                RuntimeProvider::Tmux,
                request.session_name.clone(),
                1,
            ))
        }

        fn stop(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
            self.stop_calls.fetch_add(1, Ordering::Relaxed);
            Ok(())
        }

        fn attach(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
            Err(stub_error("attach"))
        }

        fn detach_client(&self) -> Result<(), AppError> {
            Err(stub_error("detach_client"))
        }

        fn probe(
            &self,
            _bindings: &[AgentRuntimeBinding],
        ) -> Result<Vec<RuntimeProbeResult>, AppError> {
            Err(stub_error("probe"))
        }

        fn capture_output(
            &self,
            _binding: &AgentRuntimeBinding,
            _lines: u16,
        ) -> Result<String, AppError> {
            Err(stub_error("capture_output"))
        }

        fn send_key(&self, _binding: &AgentRuntimeBinding, _key: &str) -> Result<(), AppError> {
            Err(stub_error("send_key"))
        }

        fn rename(
            &self,
            _binding: &AgentRuntimeBinding,
            _new_external_ref: &str,
        ) -> Result<(), AppError> {
            Err(stub_error("rename"))
        }
    }

    struct WorktreeStub {
        delete_calls: AtomicUsize,
    }

    impl WorktreeStub {
        fn new() -> Self {
            Self {
                delete_calls: AtomicUsize::new(0),
            }
        }
    }

    impl WorktreePort for WorktreeStub {
        fn create_worktree(
            &self,
            _agent: &Agent,
            _spec: &ResolvedGitWorktreeSpec,
        ) -> Result<AgentStateBinding, AppError> {
            Err(stub_error("create_worktree"))
        }

        fn delete_worktree(&self, _state: &AgentStateBinding) -> Result<(), AppError> {
            self.delete_calls.fetch_add(1, Ordering::Relaxed);
            Ok(())
        }

        fn current_branch(&self, _worktree_path: &str) -> Result<Option<String>, AppError> {
            Err(stub_error("current_branch"))
        }

        fn resolve_base_ref(&self, _path: &str) -> Result<Option<String>, AppError> {
            Err(stub_error("resolve_base_ref"))
        }

        fn parent_git_root(&self, _path: &str) -> Result<Option<String>, AppError> {
            Err(stub_error("parent_git_root"))
        }
    }

    fn fixture_record_with_binding() -> (AgentId, AgentRuntimeRecord) {
        let agent = Agent::new("dev".to_string(), crate::domain::AgentKind::Shell, 1);
        let id = agent.id();
        let binding =
            AgentRuntimeBinding::new(id.clone(), RuntimeProvider::Tmux, "dev".to_string(), 1);
        (
            id,
            AgentRuntimeRecord {
                agent,
                binding: Some(binding),
            },
        )
    }

    fn fixture_states(agent_id: AgentId) -> Vec<AgentStateBinding> {
        vec![
            AgentStateBinding::new(
                agent_id.clone(),
                AgentStateKind::GitWorktree,
                AgentStateProvider::Git,
                PRIMARY_STATE_BINDING_KEY.to_string(),
                "/tmp/wt".to_string(),
                "{}".to_string(),
                1,
            ),
            AgentStateBinding::new(
                agent_id,
                AgentStateKind::WorkingDirectory,
                AgentStateProvider::Git,
                PRIMARY_STATE_BINDING_KEY.to_string(),
                "/tmp/wt".to_string(),
                serde_json::json!({"path": "/tmp/wt"}).to_string(),
                1,
            ),
        ]
    }

    fn no_pinned_guard(specs: &[PinnedSessionSpec]) -> PinnedSessionGuard<'_> {
        PinnedSessionGuard::new(specs)
    }

    #[test]
    fn delete_stops_runtime_and_removes_agent() {
        let (id, record) = fixture_record_with_binding();
        let states = fixture_states(id.clone());
        let store = StoreStub::with_record_and_states(record, states);
        let runtime = RuntimeStub::new();
        let worktree = WorktreeStub::new();
        let pinned_specs: Vec<PinnedSessionSpec> = vec![];
        let pinned_guard = no_pinned_guard(&pinned_specs);

        let result = delete_agent(&store, &runtime, &worktree, &id, &pinned_guard);

        assert!(result.is_ok());
        assert_eq!(runtime.stop_calls.load(Ordering::Relaxed), 1);
        assert_eq!(worktree.delete_calls.load(Ordering::Relaxed), 1);
        assert_eq!(store.delete_agent_calls.load(Ordering::Relaxed), 1);
    }

    #[test]
    fn delete_restarts_pinned_agent_instead_of_deleting() {
        let (id, record) = fixture_record_with_binding();
        let states = fixture_states(id.clone());
        let store = StoreStub::with_record_and_states(record, states);
        let runtime = RuntimeStub::new();
        let worktree = WorktreeStub::new();
        let pinned_specs = vec![PinnedSessionSpec {
            name: "dev".to_string(),
            position: 1,
            agent_kind: AgentKind::Shell,
            working_dir: None,
        }];
        let pinned_guard = no_pinned_guard(&pinned_specs);

        let result = delete_agent(&store, &runtime, &worktree, &id, &pinned_guard);

        assert!(result.is_ok());
        assert_eq!(runtime.stop_calls.load(Ordering::Relaxed), 1);
        assert_eq!(runtime.start_calls.load(Ordering::Relaxed), 1);
        assert_eq!(store.upsert_binding_calls.load(Ordering::Relaxed), 1);
        assert_eq!(store.delete_agent_calls.load(Ordering::Relaxed), 0);
    }
}
