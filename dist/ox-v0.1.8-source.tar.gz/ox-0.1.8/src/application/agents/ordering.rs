use std::convert::TryFrom;

use crate::application::clock::unix_time_ms;
use crate::application::pinned_session_guard::PinnedSessionGuard;
use crate::application::ports::AgentStorePort;
use crate::domain::{Agent, AgentDisplayName, AgentId};
use crate::error::{AgentError, AppError};

pub(super) fn reorder_agent(
    store: &dyn AgentStorePort,
    id: &AgentId,
    target_visual_position: i64,
    pinned_guard: &PinnedSessionGuard<'_>,
) -> Result<(), AppError> {
    let records = store.list_agent_runtime_records()?;
    if records.is_empty() {
        return Err(AppError::Agent(AgentError::NotFound));
    }

    let len = records.len();
    let target_pos = usize::try_from(target_visual_position).unwrap_or(0);
    if target_pos < 1 || target_pos > len {
        return Err(AppError::InvalidInput {
            message: format!("position {target_visual_position} is out of range (1..{len})"),
        });
    }

    let pinned_len = i64::try_from(pinned_guard.pinned_len()).unwrap_or(i64::MAX);
    if target_visual_position >= 1 && target_visual_position <= pinned_len {
        return Err(AppError::InvalidInput {
            message: format!("position {target_visual_position} is reserved for pinned sessions"),
        });
    }

    let source_idx = records
        .iter()
        .position(|record| record.agent.id().as_str() == id.as_str())
        .ok_or(AppError::Agent(AgentError::NotFound))?;

    pinned_guard.reject_if_pinned(records[source_idx].agent.display_name(), "reordered")?;

    let target_idx = target_pos - 1;
    if source_idx == target_idx {
        return Ok(());
    }

    let source = &records[source_idx].agent;
    let target = &records[target_idx].agent;
    swap_display_order(store, source, target, unix_time_ms())
}

pub(crate) fn swap_display_order(
    store: &dyn AgentStorePort,
    source: &Agent,
    target: &Agent,
    now_unix_ms: u128,
) -> Result<(), AppError> {
    let source_version = source.version();
    let target_version = target.version();
    let new_source = source
        .clone()
        .with_display_order(target.display_order(), now_unix_ms);
    let new_target = target
        .clone()
        .with_display_order(source.display_order(), now_unix_ms);
    store.swap_display_order(&new_source, source_version, &new_target, target_version)
}

pub(super) fn validate_display_name(display_name: &str) -> Result<(), AppError> {
    AgentDisplayName::try_from(display_name)
        .map(|_| ())
        .map_err(|message| AppError::InvalidInput {
            message: message.to_string(),
        })
}
