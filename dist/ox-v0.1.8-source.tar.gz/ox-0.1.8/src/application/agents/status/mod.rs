mod classifiers;
mod evidence;
mod merge;
mod pane;
mod provider;

use crate::application::ports::{
    AgentRuntimePort, AgentStorePort, CodexThreadPort, MessageDispatchPort,
};

use super::listing::LoadedAgentSnapshot;
use evidence::StatusEvidence;

/// Apply the status semantics used everywhere `ox` renders runtime state.
///
/// The public labels stay the same, but their meaning is intentionally strict:
/// - `running`: trustworthy evidence shows the agent is actively working.
/// - `waiting`: the agent is ready for input or blocked on a user decision.
/// - `unknown`: `ox` cannot derive a trustworthy managed status.
///
/// Provider-backed agents prefer native provider/session state. Pane scraping is
/// only a fallback when the managed provider identity exists but the provider
/// cannot currently prove a status.
pub(super) fn apply_effective_statuses(
    store: &dyn AgentStorePort,
    runtime: &dyn AgentRuntimePort,
    codex_threads: &dyn CodexThreadPort,
    dispatch: &dyn MessageDispatchPort,
    snapshots: &mut [LoadedAgentSnapshot],
) {
    let pane_status_by_agent_id = pane::resolve_pane_statuses(runtime, snapshots);
    let provider_status_by_agent_id =
        provider::resolve_provider_statuses(store, runtime, codex_threads, dispatch, snapshots);

    for snapshot in snapshots {
        let agent_id = snapshot.record.agent.id();
        let evidence = StatusEvidence {
            pane_status: pane_status_by_agent_id.get(&agent_id).copied().flatten(),
            provider: provider::build_provider_status_evidence(
                snapshot,
                provider_status_by_agent_id.get(&agent_id).copied(),
            ),
        };
        let effective_status = merge::resolve_effective_status(evidence);
        snapshot.effective_probe = merge::merge_effective_status(
            snapshot.observed_probe.clone(),
            &snapshot.record,
            effective_status,
        );
    }
}
