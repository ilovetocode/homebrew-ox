use std::collections::HashMap;

use crate::application::codex_thread_state::find_codex_thread_id;
use crate::application::opencode_session_state::find_opencode_session_state;
use crate::application::opencode_session_tracker::OpencodeSessionTracker;
use crate::application::ports::{
    AgentRuntimePort, AgentStorePort, CodexThreadPort, MessageDispatchPort,
};
use crate::application::{MessageDispatchSessionRef, MessageReadRequest, RuntimeStatus};
use crate::domain::{AgentId, AgentKind};

use super::super::listing::LoadedAgentSnapshot;

/// Managed provider evidence used by the final merge step.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct ProviderStatusEvidence {
    pub(super) identity_present: bool,
    pub(super) status: Option<RuntimeStatus>,
}

/// Resolve provider-native statuses in batch where possible.
pub(super) fn resolve_provider_statuses(
    store: &dyn AgentStorePort,
    runtime: &dyn AgentRuntimePort,
    codex_threads: &dyn CodexThreadPort,
    dispatch: &dyn MessageDispatchPort,
    snapshots: &[LoadedAgentSnapshot],
) -> HashMap<AgentId, RuntimeStatus> {
    let mut out = resolve_codex_provider_statuses(codex_threads, snapshots);
    out.extend(resolve_opencode_provider_statuses(
        store, runtime, dispatch, snapshots,
    ));
    out
}

/// Convert raw provider results into mergeable authority metadata.
pub(super) fn build_provider_status_evidence(
    snapshot: &LoadedAgentSnapshot,
    resolved_status: Option<RuntimeStatus>,
) -> Option<ProviderStatusEvidence> {
    match snapshot.record.agent.kind() {
        AgentKind::Codex => Some(ProviderStatusEvidence {
            identity_present: find_codex_thread_id(&snapshot.states).is_some(),
            status: normalize_provider_status(resolved_status),
        }),
        AgentKind::Opencode => Some(ProviderStatusEvidence {
            identity_present: find_opencode_session_state(&snapshot.states).is_some(),
            status: normalize_provider_status(resolved_status),
        }),
        AgentKind::Claude | AgentKind::Shell => None,
    }
}

fn resolve_codex_provider_statuses(
    codex_threads: &dyn CodexThreadPort,
    snapshots: &[LoadedAgentSnapshot],
) -> HashMap<AgentId, RuntimeStatus> {
    let mut thread_ids_by_agent_id = HashMap::<AgentId, String>::new();
    let mut requested_thread_ids = Vec::<String>::new();
    for snapshot in snapshots {
        if snapshot.record.agent.kind() != AgentKind::Codex {
            continue;
        }
        if snapshot.record.binding.is_none() || snapshot.observed_probe.is_none() {
            continue;
        }
        let Some(thread_id) = find_codex_thread_id(&snapshot.states) else {
            continue;
        };

        requested_thread_ids.push(thread_id.clone());
        thread_ids_by_agent_id.insert(snapshot.record.agent.id(), thread_id);
    }

    // Query Codex in batch so listing one fleet does not spawn one status call
    // per agent. Pane text stays as a fallback when the provider returns
    // `unknown`.
    let status_by_thread_id = codex_threads
        .read_thread_statuses(&requested_thread_ids)
        .unwrap_or_default();

    let mut out = HashMap::new();
    for snapshot in snapshots {
        if snapshot.record.agent.kind() != AgentKind::Codex {
            continue;
        }
        if snapshot.observed_probe.is_none() {
            continue;
        }

        out.insert(
            snapshot.record.agent.id(),
            thread_ids_by_agent_id
                .get(&snapshot.record.agent.id())
                .and_then(|thread_id| status_by_thread_id.get(thread_id).copied())
                .unwrap_or(RuntimeStatus::Unknown),
        );
    }

    out
}

fn resolve_opencode_provider_statuses(
    store: &dyn AgentStorePort,
    runtime: &dyn AgentRuntimePort,
    dispatch: &dyn MessageDispatchPort,
    snapshots: &[LoadedAgentSnapshot],
) -> HashMap<AgentId, RuntimeStatus> {
    let mut out = HashMap::new();
    let tracker = OpencodeSessionTracker::new(store, dispatch);
    for snapshot in snapshots {
        if snapshot.record.agent.kind() != AgentKind::Opencode {
            continue;
        }
        let Some(binding) = snapshot.record.binding.as_ref() else {
            continue;
        };
        if snapshot.observed_probe.is_none() {
            continue;
        }
        if find_opencode_session_state(&snapshot.states).is_none() {
            out.insert(snapshot.record.agent.id(), RuntimeStatus::Unknown);
            continue;
        }

        let provider_status = tracker
            .resolve_bound_session(&snapshot.states, Some(binding), |binding, lines| {
                runtime.capture_output(binding, lines)
            })
            .ok()
            .map_or(RuntimeStatus::Unknown, |session_ref| {
                read_opencode_runtime_status(dispatch, &session_ref)
            });
        out.insert(snapshot.record.agent.id(), provider_status);
    }
    out
}

fn read_opencode_runtime_status(
    dispatch: &dyn MessageDispatchPort,
    session: &MessageDispatchSessionRef,
) -> RuntimeStatus {
    let provider_status = dispatch
        .read_session_status(session)
        .unwrap_or(RuntimeStatus::Unknown);
    if provider_status == RuntimeStatus::Unknown {
        infer_opencode_status_from_conversation(dispatch, session).unwrap_or(provider_status)
    } else {
        provider_status
    }
}

fn infer_opencode_status_from_conversation(
    dispatch: &dyn MessageDispatchPort,
    session: &MessageDispatchSessionRef,
) -> Option<RuntimeStatus> {
    let request = MessageReadRequest {
        session: session.clone(),
        limit: Some(3),
    };
    let conversation = dispatch.read_full_conversation(&request).ok()?;
    // Freshly created managed sessions can have zero messages while the UI is
    // already waiting at a prompt. Treat that as `Waiting` so the fallback
    // reflects user-visible readiness instead of tmux's coarse "alive" signal.
    if conversation.messages.is_empty() {
        return Some(RuntimeStatus::Waiting);
    }
    let last = conversation.messages.last()?;
    match last.role.as_str() {
        "assistant" if last.completed_at_unix_ms.is_some() => Some(RuntimeStatus::Waiting),
        "assistant" | "user" => Some(RuntimeStatus::Running),
        _ => None,
    }
}

fn normalize_provider_status(status: Option<RuntimeStatus>) -> Option<RuntimeStatus> {
    status.filter(|status| *status != RuntimeStatus::Unknown)
}

#[cfg(test)]
mod tests {
    use super::{ProviderStatusEvidence, build_provider_status_evidence};
    use crate::application::RuntimeProbeResult;
    use crate::application::agents::listing::LoadedAgentSnapshot;
    use crate::application::codex_thread_state::build_codex_thread_state_binding;
    use crate::application::opencode_session_state::build_opencode_session_state_binding;
    use crate::domain::{
        Agent, AgentKind, AgentRuntimeBinding, AgentRuntimeRecord, RuntimeProvider,
    };

    fn snapshot(
        kind: AgentKind,
        states: Vec<crate::domain::AgentStateBinding>,
    ) -> LoadedAgentSnapshot {
        let agent = Agent::new("worker".to_string(), kind, 1);
        let agent_id = agent.id();
        LoadedAgentSnapshot {
            record: AgentRuntimeRecord {
                agent,
                binding: Some(AgentRuntimeBinding::new(
                    agent_id.clone(),
                    RuntimeProvider::Tmux,
                    "worker".to_string(),
                    1,
                )),
            },
            states,
            observed_probe: Some(RuntimeProbeResult {
                binding_id: "bind_1".to_string(),
                runtime_status: crate::application::RuntimeStatus::Running,
                attached: false,
                agent_kind: kind,
                current_working_dir: None,
                observed_at_unix_ms: 1,
            }),
            effective_probe: None,
        }
    }

    #[test]
    fn codex_snapshot_without_thread_identity_requires_unknown() {
        let snapshot = snapshot(AgentKind::Codex, Vec::new());

        let evidence = build_provider_status_evidence(
            &snapshot,
            Some(crate::application::RuntimeStatus::Running),
        );

        assert_eq!(
            evidence,
            Some(ProviderStatusEvidence {
                identity_present: false,
                status: Some(crate::application::RuntimeStatus::Running),
            })
        );
    }

    #[test]
    fn codex_snapshot_with_thread_identity_keeps_provider_status() {
        let agent = Agent::new("worker".to_string(), AgentKind::Codex, 1);
        let state = build_codex_thread_state_binding(&agent, "thread_1", 0, 1);
        let snapshot = LoadedAgentSnapshot {
            record: AgentRuntimeRecord {
                agent: agent.clone(),
                binding: Some(AgentRuntimeBinding::new(
                    agent.id(),
                    RuntimeProvider::Tmux,
                    "worker".to_string(),
                    1,
                )),
            },
            states: vec![state],
            observed_probe: Some(RuntimeProbeResult {
                binding_id: "bind_1".to_string(),
                runtime_status: crate::application::RuntimeStatus::Running,
                attached: false,
                agent_kind: AgentKind::Codex,
                current_working_dir: None,
                observed_at_unix_ms: 1,
            }),
            effective_probe: None,
        };

        let evidence = build_provider_status_evidence(
            &snapshot,
            Some(crate::application::RuntimeStatus::Waiting),
        );

        assert_eq!(
            evidence,
            Some(ProviderStatusEvidence {
                identity_present: true,
                status: Some(crate::application::RuntimeStatus::Waiting),
            })
        );
    }

    #[test]
    fn opencode_snapshot_normalizes_unknown_provider_status_to_fallback() {
        let agent = Agent::new("worker".to_string(), AgentKind::Opencode, 1);
        let state = build_opencode_session_state_binding(
            &agent,
            "http://127.0.0.1:4096",
            "session_1",
            "none",
            None,
            1,
        );
        let snapshot = LoadedAgentSnapshot {
            record: AgentRuntimeRecord {
                agent: agent.clone(),
                binding: Some(AgentRuntimeBinding::new(
                    agent.id(),
                    RuntimeProvider::Tmux,
                    "worker".to_string(),
                    1,
                )),
            },
            states: vec![state],
            observed_probe: Some(RuntimeProbeResult {
                binding_id: "bind_1".to_string(),
                runtime_status: crate::application::RuntimeStatus::Running,
                attached: false,
                agent_kind: AgentKind::Opencode,
                current_working_dir: None,
                observed_at_unix_ms: 1,
            }),
            effective_probe: None,
        };

        let evidence = build_provider_status_evidence(
            &snapshot,
            Some(crate::application::RuntimeStatus::Unknown),
        );

        assert_eq!(
            evidence,
            Some(ProviderStatusEvidence {
                identity_present: true,
                status: None,
            })
        );
    }

    #[test]
    fn shell_snapshot_has_no_provider_authority() {
        let snapshot = snapshot(AgentKind::Shell, Vec::new());

        let evidence = build_provider_status_evidence(
            &snapshot,
            Some(crate::application::RuntimeStatus::Running),
        );

        assert_eq!(evidence, None);
    }
}
