use crate::application::{RuntimeProbeResult, RuntimeStatus};
use crate::domain::AgentRuntimeRecord;

use super::evidence::StatusEvidence;

/// Resolve the final status from explicit evidence precedence.
///
/// Provider-backed agents are authoritative when they have a managed identity
/// and the provider reports a known state. When the identity is missing, `ox`
/// reports `unknown` rather than trusting pane text from an ambiguous runtime.
pub(super) fn resolve_effective_status(evidence: StatusEvidence) -> RuntimeStatus {
    match evidence.provider {
        Some(provider) if !provider.identity_present => RuntimeStatus::Unknown,
        Some(provider) => provider
            .status
            .unwrap_or_else(|| evidence.pane_status.unwrap_or(RuntimeStatus::Unknown)),
        None => evidence.pane_status.unwrap_or(RuntimeStatus::Unknown),
    }
}

/// Overlay the resolved status on top of one observed tmux probe.
pub(super) fn merge_effective_status(
    base: Option<RuntimeProbeResult>,
    record: &AgentRuntimeRecord,
    runtime_status: RuntimeStatus,
) -> Option<RuntimeProbeResult> {
    let mut effective = base;
    match effective.as_mut() {
        Some(probe) => {
            probe.runtime_status = runtime_status;
        }
        None if runtime_status != RuntimeStatus::Unknown => {
            effective = Some(RuntimeProbeResult {
                binding_id: String::new(),
                runtime_status,
                attached: false,
                agent_kind: record.agent.kind(),
                current_working_dir: None,
                observed_at_unix_ms: 0,
            });
        }
        _ => {}
    }
    effective
}

#[cfg(test)]
mod tests {
    use super::{merge_effective_status, resolve_effective_status};
    use crate::application::{RuntimeProbeResult, RuntimeStatus};
    use crate::domain::{AgentKind, AgentRuntimeBinding, AgentRuntimeRecord, RuntimeProvider};

    use crate::application::agents::status::evidence::StatusEvidence;
    use crate::application::agents::status::provider::ProviderStatusEvidence;

    #[test]
    fn provider_backed_status_uses_native_provider_when_known() {
        let effective = resolve_effective_status(StatusEvidence {
            pane_status: Some(RuntimeStatus::Running),
            provider: Some(ProviderStatusEvidence {
                identity_present: true,
                status: Some(RuntimeStatus::Waiting),
            }),
        });

        assert_eq!(effective, RuntimeStatus::Waiting);
    }

    #[test]
    fn provider_backed_status_falls_back_to_pane_when_provider_is_unknown() {
        let effective = resolve_effective_status(StatusEvidence {
            pane_status: Some(RuntimeStatus::Waiting),
            provider: Some(ProviderStatusEvidence {
                identity_present: true,
                status: None,
            }),
        });

        assert_eq!(effective, RuntimeStatus::Waiting);
    }

    #[test]
    fn provider_backed_status_without_managed_identity_is_unknown() {
        let effective = resolve_effective_status(StatusEvidence {
            pane_status: Some(RuntimeStatus::Running),
            provider: Some(ProviderStatusEvidence {
                identity_present: false,
                status: Some(RuntimeStatus::Running),
            }),
        });

        assert_eq!(effective, RuntimeStatus::Unknown);
    }

    #[test]
    fn pane_only_status_uses_pane_signal() {
        let effective = resolve_effective_status(StatusEvidence {
            pane_status: Some(RuntimeStatus::Running),
            provider: None,
        });

        assert_eq!(effective, RuntimeStatus::Running);
    }

    #[test]
    fn merge_effective_status_overrides_tmux_running_with_waiting_status() {
        let agent = crate::domain::Agent::new("manager-5".to_string(), AgentKind::Opencode, 5);
        let agent_id = agent.id();
        let record = AgentRuntimeRecord {
            agent,
            binding: Some(AgentRuntimeBinding::new(
                agent_id.clone(),
                RuntimeProvider::Tmux,
                "manager-5".to_string(),
                1,
            )),
        };
        let base = Some(RuntimeProbeResult {
            binding_id: "bind_1".to_string(),
            runtime_status: RuntimeStatus::Running,
            attached: false,
            agent_kind: AgentKind::Opencode,
            current_working_dir: None,
            observed_at_unix_ms: 1,
        });
        let effective = merge_effective_status(base, &record, RuntimeStatus::Waiting);

        assert_eq!(
            effective.map(|probe| probe.runtime_status),
            Some(RuntimeStatus::Waiting)
        );
    }

    #[test]
    fn merge_effective_status_overrides_tmux_running_with_unknown_status() {
        let agent = crate::domain::Agent::new("worker-2".to_string(), AgentKind::Codex, 2);
        let record = AgentRuntimeRecord {
            agent,
            binding: Some(AgentRuntimeBinding::new(
                crate::domain::AgentId::new(),
                RuntimeProvider::Tmux,
                "worker-2".to_string(),
                1,
            )),
        };
        let base = Some(RuntimeProbeResult {
            binding_id: "bind_2".to_string(),
            runtime_status: RuntimeStatus::Running,
            attached: false,
            agent_kind: AgentKind::Codex,
            current_working_dir: None,
            observed_at_unix_ms: 1,
        });
        let effective = merge_effective_status(base, &record, RuntimeStatus::Unknown);

        assert_eq!(
            effective.map(|probe| probe.runtime_status),
            Some(RuntimeStatus::Unknown)
        );
    }
}
