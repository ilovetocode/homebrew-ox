use crate::application::RuntimeStatus;
use crate::domain::AgentKind;

const STATUS_CAPTURE_RECENT_LINES: usize = 25;
const STATUS_CAPTURE_RECENT_LINES_CLAUDE: usize = 15;
const STATUS_CAPTURE_RECENT_LINES_CLAUDE_SPINNER: usize = 10;
const STATUS_CAPTURE_RECENT_LINES_CLAUDE_PROMPT: usize = 5;
const STATUS_CAPTURE_RECENT_LINES_CLAUDE_COMPLETION: usize = 3;
const STATUS_CAPTURE_RECENT_LINES_CODEX_PROMPT: usize = 10;
const STATUS_CAPTURE_RECENT_LINES_LINE_SUFFIX: usize = 5;
const STATUS_CAPTURE_RECENT_LINES_SHELL_CONFIRM: usize = 5;
const CLAUDE_RUNNING_MARKERS: &[&str] = &["ctrl+c to interrupt", "esc to interrupt"];
const CLAUDE_PERMISSION_PROMPTS: &[&str] = &[
    "No, and tell Claude what to do differently",
    "Yes, allow once",
    "Yes, allow always",
    "Allow once",
    "Allow always",
    "│ Do you want",
    "│ Would you like",
    "│ Allow",
    "❯ Yes",
    "❯ No",
    "❯ Allow",
    "Do you trust the files in this folder?",
    "Allow this MCP server",
    "Run this command?",
    "Execute this?",
    "Action Required",
    "Waiting for user confirmation",
    "Allow execution of",
    "Use arrow keys to navigate",
    "Press Enter to select",
];
const CLAUDE_QUESTION_PROMPTS: &[&str] = &[
    "Continue?",
    "Proceed?",
    "(Y/n)",
    "(y/N)",
    "[Y/n]",
    "[y/N]",
    "(yes/no)",
    "[yes/no]",
    "Approve this plan?",
    "Execute plan?",
];
const CLAUDE_COMPLETION_INDICATORS: &[&str] = &[
    "Task completed",
    "Done!",
    "Finished",
    "What would you like",
    "What else",
    "Anything else",
    "Let me know if",
];
const CLAUDE_SPINNER_CHARS: &[char] = &[
    '⠋', '⠙', '⠹', '⠸', '⠼', '⠴', '⠦', '⠧', '⠇', '⠏', '✳', '✽', '✶', '✢',
];
const BOX_DRAWING_PREFIX_CHARS: &[char] = &[
    '│', '├', '└', '─', '┌', '┐', '┘', '┤', '┬', '┴', '┼', '╭', '╰', '╮', '╯',
];
const CODEX_RUNNING_MARKERS: &[&str] = &["ctrl+c to interrupt", "esc to interrupt"];
const CODEX_WAITING_MARKERS: &[&str] = &["codex>", "continue?", "how can i help"];
const OPENCODE_RUNNING_MARKERS: &[&str] = &[
    "thinking...",
    "generating...",
    "building tool call...",
    "waiting for tool response...",
    "esc interrupt",
    "esc to exit",
    "loading...",
];
const OPENCODE_WAITING_MARKERS: &[&str] = &[
    "press enter to send",
    "ask anything",
    "enter submit",
    "esc dismiss",
    "open code",
];
const OPENCODE_PULSE_SPINNER_CHARS: &[char] = &['█', '▓', '▒', '░'];
const SHELL_PROMPT_SUFFIXES: &[&str] = &["$ ", "# ", "% ", "❯ ", "➜ ", "> "];
const SHELL_CONFIRMATION_PROMPTS: &[&str] = &[
    "(Y/n)",
    "[Y/n]",
    "(y/N)",
    "[y/N]",
    "(yes/no)",
    "[yes/no]",
    "Continue?",
    "Proceed?",
];

pub(super) fn classify_output_for_agent_kind(
    agent_kind: AgentKind,
    output: &str,
) -> Option<RuntimeStatus> {
    match agent_kind {
        AgentKind::Codex => classify_codex_output(output),
        AgentKind::Opencode => classify_opencode_output(output),
        AgentKind::Claude => classify_claude_output(output),
        AgentKind::Shell => classify_shell_output(output),
    }
}

fn classify_codex_output(output: &str) -> Option<RuntimeStatus> {
    if recent_output_contains_marker(output, CODEX_RUNNING_MARKERS) {
        return Some(RuntimeStatus::Running);
    }
    if recent_non_empty_lines(output, STATUS_CAPTURE_RECENT_LINES_CODEX_PROMPT)
        .into_iter()
        .map(normalize_prompt_line)
        .any(|line| line == "›" || line.starts_with("› "))
    {
        return Some(RuntimeStatus::Waiting);
    }
    if recent_output_contains_marker(output, CODEX_WAITING_MARKERS) {
        return Some(RuntimeStatus::Waiting);
    }
    None
}

fn classify_opencode_output(output: &str) -> Option<RuntimeStatus> {
    if recent_output_contains_marker(output, OPENCODE_RUNNING_MARKERS) {
        return Some(RuntimeStatus::Running);
    }
    let has_prompt_hint = recent_output_contains_marker(output, OPENCODE_WAITING_MARKERS)
        || recent_non_empty_lines(output, STATUS_CAPTURE_RECENT_LINES_LINE_SUFFIX)
            .into_iter()
            .map(normalize_prompt_line)
            .any(|line| line.ends_with('>'));
    if !has_prompt_hint
        && recent_non_empty_lines(output, STATUS_CAPTURE_RECENT_LINES)
            .into_iter()
            .any(|line| contains_any_char(line, OPENCODE_PULSE_SPINNER_CHARS))
    {
        return Some(RuntimeStatus::Running);
    }
    if has_prompt_hint {
        return Some(RuntimeStatus::Waiting);
    }
    None
}

fn classify_claude_output(output: &str) -> Option<RuntimeStatus> {
    let recent_lines = recent_non_empty_lines(output, STATUS_CAPTURE_RECENT_LINES_CLAUDE);
    let recent_text = recent_lines.join("\n");
    let recent_lower = recent_text.to_ascii_lowercase();
    if CLAUDE_RUNNING_MARKERS
        .iter()
        .any(|marker| recent_lower.contains(marker))
    {
        return Some(RuntimeStatus::Running);
    }
    if recent_lines
        .iter()
        .rev()
        .take(STATUS_CAPTURE_RECENT_LINES_CLAUDE_SPINNER)
        .filter(|line| !starts_with_box_drawing(line))
        .any(|line| contains_any_char(line, CLAUDE_SPINNER_CHARS))
    {
        return Some(RuntimeStatus::Running);
    }
    if (recent_text.contains('…') && recent_lower.contains("tokens"))
        || (recent_lower.contains("thinking") && recent_lower.contains("tokens"))
        || (recent_lower.contains("connecting") && recent_lower.contains("tokens"))
    {
        return Some(RuntimeStatus::Running);
    }

    // Confirmation and approval prompts are treated as `Waiting` because the
    // session is blocked on the user even though the terminal is interactive.
    if CLAUDE_PERMISSION_PROMPTS
        .iter()
        .any(|prompt| output.contains(prompt))
    {
        return Some(RuntimeStatus::Waiting);
    }

    if recent_lines
        .last()
        .is_some_and(|line| is_claude_input_prompt_line(line))
    {
        return Some(RuntimeStatus::Waiting);
    }

    if recent_lines
        .iter()
        .rev()
        .take(STATUS_CAPTURE_RECENT_LINES_CLAUDE_PROMPT)
        .map(|line| normalize_prompt_line(line))
        .any(|line| {
            line == ">" || line == "❯" || line.starts_with("❯ Try ") || line.starts_with("> Try ")
        })
    {
        return Some(RuntimeStatus::Waiting);
    }

    if CLAUDE_QUESTION_PROMPTS
        .iter()
        .any(|prompt| recent_text.contains(prompt))
    {
        return Some(RuntimeStatus::Waiting);
    }

    let has_completion_indicator = CLAUDE_COMPLETION_INDICATORS
        .iter()
        .any(|indicator| recent_lower.contains(&indicator.to_ascii_lowercase()));
    if has_completion_indicator
        && recent_lines
            .iter()
            .rev()
            .take(STATUS_CAPTURE_RECENT_LINES_CLAUDE_COMPLETION)
            .any(|line| {
                let line = normalize_prompt_line(line);
                line == ">" || line == "❯"
            })
    {
        return Some(RuntimeStatus::Waiting);
    }

    None
}

fn classify_shell_output(output: &str) -> Option<RuntimeStatus> {
    if recent_non_empty_lines(output, STATUS_CAPTURE_RECENT_LINES_LINE_SUFFIX)
        .into_iter()
        .map(normalize_prompt_line)
        .any(|line| is_shell_prompt_line(&line))
    {
        return Some(RuntimeStatus::Waiting);
    }

    let recent_text =
        recent_non_empty_lines(output, STATUS_CAPTURE_RECENT_LINES_SHELL_CONFIRM).join("\n");
    if SHELL_CONFIRMATION_PROMPTS
        .iter()
        .any(|marker| recent_text.contains(marker))
    {
        return Some(RuntimeStatus::Waiting);
    }

    None
}

fn recent_output_contains_marker(output: &str, markers: &[&str]) -> bool {
    let normalized = recent_output_text(output).to_ascii_lowercase();
    markers.iter().any(|marker| normalized.contains(marker))
}

fn recent_output_text(output: &str) -> String {
    recent_non_empty_lines(output, STATUS_CAPTURE_RECENT_LINES).join("\n")
}

fn recent_non_empty_lines(output: &str, lines: usize) -> Vec<&str> {
    let mut recent = output
        .lines()
        .rev()
        .filter(|line| !line.trim().is_empty())
        .take(lines)
        .collect::<Vec<_>>();
    recent.reverse();
    recent
}

fn normalize_prompt_line(line: &str) -> String {
    line.trim().replace('\u{00A0}', " ")
}

fn starts_with_box_drawing(line: &str) -> bool {
    let Some(first) = line.trim().chars().next() else {
        return false;
    };
    BOX_DRAWING_PREFIX_CHARS.contains(&first)
}

fn contains_any_char(line: &str, chars: &[char]) -> bool {
    line.chars().any(|ch| chars.contains(&ch))
}

fn is_claude_input_prompt_line(line: &str) -> bool {
    let normalized = normalize_prompt_line(line);
    if normalized == ">" || normalized == "❯" {
        return true;
    }
    (normalized.starts_with("> ") || normalized.starts_with("❯ "))
        && !normalized.to_ascii_lowercase().contains("esc")
        && normalized.len() < 100
}

fn is_shell_prompt_line(line: &str) -> bool {
    let padded = format!("{line} ");
    SHELL_PROMPT_SUFFIXES
        .iter()
        .any(|suffix| padded.ends_with(suffix))
}

#[cfg(test)]
mod tests {
    use super::{
        classify_claude_output, classify_codex_output, classify_opencode_output,
        classify_shell_output,
    };
    use crate::application::RuntimeStatus;

    #[test]
    fn classify_codex_output_detects_waiting_prompt() {
        let output = "some prior line\ncodex>\n";
        assert_eq!(classify_codex_output(output), Some(RuntimeStatus::Waiting));
    }

    #[test]
    fn classify_codex_output_detects_running_interrupt_banner() {
        let output = "working...\nctrl+c to interrupt\n";
        assert_eq!(classify_codex_output(output), Some(RuntimeStatus::Running));
    }

    #[test]
    fn classify_opencode_output_detects_waiting_prompt() {
        let output = "conversation\nproject/feature>\n";
        assert_eq!(
            classify_opencode_output(output),
            Some(RuntimeStatus::Waiting)
        );
    }

    #[test]
    fn classify_opencode_output_prefers_busy_markers_over_prompt_ui() {
        let output = "Ask anything\nthinking...\n";
        assert_eq!(
            classify_opencode_output(output),
            Some(RuntimeStatus::Running)
        );
    }

    #[test]
    fn classify_claude_output_detects_waiting_prompt() {
        let output = "summary\n❯ Try asking for a patch\n";
        assert_eq!(classify_claude_output(output), Some(RuntimeStatus::Waiting));
    }

    #[test]
    fn classify_claude_output_detects_permission_prompt_as_waiting() {
        let output = "Action Required\n❯ Yes\n❯ No\n";
        assert_eq!(classify_claude_output(output), Some(RuntimeStatus::Waiting));
    }

    #[test]
    fn classify_claude_output_detects_running_spinner() {
        let output = "│ ignored border line\n⠋ Thinking about the next step\n";
        assert_eq!(classify_claude_output(output), Some(RuntimeStatus::Running));
    }

    #[test]
    fn classify_shell_output_detects_prompt_suffix() {
        let output = "user@host:~/repo$ \n";
        assert_eq!(classify_shell_output(output), Some(RuntimeStatus::Waiting));
    }
}
