use crate::application::RuntimeStatus;

use super::provider::ProviderStatusEvidence;

/// Collected signals used to resolve one final runtime status.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct StatusEvidence {
    pub(super) pane_status: Option<RuntimeStatus>,
    pub(super) provider: Option<ProviderStatusEvidence>,
}
