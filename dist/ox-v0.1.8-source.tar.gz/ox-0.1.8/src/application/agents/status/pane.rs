use std::collections::HashMap;

use crate::application::RuntimeStatus;
use crate::application::ports::AgentRuntimePort;
use crate::domain::{AgentId, AgentRuntimeBinding};

use super::super::listing::LoadedAgentSnapshot;
use super::classifiers::classify_output_for_agent_kind;

const STATUS_CAPTURE_LINES: u16 = 120;

/// Read status hints from recent pane output for snapshots that have a live
/// tmux probe. This is a fallback signal for provider-backed agents and the
/// primary signal for shell/Claude sessions.
pub(super) fn resolve_pane_statuses(
    runtime: &dyn AgentRuntimePort,
    snapshots: &[LoadedAgentSnapshot],
) -> HashMap<AgentId, Option<RuntimeStatus>> {
    let mut out = HashMap::new();
    for snapshot in snapshots {
        let Some(binding) = snapshot.record.binding.as_ref() else {
            continue;
        };
        if snapshot.observed_probe.is_none() {
            continue;
        }
        let observed_agent_kind = snapshot
            .observed_probe
            .as_ref()
            .map_or(snapshot.record.agent.kind(), |probe| probe.agent_kind);

        out.insert(
            snapshot.record.agent.id(),
            read_pane_status(runtime, binding, observed_agent_kind),
        );
    }
    out
}

fn read_pane_status(
    runtime: &dyn AgentRuntimePort,
    binding: &AgentRuntimeBinding,
    agent_kind: crate::domain::AgentKind,
) -> Option<RuntimeStatus> {
    let output = runtime.capture_output(binding, STATUS_CAPTURE_LINES).ok()?;
    classify_output_for_agent_kind(agent_kind, &output)
}
