use crate::application::ports::WorktreePort;
use crate::application::{AgentView, RuntimeProbeResult, RuntimeStatus};
use crate::domain::{Agent, AgentRuntimeRecord, AgentStateBinding};

use super::state::AgentFsContextResolver;

/// Build one `AgentView` by combining persisted record/state with optional live runtime probe.
pub(crate) fn project_agent_view(
    worktree: &dyn WorktreePort,
    record: &AgentRuntimeRecord,
    states: &[AgentStateBinding],
    runtime_probe: Option<&RuntimeProbeResult>,
) -> AgentView {
    let git_context = AgentFsContextResolver::resolve_for_view(worktree, states, runtime_probe);
    let runtime_status = runtime_probe.map_or(RuntimeStatus::Unknown, |probe| probe.runtime_status);
    let agent = projected_agent_with_runtime_kind(&record.agent, runtime_probe);

    AgentView {
        agent,
        runtime_status,
        attached: runtime_probe.is_some_and(|probe| probe.attached),
        working_dir: git_context.working_dir.clone(),
        git_root: git_context.git_root.clone(),
        git_worktree_path: git_context.worktree_path,
        git_branch: git_context.branch,
        git_base_ref: git_context.base_ref,
    }
}

fn projected_agent_with_runtime_kind(
    agent: &Agent,
    runtime_probe: Option<&RuntimeProbeResult>,
) -> Agent {
    runtime_probe.map_or_else(
        || agent.clone(),
        |result| agent.with_kind(result.agent_kind),
    )
}

#[cfg(test)]
mod tests {
    use std::error::Error;

    use super::project_agent_view;
    use crate::application::{
        ResolvedGitWorktreeSpec, RuntimeProbeResult, RuntimeStatus, WorktreePort,
    };
    use crate::domain::{
        Agent, AgentKind, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding,
        AgentStateKind, AgentStateProvider, PRIMARY_STATE_BINDING_KEY, RuntimeProvider,
    };
    use crate::error::AppError;

    type TestResult = Result<(), Box<dyn Error>>;

    #[derive(Default)]
    struct FakeWorktree {
        parent_git_root: Option<String>,
        current_branch: Option<String>,
    }

    impl WorktreePort for FakeWorktree {
        fn create_worktree(
            &self,
            _agent: &Agent,
            _spec: &ResolvedGitWorktreeSpec,
        ) -> Result<AgentStateBinding, AppError> {
            Err(AppError::InvalidInput {
                message: "not used in this test".to_string(),
            })
        }

        fn delete_worktree(&self, _state: &AgentStateBinding) -> Result<(), AppError> {
            Ok(())
        }

        fn current_branch(&self, _worktree_path: &str) -> Result<Option<String>, AppError> {
            Ok(self.current_branch.clone())
        }

        fn resolve_base_ref(&self, _path: &str) -> Result<Option<String>, AppError> {
            Ok(self.current_branch.clone())
        }

        fn parent_git_root(&self, _path: &str) -> Result<Option<String>, AppError> {
            Ok(self.parent_git_root.clone())
        }
    }

    #[test]
    fn project_agent_view_prefers_probe_kind() {
        let worktree = FakeWorktree::default();
        let agent = Agent::new("shell-1".to_string(), AgentKind::Shell, 1);
        let record = AgentRuntimeRecord {
            agent,
            binding: None,
        };
        let probe = RuntimeProbeResult {
            binding_id: "binding-1".to_string(),
            runtime_status: RuntimeStatus::Running,
            attached: true,
            agent_kind: AgentKind::Codex,
            current_working_dir: None,
            observed_at_unix_ms: 1,
        };

        let view = project_agent_view(&worktree, &record, &[], Some(&probe));
        assert_eq!(view.agent.kind(), AgentKind::Codex);
        assert_eq!(view.runtime_status, RuntimeStatus::Running);
        assert!(view.attached);
    }

    #[test]
    fn project_agent_view_prefers_runtime_working_dir_for_branch() -> TestResult {
        let temp = std::env::temp_dir().join(format!(
            "ox-agent-view-projector-test-{}",
            std::process::id()
        ));
        std::fs::create_dir_all(&temp)?;
        let runtime_dir = temp.join("runtime-dir");
        std::fs::create_dir_all(&runtime_dir)?;
        let runtime_dir = runtime_dir.canonicalize()?;

        let worktree = FakeWorktree {
            parent_git_root: Some(runtime_dir.to_string_lossy().to_string()),
            current_branch: Some("feature/runtime".to_string()),
        };
        let agent = Agent::new("shell-1".to_string(), AgentKind::Shell, 1);
        let record = AgentRuntimeRecord {
            agent,
            binding: Some(AgentRuntimeBinding::new(
                crate::domain::AgentId::new(),
                RuntimeProvider::Tmux,
                "shell-1".to_string(),
                1,
            )),
        };
        let probe = RuntimeProbeResult {
            binding_id: "binding-1".to_string(),
            runtime_status: RuntimeStatus::Running,
            attached: false,
            agent_kind: AgentKind::Shell,
            current_working_dir: Some(runtime_dir.to_string_lossy().to_string()),
            observed_at_unix_ms: 2,
        };
        let wd_state = AgentStateBinding::new(
            record.agent.id(),
            AgentStateKind::WorkingDirectory,
            AgentStateProvider::Git,
            PRIMARY_STATE_BINDING_KEY.to_string(),
            "binding".to_string(),
            serde_json::json!({ "path": "/" }).to_string(),
            1,
        );

        let view = project_agent_view(&worktree, &record, &[wd_state], Some(&probe));
        assert_eq!(
            view.working_dir.as_deref(),
            Some(runtime_dir.to_string_lossy().as_ref())
        );
        assert_eq!(view.git_branch.as_deref(), Some("feature/runtime"));
        Ok(())
    }
}
