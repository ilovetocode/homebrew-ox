use std::path::PathBuf;

use serde::Deserialize;

use crate::application::ports::{AgentRuntimePort, AgentStorePort, WorktreePort};
use crate::application::provisioning::util::{
    build_path_state_binding, canonicalize_path, current_unix_time_ms,
};
use crate::application::runtime_binding_manager::is_retryable_missing_tmux;
use crate::application::runtime_start_request_builder::build_runtime_start_request;
use crate::application::{AgentFsContextResolver, ResolvedGitWorktreeSpec, RuntimeProbeResult};
use crate::domain::{
    AgentId, AgentKind, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding, AgentStateKind,
    PRIMARY_STATE_BINDING_KEY,
};
use crate::error::{AgentError, AppError};

/// Recreate one existing agent as a shell rooted in a managed worktree.
pub(super) fn switch_agent_to_worktree_shell(
    store: &dyn AgentStorePort,
    runtime: &dyn AgentRuntimePort,
    worktree: &dyn WorktreePort,
    id: &AgentId,
    branch_name: &str,
) -> Result<(), AppError> {
    let branch_name = branch_name.trim();
    if branch_name.is_empty() {
        return Err(AppError::InvalidInput {
            message: "branch name cannot be empty".to_string(),
        });
    }

    let current = store
        .find_agent_runtime_record_by_id(id.clone())?
        .ok_or(AppError::Agent(AgentError::NotFound))?;
    let states = store.list_state_bindings_by_agent_id(current.agent.id())?;
    let runtime_probe = load_runtime_probe(runtime, current.binding.as_ref());
    let existing_worktree_state = states
        .iter()
        .find(|state| state.state_kind == AgentStateKind::GitWorktree)
        .cloned();

    if let Some(existing_worktree_state) = existing_worktree_state.as_ref()
        && worktree
            .current_branch(&existing_worktree_state.external_ref)?
            .as_deref()
            == Some(branch_name)
    {
        if current.agent.kind() == AgentKind::Shell {
            return Ok(());
        }

        let repo_root = resolve_repo_root(worktree, &states, runtime_probe.as_ref())?;
        return switch_using_existing_worktree(
            store,
            runtime,
            &current,
            &states,
            existing_worktree_state,
            &repo_root,
        );
    }

    let repo_root = resolve_repo_root(worktree, &states, runtime_probe.as_ref())?;
    let base_ref_path = resolve_base_ref_path(&states, runtime_probe.as_ref());
    let base_ref =
        worktree
            .resolve_base_ref(&base_ref_path)?
            .ok_or_else(|| AppError::InvalidInput {
                message: format!("cannot resolve a git base ref from '{base_ref_path}'"),
            })?;

    switch_using_new_worktree(
        store,
        runtime,
        worktree,
        &current,
        &states,
        existing_worktree_state.as_ref(),
        &repo_root,
        branch_name,
        &base_ref,
    )
}

fn switch_using_existing_worktree(
    store: &dyn AgentStorePort,
    runtime: &dyn AgentRuntimePort,
    current: &AgentRuntimeRecord,
    states: &[AgentStateBinding],
    existing_worktree_state: &AgentStateBinding,
    repo_root: &str,
) -> Result<(), AppError> {
    let now = current_unix_time_ms();
    let updated_agent = current.agent.retyped(AgentKind::Shell, now);
    let next_states =
        build_workspace_state_bindings(&updated_agent, existing_worktree_state, repo_root, now);
    let start_request = shell_start_request(&updated_agent, &existing_worktree_state.external_ref);
    let previous_start_request = build_runtime_start_request(current, states);
    let rollback = stop_runtime_for_switch(runtime, current.binding.as_ref())?;
    let new_binding = match runtime.start(&start_request, current.binding.as_ref()) {
        Ok(binding) => binding,
        Err(err) => {
            rollback_previous_runtime(runtime, rollback.as_ref(), &previous_start_request);
            return Err(err);
        }
    };

    if let Err(err) = store.update_agent_runtime_context(
        &updated_agent,
        current.agent.version(),
        &new_binding,
        &next_states,
        &[AgentStateKind::CodexThread, AgentStateKind::OpencodeSession],
    ) {
        rollback_switch(
            runtime,
            rollback.as_ref(),
            Some(&new_binding),
            None,
            &previous_start_request,
        );
        return Err(err);
    }

    Ok(())
}

#[allow(clippy::too_many_arguments)]
fn switch_using_new_worktree(
    store: &dyn AgentStorePort,
    runtime: &dyn AgentRuntimePort,
    worktree: &dyn WorktreePort,
    current: &AgentRuntimeRecord,
    states: &[AgentStateBinding],
    previous_worktree_state: Option<&AgentStateBinding>,
    repo_root: &str,
    branch_name: &str,
    base_ref: &str,
) -> Result<(), AppError> {
    let now = current_unix_time_ms();
    let updated_agent = current.agent.retyped(AgentKind::Shell, now);
    let created_worktree = worktree.create_worktree(
        &updated_agent,
        &ResolvedGitWorktreeSpec {
            worktree_label: branch_name.to_string(),
            base_ref: base_ref.to_string(),
            repo_root: Some(repo_root.to_string()),
        },
    )?;
    let next_states =
        build_workspace_state_bindings(&updated_agent, &created_worktree, repo_root, now);
    let start_request = shell_start_request(&updated_agent, &created_worktree.external_ref);
    let previous_start_request = build_runtime_start_request(current, states);
    let rollback = match stop_runtime_for_switch(runtime, current.binding.as_ref()) {
        Ok(rollback) => rollback,
        Err(err) => {
            let _ = worktree.delete_worktree(&created_worktree);
            return Err(err);
        }
    };
    let new_binding = match runtime.start(&start_request, current.binding.as_ref()) {
        Ok(binding) => binding,
        Err(err) => {
            rollback_switch(
                runtime,
                rollback.as_ref(),
                None,
                Some((worktree, &created_worktree)),
                &previous_start_request,
            );
            return Err(err);
        }
    };

    if let Err(err) = store.update_agent_runtime_context(
        &updated_agent,
        current.agent.version(),
        &new_binding,
        &next_states,
        &[AgentStateKind::CodexThread, AgentStateKind::OpencodeSession],
    ) {
        rollback_switch(
            runtime,
            rollback.as_ref(),
            Some(&new_binding),
            Some((worktree, &created_worktree)),
            &previous_start_request,
        );
        return Err(err);
    }

    if let Some(previous_worktree_state) = previous_worktree_state
        && previous_worktree_state.external_ref != created_worktree.external_ref
    {
        let _ = worktree.delete_worktree(previous_worktree_state);
    }
    Ok(())
}

fn resolve_repo_root(
    worktree: &dyn WorktreePort,
    states: &[AgentStateBinding],
    runtime_probe: Option<&RuntimeProbeResult>,
) -> Result<String, AppError> {
    if let Some(repo_root) = states
        .iter()
        .find(|state| state.state_kind == AgentStateKind::GitWorktree)
        .and_then(worktree_repo_root)
    {
        return Ok(normalize_path_for_state(&repo_root));
    }

    if let Some(runtime_working_dir) = runtime_probe
        .and_then(|probe| probe.current_working_dir.as_deref())
        .map(str::trim)
        .filter(|path| !path.is_empty())
        && let Some(repo_root) = worktree.parent_git_root(runtime_working_dir)?
    {
        return Ok(normalize_path_for_state(&repo_root));
    }

    let context = AgentFsContextResolver::resolve_from_states(states);
    if let Some(git_root) = context.git_root {
        return Ok(normalize_path_for_state(&git_root));
    }
    if let Some(working_dir) = context.working_dir
        && let Some(repo_root) = worktree.parent_git_root(&working_dir)?
    {
        return Ok(normalize_path_for_state(&repo_root));
    }

    Err(AppError::InvalidInput {
        message: "selected agent is not inside a git repository".to_string(),
    })
}

fn resolve_base_ref_path(
    states: &[AgentStateBinding],
    runtime_probe: Option<&RuntimeProbeResult>,
) -> String {
    if let Some(runtime_working_dir) = runtime_probe
        .and_then(|probe| probe.current_working_dir.as_deref())
        .map(str::trim)
        .filter(|path| !path.is_empty())
    {
        return runtime_working_dir.to_string();
    }

    let context = AgentFsContextResolver::resolve_from_states(states);
    if let Some(worktree_path) = context.worktree_path {
        return worktree_path;
    }
    if let Some(working_dir) = context.working_dir {
        return working_dir;
    }
    context.git_root.unwrap_or_default()
}

fn load_runtime_probe(
    runtime: &dyn AgentRuntimePort,
    binding: Option<&AgentRuntimeBinding>,
) -> Option<RuntimeProbeResult> {
    let binding = binding?.clone();
    runtime
        .probe(&[binding])
        .ok()
        .and_then(|mut probes| probes.pop())
}

fn build_workspace_state_bindings(
    agent: &crate::domain::Agent,
    worktree_state: &AgentStateBinding,
    repo_root: &str,
    now: u128,
) -> Vec<AgentStateBinding> {
    // Canonical paths keep the persisted workspace state stable across tmux
    // cwd changes and symlink-heavy local setups.
    let working_dir = normalize_path_for_state(&worktree_state.external_ref);
    let repo_root = normalize_path_for_state(repo_root);
    vec![
        worktree_state.clone(),
        build_path_state_binding(
            agent,
            AgentStateKind::WorkingDirectory,
            PRIMARY_STATE_BINDING_KEY,
            &working_dir,
            now,
        ),
        build_path_state_binding(
            agent,
            AgentStateKind::GitRoot,
            PRIMARY_STATE_BINDING_KEY,
            &repo_root,
            now,
        ),
    ]
}

fn normalize_path_for_state(path: &str) -> String {
    canonicalize_path(path).unwrap_or_else(|_| path.to_string())
}

fn shell_start_request(
    agent: &crate::domain::Agent,
    working_dir: &str,
) -> crate::application::RuntimeStartRequest {
    crate::application::RuntimeStartRequest {
        agent_id: agent.id(),
        session_name: agent.display_name().to_string(),
        agent_kind: AgentKind::Shell,
        working_dir: Some(PathBuf::from(working_dir)),
        codex_thread_id: None,
        opencode_server_url: None,
        opencode_session_id: None,
    }
}

fn stop_runtime_for_switch(
    runtime: &dyn AgentRuntimePort,
    binding: Option<&AgentRuntimeBinding>,
) -> Result<Option<AgentRuntimeBinding>, AppError> {
    let Some(binding) = binding else {
        return Ok(None);
    };

    match runtime.stop(binding) {
        Ok(()) => Ok(Some(binding.clone())),
        Err(err) if is_retryable_missing_tmux(&err) => Ok(Some(binding.clone())),
        Err(err) => Err(err),
    }
}

fn rollback_switch(
    runtime: &dyn AgentRuntimePort,
    rollback_binding: Option<&AgentRuntimeBinding>,
    new_binding: Option<&AgentRuntimeBinding>,
    created_worktree: Option<(&dyn WorktreePort, &AgentStateBinding)>,
    previous_start_request: &crate::application::RuntimeStartRequest,
) {
    if let Some(new_binding) = new_binding {
        let _ = runtime.stop(new_binding);
    }
    if let Some((worktree, created_worktree)) = created_worktree {
        let _ = worktree.delete_worktree(created_worktree);
    }
    rollback_previous_runtime(runtime, rollback_binding, previous_start_request);
}

fn rollback_previous_runtime(
    runtime: &dyn AgentRuntimePort,
    rollback_binding: Option<&AgentRuntimeBinding>,
    previous_start_request: &crate::application::RuntimeStartRequest,
) {
    let Some(binding) = rollback_binding else {
        return;
    };
    let _ = runtime.start(previous_start_request, Some(binding));
}

fn worktree_repo_root(state: &AgentStateBinding) -> Option<String> {
    serde_json::from_str::<GitWorktreeStateMetadata>(&state.metadata_json)
        .ok()
        .and_then(|metadata| metadata.repo_root)
}

#[derive(Deserialize)]
struct GitWorktreeStateMetadata {
    repo_root: Option<String>,
}

#[cfg(test)]
mod tests {
    use std::collections::VecDeque;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::{Mutex, MutexGuard};

    use super::switch_agent_to_worktree_shell;
    use crate::application::ports::{AgentRuntimePort, AgentStorePort, WorktreePort};
    use crate::application::{
        ResolvedGitWorktreeSpec, RuntimeProbeResult, RuntimeStartRequest, RuntimeStatus,
    };
    use crate::domain::{
        Agent, AgentId, AgentKind, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding,
        AgentStateKind, AgentStateProvider, PRIMARY_STATE_BINDING_KEY, RuntimeProvider,
    };
    use crate::error::{AgentError, AppError};

    fn stub_error(message: &str) -> AppError {
        AppError::Agent(AgentError::Unavailable {
            message: message.to_string(),
        })
    }

    fn lock<T>(mutex: &Mutex<T>) -> MutexGuard<'_, T> {
        mutex
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
    }

    fn worktree_state(
        agent_id: &AgentId,
        path: &str,
        branch: &str,
        repo_root: &str,
    ) -> AgentStateBinding {
        AgentStateBinding::new(
            agent_id.clone(),
            AgentStateKind::GitWorktree,
            AgentStateProvider::Git,
            PRIMARY_STATE_BINDING_KEY.to_string(),
            path.to_string(),
            serde_json::json!({
                "repo_root": repo_root,
                "worktree_path": path,
                "worktree_label": branch,
                "base_ref": "main"
            })
            .to_string(),
            1,
        )
    }

    fn working_dir_state(agent_id: &AgentId, path: &str) -> AgentStateBinding {
        AgentStateBinding::new(
            agent_id.clone(),
            AgentStateKind::WorkingDirectory,
            AgentStateProvider::Git,
            PRIMARY_STATE_BINDING_KEY.to_string(),
            "opaque".to_string(),
            serde_json::json!({ "path": path }).to_string(),
            1,
        )
    }

    fn git_root_state(agent_id: &AgentId, path: &str) -> AgentStateBinding {
        AgentStateBinding::new(
            agent_id.clone(),
            AgentStateKind::GitRoot,
            AgentStateProvider::Git,
            PRIMARY_STATE_BINDING_KEY.to_string(),
            "opaque".to_string(),
            serde_json::json!({ "path": path }).to_string(),
            1,
        )
    }

    struct StoreStub {
        record: Option<AgentRuntimeRecord>,
        states: Vec<AgentStateBinding>,
        update_calls: AtomicUsize,
        updated_kind: Mutex<Option<AgentKind>>,
        deleted_state_kinds: Mutex<Vec<AgentStateKind>>,
        fail_update: bool,
    }

    impl StoreStub {
        fn new(record: Option<AgentRuntimeRecord>, states: Vec<AgentStateBinding>) -> Self {
            Self {
                record,
                states,
                update_calls: AtomicUsize::new(0),
                updated_kind: Mutex::new(None),
                deleted_state_kinds: Mutex::new(Vec::new()),
                fail_update: false,
            }
        }

        fn with_failed_update(
            record: Option<AgentRuntimeRecord>,
            states: Vec<AgentStateBinding>,
        ) -> Self {
            let mut store = Self::new(record, states);
            store.fail_update = true;
            store
        }
    }

    impl AgentStorePort for StoreStub {
        fn insert_agent_with_binding(
            &self,
            _agent: &Agent,
            _binding: &AgentRuntimeBinding,
            _state_bindings: &[AgentStateBinding],
        ) -> Result<(), AppError> {
            Err(stub_error("insert_agent_with_binding"))
        }

        fn list_agent_runtime_records(&self) -> Result<Vec<AgentRuntimeRecord>, AppError> {
            Err(stub_error("list_agent_runtime_records"))
        }

        fn find_agent_runtime_record_by_id(
            &self,
            id: AgentId,
        ) -> Result<Option<AgentRuntimeRecord>, AppError> {
            Ok(self
                .record
                .as_ref()
                .filter(|record| record.agent.id().as_str() == id.as_str())
                .cloned())
        }

        fn list_state_bindings_by_agent_id(
            &self,
            id: AgentId,
        ) -> Result<Vec<AgentStateBinding>, AppError> {
            Ok(self
                .states
                .iter()
                .filter(|state| state.agent_id.as_str() == id.as_str())
                .cloned()
                .collect())
        }

        fn list_state_bindings_by_agent_ids(
            &self,
            _ids: &[AgentId],
        ) -> Result<Vec<AgentStateBinding>, AppError> {
            Err(stub_error("list_state_bindings_by_agent_ids"))
        }

        fn upsert_state_binding(&self, _binding: &AgentStateBinding) -> Result<(), AppError> {
            Err(stub_error("upsert_state_binding"))
        }

        fn find_agent_by_display_name(
            &self,
            _display_name: &str,
        ) -> Result<Option<Agent>, AppError> {
            Err(stub_error("find_agent_by_display_name"))
        }

        fn update_agent(&self, _updated: &Agent, _expected_version: i64) -> Result<(), AppError> {
            Err(stub_error("update_agent"))
        }

        fn upsert_binding(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
            Err(stub_error("upsert_binding"))
        }

        fn update_agent_runtime_context(
            &self,
            updated: &Agent,
            _expected_version: i64,
            _binding: &AgentRuntimeBinding,
            _upsert_state_bindings: &[AgentStateBinding],
            delete_state_kinds: &[AgentStateKind],
        ) -> Result<(), AppError> {
            self.update_calls.fetch_add(1, Ordering::Relaxed);
            *lock(&self.updated_kind) = Some(updated.kind());
            *lock(&self.deleted_state_kinds) = delete_state_kinds.to_vec();
            if self.fail_update {
                return Err(stub_error("update_agent_runtime_context"));
            }
            Ok(())
        }

        fn delete_agent(&self, _id: AgentId) -> Result<(), AppError> {
            Err(stub_error("delete_agent"))
        }

        fn next_display_order(&self) -> Result<i64, AppError> {
            Err(stub_error("next_display_order"))
        }

        fn swap_display_order(
            &self,
            _a: &Agent,
            _a_expected_version: i64,
            _b: &Agent,
            _b_expected_version: i64,
        ) -> Result<(), AppError> {
            Err(stub_error("swap_display_order"))
        }
    }

    struct RuntimeStub {
        probe_result: Mutex<Option<Result<Vec<RuntimeProbeResult>, AppError>>>,
        start_results: Mutex<VecDeque<Result<AgentRuntimeBinding, AppError>>>,
        stop_calls: AtomicUsize,
        start_calls: AtomicUsize,
    }

    impl RuntimeStub {
        fn new(binding: AgentRuntimeBinding) -> Self {
            Self {
                probe_result: Mutex::new(None),
                start_results: Mutex::new(VecDeque::from([Ok(binding)])),
                stop_calls: AtomicUsize::new(0),
                start_calls: AtomicUsize::new(0),
            }
        }

        fn with_probe(self, probes: Vec<RuntimeProbeResult>) -> Self {
            *lock(&self.probe_result) = Some(Ok(probes));
            self
        }

        fn push_start_result(&self, result: Result<AgentRuntimeBinding, AppError>) {
            lock(&self.start_results).push_back(result);
        }
    }

    impl AgentRuntimePort for RuntimeStub {
        fn start(
            &self,
            _request: &RuntimeStartRequest,
            _binding: Option<&AgentRuntimeBinding>,
        ) -> Result<AgentRuntimeBinding, AppError> {
            self.start_calls.fetch_add(1, Ordering::Relaxed);
            lock(&self.start_results)
                .pop_front()
                .unwrap_or_else(|| Err(stub_error("missing start result")))
        }

        fn stop(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
            self.stop_calls.fetch_add(1, Ordering::Relaxed);
            Ok(())
        }

        fn attach(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
            Err(stub_error("attach"))
        }

        fn detach_client(&self) -> Result<(), AppError> {
            Err(stub_error("detach_client"))
        }

        fn probe(
            &self,
            _bindings: &[AgentRuntimeBinding],
        ) -> Result<Vec<RuntimeProbeResult>, AppError> {
            lock(&self.probe_result)
                .take()
                .unwrap_or_else(|| Ok(Vec::new()))
        }

        fn capture_output(
            &self,
            _binding: &AgentRuntimeBinding,
            _lines: u16,
        ) -> Result<String, AppError> {
            Err(stub_error("capture_output"))
        }

        fn send_key(&self, _binding: &AgentRuntimeBinding, _key: &str) -> Result<(), AppError> {
            Err(stub_error("send_key"))
        }

        fn rename(
            &self,
            _binding: &AgentRuntimeBinding,
            _new_external_ref: &str,
        ) -> Result<(), AppError> {
            Err(stub_error("rename"))
        }
    }

    struct WorktreeStub {
        current_branch: Option<String>,
        resolve_base_ref: Option<String>,
        parent_git_root: Option<String>,
        created_state: Mutex<Option<AgentStateBinding>>,
        delete_calls: AtomicUsize,
    }

    impl WorktreeStub {
        fn new() -> Self {
            Self {
                current_branch: None,
                resolve_base_ref: Some("main".to_string()),
                parent_git_root: None,
                created_state: Mutex::new(None),
                delete_calls: AtomicUsize::new(0),
            }
        }
    }

    impl WorktreePort for WorktreeStub {
        fn create_worktree(
            &self,
            agent: &Agent,
            spec: &ResolvedGitWorktreeSpec,
        ) -> Result<AgentStateBinding, AppError> {
            let state = worktree_state(
                &agent.id(),
                &format!("/repo/.ox/worktrees/{}", spec.worktree_label),
                &spec.worktree_label,
                spec.repo_root.as_deref().unwrap_or("/repo"),
            );
            *lock(&self.created_state) = Some(state.clone());
            Ok(state)
        }

        fn delete_worktree(&self, _state: &AgentStateBinding) -> Result<(), AppError> {
            self.delete_calls.fetch_add(1, Ordering::Relaxed);
            Ok(())
        }

        fn current_branch(&self, _worktree_path: &str) -> Result<Option<String>, AppError> {
            Ok(self.current_branch.clone())
        }

        fn resolve_base_ref(&self, _path: &str) -> Result<Option<String>, AppError> {
            Ok(self.resolve_base_ref.clone())
        }

        fn parent_git_root(&self, _path: &str) -> Result<Option<String>, AppError> {
            Ok(self.parent_git_root.clone())
        }
    }

    fn sample_record(kind: AgentKind) -> (AgentRuntimeRecord, AgentRuntimeBinding) {
        let agent = Agent::new("alpha".to_string(), kind, 1);
        let binding =
            AgentRuntimeBinding::new(agent.id(), RuntimeProvider::Tmux, "alpha".to_string(), 1);
        (
            AgentRuntimeRecord {
                agent,
                binding: Some(binding.clone()),
            },
            binding,
        )
    }

    #[test]
    fn same_worktree_branch_shell_is_noop() {
        let (record, binding) = sample_record(AgentKind::Shell);
        let store = StoreStub::new(
            Some(record.clone()),
            vec![
                worktree_state(
                    &record.agent.id(),
                    "/repo/.ox/worktrees/feature",
                    "feature",
                    "/repo",
                ),
                working_dir_state(&record.agent.id(), "/repo/.ox/worktrees/feature"),
                git_root_state(&record.agent.id(), "/repo"),
            ],
        );
        let runtime = RuntimeStub::new(binding);
        let mut worktree = WorktreeStub::new();
        worktree.current_branch = Some("feature".to_string());

        let result = switch_agent_to_worktree_shell(
            &store,
            &runtime,
            &worktree,
            &record.agent.id(),
            "feature",
        );

        assert!(result.is_ok());
        assert_eq!(store.update_calls.load(Ordering::Relaxed), 0);
        assert_eq!(runtime.stop_calls.load(Ordering::Relaxed), 0);
        assert_eq!(runtime.start_calls.load(Ordering::Relaxed), 0);
    }

    #[test]
    fn current_tree_session_creates_new_worktree_and_updates_context() {
        let (record, binding) = sample_record(AgentKind::Codex);
        let store = StoreStub::new(
            Some(record.clone()),
            vec![
                working_dir_state(&record.agent.id(), "/repo"),
                git_root_state(&record.agent.id(), "/repo"),
            ],
        );
        let runtime = RuntimeStub::new(binding).with_probe(vec![RuntimeProbeResult {
            binding_id: "binding".to_string(),
            runtime_status: RuntimeStatus::Running,
            attached: false,
            agent_kind: AgentKind::Codex,
            current_working_dir: Some("/repo/subdir".to_string()),
            observed_at_unix_ms: 1,
        }]);
        let mut worktree = WorktreeStub::new();
        worktree.parent_git_root = Some("/repo".to_string());

        let result = switch_agent_to_worktree_shell(
            &store,
            &runtime,
            &worktree,
            &record.agent.id(),
            "feature-x",
        );

        assert!(result.is_ok());
        assert_eq!(*lock(&store.updated_kind), Some(AgentKind::Shell));
        assert_eq!(
            lock(&store.deleted_state_kinds).as_slice(),
            &[AgentStateKind::CodexThread, AgentStateKind::OpencodeSession]
        );
        assert_eq!(runtime.stop_calls.load(Ordering::Relaxed), 1);
        assert_eq!(runtime.start_calls.load(Ordering::Relaxed), 1);
    }

    #[test]
    fn missing_git_context_is_rejected() {
        let (record, binding) = sample_record(AgentKind::Shell);
        let store = StoreStub::new(Some(record.clone()), Vec::new());
        let runtime = RuntimeStub::new(binding);
        let worktree = WorktreeStub::new();

        let result = switch_agent_to_worktree_shell(
            &store,
            &runtime,
            &worktree,
            &record.agent.id(),
            "feature-x",
        );

        assert!(matches!(
            result,
            Err(AppError::InvalidInput { message })
                if message.contains("not inside a git repository")
        ));
    }

    #[test]
    fn persist_failure_rolls_back_new_runtime_and_worktree() {
        let (record, binding) = sample_record(AgentKind::Codex);
        let store = StoreStub::with_failed_update(
            Some(record.clone()),
            vec![
                working_dir_state(&record.agent.id(), "/repo"),
                git_root_state(&record.agent.id(), "/repo"),
            ],
        );
        let runtime = RuntimeStub::new(binding.clone());
        runtime.push_start_result(Ok(binding));
        let mut worktree = WorktreeStub::new();
        worktree.parent_git_root = Some("/repo".to_string());

        let result = switch_agent_to_worktree_shell(
            &store,
            &runtime,
            &worktree,
            &record.agent.id(),
            "feature-x",
        );

        assert!(result.is_err());
        assert_eq!(runtime.stop_calls.load(Ordering::Relaxed), 2);
        assert_eq!(runtime.start_calls.load(Ordering::Relaxed), 2);
        assert_eq!(worktree.delete_calls.load(Ordering::Relaxed), 1);
    }
}
