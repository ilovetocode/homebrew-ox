use crate::error::AppError;

/// Parsed slash-command payload (`/name args`) used across CLI and runtime dispatch.
pub(crate) struct SlashCommandParts {
    pub(crate) command: String,
    pub(crate) arguments: String,
}

/// Normalize raw slash-command-like input by trimming whitespace and one leading `/`.
pub(crate) fn normalize_slash_command(raw: &str) -> Result<String, AppError> {
    let normalized = raw.trim().trim_start_matches('/').trim();
    if normalized.is_empty() {
        return Err(AppError::InvalidInput {
            message: "slash command cannot be empty".to_string(),
        });
    }
    Ok(normalized.to_string())
}

/// Parse slash-command input into command name and argument tail.
pub(crate) fn parse_slash_command(raw: &str) -> Result<SlashCommandParts, AppError> {
    let normalized = normalize_slash_command(raw)?;
    let mut parts = normalized.splitn(2, char::is_whitespace);
    let command = parts.next().unwrap_or_default().trim().to_string();
    let arguments = parts.next().unwrap_or_default().trim().to_string();
    if command.is_empty() {
        return Err(AppError::InvalidInput {
            message: "slash command cannot be empty".to_string(),
        });
    }

    Ok(SlashCommandParts { command, arguments })
}

#[cfg(test)]
mod tests {
    use super::{normalize_slash_command, parse_slash_command};

    #[test]
    fn normalize_removes_prefix_and_surrounding_whitespace() {
        let normalized = normalize_slash_command("  /implement use plan  ")
            .unwrap_or_else(|_| unreachable!("slash command should normalize"));

        assert_eq!(normalized, "implement use plan");
    }

    #[test]
    fn normalize_rejects_empty_values() {
        let result = normalize_slash_command(" /   ");
        assert!(result.is_err());
    }

    #[test]
    fn parse_splits_command_and_arguments() {
        let parsed = parse_slash_command("/implement use the approved plan")
            .unwrap_or_else(|_| unreachable!("slash command should parse"));

        assert_eq!(parsed.command, "implement");
        assert_eq!(parsed.arguments, "use the approved plan");
    }
}
