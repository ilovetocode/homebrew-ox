use std::time::{SystemTime, UNIX_EPOCH};

/// Time seam for application services that need wall-clock timestamps.
pub(super) trait Clock {
    fn now_unix_ms(&self) -> u128;
}

pub(super) struct SystemClock;

impl Clock for SystemClock {
    fn now_unix_ms(&self) -> u128 {
        SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |duration| duration.as_millis())
    }
}

pub(super) fn unix_time_ms() -> u128 {
    SystemClock.now_unix_ms()
}

#[cfg(test)]
mod tests {
    use super::Clock;

    struct FixedClock(u128);

    impl Clock for FixedClock {
        fn now_unix_ms(&self) -> u128 {
            self.0
        }
    }

    #[test]
    fn clock_trait_allows_deterministic_time_source() {
        let clock = FixedClock(1234);
        assert_eq!(clock.now_unix_ms(), 1234);
    }
}
