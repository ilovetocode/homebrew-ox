use crate::application::PinnedSessionSpec;
use crate::error::AppError;

pub(super) struct PinnedSessionGuard<'a> {
    pinned_sessions: &'a [PinnedSessionSpec],
}

impl<'a> PinnedSessionGuard<'a> {
    pub(super) fn new(pinned_sessions: &'a [PinnedSessionSpec]) -> Self {
        Self { pinned_sessions }
    }

    pub(super) fn is_pinned_name(&self, name: &str) -> bool {
        self.pinned_sessions
            .iter()
            .any(|pinned| pinned.name == name)
    }

    pub(super) fn reject_if_pinned(
        &self,
        display_name: &str,
        action: &str,
    ) -> Result<(), AppError> {
        if self.is_pinned_name(display_name) {
            return Err(AppError::InvalidInput {
                message: format!("the pinned session '{display_name}' cannot be {action}"),
            });
        }
        Ok(())
    }

    pub(super) fn pinned_len(&self) -> usize {
        self.pinned_sessions.len()
    }
}

#[cfg(test)]
mod tests {
    use super::PinnedSessionGuard;
    use crate::application::PinnedSessionSpec;
    use crate::domain::AgentKind;
    use crate::error::AppError;

    fn pinned_specs() -> Vec<PinnedSessionSpec> {
        vec![PinnedSessionSpec {
            name: "manager".to_string(),
            position: 1,
            agent_kind: AgentKind::Opencode,
            working_dir: None,
        }]
    }

    #[test]
    fn reject_if_pinned_blocks_mutation_action() {
        let specs = pinned_specs();
        let guard = PinnedSessionGuard::new(&specs);

        let result = guard.reject_if_pinned("manager", "deleted");

        assert!(matches!(
            result,
            Err(AppError::InvalidInput { message }) if message.contains("cannot be deleted")
        ));
    }

    #[test]
    fn reject_if_pinned_allows_non_pinned_name() {
        let specs = pinned_specs();
        let guard = PinnedSessionGuard::new(&specs);

        let result = guard.reject_if_pinned("dev", "renamed");

        assert!(result.is_ok());
    }
}
