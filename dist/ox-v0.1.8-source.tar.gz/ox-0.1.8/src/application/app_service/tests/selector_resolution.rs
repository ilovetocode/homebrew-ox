use super::super::test_support::build_service_fixture;
use crate::application::AppAgents;
use crate::domain::{Agent, AgentId, AgentKind};
use crate::error::AppError;

#[test]
fn selector_resolution_rejects_empty_selector() {
    let fixture = build_service_fixture();

    let result = AppAgents::resolve_agent_selector(&fixture.service, "   ");

    assert!(matches!(
        result,
        Err(AppError::InvalidInput { message }) if message == "agent selector cannot be empty"
    ));
}

#[test]
fn selector_resolution_parses_id_selector_after_trimming() {
    let fixture = build_service_fixture();
    let Some(id) = AgentId::parse("ag_selector") else {
        return;
    };
    fixture.store.insert_record(
        Agent::from_persisted(
            id.clone(),
            "alpha".to_string(),
            AgentKind::Shell,
            1,
            1,
            1,
            1,
        ),
        None,
        Vec::new(),
    );
    let resolved = AppAgents::resolve_agent_selector(&fixture.service, "  id:  ag_selector  ");

    assert!(matches!(resolved, Ok(found) if found.as_str() == "ag_selector"));
}

#[test]
fn selector_resolution_rejects_invalid_id_selector() {
    let fixture = build_service_fixture();

    let result = AppAgents::resolve_agent_selector(&fixture.service, "id:   ");

    assert!(matches!(
        result,
        Err(AppError::InvalidInput { message })
            if message == "invalid id selector; expected 'id:<agent-id>'"
    ));
}

#[test]
fn selector_resolution_uses_trimmed_exact_display_name_match() {
    let fixture = build_service_fixture();
    let agent = Agent::new("Alpha".to_string(), AgentKind::Shell, 1);
    let id = fixture.store.insert_record(agent, None, Vec::new());

    let resolved = AppAgents::resolve_agent_selector(&fixture.service, "  Alpha  ");

    assert!(matches!(resolved, Ok(found) if found == id));
}

#[test]
fn selector_resolution_accepts_case_insensitive_exact_display_name() {
    let fixture = build_service_fixture();
    let agent = Agent::new("Alpha".to_string(), AgentKind::Shell, 1);
    let id = fixture.store.insert_record(agent, None, Vec::new());

    let resolved = AppAgents::resolve_agent_selector(&fixture.service, "alpha");

    assert!(matches!(resolved, Ok(found) if found == id));
}

#[test]
fn selector_resolution_accepts_unique_display_name_prefix() {
    let fixture = build_service_fixture();
    let agent = Agent::new("worker-alpha".to_string(), AgentKind::Shell, 1);
    let id = fixture.store.insert_record(agent, None, Vec::new());

    let resolved = AppAgents::resolve_agent_selector(&fixture.service, "worker-a");

    assert!(matches!(resolved, Ok(found) if found == id));
}
