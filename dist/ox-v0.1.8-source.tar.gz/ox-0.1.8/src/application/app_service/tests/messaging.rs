use super::super::test_support::build_service_fixture;
use crate::application::opencode_session_state::build_opencode_session_state_binding;
use crate::application::{
    AppAgents, ConversationMessage, ConversationReadResult, ConversationReadSource,
    MessageDispatchResult,
};
use crate::domain::{Agent, AgentKind};
use crate::error::{AgentError, AppError};

fn opencode_read_result(messages: Vec<ConversationMessage>) -> ConversationReadResult {
    ConversationReadResult {
        messages,
        source: ConversationReadSource::OpencodeSession,
        partial: false,
    }
}

#[test]
fn send_message_reports_missing_recoverable_opencode_session_binding() {
    let fixture = build_service_fixture();
    let agent = Agent::new("scribe".to_string(), AgentKind::Opencode, 1);
    let agent_id = fixture.store.insert_record(agent, None, Vec::new());

    let result = AppAgents::send_message_to_agent(&fixture.service, &agent_id, "hello");

    assert!(matches!(
        result,
        Err(AppError::Agent(AgentError::Unavailable { message }))
            if message == "agent 'scribe' has no recoverable opencode session binding"
    ));
    assert_eq!(fixture.dispatch.send_calls(), 0);
}

#[test]
fn send_message_retries_when_fresh_opencode_dispatch_does_not_persist() {
    let fixture = build_service_fixture();
    let agent = Agent::new("scribe".to_string(), AgentKind::Opencode, u128::MAX);
    let runtime = crate::domain::AgentRuntimeBinding::new(
        agent.id(),
        crate::domain::RuntimeProvider::Tmux,
        "scribe".to_string(),
        u128::MAX,
    );
    let session_state = build_opencode_session_state_binding(
        &agent,
        "http://127.0.0.1:4096",
        "session_1",
        "basic",
        Some("/tmp"),
        u128::MAX,
    );
    let agent_id = fixture
        .store
        .insert_record(agent, Some(runtime), vec![session_state]);
    fixture
        .dispatch
        .list_sessions_result
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
        .replace(Ok(vec![
            crate::application::MessageDispatchSessionSummary {
                session: crate::application::MessageDispatchSessionRef {
                    provider: crate::application::MessageDispatchProvider::Opencode,
                    server_url: "http://127.0.0.1:4096".to_string(),
                    session_id: "session_1".to_string(),
                    directory: Some("/tmp".to_string()),
                },
                title: None,
                slug: None,
                parent_session_id: None,
                updated_at_unix_ms: None,
            },
        ]));

    let mut queued_reads = fixture
        .dispatch
        .full_conversation_results
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    queued_reads.push_back(Ok(opencode_read_result(Vec::new())));
    for _ in 0..20 {
        queued_reads.push_back(Ok(opencode_read_result(Vec::new())));
    }
    queued_reads.push_back(Ok(opencode_read_result(Vec::new())));
    queued_reads.push_back(Ok(opencode_read_result(vec![ConversationMessage {
        message_id: "user_1".to_string(),
        role: "user".to_string(),
        created_at_unix_ms: 1,
        completed_at_unix_ms: Some(1),
        text: "hello".to_string(),
        tool_names: Vec::new(),
        patch_files: Vec::new(),
        finish_reason: Some("stop".to_string()),
        synthesized_text: false,
    }])));
    drop(queued_reads);

    let result = AppAgents::send_message_to_agent(&fixture.service, &agent_id, "hello");

    assert!(matches!(result, Ok(MessageDispatchResult { .. })));
    assert_eq!(fixture.dispatch.send_calls(), 2);
}

#[test]
fn send_slash_command_reports_missing_recoverable_opencode_session_binding() {
    let fixture = build_service_fixture();
    let agent = Agent::new("scribe".to_string(), AgentKind::Opencode, 1);
    let agent_id = fixture.store.insert_record(agent, None, Vec::new());

    let result = AppAgents::send_slash_command_to_agent(&fixture.service, &agent_id, "consistency");

    assert!(matches!(
        result,
        Err(AppError::Agent(AgentError::Unavailable { message }))
            if message == "agent 'scribe' has no recoverable opencode session binding"
    ));
    assert_eq!(fixture.dispatch.slash_command_calls(), 0);
}

#[test]
fn send_slash_command_retries_when_fresh_opencode_dispatch_does_not_persist() {
    let fixture = build_service_fixture();
    let agent = Agent::new("scribe".to_string(), AgentKind::Opencode, u128::MAX);
    let runtime = crate::domain::AgentRuntimeBinding::new(
        agent.id(),
        crate::domain::RuntimeProvider::Tmux,
        "scribe".to_string(),
        u128::MAX,
    );
    let session_state = build_opencode_session_state_binding(
        &agent,
        "http://127.0.0.1:4096",
        "session_1",
        "basic",
        Some("/tmp"),
        u128::MAX,
    );
    let agent_id = fixture
        .store
        .insert_record(agent, Some(runtime), vec![session_state]);
    fixture
        .dispatch
        .list_sessions_result
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
        .replace(Ok(vec![
            crate::application::MessageDispatchSessionSummary {
                session: crate::application::MessageDispatchSessionRef {
                    provider: crate::application::MessageDispatchProvider::Opencode,
                    server_url: "http://127.0.0.1:4096".to_string(),
                    session_id: "session_1".to_string(),
                    directory: Some("/tmp".to_string()),
                },
                title: None,
                slug: None,
                parent_session_id: None,
                updated_at_unix_ms: None,
            },
        ]));

    let mut queued_reads = fixture
        .dispatch
        .full_conversation_results
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    queued_reads.push_back(Ok(opencode_read_result(Vec::new())));
    for _ in 0..20 {
        queued_reads.push_back(Ok(opencode_read_result(Vec::new())));
    }
    queued_reads.push_back(Ok(opencode_read_result(Vec::new())));
    queued_reads.push_back(Ok(opencode_read_result(vec![ConversationMessage {
        message_id: "user_1".to_string(),
        role: "user".to_string(),
        created_at_unix_ms: 1,
        completed_at_unix_ms: Some(1),
        text: "expanded slash command prompt".to_string(),
        tool_names: Vec::new(),
        patch_files: Vec::new(),
        finish_reason: Some("stop".to_string()),
        synthesized_text: false,
    }])));
    drop(queued_reads);

    let result = AppAgents::send_slash_command_to_agent(&fixture.service, &agent_id, "consistency");

    assert!(matches!(result, Ok(MessageDispatchResult { .. })));
    assert_eq!(fixture.dispatch.slash_command_calls(), 2);
}
