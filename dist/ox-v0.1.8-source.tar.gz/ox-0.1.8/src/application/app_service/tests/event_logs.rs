use super::super::test_support::build_service_fixture;
use crate::error::AppError;

#[test]
fn run_with_event_writes_to_sync_log_and_returns_operation_result() {
    let fixture = build_service_fixture();

    let result = fixture
        .service
        .event_logs
        .run_with_event("diagnostics", "status", None, || Ok::<_, AppError>(7));

    assert!(matches!(result, Ok(7)));
    assert_eq!(fixture.sync_log.events().len(), 1);
    assert_eq!(
        fixture.sync_log.events()[0].outcome,
        crate::application::EventOutcome::Success
    );
}

#[test]
fn run_with_event_returns_sync_log_failure_even_after_successful_operation() {
    let fixture = build_service_fixture();
    fixture.sync_log.fail_once_with(AppError::InvalidInput {
        message: "event log unavailable".to_string(),
    });

    let result = fixture
        .service
        .event_logs
        .run_with_event("diagnostics", "status", None, || Ok::<_, AppError>(7));

    assert!(matches!(
        result,
        Err(AppError::InvalidInput { message }) if message == "event log unavailable"
    ));
    assert!(fixture.sync_log.events().is_empty());
}
