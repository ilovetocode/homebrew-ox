use std::sync::Arc;

use crate::application::ports::EventLogPort;
use crate::application::types::{AppEvent, LoggedEvent};
use crate::error::AppError;

/// Event-log sinks used by `AppService` to record operation outcomes.
pub(crate) struct AppEventLogs {
    sync: Arc<dyn EventLogPort>,
}

impl AppEventLogs {
    pub(crate) fn new(sync: Arc<dyn EventLogPort>) -> Self {
        Self { sync }
    }

    pub(crate) fn read_recent(&self, limit: usize) -> Result<Vec<LoggedEvent>, AppError> {
        self.sync.read_recent(limit)
    }

    pub(crate) fn run_with_event<T, F>(
        &self,
        feature: &str,
        action: &str,
        target: Option<String>,
        operation: F,
    ) -> Result<T, AppError>
    where
        F: FnOnce() -> Result<T, AppError>,
    {
        let result = operation();
        let event = event_from_operation_result(feature, action, target, &result);
        self.sync.append(&event)?;
        result
    }

    pub(crate) fn run_agent_event<T, F>(
        &self,
        action: &str,
        target: Option<String>,
        operation: F,
    ) -> Result<T, AppError>
    where
        F: FnOnce() -> Result<T, AppError>,
    {
        self.run_with_event("agents", action, target, operation)
    }
}

fn event_from_operation_result<T>(
    feature: &str,
    action: &str,
    target: Option<String>,
    result: &Result<T, AppError>,
) -> AppEvent {
    match result {
        Ok(_) => AppEvent::success(feature, action, target),
        Err(err) => AppEvent::failure(feature, action, target, err.to_string()),
    }
}
