use crate::application::types::CreateAgentRequest;
use crate::application::{EventOutcome, LoggedEvent, TuiAttachReturn, TuiFleetSnapshot};
use crate::domain::AgentId;
use crate::error::AppError;

use super::AppService;

pub(super) fn create_agent(
    app: &AppService,
    request: CreateAgentRequest,
) -> Result<AgentId, AppError> {
    app.event_logs
        .run_agent_event("create", Some(request.display_name.clone()), || {
            app.agents.create_agent(request)
        })
}

pub(super) fn rename_agent(
    app: &AppService,
    id: &AgentId,
    new_display_name: &str,
) -> Result<(), AppError> {
    app.event_logs.run_agent_event(
        "rename",
        Some(format!("{}->{new_display_name}", id.as_str())),
        || app.agents.rename_agent(id, new_display_name),
    )
}

pub(super) fn reorder_agent(
    app: &AppService,
    id: &AgentId,
    target_position: i64,
) -> Result<(), AppError> {
    app.event_logs.run_agent_event(
        "reorder",
        Some(format!("{}->pos:{target_position}", id.as_str())),
        || app.agents.reorder_agent(id, target_position),
    )
}

pub(super) fn delete_agent(app: &AppService, id: &AgentId) -> Result<(), AppError> {
    app.event_logs
        .run_agent_event("delete", Some(id.as_str().to_string()), || {
            app.agents.delete_agent(id)
        })
}

pub(super) fn switch_agent_to_worktree_shell(
    app: &AppService,
    id: &AgentId,
    branch_name: &str,
) -> Result<(), AppError> {
    app.event_logs.run_agent_event(
        "worktree",
        Some(format!("{}->{branch_name}", id.as_str())),
        || app.agents.switch_agent_to_worktree_shell(id, branch_name),
    )
}

pub(super) fn tui_create_agent(
    app: &AppService,
    request: CreateAgentRequest,
) -> Result<TuiFleetSnapshot, AppError> {
    let created_id = create_agent(app, request)?;
    let agents = app.agents.list_agents()?;
    Ok(TuiFleetSnapshot {
        agents,
        selected_agent_id: Some(created_id),
    })
}

pub(super) fn tui_rename_agent(
    app: &AppService,
    id: &AgentId,
    new_display_name: &str,
) -> Result<TuiFleetSnapshot, AppError> {
    rename_agent(app, id, new_display_name)?;
    let agents = app.agents.list_agents()?;
    Ok(TuiFleetSnapshot {
        agents,
        selected_agent_id: Some(id.clone()),
    })
}

pub(super) fn tui_delete_agent(
    app: &AppService,
    id: &AgentId,
) -> Result<TuiFleetSnapshot, AppError> {
    delete_agent(app, id)?;
    let agents = app.agents.list_agents()?;
    let selected_agent_id = agents
        .iter()
        .any(|agent| agent.agent.id().as_str() == id.as_str())
        .then(|| id.clone());
    Ok(TuiFleetSnapshot {
        agents,
        selected_agent_id,
    })
}

pub(super) fn tui_switch_agent_to_worktree_shell(
    app: &AppService,
    id: &AgentId,
    branch_name: &str,
) -> Result<TuiFleetSnapshot, AppError> {
    switch_agent_to_worktree_shell(app, id, branch_name)?;
    let agents = app.agents.list_agents()?;
    Ok(TuiFleetSnapshot {
        agents,
        selected_agent_id: Some(id.clone()),
    })
}

pub(super) fn connect_agent(app: &AppService, id: &AgentId) -> Result<(), AppError> {
    // Keep attach events on the synchronous log path so the waiting TUI can
    // reliably recover the final session the user detached from after any
    // quick-switches that happened inside tmux.
    app.event_logs
        .run_agent_event("connect", Some(id.as_str().to_string()), || {
            app.runtime_agents.attach_agent(id)
        })
}

pub(super) fn disconnect_to_dashboard(app: &AppService) -> Result<(), AppError> {
    // Dashboard returns use the persisted event stream as a handoff breadcrumb,
    // so detach events also stay synchronous.
    app.event_logs
        .run_agent_event("disconnect", None, || app.runtime_agents.detach_client())
}

pub(super) fn tui_resolve_attach_return(
    app: &AppService,
    requested_id: &AgentId,
    attach_started_at_unix_ms: u128,
) -> Result<TuiAttachReturn, AppError> {
    let recent_events = app.event_logs.read_recent(200)?;
    let resolved_id =
        resolve_post_attach_agent_id(requested_id, &recent_events, attach_started_at_unix_ms);
    let record = if let Some(record) = app
        .store
        .find_agent_runtime_record_by_id(resolved_id.clone())?
    {
        Some(record)
    } else {
        app.store
            .find_agent_runtime_record_by_id(requested_id.clone())?
    };
    let Some(record) = record else {
        return Ok(TuiAttachReturn {
            id: requested_id.clone(),
            name: requested_id.as_str().to_string(),
        });
    };

    Ok(TuiAttachReturn {
        id: record.agent.id(),
        name: record.agent.display_name().to_string(),
    })
}

fn resolve_post_attach_agent_id(
    requested_id: &AgentId,
    recent_events: &[LoggedEvent],
    attach_started_at_unix_ms: u128,
) -> AgentId {
    // Read from newest to oldest and stop at the first successful connect that
    // happened after the attach handoff started. That event is the final
    // managed session the user reached before detaching back to the dashboard.
    recent_events
        .iter()
        .find_map(|event| {
            (event.timestamp_unix_ms >= attach_started_at_unix_ms
                && event.feature == "agents"
                && event.action == "connect"
                && event.outcome == EventOutcome::Success)
                .then_some(event.target.as_deref())
                .flatten()
                .and_then(AgentId::parse)
        })
        .unwrap_or_else(|| requested_id.clone())
}

#[cfg(test)]
mod tests {
    use super::resolve_post_attach_agent_id;
    use crate::application::{EventOutcome, LoggedEvent};
    use crate::domain::AgentId;

    fn must_id(raw: &str) -> Option<AgentId> {
        AgentId::parse(raw)
    }

    fn logged_event(
        timestamp_unix_ms: u128,
        action: &str,
        target: Option<&str>,
        outcome: EventOutcome,
    ) -> LoggedEvent {
        LoggedEvent {
            timestamp_unix_ms,
            op_id: format!("op-{timestamp_unix_ms}-{action}"),
            feature: "agents".to_string(),
            action: action.to_string(),
            target: target.map(str::to_string),
            outcome,
            detail: None,
        }
    }

    #[test]
    fn post_attach_resolution_prefers_latest_connect_after_attach_started() {
        let requested_id = must_id("ag-requested");
        assert!(requested_id.is_some(), "valid id");
        let Some(requested_id) = requested_id else {
            return;
        };
        let quick_switched_id = must_id("ag-switched");
        assert!(quick_switched_id.is_some(), "valid id");
        let Some(quick_switched_id) = quick_switched_id else {
            return;
        };
        let recent_events = vec![
            logged_event(
                40,
                "connect",
                Some(quick_switched_id.as_str()),
                EventOutcome::Success,
            ),
            logged_event(
                20,
                "connect",
                Some(requested_id.as_str()),
                EventOutcome::Success,
            ),
        ];

        let resolved = resolve_post_attach_agent_id(&requested_id, &recent_events, 10);

        assert_eq!(resolved.as_str(), quick_switched_id.as_str());
    }

    #[test]
    fn post_attach_resolution_ignores_connects_before_attach_started() {
        let requested_id = must_id("ag-requested");
        assert!(requested_id.is_some(), "valid id");
        let Some(requested_id) = requested_id else {
            return;
        };
        let older_id = must_id("ag-older");
        assert!(older_id.is_some(), "valid id");
        let Some(older_id) = older_id else {
            return;
        };
        let recent_events = vec![logged_event(
            5,
            "connect",
            Some(older_id.as_str()),
            EventOutcome::Success,
        )];

        let resolved = resolve_post_attach_agent_id(&requested_id, &recent_events, 10);

        assert_eq!(resolved.as_str(), requested_id.as_str());
    }

    #[test]
    fn post_attach_resolution_ignores_non_success_connect_events() {
        let requested_id = must_id("ag-requested");
        assert!(requested_id.is_some(), "valid id");
        let Some(requested_id) = requested_id else {
            return;
        };
        let failed_id = must_id("ag-failed");
        assert!(failed_id.is_some(), "valid id");
        let Some(failed_id) = failed_id else {
            return;
        };
        let recent_events = vec![
            logged_event(30, "disconnect", None, EventOutcome::Success),
            logged_event(
                20,
                "connect",
                Some(failed_id.as_str()),
                EventOutcome::Failure,
            ),
        ];

        let resolved = resolve_post_attach_agent_id(&requested_id, &recent_events, 10);

        assert_eq!(resolved.as_str(), requested_id.as_str());
    }
}
