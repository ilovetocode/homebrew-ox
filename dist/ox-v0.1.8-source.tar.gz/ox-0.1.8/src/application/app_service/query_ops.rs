use crate::application::types::{AgentView, LoggedEvent};
use crate::application::{DoctorReport, StatusReport};
use crate::domain::AgentId;
use crate::error::AppError;

use super::AppService;

pub(super) fn status_report(app: &AppService) -> Result<StatusReport, AppError> {
    app.event_logs
        .run_with_event("diagnostics", "status", None, || {
            app.diagnostics.status_report()
        })
}

pub(super) fn doctor_report(app: &AppService, fix: bool) -> Result<DoctorReport, AppError> {
    app.event_logs
        .run_with_event("diagnostics", "doctor", Some(format!("fix={fix}")), || {
            app.diagnostics.doctor_report(fix)
        })
}

pub(super) fn reconcile_pinned_sessions(app: &AppService) -> Result<(), AppError> {
    app.event_logs
        .run_agent_event("reconcile-pinned", None, || {
            app.agents.reconcile_pinned_sessions()
        })
}

pub(super) fn list_agents(app: &AppService) -> Result<Vec<AgentView>, AppError> {
    // `agents list` backs interactive refresh loops, so keep it outside the
    // synchronous event-log path to avoid SQLite latency on every repaint.
    app.agents.list_agents()
}

pub(super) fn list_agents_for_picker(app: &AppService) -> Result<Vec<AgentView>, AppError> {
    app.agents.list_agents_for_picker()
}

pub(super) fn recent_events(app: &AppService, limit: usize) -> Result<Vec<LoggedEvent>, AppError> {
    app.event_logs.read_recent(limit)
}

pub(super) fn events_default_limit(app: &AppService) -> usize {
    app.settings.events_default_limit
}

pub(super) fn tui_refresh_interval_ms(app: &AppService) -> u64 {
    app.settings.tui_refresh_interval_ms
}

pub(super) fn resolve_agent_selector(
    app: &AppService,
    selector: &str,
) -> Result<AgentId, AppError> {
    let selector = selector.trim();
    if selector.is_empty() {
        return Err(AppError::InvalidInput {
            message: "agent selector cannot be empty".to_string(),
        });
    }

    if let Some(raw_id) = selector.strip_prefix("id:") {
        let raw_id = raw_id.trim();
        let Some(id) = AgentId::parse(raw_id) else {
            return Err(AppError::InvalidInput {
                message: "invalid id selector; expected 'id:<agent-id>'".to_string(),
            });
        };
        let records = app.store.list_agent_runtime_records()?;
        if records
            .iter()
            .any(|record| record.agent.id().as_str() == id.as_str())
        {
            return Ok(id);
        }

        let prefix_matches = records
            .iter()
            .filter(|record| record.agent.id().as_str().starts_with(raw_id))
            .collect::<Vec<_>>();
        return resolve_selector_matches(
            &prefix_matches,
            || format!("agent selector '{selector}' is ambiguous"),
            || selector_not_found_error(selector, &records),
        );
    }

    let records = app.store.list_agent_runtime_records()?;
    if let Some(record) = records
        .iter()
        .find(|record| record.agent.display_name() == selector)
    {
        return Ok(record.agent.id());
    }

    let case_insensitive_matches = records
        .iter()
        .filter(|record| record.agent.display_name().eq_ignore_ascii_case(selector))
        .collect::<Vec<_>>();
    if let Ok(id) = resolve_selector_matches(
        &case_insensitive_matches,
        || format!("agent selector '{selector}' matches more than one display name"),
        || selector_not_found_error(selector, &records),
    ) {
        return Ok(id);
    }

    let selector_lower = selector.to_ascii_lowercase();
    let prefix_matches = records
        .iter()
        .filter(|record| {
            record
                .agent
                .display_name()
                .to_ascii_lowercase()
                .starts_with(&selector_lower)
        })
        .collect::<Vec<_>>();
    resolve_selector_matches(
        &prefix_matches,
        || format!("agent selector '{selector}' matches more than one prefix"),
        || selector_not_found_error(selector, &records),
    )
}

fn resolve_selector_matches<F, G>(
    matches: &[&crate::domain::AgentRuntimeRecord],
    ambiguous_message: F,
    not_found: G,
) -> Result<AgentId, AppError>
where
    F: FnOnce() -> String,
    G: FnOnce() -> AppError,
{
    match matches {
        [record] => Ok(record.agent.id()),
        [] => Err(not_found()),
        _ => Err(AppError::InvalidInput {
            message: format!(
                "{}; candidates: {}",
                ambiguous_message(),
                format_selector_candidates(matches)
            ),
        }),
    }
}

fn selector_not_found_error(
    selector: &str,
    records: &[crate::domain::AgentRuntimeRecord],
) -> AppError {
    let suggestions = nearest_selector_candidates(selector, records);
    if suggestions.is_empty() {
        return AppError::InvalidInput {
            message: format!("agent selector '{selector}' was not found"),
        };
    }

    AppError::InvalidInput {
        message: format!(
            "agent selector '{selector}' was not found; nearest matches: {}",
            suggestions.join(", ")
        ),
    }
}

fn format_selector_candidates(records: &[&crate::domain::AgentRuntimeRecord]) -> String {
    records
        .iter()
        .take(5)
        .map(|record| {
            format!(
                "{} (id:{})",
                record.agent.display_name(),
                record.agent.id().as_str()
            )
        })
        .collect::<Vec<_>>()
        .join(", ")
}

fn nearest_selector_candidates(
    selector: &str,
    records: &[crate::domain::AgentRuntimeRecord],
) -> Vec<String> {
    let mut scored = records
        .iter()
        .filter_map(|record| {
            let name = record.agent.display_name();
            let id = record.agent.id();
            let score =
                selector_similarity(selector, name).max(selector_similarity(selector, id.as_str()));
            (score > 0).then_some((score, format!("{name} (id:{})", id.as_str())))
        })
        .collect::<Vec<_>>();

    scored.sort_by(|left, right| right.0.cmp(&left.0).then_with(|| left.1.cmp(&right.1)));
    scored.truncate(5);
    scored.into_iter().map(|(_, label)| label).collect()
}

fn selector_similarity(selector: &str, candidate: &str) -> i64 {
    let selector = selector.trim().to_ascii_lowercase();
    let candidate = candidate.to_ascii_lowercase();
    if selector.is_empty() || candidate.is_empty() {
        return 0;
    }
    if candidate == selector {
        return 100;
    }
    if candidate.starts_with(&selector) {
        return 80;
    }
    if candidate.contains(&selector) {
        return 60;
    }

    let mut score = 0_i64;
    let mut offset = 0_usize;
    for ch in selector.chars() {
        let Some(found) = candidate[offset..].find(ch) else {
            return 0;
        };
        score += 5;
        offset += found + 1;
    }
    score
}
