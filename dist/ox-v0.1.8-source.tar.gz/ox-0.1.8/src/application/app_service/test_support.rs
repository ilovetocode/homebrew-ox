use std::collections::{HashMap, VecDeque};
use std::sync::{Arc, Mutex};

use super::{AppEventLogs, AppService};
use crate::application::ports::{
    AgentRuntimePort, AgentStorePort, CodexThreadPort, ConfigPort, EventLogPort,
    MessageDispatchPort, OpencodeSessionBootstrapPort, SessionPort, SessionStatePort, WorktreePort,
};
use crate::application::{
    AgentConversationService, AgentInteractionService, AgentLifecycleService, AppEvent,
    AppSettings, AppStoragePaths, ConversationMessage, ConversationReadResult,
    ConversationReadSource, MessageDispatchCreateSessionRequest,
    MessageDispatchCreateSessionResult, MessageDispatchProvider, MessageDispatchResult,
    MessageDispatchSendRequest, MessageDispatchSessionRef, MessageDispatchSessionSummary,
    MessageDispatchSlashCommandRequest, MessageReadRequest, OpencodeProvisioning, OpencodeSettings,
    RuntimeProbeResult, RuntimeStartRequest, RuntimeStatus,
};
use crate::domain::{
    Agent, AgentId, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding, AgentStateKind,
};
use crate::error::{AgentError, AppError, StartupError};

fn stub_error(op: &str) -> AppError {
    AppError::Agent(AgentError::Unavailable {
        message: format!("stubbed method called: {op}"),
    })
}

#[derive(Default)]
pub(super) struct SyncLogStub {
    events: Mutex<Vec<AppEvent>>,
    fail_with: Mutex<Option<AppError>>,
}

impl SyncLogStub {
    pub(super) fn events(&self) -> Vec<AppEvent> {
        self.events
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .clone()
    }

    pub(super) fn fail_once_with(&self, err: AppError) {
        *self
            .fail_with
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner) = Some(err);
    }
}

impl EventLogPort for SyncLogStub {
    fn append(&self, event: &AppEvent) -> Result<(), AppError> {
        if let Some(err) = self
            .fail_with
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .take()
        {
            return Err(err);
        }

        self.events
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .push(event.clone());
        Ok(())
    }

    fn read_recent(&self, _limit: usize) -> Result<Vec<crate::application::LoggedEvent>, AppError> {
        Ok(Vec::new())
    }
}

#[derive(Default)]
struct RuntimeStub;

impl AgentRuntimePort for RuntimeStub {
    fn start(
        &self,
        _request: &RuntimeStartRequest,
        _binding: Option<&AgentRuntimeBinding>,
    ) -> Result<AgentRuntimeBinding, AppError> {
        Err(stub_error("start"))
    }

    fn stop(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
        Ok(())
    }

    fn attach(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
        Ok(())
    }

    fn detach_client(&self) -> Result<(), AppError> {
        Ok(())
    }

    fn probe(
        &self,
        _bindings: &[AgentRuntimeBinding],
    ) -> Result<Vec<RuntimeProbeResult>, AppError> {
        Ok(Vec::new())
    }

    fn capture_output(
        &self,
        _binding: &AgentRuntimeBinding,
        _lines: u16,
    ) -> Result<String, AppError> {
        Ok(String::new())
    }

    fn send_key(&self, _binding: &AgentRuntimeBinding, _key: &str) -> Result<(), AppError> {
        Ok(())
    }

    fn rename(
        &self,
        _binding: &AgentRuntimeBinding,
        _new_external_ref: &str,
    ) -> Result<(), AppError> {
        Ok(())
    }
}

#[derive(Default)]
struct TmuxStub;

impl SessionPort for TmuxStub {
    fn list_sessions(&self) -> Result<Vec<crate::application::HostSessionSnapshot>, AppError> {
        Ok(Vec::new())
    }
}

impl crate::application::RuntimePort for TmuxStub {
    fn ensure_tmux_on_path(&self) -> Result<(), StartupError> {
        Ok(())
    }

    fn tmux_available(&self) -> bool {
        true
    }
}

impl ConfigPort for TmuxStub {
    fn tmux_conf_path(&self) -> String {
        "~/.config/ox/tmux.conf".to_string()
    }

    fn is_in_sync(&self) -> bool {
        true
    }

    fn reconcile(&self) -> Result<(), AppError> {
        Ok(())
    }
}

#[derive(Default)]
struct SessionStateStub;

impl SessionStatePort for SessionStateStub {
    fn replace_sessions(
        &self,
        _sessions: &[crate::application::HostSessionSnapshot],
    ) -> Result<(), AppError> {
        Ok(())
    }
}

#[derive(Default)]
pub(super) struct WorktreeStub {
    pub(super) parent_git_root: Mutex<Option<String>>,
    pub(super) current_branch: Mutex<Option<String>>,
}

impl WorktreePort for WorktreeStub {
    fn create_worktree(
        &self,
        _agent: &Agent,
        _spec: &crate::application::ResolvedGitWorktreeSpec,
    ) -> Result<AgentStateBinding, AppError> {
        Err(stub_error("create_worktree"))
    }

    fn delete_worktree(&self, _state: &AgentStateBinding) -> Result<(), AppError> {
        Ok(())
    }

    fn current_branch(&self, _worktree_path: &str) -> Result<Option<String>, AppError> {
        Ok(self
            .current_branch
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .clone())
    }

    fn resolve_base_ref(&self, _path: &str) -> Result<Option<String>, AppError> {
        Ok(self
            .current_branch
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .clone())
    }

    fn parent_git_root(&self, _path: &str) -> Result<Option<String>, AppError> {
        Ok(self
            .parent_git_root
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .clone())
    }
}

#[derive(Default)]
struct CodexThreadStub;

impl CodexThreadPort for CodexThreadStub {
    fn start_thread(
        &self,
        _request: &crate::application::CodexThreadStartRequest,
    ) -> Result<crate::application::CodexThreadBootstrap, AppError> {
        Err(stub_error("start_thread"))
    }

    fn read_thread_statuses(
        &self,
        _thread_ids: &[String],
    ) -> Result<HashMap<String, RuntimeStatus>, AppError> {
        Ok(HashMap::new())
    }

    fn read_thread_conversation(
        &self,
        _thread_id: &str,
        _limit: Option<usize>,
    ) -> Result<ConversationReadResult, AppError> {
        Ok(ConversationReadResult {
            messages: Vec::new(),
            source: ConversationReadSource::CodexRollout,
            partial: false,
        })
    }
}

#[derive(Default)]
struct OpencodeBootstrapStub;

impl OpencodeSessionBootstrapPort for OpencodeBootstrapStub {
    fn ensure_session_for_directory(
        &self,
        directory: &str,
    ) -> Result<MessageDispatchSessionRef, AppError> {
        Ok(MessageDispatchSessionRef {
            provider: MessageDispatchProvider::Opencode,
            server_url: "http://127.0.0.1:4096".to_string(),
            session_id: "session_1".to_string(),
            directory: Some(directory.to_string()),
        })
    }
}

#[derive(Default)]
pub(super) struct DispatchStub {
    send_requests: Mutex<Vec<MessageDispatchSendRequest>>,
    slash_command_requests: Mutex<Vec<MessageDispatchSlashCommandRequest>>,
    pub(super) send_result: Mutex<Option<Result<MessageDispatchResult, AppError>>>,
    last_message_result: Mutex<Option<Result<Option<ConversationMessage>, AppError>>>,
    pub(super) last_message_results: Mutex<VecDeque<Result<Option<ConversationMessage>, AppError>>>,
    full_conversation_result: Mutex<Option<Result<ConversationReadResult, AppError>>>,
    pub(super) full_conversation_results: Mutex<VecDeque<Result<ConversationReadResult, AppError>>>,
    pub(super) list_sessions_result:
        Mutex<Option<Result<Vec<MessageDispatchSessionSummary>, AppError>>>,
    pub(super) list_sessions_results:
        Mutex<VecDeque<Result<Vec<MessageDispatchSessionSummary>, AppError>>>,
}

impl DispatchStub {
    pub(super) fn send_calls(&self) -> usize {
        self.send_requests
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .len()
    }

    pub(super) fn slash_command_calls(&self) -> usize {
        self.slash_command_requests
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .len()
    }
}

impl MessageDispatchPort for DispatchStub {
    fn create_session(
        &self,
        _request: &MessageDispatchCreateSessionRequest,
    ) -> Result<MessageDispatchCreateSessionResult, AppError> {
        Err(stub_error("create_session"))
    }

    fn list_sessions(
        &self,
        _server_url: &str,
    ) -> Result<Vec<MessageDispatchSessionSummary>, AppError> {
        if let Some(next) = self
            .list_sessions_results
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .pop_front()
        {
            return next;
        }
        self.list_sessions_result
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .take()
            .unwrap_or_else(|| Ok(Vec::new()))
    }

    fn list_child_sessions(
        &self,
        _session: &MessageDispatchSessionRef,
    ) -> Result<Vec<MessageDispatchSessionSummary>, AppError> {
        Ok(Vec::new())
    }

    fn send_message(
        &self,
        request: &MessageDispatchSendRequest,
    ) -> Result<MessageDispatchResult, AppError> {
        self.send_requests
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .push(request.clone());
        self.send_result
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .take()
            .unwrap_or_else(|| {
                Ok(MessageDispatchResult {
                    dispatch_id: "dispatch_1".to_string(),
                    accepted_at_unix_ms: 1,
                    provider_message_id: None,
                })
            })
    }

    fn send_slash_command(
        &self,
        request: &MessageDispatchSlashCommandRequest,
    ) -> Result<MessageDispatchResult, AppError> {
        self.slash_command_requests
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .push(request.clone());
        self.send_result
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .take()
            .unwrap_or_else(|| {
                Ok(MessageDispatchResult {
                    dispatch_id: "dispatch_1".to_string(),
                    accepted_at_unix_ms: 1,
                    provider_message_id: None,
                })
            })
    }

    fn read_last_message(
        &self,
        _request: &MessageReadRequest,
    ) -> Result<Option<ConversationMessage>, AppError> {
        if let Some(next) = self
            .last_message_results
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .pop_front()
        {
            return next;
        }
        self.last_message_result
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .take()
            .unwrap_or(Ok(None))
    }

    fn read_full_conversation(
        &self,
        _request: &MessageReadRequest,
    ) -> Result<ConversationReadResult, AppError> {
        if let Some(next) = self
            .full_conversation_results
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .pop_front()
        {
            return next;
        }
        self.full_conversation_result
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .take()
            .unwrap_or_else(|| {
                Ok(ConversationReadResult {
                    messages: Vec::new(),
                    source: ConversationReadSource::OpencodeSession,
                    partial: false,
                })
            })
    }

    fn read_session_status(
        &self,
        _session: &MessageDispatchSessionRef,
    ) -> Result<RuntimeStatus, AppError> {
        Ok(RuntimeStatus::Waiting)
    }
}

#[derive(Default)]
pub(super) struct StoreStub {
    runtime_records: Mutex<HashMap<String, AgentRuntimeRecord>>,
    state_bindings: Mutex<HashMap<String, Vec<AgentStateBinding>>>,
}

impl StoreStub {
    pub(super) fn insert_record(
        &self,
        agent: Agent,
        binding: Option<AgentRuntimeBinding>,
        states: Vec<AgentStateBinding>,
    ) -> AgentId {
        let id = agent.id();
        self.runtime_records
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .insert(
                id.as_str().to_string(),
                AgentRuntimeRecord { agent, binding },
            );
        self.state_bindings
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .insert(id.as_str().to_string(), states);
        id
    }
}

impl AgentStorePort for StoreStub {
    fn insert_agent_with_binding(
        &self,
        agent: &Agent,
        binding: &AgentRuntimeBinding,
        state_bindings: &[AgentStateBinding],
    ) -> Result<(), AppError> {
        self.runtime_records
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .insert(
                binding.agent_id.as_str().to_string(),
                AgentRuntimeRecord {
                    agent: agent.clone(),
                    binding: Some(binding.clone()),
                },
            );
        self.state_bindings
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .insert(
                binding.agent_id.as_str().to_string(),
                state_bindings.to_vec(),
            );
        Ok(())
    }

    fn list_agent_runtime_records(&self) -> Result<Vec<AgentRuntimeRecord>, AppError> {
        Ok(self
            .runtime_records
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .values()
            .cloned()
            .collect())
    }

    fn find_agent_runtime_record_by_id(
        &self,
        id: AgentId,
    ) -> Result<Option<AgentRuntimeRecord>, AppError> {
        Ok(self
            .runtime_records
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .get(id.as_str())
            .cloned())
    }

    fn list_state_bindings_by_agent_id(
        &self,
        id: AgentId,
    ) -> Result<Vec<AgentStateBinding>, AppError> {
        Ok(self
            .state_bindings
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .get(id.as_str())
            .cloned()
            .unwrap_or_default())
    }

    fn list_state_bindings_by_agent_ids(
        &self,
        ids: &[AgentId],
    ) -> Result<Vec<AgentStateBinding>, AppError> {
        let bindings = self
            .state_bindings
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        Ok(ids
            .iter()
            .flat_map(|id| bindings.get(id.as_str()).cloned().unwrap_or_default())
            .collect())
    }

    fn upsert_state_binding(&self, binding: &AgentStateBinding) -> Result<(), AppError> {
        let mut all_bindings = self
            .state_bindings
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let agent_bindings = all_bindings
            .entry(binding.agent_id.as_str().to_string())
            .or_default();
        if let Some(slot) = agent_bindings.iter_mut().find(|row| row.id == binding.id) {
            *slot = binding.clone();
        } else {
            agent_bindings.push(binding.clone());
        }
        Ok(())
    }

    fn find_agent_by_display_name(&self, display_name: &str) -> Result<Option<Agent>, AppError> {
        Ok(self
            .runtime_records
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .values()
            .find(|record| record.agent.display_name() == display_name)
            .map(|record| record.agent.clone()))
    }

    fn update_agent(&self, _updated: &Agent, _expected_version: i64) -> Result<(), AppError> {
        Err(stub_error("update_agent"))
    }

    fn upsert_binding(&self, binding: &AgentRuntimeBinding) -> Result<(), AppError> {
        let mut records = self
            .runtime_records
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let Some(record) = records.get_mut(binding.agent_id.as_str()) else {
            return Err(stub_error("upsert_binding missing record"));
        };
        record.binding = Some(binding.clone());
        Ok(())
    }

    fn update_agent_runtime_context(
        &self,
        updated: &Agent,
        _expected_version: i64,
        binding: &AgentRuntimeBinding,
        upsert_state_bindings: &[AgentStateBinding],
        delete_state_kinds: &[AgentStateKind],
    ) -> Result<(), AppError> {
        let mut records = self
            .runtime_records
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let Some(record) = records.get_mut(updated.id().as_str()) else {
            return Err(stub_error("update_agent_runtime_context missing record"));
        };
        record.agent = updated.clone();
        record.binding = Some(binding.clone());
        drop(records);

        let mut all_bindings = self
            .state_bindings
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        let agent_bindings = all_bindings
            .entry(updated.id().as_str().to_string())
            .or_default();
        agent_bindings.retain(|row| !delete_state_kinds.contains(&row.state_kind));
        for binding in upsert_state_bindings {
            if let Some(slot) = agent_bindings.iter_mut().find(|row| {
                row.state_kind == binding.state_kind && row.binding_key == binding.binding_key
            }) {
                *slot = binding.clone();
            } else {
                agent_bindings.push(binding.clone());
            }
        }
        Ok(())
    }

    fn delete_agent(&self, _id: AgentId) -> Result<(), AppError> {
        Err(stub_error("delete_agent"))
    }

    fn next_display_order(&self) -> Result<i64, AppError> {
        let next = self
            .runtime_records
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .values()
            .map(|record| record.agent.display_order())
            .max()
            .unwrap_or(0)
            .saturating_add(1);
        Ok(next)
    }

    fn swap_display_order(
        &self,
        _a: &Agent,
        _a_expected_version: i64,
        _b: &Agent,
        _b_expected_version: i64,
    ) -> Result<(), AppError> {
        Err(stub_error("swap_display_order"))
    }
}

pub(super) struct ServiceFixture {
    pub(super) service: AppService,
    pub(super) store: Arc<StoreStub>,
    pub(super) sync_log: Arc<SyncLogStub>,
    pub(super) dispatch: Arc<DispatchStub>,
}

fn test_settings() -> AppSettings {
    AppSettings {
        events_default_limit: 50,
        tui_refresh_interval_ms: 250,
        opencode: OpencodeSettings {
            server_url: "http://127.0.0.1:4096".to_string(),
            username_env: "OPENCODE_USERNAME".to_string(),
            password_env: "OPENCODE_PASSWORD".to_string(),
            request_timeout_ms: 1_000,
            read_request_timeout_ms: 1_000,
            status_poll_interval_ms: 10,
            conversation_page_size: 25,
        },
    }
}

pub(super) fn build_service_fixture() -> ServiceFixture {
    let store = Arc::new(StoreStub::default());
    let dispatch = Arc::new(DispatchStub::default());
    let sync_log = Arc::new(SyncLogStub::default());
    let runtime = Arc::new(RuntimeStub);
    let opencode_bootstrap = Arc::new(OpencodeBootstrapStub);
    let worktree = Arc::new(WorktreeStub::default());
    let settings = test_settings();
    let conversation_agents = Arc::new(AgentConversationService::new(
        store.clone(),
        runtime.clone(),
        Arc::new(CodexThreadStub),
        dispatch.clone(),
        settings.opencode.conversation_page_size,
    ));
    let agents = AgentLifecycleService::new(
        store.clone(),
        runtime.clone(),
        worktree.clone(),
        Arc::new(CodexThreadStub),
        dispatch.clone(),
        OpencodeProvisioning::new(opencode_bootstrap.clone()),
        Vec::new(),
    );
    let runtime_agents = AgentInteractionService::new(store.clone(), runtime);
    let diagnostics = crate::application::DiagnosticsService::new(
        Arc::new(TmuxStub),
        Arc::new(SessionStateStub),
        AppStoragePaths {
            sqlite_db_path: "/tmp/ox-test.sqlite".to_string(),
            config_path: "/tmp/ox-config.json".to_string(),
        },
    );
    let service = AppService::new(
        agents,
        runtime_agents,
        conversation_agents,
        diagnostics,
        AppEventLogs::new(sync_log.clone()),
        settings,
        store.clone(),
    );

    ServiceFixture {
        service,
        store,
        sync_log,
        dispatch,
    }
}
