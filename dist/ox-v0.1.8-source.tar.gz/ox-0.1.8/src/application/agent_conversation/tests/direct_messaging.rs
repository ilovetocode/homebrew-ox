use super::support::service_with_agent;
use crate::application::AgentConversationPort;
use crate::application::RuntimeStatus;
use crate::domain::{Agent, AgentKind};
use crate::error::{AgentError, AppError};

#[test]
fn direct_send_reports_missing_recoverable_opencode_session_binding() {
    let agent = Agent::new("scribe".to_string(), AgentKind::Opencode, 1);
    let service = service_with_agent(&agent, Vec::new(), None, RuntimeStatus::Waiting);

    let result = service.send_message_to_agent(&agent.id(), "hello");

    assert!(matches!(
        result,
        Err(AppError::Agent(AgentError::Unavailable { message }))
            if message == "agent 'scribe' has no recoverable opencode session binding"
    ));
}
