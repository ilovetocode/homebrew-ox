use std::sync::{Arc, Mutex};

use super::super::AgentConversationService;
use crate::application::ports::{
    AgentRuntimePort, AgentStorePort, CodexThreadPort, MessageDispatchPort,
};
use crate::application::{
    CodexThreadBootstrap, CodexThreadStartRequest, ConversationMessage, ConversationReadResult,
    ConversationReadSource, MessageDispatchCreateSessionRequest,
    MessageDispatchCreateSessionResult, MessageDispatchProvider, MessageDispatchResult,
    MessageDispatchSendRequest, MessageDispatchSessionRef, MessageDispatchSessionSummary,
    MessageDispatchSlashCommandRequest, MessageReadRequest, RuntimeProbeResult,
    RuntimeStartRequest, RuntimeStatus,
};
use crate::domain::{
    Agent, AgentId, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding, RuntimeProvider,
};
use crate::error::{AgentError, AppError};

pub(super) fn stub_error(op: &str) -> AppError {
    AppError::Agent(AgentError::Unavailable {
        message: format!("stubbed method called: {op}"),
    })
}

pub(super) struct StoreStub {
    record: Option<AgentRuntimeRecord>,
    states: Vec<AgentStateBinding>,
}

impl StoreStub {
    pub(super) fn new(record: Option<AgentRuntimeRecord>, states: Vec<AgentStateBinding>) -> Self {
        Self { record, states }
    }
}

impl AgentStorePort for StoreStub {
    fn insert_agent_with_binding(
        &self,
        _agent: &Agent,
        _binding: &AgentRuntimeBinding,
        _state_bindings: &[AgentStateBinding],
    ) -> Result<(), AppError> {
        Err(stub_error("insert_agent_with_binding"))
    }

    fn list_agent_runtime_records(&self) -> Result<Vec<AgentRuntimeRecord>, AppError> {
        Err(stub_error("list_agent_runtime_records"))
    }

    fn find_agent_runtime_record_by_id(
        &self,
        id: AgentId,
    ) -> Result<Option<AgentRuntimeRecord>, AppError> {
        Ok(self
            .record
            .as_ref()
            .filter(|record| record.agent.id().as_str() == id.as_str())
            .cloned())
    }

    fn list_state_bindings_by_agent_id(
        &self,
        id: AgentId,
    ) -> Result<Vec<AgentStateBinding>, AppError> {
        let Some(record) = self.record.as_ref() else {
            return Ok(Vec::new());
        };
        if record.agent.id().as_str() != id.as_str() {
            return Ok(Vec::new());
        }
        Ok(self.states.clone())
    }

    fn list_state_bindings_by_agent_ids(
        &self,
        _ids: &[AgentId],
    ) -> Result<Vec<AgentStateBinding>, AppError> {
        Err(stub_error("list_state_bindings_by_agent_ids"))
    }

    fn upsert_state_binding(&self, _binding: &AgentStateBinding) -> Result<(), AppError> {
        Ok(())
    }

    fn find_agent_by_display_name(&self, _display_name: &str) -> Result<Option<Agent>, AppError> {
        Err(stub_error("find_agent_by_display_name"))
    }

    fn update_agent(&self, _updated: &Agent, _expected_version: i64) -> Result<(), AppError> {
        Err(stub_error("update_agent"))
    }

    fn upsert_binding(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
        Ok(())
    }

    fn update_agent_runtime_context(
        &self,
        _updated: &Agent,
        _expected_version: i64,
        _binding: &AgentRuntimeBinding,
        _upsert_state_bindings: &[AgentStateBinding],
        _delete_state_kinds: &[crate::domain::AgentStateKind],
    ) -> Result<(), AppError> {
        Err(stub_error("update_agent_runtime_context"))
    }

    fn delete_agent(&self, _id: AgentId) -> Result<(), AppError> {
        Err(stub_error("delete_agent"))
    }

    fn next_display_order(&self) -> Result<i64, AppError> {
        Err(stub_error("next_display_order"))
    }

    fn swap_display_order(
        &self,
        _a: &Agent,
        _a_expected_version: i64,
        _b: &Agent,
        _b_expected_version: i64,
    ) -> Result<(), AppError> {
        Err(stub_error("swap_display_order"))
    }
}

pub(super) struct RuntimeStub;

impl AgentRuntimePort for RuntimeStub {
    fn start(
        &self,
        _request: &RuntimeStartRequest,
        _binding: Option<&AgentRuntimeBinding>,
    ) -> Result<AgentRuntimeBinding, AppError> {
        Err(stub_error("start"))
    }

    fn stop(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
        Err(stub_error("stop"))
    }

    fn attach(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
        Err(stub_error("attach"))
    }

    fn detach_client(&self) -> Result<(), AppError> {
        Err(stub_error("detach_client"))
    }

    fn probe(
        &self,
        _bindings: &[AgentRuntimeBinding],
    ) -> Result<Vec<RuntimeProbeResult>, AppError> {
        Err(stub_error("probe"))
    }

    fn capture_output(
        &self,
        _binding: &AgentRuntimeBinding,
        _lines: u16,
    ) -> Result<String, AppError> {
        Ok(String::new())
    }

    fn send_key(&self, _binding: &AgentRuntimeBinding, _key: &str) -> Result<(), AppError> {
        Err(stub_error("send_key"))
    }

    fn rename(
        &self,
        _binding: &AgentRuntimeBinding,
        _new_external_ref: &str,
    ) -> Result<(), AppError> {
        Err(stub_error("rename"))
    }
}

pub(super) struct DispatchStub {
    last_message: Mutex<Option<ConversationMessage>>,
    session_status: Mutex<RuntimeStatus>,
    sessions: Vec<MessageDispatchSessionSummary>,
}

impl DispatchStub {
    pub(super) fn new(
        last_message: Option<ConversationMessage>,
        session_status: RuntimeStatus,
        sessions: Vec<MessageDispatchSessionSummary>,
    ) -> Self {
        Self {
            last_message: Mutex::new(last_message),
            session_status: Mutex::new(session_status),
            sessions,
        }
    }
}

impl MessageDispatchPort for DispatchStub {
    fn create_session(
        &self,
        _request: &MessageDispatchCreateSessionRequest,
    ) -> Result<MessageDispatchCreateSessionResult, AppError> {
        Err(stub_error("create_session"))
    }

    fn list_sessions(
        &self,
        _server_url: &str,
    ) -> Result<Vec<MessageDispatchSessionSummary>, AppError> {
        Ok(self.sessions.clone())
    }

    fn list_child_sessions(
        &self,
        _session: &MessageDispatchSessionRef,
    ) -> Result<Vec<MessageDispatchSessionSummary>, AppError> {
        Ok(Vec::new())
    }

    fn send_message(
        &self,
        _request: &MessageDispatchSendRequest,
    ) -> Result<MessageDispatchResult, AppError> {
        Ok(MessageDispatchResult {
            dispatch_id: "dispatch_1".to_string(),
            accepted_at_unix_ms: 1,
            provider_message_id: Some("msg_user_1".to_string()),
        })
    }

    fn send_slash_command(
        &self,
        _request: &MessageDispatchSlashCommandRequest,
    ) -> Result<MessageDispatchResult, AppError> {
        Ok(MessageDispatchResult {
            dispatch_id: "dispatch_1".to_string(),
            accepted_at_unix_ms: 1,
            provider_message_id: Some("msg_user_1".to_string()),
        })
    }

    fn read_last_message(
        &self,
        _request: &MessageReadRequest,
    ) -> Result<Option<ConversationMessage>, AppError> {
        Ok(self
            .last_message
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .clone())
    }

    fn read_full_conversation(
        &self,
        _request: &MessageReadRequest,
    ) -> Result<ConversationReadResult, AppError> {
        Ok(ConversationReadResult {
            messages: self
                .last_message
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner)
                .clone()
                .into_iter()
                .collect(),
            source: ConversationReadSource::OpencodeSession,
            partial: false,
        })
    }

    fn read_session_status(
        &self,
        _session: &MessageDispatchSessionRef,
    ) -> Result<RuntimeStatus, AppError> {
        Ok(*self
            .session_status
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner))
    }
}

pub(super) struct CodexThreadStub;

impl CodexThreadPort for CodexThreadStub {
    fn start_thread(
        &self,
        _request: &CodexThreadStartRequest,
    ) -> Result<CodexThreadBootstrap, AppError> {
        Err(stub_error("start_thread"))
    }

    fn read_thread_statuses(
        &self,
        _thread_ids: &[String],
    ) -> Result<std::collections::HashMap<String, RuntimeStatus>, AppError> {
        Err(stub_error("read_thread_statuses"))
    }

    fn read_thread_conversation(
        &self,
        _thread_id: &str,
        _limit: Option<usize>,
    ) -> Result<ConversationReadResult, AppError> {
        Ok(ConversationReadResult {
            messages: Vec::new(),
            source: ConversationReadSource::CodexRollout,
            partial: false,
        })
    }
}

pub(super) fn service_with_agent(
    agent: &Agent,
    states: Vec<AgentStateBinding>,
    last_message: Option<ConversationMessage>,
    session_status: RuntimeStatus,
) -> AgentConversationService {
    let session = MessageDispatchSessionSummary {
        session: MessageDispatchSessionRef {
            provider: MessageDispatchProvider::Opencode,
            server_url: "http://127.0.0.1:4096".to_string(),
            session_id: "session_1".to_string(),
            directory: Some("/tmp".to_string()),
        },
        title: None,
        slug: None,
        parent_session_id: None,
        updated_at_unix_ms: None,
    };
    AgentConversationService::new(
        Arc::new(StoreStub::new(
            Some(AgentRuntimeRecord {
                agent: agent.clone(),
                binding: Some(AgentRuntimeBinding::new(
                    agent.id(),
                    RuntimeProvider::Tmux,
                    agent.display_name().to_string(),
                    1,
                )),
            }),
            states,
        )),
        Arc::new(RuntimeStub),
        Arc::new(CodexThreadStub),
        Arc::new(DispatchStub::new(
            last_message,
            session_status,
            vec![session],
        )),
        25,
    )
}
