use std::thread;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

use crate::application::{
    MessageDispatchResult, MessageDispatchSendRequest, MessageDispatchSessionRef,
    MessageDispatchSlashCommandRequest, parse_slash_command,
};
use crate::domain::{Agent, AgentId, AgentKind};
use crate::error::{AgentError, AppError};

use super::resolution::ResolvedConversationTarget;
use super::service::AgentConversationService;
use crate::application::ConversationReadResult;

const FRESH_OPENCODE_SEND_WINDOW_MS: u128 = 5_000;
const DELIVERY_POLL_ATTEMPTS: usize = 20;
const DELIVERY_POLL_INTERVAL: Duration = Duration::from_millis(100);
const DELIVERY_RETRY_DELAY: Duration = Duration::from_millis(250);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum AgentInteractionKind {
    Message,
    SlashCommand,
}

impl AgentConversationService {
    pub(super) fn submit_interaction(
        &self,
        id: &AgentId,
        kind: AgentInteractionKind,
        payload: &str,
    ) -> Result<MessageDispatchResult, AppError> {
        let target = self.resolve_conversation_target(id)?;
        if target.record.agent.kind() != AgentKind::Opencode
            || !is_fresh_opencode_agent(&target.record.agent)
        {
            return self.dispatch_interaction(&target.session, kind, payload);
        }

        self.send_with_fresh_opencode_retry(&target, kind, payload, || {
            AppError::Agent(AgentError::Unavailable {
                message: format!(
                    "fresh opencode agent '{}' did not persist the initial {} dispatch; retry the send",
                    target.record.agent.display_name(),
                    interaction_label(kind),
                ),
            })
        })
    }

    fn send_with_fresh_opencode_retry<ErrorFn>(
        &self,
        target: &ResolvedConversationTarget,
        kind: AgentInteractionKind,
        payload: &str,
        unavailable_error: ErrorFn,
    ) -> Result<MessageDispatchResult, AppError>
    where
        ErrorFn: Fn() -> AppError,
    {
        let baseline = self
            .read_full_conversation_from_session(&target.session)
            .ok();
        let first = self.dispatch_interaction(&target.session, kind, payload)?;
        if self.wait_for_delivery(&target.session, kind, baseline.as_ref(), payload) {
            return Ok(first);
        }

        thread::sleep(DELIVERY_RETRY_DELAY);
        let retry_baseline = self
            .read_full_conversation_from_session(&target.session)
            .ok();
        let second = self.dispatch_interaction(&target.session, kind, payload)?;
        if self.wait_for_delivery(&target.session, kind, retry_baseline.as_ref(), payload) {
            return Ok(second);
        }

        Err(unavailable_error())
    }

    fn dispatch_interaction(
        &self,
        session: &MessageDispatchSessionRef,
        kind: AgentInteractionKind,
        payload: &str,
    ) -> Result<MessageDispatchResult, AppError> {
        match kind {
            AgentInteractionKind::Message => {
                let request = MessageDispatchSendRequest {
                    session: session.clone(),
                    message: payload.to_string(),
                };
                self.dispatch.send_message(&request)
            }
            AgentInteractionKind::SlashCommand => {
                let parsed = parse_slash_command(payload)?;
                let request = MessageDispatchSlashCommandRequest {
                    session: session.clone(),
                    command: parsed.command,
                    arguments: parsed.arguments,
                };
                self.dispatch.send_slash_command(&request)
            }
        }
    }

    fn wait_for_delivery(
        &self,
        session: &MessageDispatchSessionRef,
        kind: AgentInteractionKind,
        baseline: Option<&ConversationReadResult>,
        payload: &str,
    ) -> bool {
        for _ in 0..DELIVERY_POLL_ATTEMPTS {
            if let Ok(conversation) = self.read_full_conversation_from_session(session)
                && conversation_has_new_user_message(&conversation, baseline, kind, payload)
            {
                return true;
            }
            thread::sleep(DELIVERY_POLL_INTERVAL);
        }
        false
    }
}

fn conversation_has_new_user_message(
    conversation: &ConversationReadResult,
    baseline: Option<&ConversationReadResult>,
    kind: AgentInteractionKind,
    payload: &str,
) -> bool {
    match kind {
        AgentInteractionKind::Message => {
            let expected = normalize_message(payload);
            conversation
                .messages
                .iter()
                .skip(baseline_message_len(baseline))
                .any(|entry| entry.role == "user" && normalize_message(&entry.text) == expected)
        }
        AgentInteractionKind::SlashCommand => conversation
            .messages
            .iter()
            .skip(baseline_message_len(baseline))
            .any(|entry| entry.role == "user"),
    }
}

fn baseline_message_len(baseline: Option<&ConversationReadResult>) -> usize {
    baseline.map_or(0, |existing| existing.messages.len())
}

fn normalize_message(value: &str) -> String {
    value.split_whitespace().collect::<Vec<_>>().join(" ")
}

fn interaction_label(kind: AgentInteractionKind) -> &'static str {
    match kind {
        AgentInteractionKind::Message => "message",
        AgentInteractionKind::SlashCommand => "slash-command",
    }
}

fn is_fresh_opencode_agent(agent: &Agent) -> bool {
    now_unix_ms().saturating_sub(agent.created_at_unix_ms()) <= FRESH_OPENCODE_SEND_WINDOW_MS
}

fn now_unix_ms() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_millis())
}
