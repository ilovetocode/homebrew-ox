use std::sync::Arc;

use crate::application::ports::{
    AgentConversationPort, AgentRuntimePort, AgentStorePort, CodexThreadPort, MessageDispatchPort,
};
use crate::application::{ConversationReadResult, MessageDispatchResult};
use crate::domain::{AgentId, AgentKind};
use crate::error::{AgentError, AppError};

use super::dispatch::AgentInteractionKind;
use crate::application::codex_thread_state::find_codex_thread_id;

/// Shared provider-backed conversation execution for direct agent messaging.
pub(crate) struct AgentConversationService {
    pub(super) store: Arc<dyn AgentStorePort>,
    pub(super) runtime: Arc<dyn AgentRuntimePort>,
    pub(super) codex_threads: Arc<dyn CodexThreadPort>,
    pub(super) dispatch: Arc<dyn MessageDispatchPort>,
    pub(super) conversation_page_size: usize,
}

impl AgentConversationService {
    /// Build the shared conversation service from application ports.
    pub(crate) fn new(
        store: Arc<dyn AgentStorePort>,
        runtime: Arc<dyn AgentRuntimePort>,
        codex_threads: Arc<dyn CodexThreadPort>,
        dispatch: Arc<dyn MessageDispatchPort>,
        conversation_page_size: usize,
    ) -> Self {
        Self {
            store,
            runtime,
            codex_threads,
            dispatch,
            conversation_page_size,
        }
    }

    fn read_last_message_for_agent(
        &self,
        id: &AgentId,
    ) -> Result<ConversationReadResult, AppError> {
        let full = self.read_full_conversation_for_agent(id)?;
        Ok(ConversationReadResult {
            messages: full.messages.last().cloned().into_iter().collect(),
            source: full.source,
            partial: full.partial,
        })
    }

    fn read_full_conversation_for_agent(
        &self,
        id: &AgentId,
    ) -> Result<ConversationReadResult, AppError> {
        let record = self.find_agent_record(id)?;
        match record.agent.kind() {
            AgentKind::Opencode => {
                let target = self.resolve_conversation_target(id)?;
                self.read_full_conversation_from_session(&target.session)
            }
            AgentKind::Codex => {
                let states = self.store.list_state_bindings_by_agent_id(id.clone())?;
                let Some(thread_id) = find_codex_thread_id(&states) else {
                    return Err(AppError::Agent(AgentError::Unavailable {
                        message: format!(
                            "agent '{}' has no managed codex thread binding",
                            record.agent.display_name()
                        ),
                    }));
                };
                self.codex_threads
                    .read_thread_conversation(&thread_id, Some(self.conversation_page_size))
            }
            other_kind => Err(AppError::Agent(AgentError::Unavailable {
                message: format!(
                    "agent '{}' does not support transcript reads yet (kind: {})",
                    record.agent.display_name(),
                    other_kind.as_str()
                ),
            })),
        }
    }
}

impl AgentConversationPort for AgentConversationService {
    fn send_message_to_agent(
        &self,
        id: &AgentId,
        message: &str,
    ) -> Result<MessageDispatchResult, AppError> {
        self.submit_interaction(id, AgentInteractionKind::Message, message)
    }

    fn send_slash_command_to_agent(
        &self,
        id: &AgentId,
        command: &str,
    ) -> Result<MessageDispatchResult, AppError> {
        self.submit_interaction(id, AgentInteractionKind::SlashCommand, command)
    }

    fn read_last_message_from_agent(
        &self,
        id: &AgentId,
    ) -> Result<ConversationReadResult, AppError> {
        self.read_last_message_for_agent(id)
    }

    fn read_full_conversation_from_agent(
        &self,
        id: &AgentId,
    ) -> Result<ConversationReadResult, AppError> {
        self.read_full_conversation_for_agent(id)
    }
}
