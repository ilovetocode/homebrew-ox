use crate::application::{ConversationReadResult, MessageDispatchSessionRef, MessageReadRequest};

use super::service::AgentConversationService;
use crate::error::AppError;

impl AgentConversationService {
    pub(super) fn read_full_conversation_from_session(
        &self,
        session: &MessageDispatchSessionRef,
    ) -> Result<ConversationReadResult, AppError> {
        self.dispatch
            .read_full_conversation(&self.build_message_read_request(session.clone()))
    }

    fn build_message_read_request(&self, session: MessageDispatchSessionRef) -> MessageReadRequest {
        MessageReadRequest {
            session,
            limit: Some(self.conversation_page_size),
        }
    }
}
