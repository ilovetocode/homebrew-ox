use crate::application::MessageDispatchSessionRef;
use crate::application::opencode_session_tracker::OpencodeSessionTracker;
use crate::application::runtime_binding_manager::{
    RuntimeBindingManager, should_retry_with_fresh_tmux_session,
};
use crate::domain::{AgentId, AgentRuntimeBinding, AgentRuntimeRecord};
use crate::error::{AgentError, AppError};

use super::service::AgentConversationService;

pub(super) struct ResolvedConversationTarget {
    pub(super) record: AgentRuntimeRecord,
    pub(super) session: MessageDispatchSessionRef,
}

impl AgentConversationService {
    pub(super) fn find_agent_record(&self, id: &AgentId) -> Result<AgentRuntimeRecord, AppError> {
        self.store
            .find_agent_runtime_record_by_id(id.clone())?
            .ok_or(AppError::Agent(AgentError::NotFound))
    }

    pub(super) fn resolve_conversation_target(
        &self,
        agent_id: &AgentId,
    ) -> Result<ResolvedConversationTarget, AppError> {
        let record = self.find_agent_record(agent_id)?;
        let states = self
            .store
            .list_state_bindings_by_agent_id(agent_id.clone())?;
        let tracker = OpencodeSessionTracker::new(self.store.as_ref(), self.dispatch.as_ref());
        let session = tracker
            .resolve_bound_session(&states, record.binding.as_ref(), |binding, lines| {
                self.capture_output_with_retry(&record, binding, lines)
            })
            .map_err(|err| match err {
                AppError::Agent(AgentError::Unavailable { .. }) => {
                    AppError::Agent(AgentError::Unavailable {
                        message: format!(
                            "agent '{}' has no recoverable opencode session binding",
                            record.agent.display_name()
                        ),
                    })
                }
                _ => err,
            })?;
        Ok(ResolvedConversationTarget { record, session })
    }

    pub(super) fn capture_output_with_retry(
        &self,
        record: &AgentRuntimeRecord,
        binding: &AgentRuntimeBinding,
        lines: u16,
    ) -> Result<String, AppError> {
        match self.runtime.capture_output(binding, lines) {
            Ok(output) => Ok(output),
            Err(err) if should_retry_with_fresh_tmux_session(binding, &err) => {
                let ensured_binding =
                    RuntimeBindingManager::new(self.store.as_ref(), self.runtime.as_ref())
                        .ensure_binding(record)?;
                self.runtime.capture_output(&ensured_binding, lines)
            }
            Err(err) => Err(err),
        }
    }
}
