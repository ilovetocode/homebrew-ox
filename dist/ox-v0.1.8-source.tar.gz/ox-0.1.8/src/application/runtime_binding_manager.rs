use crate::application::ports::{AgentRuntimePort, AgentStorePort};
use crate::application::runtime_start_request_builder::build_runtime_start_request;
use crate::domain::{AgentRuntimeBinding, AgentRuntimeRecord, RuntimeProvider};
use crate::error::{AppError, app_error_is_recoverable_missing_tmux_runtime};

/// Shared runtime-healing helper for flows that may need to recreate a tmux-backed
/// agent session from persisted state.
pub(super) struct RuntimeBindingManager<'a> {
    store: &'a dyn AgentStorePort,
    runtime: &'a dyn AgentRuntimePort,
}

impl<'a> RuntimeBindingManager<'a> {
    /// Build the helper from the narrow store/runtime ports used by callers.
    pub(super) fn new(store: &'a dyn AgentStorePort, runtime: &'a dyn AgentRuntimePort) -> Self {
        Self { store, runtime }
    }

    /// Rebuild the canonical runtime start request from persisted state, then
    /// persist the freshly ensured binding so later calls can reuse it.
    pub(super) fn ensure_binding(
        &self,
        record: &AgentRuntimeRecord,
    ) -> Result<AgentRuntimeBinding, AppError> {
        let states = self
            .store
            .list_state_bindings_by_agent_id(record.agent.id())?;
        let start_request = build_runtime_start_request(record, &states);
        let ensured_binding = self
            .runtime
            .start(&start_request, record.binding.as_ref())?;
        self.store.upsert_binding(&ensured_binding)?;
        Ok(ensured_binding)
    }
}

/// Return whether a runtime action should retry by recreating the tmux session.
pub(super) fn should_retry_with_fresh_tmux_session(
    binding: &AgentRuntimeBinding,
    err: &AppError,
) -> bool {
    binding.provider == RuntimeProvider::Tmux && is_retryable_missing_tmux(err)
}

/// Treat the common tmux "session disappeared" failures as recoverable.
pub(super) fn is_retryable_missing_tmux(err: &AppError) -> bool {
    app_error_is_recoverable_missing_tmux_runtime(err)
}

#[cfg(test)]
mod tests {
    use super::{is_retryable_missing_tmux, should_retry_with_fresh_tmux_session};
    use crate::domain::{AgentId, AgentRuntimeBinding, RuntimeProvider};
    use crate::error::{AgentError, AppError, TmuxError};

    fn tmux_binding() -> AgentRuntimeBinding {
        AgentRuntimeBinding::new(AgentId::new(), RuntimeProvider::Tmux, "dev".to_string(), 1)
    }

    #[test]
    fn retryable_missing_tmux_detects_known_session_errors() {
        for stderr in [
            "can't find session: planner",
            "can't find pane: n5",
            "no server running on /tmp/tmux-1000/default",
            "failed to connect to server",
        ] {
            let err = AppError::Tmux(TmuxError::CommandFailed {
                stderr: stderr.to_string(),
            });
            assert!(
                is_retryable_missing_tmux(&err),
                "stderr should retry: {stderr}"
            );
        }
    }

    #[test]
    fn retryable_missing_tmux_rejects_other_errors() {
        let err = AppError::Tmux(TmuxError::CommandFailed {
            stderr: "permission denied".to_string(),
        });
        assert!(!is_retryable_missing_tmux(&err));
    }

    #[test]
    fn retry_predicate_rejects_non_tmux_errors() {
        let err = AppError::Agent(AgentError::Unavailable {
            message: "attach failed".to_string(),
        });
        assert!(!should_retry_with_fresh_tmux_session(&tmux_binding(), &err));
    }
}
