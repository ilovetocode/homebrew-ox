use crate::application::agents::swap_display_order;
use crate::application::clock::unix_time_ms;
use crate::application::ports::{
    AgentRuntimePort, AgentStorePort, CodexThreadPort, OpencodeSessionBootstrapPort, WorktreePort,
};
use crate::application::runtime_binding_manager::RuntimeBindingManager;
use crate::application::{AgentProvisioningService, CreateAgentRequest, PinnedSessionSpec};
use crate::error::{AgentError, AppError};

/// Reconciles declarative pinned-session policy against persisted/runtime state.
pub(crate) struct PinnedSessionReconciler<'a> {
    store: &'a dyn AgentStorePort,
    runtime: &'a dyn AgentRuntimePort,
    worktree: &'a dyn WorktreePort,
    codex_threads: &'a dyn CodexThreadPort,
    opencode_session_bootstrap: &'a dyn OpencodeSessionBootstrapPort,
    pinned_sessions: &'a [PinnedSessionSpec],
}

impl<'a> PinnedSessionReconciler<'a> {
    pub(super) fn new(
        store: &'a dyn AgentStorePort,
        runtime: &'a dyn AgentRuntimePort,
        worktree: &'a dyn WorktreePort,
        codex_threads: &'a dyn CodexThreadPort,
        opencode_session_bootstrap: &'a dyn OpencodeSessionBootstrapPort,
        pinned_sessions: &'a [PinnedSessionSpec],
    ) -> Self {
        Self {
            store,
            runtime,
            worktree,
            codex_threads,
            opencode_session_bootstrap,
            pinned_sessions,
        }
    }

    pub(super) fn reconcile(&self) -> Result<(), AppError> {
        if self.pinned_sessions.is_empty() {
            return Ok(());
        }

        for pinned in self.pinned_sessions {
            if self
                .store
                .find_agent_by_display_name(&pinned.name)?
                .is_none()
            {
                // Pinned reconciliation runs during normal commands and
                // background daemon startup, so missing `working_dir` must not
                // inherit an arbitrary process cwd when we recreate a session.
                let request = CreateAgentRequest::new(pinned.name.clone(), pinned.agent_kind)
                    .with_working_dir(resolve_pinned_create_working_dir(pinned));
                match self.provisioning().provision(request) {
                    Ok(_) | Err(AppError::Agent(AgentError::DisplayNameTaken)) => {}
                    Err(err) => return Err(err),
                }
            }
        }

        for pinned in self.pinned_sessions {
            self.ensure_runtime_binding_for_pinned(pinned)?;
        }

        self.reconcile_display_order()
    }

    fn provisioning(&self) -> AgentProvisioningService<'_> {
        AgentProvisioningService::new(
            self.store,
            self.runtime,
            self.worktree,
            self.codex_threads,
            self.opencode_session_bootstrap,
        )
    }

    fn ensure_runtime_binding_for_pinned(
        &self,
        pinned: &PinnedSessionSpec,
    ) -> Result<(), AppError> {
        let Some(agent) = self.store.find_agent_by_display_name(&pinned.name)? else {
            return Ok(());
        };
        let Some(record) = self.store.find_agent_runtime_record_by_id(agent.id())? else {
            return Ok(());
        };

        if let Some(binding) = record.binding.as_ref()
            && self.runtime.capture_output(binding, 1).is_ok()
        {
            return Ok(());
        }

        RuntimeBindingManager::new(self.store, self.runtime)
            .ensure_binding(&record)
            .map(|_| ())
    }

    fn reconcile_display_order(&self) -> Result<(), AppError> {
        let mut records = self.store.list_agent_runtime_records()?;
        if records.is_empty() {
            return Ok(());
        }

        for (desired_index, pinned) in self.pinned_sessions.iter().enumerate() {
            if desired_index >= records.len() {
                break;
            }
            let Some(current_index) = records
                .iter()
                .position(|record| record.agent.display_name() == pinned.name)
            else {
                continue;
            };
            if current_index == desired_index {
                continue;
            }

            let source = &records[current_index].agent;
            let target = &records[desired_index].agent;
            swap_display_order(self.store, source, target, unix_time_ms())?;

            // Reload after each swap because versions changed.
            records = self.store.list_agent_runtime_records()?;
        }

        Ok(())
    }
}

fn resolve_pinned_create_working_dir(pinned: &PinnedSessionSpec) -> Option<String> {
    select_pinned_create_working_dir(
        pinned.working_dir.clone(),
        resolve_home_dir(),
        resolve_current_dir(),
    )
}

fn select_pinned_create_working_dir(
    configured: Option<String>,
    home_dir: Option<String>,
    current_dir: Option<String>,
) -> Option<String> {
    configured.or(home_dir).or(current_dir)
}

fn resolve_home_dir() -> Option<String> {
    let path = std::env::var_os("HOME")?;
    canonicalize_existing_path(path.to_string_lossy().to_string())
}

fn resolve_current_dir() -> Option<String> {
    let path = std::env::current_dir().ok()?;
    canonicalize_existing_path(path.to_string_lossy().to_string())
}

fn canonicalize_existing_path(path: String) -> Option<String> {
    std::fs::canonicalize(path)
        .ok()
        .map(|resolved| resolved.to_string_lossy().to_string())
}

#[cfg(test)]
mod tests {
    use super::select_pinned_create_working_dir;

    #[test]
    fn pinned_create_working_dir_prefers_explicit_config() {
        let resolved = select_pinned_create_working_dir(
            Some("/repo/worktree".to_string()),
            Some("/home/testing".to_string()),
            Some("/tmp/cwd".to_string()),
        );

        assert_eq!(resolved.as_deref(), Some("/repo/worktree"));
    }

    #[test]
    fn pinned_create_working_dir_prefers_home_over_process_cwd() {
        let resolved = select_pinned_create_working_dir(
            None,
            Some("/home/testing".to_string()),
            Some("/tmp/cwd".to_string()),
        );

        assert_eq!(resolved.as_deref(), Some("/home/testing"));
    }
}
