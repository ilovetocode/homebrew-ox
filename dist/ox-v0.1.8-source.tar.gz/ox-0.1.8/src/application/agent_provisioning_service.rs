use crate::application::CreateAgentRequest;
use crate::application::ports::{
    AgentRuntimePort, AgentStorePort, CodexThreadPort, OpencodeSessionBootstrapPort, WorktreePort,
};
use crate::application::provisioning::ProvisioningPorts;
use crate::application::provisioning::cleanup::ProvisioningCleanupTxn;
use crate::application::provisioning::materialize::{materialize_provision, persist_provision};
use crate::application::provisioning::naming::next_available_generated_name;
use crate::application::provisioning::planning::{
    ProvisionInput, plan_provision, resolve_create_display_name,
    should_retry_generated_name_conflict,
};
use crate::domain::{AgentId, AgentKind};
use crate::error::AppError;

/// Layer order contract: `AppApi` -> `AppService` -> `AgentLifecycleService` ->
/// `AgentInteractionService`. This component owns create-time provisioning only
/// and keeps lifecycle side effects out of interface and infrastructure layers.
pub(crate) struct AgentProvisioningService<'a> {
    store: &'a dyn AgentStorePort,
    runtime: &'a dyn AgentRuntimePort,
    worktree: &'a dyn WorktreePort,
    codex_threads: &'a dyn CodexThreadPort,
    opencode_session_bootstrap: &'a dyn OpencodeSessionBootstrapPort,
}

impl<'a> AgentProvisioningService<'a> {
    /// Build one create/provision helper from application ports.
    pub(crate) fn new(
        store: &'a dyn AgentStorePort,
        runtime: &'a dyn AgentRuntimePort,
        worktree: &'a dyn WorktreePort,
        codex_threads: &'a dyn CodexThreadPort,
        opencode_session_bootstrap: &'a dyn OpencodeSessionBootstrapPort,
    ) -> Self {
        Self {
            store,
            runtime,
            worktree,
            codex_threads,
            opencode_session_bootstrap,
        }
    }

    /// Create one agent and eagerly provision configured external states.
    pub(crate) fn provision(&self, request: CreateAgentRequest) -> Result<AgentId, AppError> {
        let ports = self.ports();
        let input = ProvisionInput::from_request(request);
        let mut candidate_name =
            resolve_create_display_name(&input.requested_name, input.agent_kind, |kind| {
                self.next_available_generated_name(kind)
            })?;

        loop {
            match self.provision_once(&ports, &input, &candidate_name) {
                Ok(agent_id) => return Ok(agent_id),
                Err(err) if should_retry_generated_name_conflict(&err, input.generated_name) => {
                    candidate_name = self.next_available_generated_name(input.agent_kind)?;
                }
                Err(err) => return Err(err),
            }
        }
    }

    fn provision_once(
        &self,
        ports: &ProvisioningPorts<'_>,
        input: &ProvisionInput,
        candidate_name: &str,
    ) -> Result<AgentId, AppError> {
        let plan = plan_provision(ports, input, candidate_name)?;
        let mut cleanup = ProvisioningCleanupTxn::begin(self.runtime, self.worktree);
        let artifacts = materialize_provision(ports, &plan, &mut cleanup)?;
        persist_provision(ports, &artifacts)?;
        cleanup.commit();
        Ok(artifacts.agent.id())
    }

    fn next_available_generated_name(&self, agent_kind: AgentKind) -> Result<String, AppError> {
        next_available_generated_name(self.store, agent_kind)
    }

    fn ports(&self) -> ProvisioningPorts<'_> {
        ProvisioningPorts::new(
            self.store,
            self.runtime,
            self.worktree,
            self.codex_threads,
            self.opencode_session_bootstrap,
        )
    }
}

#[cfg(test)]
mod tests {
    use std::error::Error;
    use std::fs;
    use std::sync::Mutex;
    use std::sync::atomic::AtomicUsize;
    use std::sync::atomic::Ordering;

    use super::AgentProvisioningService;
    use crate::application::provisioning::planning::resolve_git_worktree_spec;
    use crate::application::provisioning::test_support::{
        FakeCodexThreads, FakeOpencodeSessionBootstrap, FakeRuntime, FakeStore, FakeWorktree,
    };
    use crate::application::provisioning::util::{
        derive_git_root_path, generate_worktree_label_token,
    };
    use crate::application::{CreateAgentRequest, GitWorktreeCreateSpec};
    use crate::domain::{
        AgentId, AgentKind, AgentNamePolicy, AgentStateBinding, AgentStateKind, AgentStateProvider,
        PRIMARY_STATE_BINDING_KEY,
    };
    use crate::error::{AgentError, AppError};

    type TestResult = Result<(), Box<dyn Error>>;

    #[test]
    fn resolve_git_worktree_spec_defaults_to_uuid_like_label() {
        let parsed = resolve_git_worktree_spec(&GitWorktreeCreateSpec::simple(None));
        assert!(parsed.is_ok(), "default worktree spec should resolve");
        let Ok(resolved) = parsed else {
            return;
        };
        assert_eq!(resolved.base_ref, "HEAD");
        assert_eq!(
            resolved.worktree_label.matches('-').count(),
            4,
            "default label should use UUID-like segments"
        );
    }

    #[test]
    fn resolve_git_worktree_spec_rejects_mismatched_names() {
        let parsed = resolve_git_worktree_spec(&GitWorktreeCreateSpec {
            worktree_name: Some("a".to_string()),
            branch_name: Some("b".to_string()),
            base_ref: None,
            repo_root: None,
        });
        assert!(
            matches!(parsed, Err(AppError::InvalidInput { .. })),
            "mismatched worktree+branch names should fail"
        );
    }

    #[test]
    fn resolve_git_worktree_spec_uses_non_empty_base_ref() {
        let parsed = resolve_git_worktree_spec(&GitWorktreeCreateSpec {
            worktree_name: Some("dev".to_string()),
            branch_name: Some("dev".to_string()),
            base_ref: Some("main".to_string()),
            repo_root: None,
        });
        assert!(parsed.is_ok(), "matching worktree+branch should resolve");
        let Ok(resolved) = parsed else {
            return;
        };

        assert_eq!(resolved.worktree_label, "dev");
        assert_eq!(resolved.base_ref, "main");
    }

    #[test]
    fn generated_worktree_label_is_non_empty() {
        assert!(!generate_worktree_label_token().is_empty());
    }

    #[test]
    fn generated_name_prefix_matches_agent_kind() {
        assert_eq!(AgentNamePolicy::generated_prefix(AgentKind::Shell), "shell");
        assert_eq!(AgentNamePolicy::generated_prefix(AgentKind::Codex), "codex");
        assert_eq!(
            AgentNamePolicy::generated_prefix(AgentKind::Opencode),
            "opencode"
        );
        assert_eq!(
            AgentNamePolicy::generated_prefix(AgentKind::Claude),
            "claude"
        );
    }

    #[test]
    fn derive_git_root_path_derives_from_working_dir() -> TestResult {
        let temp =
            std::env::temp_dir().join(format!("ox-agent-service-test-{}", std::process::id()));
        let repo_root = temp.join("repo");
        let working_dir = repo_root.join("nested");
        fs::create_dir_all(&working_dir)?;
        let working_dir = fs::canonicalize(&working_dir)?;
        let repo_root = fs::canonicalize(&repo_root)?;

        let worktree = FakeWorktree {
            create_state: None,
            delete_calls: AtomicUsize::new(0),
            derived_root: Some(repo_root.to_string_lossy().to_string()),
            seen_paths: Mutex::new(Vec::new()),
        };
        let resolved = derive_git_root_path(&worktree, working_dir.to_string_lossy().as_ref())?;
        assert_eq!(
            resolved.as_deref(),
            Some(repo_root.to_string_lossy().as_ref())
        );
        assert_eq!(
            worktree
                .seen_paths
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner)
                .len(),
            1
        );
        Ok(())
    }

    #[test]
    fn derive_git_root_path_returns_none_when_root_unknown() -> TestResult {
        let temp =
            std::env::temp_dir().join(format!("ox-agent-service-test-none-{}", std::process::id()));
        let repo_root = temp.join("repo");
        let working_dir = repo_root.join("nested");
        fs::create_dir_all(&working_dir)?;
        let working_dir = fs::canonicalize(&working_dir)?;

        let worktree = FakeWorktree::default();
        let resolved = derive_git_root_path(&worktree, working_dir.to_string_lossy().as_ref())?;
        assert!(
            resolved.is_none(),
            "missing git root should resolve to None"
        );
        Ok(())
    }

    #[test]
    fn provision_runtime_start_failure_rolls_back_worktree_state() -> TestResult {
        let temp = std::env::temp_dir().join(format!(
            "ox-agent-provision-runtime-fail-{}",
            std::process::id()
        ));
        let repo_root = temp.join("repo");
        let worktree_dir = temp.join("repo-worktrees").join("shell-1");
        fs::create_dir_all(&repo_root)?;
        fs::create_dir_all(&worktree_dir)?;
        let repo_root = fs::canonicalize(repo_root)?;
        let worktree_dir = fs::canonicalize(worktree_dir)?;

        let worktree_state = AgentStateBinding::new(
            AgentId::new(),
            AgentStateKind::GitWorktree,
            AgentStateProvider::Git,
            PRIMARY_STATE_BINDING_KEY.to_string(),
            worktree_dir.to_string_lossy().to_string(),
            "{}".to_string(),
            1,
        );
        let worktree = FakeWorktree {
            create_state: Some(worktree_state),
            delete_calls: AtomicUsize::new(0),
            derived_root: Some(repo_root.to_string_lossy().to_string()),
            seen_paths: Mutex::new(Vec::new()),
        };
        let runtime = FakeRuntime::new(true);
        let store = FakeStore::new(false);
        let codex_threads = FakeCodexThreads;

        let request = CreateAgentRequest::new("dev".to_string(), AgentKind::Shell)
            .with_working_dir(Some(repo_root.to_string_lossy().to_string()))
            .with_git_worktree(GitWorktreeCreateSpec::simple(Some("dev".to_string())));
        let opencode_bootstrap = FakeOpencodeSessionBootstrap::new(false);
        let service = AgentProvisioningService::new(
            &store,
            &runtime,
            &worktree,
            &codex_threads,
            &opencode_bootstrap,
        );
        let result = service.provision(request);

        assert!(
            matches!(result, Err(AppError::Agent(AgentError::Unavailable { .. }))),
            "runtime start error should be returned"
        );
        assert_eq!(runtime.stop_calls.load(Ordering::Relaxed), 0);
        assert_eq!(worktree.delete_calls.load(Ordering::Relaxed), 1);
        Ok(())
    }

    #[test]
    fn provision_store_conflict_rolls_back_and_retries_generated_name() -> TestResult {
        let temp = std::env::temp_dir().join(format!(
            "ox-agent-provision-store-conflict-{}",
            std::process::id()
        ));
        let repo_root = temp.join("repo");
        let worktree_dir = temp.join("repo-worktrees").join("shell-1");
        fs::create_dir_all(&repo_root)?;
        fs::create_dir_all(&worktree_dir)?;
        let repo_root = fs::canonicalize(repo_root)?;
        let worktree_dir = fs::canonicalize(worktree_dir)?;

        let worktree_state = AgentStateBinding::new(
            AgentId::new(),
            AgentStateKind::GitWorktree,
            AgentStateProvider::Git,
            PRIMARY_STATE_BINDING_KEY.to_string(),
            worktree_dir.to_string_lossy().to_string(),
            "{}".to_string(),
            1,
        );
        let worktree = FakeWorktree {
            create_state: Some(worktree_state),
            delete_calls: AtomicUsize::new(0),
            derived_root: Some(repo_root.to_string_lossy().to_string()),
            seen_paths: Mutex::new(Vec::new()),
        };
        let runtime = FakeRuntime::new(false);
        let store = FakeStore::new(true);
        let codex_threads = FakeCodexThreads;

        let request = CreateAgentRequest::new(String::new(), AgentKind::Shell)
            .with_working_dir(Some(repo_root.to_string_lossy().to_string()))
            .with_git_worktree(GitWorktreeCreateSpec::simple(Some("dev".to_string())));
        let opencode_bootstrap = FakeOpencodeSessionBootstrap::new(false);
        let service = AgentProvisioningService::new(
            &store,
            &runtime,
            &worktree,
            &codex_threads,
            &opencode_bootstrap,
        );
        let result = service.provision(request);

        assert!(
            result.is_ok(),
            "generated-name retry should eventually succeed"
        );
        assert_eq!(runtime.start_calls.load(Ordering::Relaxed), 2);
        assert_eq!(runtime.stop_calls.load(Ordering::Relaxed), 1);
        assert_eq!(worktree.delete_calls.load(Ordering::Relaxed), 1);
        Ok(())
    }

    #[test]
    fn provision_opencode_uses_bootstrap_session() -> TestResult {
        let temp = std::env::temp_dir().join(format!(
            "ox-agent-provision-opencode-mismatch-{}",
            std::process::id()
        ));
        fs::create_dir_all(&temp)?;
        let working_dir = fs::canonicalize(&temp)?;

        let worktree = FakeWorktree::default();
        let runtime = FakeRuntime::new(false);
        let store = FakeStore::new(false);
        let codex_threads = FakeCodexThreads;
        let opencode_bootstrap = FakeOpencodeSessionBootstrap::new(false);

        let request = CreateAgentRequest::new("opencode-dev".to_string(), AgentKind::Opencode)
            .with_working_dir(Some(working_dir.to_string_lossy().to_string()));
        let service = AgentProvisioningService::new(
            &store,
            &runtime,
            &worktree,
            &codex_threads,
            &opencode_bootstrap,
        );

        let result = service.provision(request);
        assert!(result.is_ok(), "opencode provision should succeed");
        assert_eq!(opencode_bootstrap.ensure_calls.load(Ordering::Relaxed), 1);
        Ok(())
    }

    #[test]
    fn generated_name_uses_first_available_gap() -> TestResult {
        let worktree = FakeWorktree::default();
        let runtime = FakeRuntime::new(false);
        let store = FakeStore::with_known_names(&["shell-1", "shell-2", "shell-4"]);
        let codex_threads = FakeCodexThreads;
        let opencode_bootstrap = FakeOpencodeSessionBootstrap::new(false);
        let service = AgentProvisioningService::new(
            &store,
            &runtime,
            &worktree,
            &codex_threads,
            &opencode_bootstrap,
        );

        let next = service.next_available_generated_name(AgentKind::Shell)?;
        assert_eq!(next, "shell-3");
        Ok(())
    }
}
