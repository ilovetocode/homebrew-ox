use std::collections::HashSet;
use std::time::{SystemTime, UNIX_EPOCH};

use crate::application::directory_matching::directory_matches;
use crate::application::opencode_session_state::{
    find_opencode_session_state, rebind_opencode_session_state_binding,
};
use crate::application::ports::{AgentStorePort, MessageDispatchPort};
use crate::application::{
    MessageDispatchProvider, MessageDispatchSessionRef, MessageDispatchSessionSummary,
    MessageReadRequest,
};
use crate::domain::{AgentRuntimeBinding, AgentStateBinding, AgentStateKind};
use crate::error::{AgentError, AppError};

const SESSION_MATCH_READ_LIMIT: usize = 200;

pub(crate) struct OpencodeSessionTracker<'a> {
    store: &'a dyn AgentStorePort,
    dispatch: &'a dyn MessageDispatchPort,
}

impl<'a> OpencodeSessionTracker<'a> {
    pub(crate) fn new(
        store: &'a dyn AgentStorePort,
        dispatch: &'a dyn MessageDispatchPort,
    ) -> Self {
        Self { store, dispatch }
    }

    pub(crate) fn resolve_bound_session<F>(
        &self,
        states: &[AgentStateBinding],
        runtime_binding: Option<&AgentRuntimeBinding>,
        capture_output: F,
    ) -> Result<MessageDispatchSessionRef, AppError>
    where
        F: Fn(&AgentRuntimeBinding, u16) -> Result<String, AppError>,
    {
        let state_binding = states
            .iter()
            .find(|state| state.state_kind == AgentStateKind::OpencodeSession)
            .ok_or(AppError::Agent(AgentError::Unavailable {
                message: "agent has no opencode session binding".to_string(),
            }))?;
        let session_state = find_opencode_session_state(states).ok_or(AppError::Agent(
            AgentError::Unavailable {
                message: "agent has invalid opencode session binding".to_string(),
            },
        ))?;
        let stored = MessageDispatchSessionRef {
            provider: MessageDispatchProvider::Opencode,
            server_url: session_state.server_url.clone(),
            session_id: session_state.session_id.clone(),
            directory: session_state.directory.clone(),
        };

        let Ok(sessions) = self.dispatch.list_sessions(&stored.server_url) else {
            return Ok(stored);
        };

        if let Some(runtime_binding) = runtime_binding
            && let Ok(pane_output) = capture_output(runtime_binding, 120)
            && !pane_output.trim().is_empty()
            && let Some(repaired) = self.find_session_for_live_pane(
                &stored,
                session_state.directory.as_deref(),
                &sessions,
                &pane_output,
            )?
        {
            if repaired.session_id != stored.session_id {
                let updated_state = rebind_opencode_session_state_binding(
                    state_binding,
                    &repaired,
                    &session_state.auth_mode,
                    now_unix_ms(),
                );
                self.store.upsert_state_binding(&updated_state)?;
            }
            return Ok(repaired);
        }

        if let Some(existing) = sessions
            .iter()
            .find(|session| session.session.session_id == stored.session_id)
        {
            return Ok(existing.session.clone());
        }

        Err(AppError::Agent(AgentError::Unavailable {
            message: format!(
                "opencode session '{}' is no longer tracked by server '{}'",
                stored.session_id, stored.server_url
            ),
        }))
    }

    fn find_session_for_live_pane(
        &self,
        stored: &MessageDispatchSessionRef,
        target_directory: Option<&str>,
        sessions: &[MessageDispatchSessionSummary],
        pane_output: &str,
    ) -> Result<Option<MessageDispatchSessionRef>, AppError> {
        if let Some(title) = extract_pane_title(pane_output) {
            let title_matches =
                filter_session_summaries_by_directory(sessions.to_vec(), target_directory)
                    .into_iter()
                    .filter(|summary| summary.title.as_deref() == Some(title.as_str()))
                    .collect::<Vec<_>>();
            if title_matches.len() == 1 {
                return Ok(Some(title_matches[0].session.clone()));
            }
        }

        if self.session_matches_pane(stored, pane_output)? {
            return Ok(Some(stored.clone()));
        }

        let mut candidates = self
            .dispatch
            .list_child_sessions(stored)
            .unwrap_or_default();
        candidates.extend_from_slice(sessions);
        let candidates = filter_session_summaries_by_directory(candidates, target_directory);
        let mut matched = Vec::new();
        for candidate in candidates {
            if self.session_matches_pane(&candidate.session, pane_output)? {
                matched.push(candidate.session);
            }
        }

        Ok((matched.len() == 1).then(|| matched.remove(0)))
    }

    fn session_matches_pane(
        &self,
        session: &MessageDispatchSessionRef,
        pane_output: &str,
    ) -> Result<bool, AppError> {
        let request = MessageReadRequest {
            session: session.clone(),
            limit: Some(SESSION_MATCH_READ_LIMIT),
        };
        let Some(message) = self.dispatch.read_last_message(&request)? else {
            return Ok(false);
        };
        Ok(message_matches_pane(&message.text, pane_output))
    }
}

fn filter_session_summaries_by_directory(
    sessions: Vec<MessageDispatchSessionSummary>,
    target_directory: Option<&str>,
) -> Vec<MessageDispatchSessionSummary> {
    let mut seen = HashSet::new();
    sessions
        .into_iter()
        .filter(|session| seen.insert(session.session.session_id.clone()))
        .filter(|session| directory_matches(target_directory, session.session.directory.as_deref()))
        .collect()
}

fn message_matches_pane(message_text: &str, pane_output: &str) -> bool {
    let message = normalize(message_text);
    let pane = normalize(pane_output);
    if message.len() < 24 || pane.len() < 24 {
        return false;
    }

    if pane.contains(&message) {
        return true;
    }

    let suffix = tail_chars(&message, 240);
    pane.contains(&suffix)
}

fn normalize(value: &str) -> String {
    value
        .split_whitespace()
        .collect::<Vec<_>>()
        .join(" ")
        .to_lowercase()
}

fn extract_pane_title(pane_output: &str) -> Option<String> {
    for line in pane_output.lines() {
        let Some(title_start) = line.find("# ") else {
            continue;
        };
        let title = line[title_start + 2..].trim();
        if title.is_empty() {
            continue;
        }
        if let Some((title, _)) = title.split_once("  ") {
            return Some(title.trim().to_string());
        }
        return Some(title.to_string());
    }
    None
}

fn tail_chars(value: &str, max_chars: usize) -> String {
    let chars = value.chars().collect::<Vec<_>>();
    let start = chars.len().saturating_sub(max_chars);
    chars[start..].iter().collect()
}

fn now_unix_ms() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_millis())
}
