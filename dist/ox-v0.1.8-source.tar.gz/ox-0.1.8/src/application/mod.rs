//! Application layer shared by CLI and TUI.

mod agent_conversation;
mod agent_interaction_service;
mod agent_provisioning_service;
mod agents;
mod app_api;
mod app_service;
mod clock;
mod codex_thread_state;
mod diagnostics_service;
mod directory_matching;
mod opencode_session_state;
mod opencode_session_tracker;
mod pinned_session_guard;
mod pinned_session_reconciler;
mod ports;
mod provisioning;
mod runtime_binding_manager;
mod runtime_start_request_builder;
mod slash_command;
mod types;

pub(crate) use crate::domain::AgentKind;
pub(crate) use agent_conversation::AgentConversationService;
pub(crate) use agent_interaction_service::AgentInteractionService;
pub(crate) use agent_provisioning_service::AgentProvisioningService;
pub(crate) use agents::{AgentFsContextResolver, AgentLifecycleService, OpencodeProvisioning};
pub(crate) use app_api::{
    AppAgents, AppApi, AppDiagnostics, TuiApi, TuiAttachReturn, TuiFleetSnapshot,
};
pub(crate) use app_service::{AppEventLogs, AppService};
#[cfg(test)]
pub(crate) use diagnostics_service::CheckResult;
pub(crate) use diagnostics_service::{DiagnosticsService, DoctorReport, StatusReport};
pub(crate) use ports::{
    AgentConversationPort, AgentRuntimePort, AgentStorePort, AppTmuxPort, AuxSessionPort,
    CodexThreadPort, ConfigPort, EventLogPort, MessageDispatchPort, OpencodeSessionBootstrapPort,
    RuntimePort, SessionPort, SessionStatePort, WorktreePort,
};
pub(crate) use slash_command::{normalize_slash_command, parse_slash_command};
pub(crate) use types::{
    AgentView, AppEvent, AppSettings, AppStoragePaths, CodexThreadBootstrap,
    CodexThreadStartRequest, ConversationMessage, ConversationReadResult, ConversationReadSource,
    CreateAgentRequest, EventOutcome, GitWorktreeCreateSpec, HostSessionSnapshot, LoggedEvent,
    MessageDispatchCreateSessionRequest, MessageDispatchCreateSessionResult,
    MessageDispatchProvider, MessageDispatchResult, MessageDispatchSendRequest,
    MessageDispatchSessionRef, MessageDispatchSessionSummary, MessageDispatchSlashCommandRequest,
    MessageReadRequest, OpencodeSettings, PinnedSessionSpec, ResolvedGitWorktreeSpec,
    RuntimeProbeResult, RuntimeStartRequest, RuntimeStatus, WorkspaceBackend, WorkspaceSpec,
};
