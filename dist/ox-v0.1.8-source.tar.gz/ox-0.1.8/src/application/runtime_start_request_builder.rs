use crate::application::codex_thread_state::find_codex_thread_id;
use crate::application::opencode_session_state::find_opencode_session_state;
use crate::application::{AgentFsContextResolver, RuntimeStartRequest};
use crate::domain::{AgentKind, AgentRuntimeRecord, AgentStateBinding};

/// Build the canonical runtime start request from persisted agent state.
///
/// Internal operations are keyed by stable `AgentId`; display names are
/// user-facing labels and must not be used as identity.
pub(crate) fn build_runtime_start_request(
    record: &AgentRuntimeRecord,
    states: &[AgentStateBinding],
) -> RuntimeStartRequest {
    let agent_id = record.agent.id();
    let kind = record.agent.kind();
    let working_dir = AgentFsContextResolver::resolve_from_states(states).working_dir_path_buf();
    let codex_thread_id = match kind {
        AgentKind::Codex => find_codex_thread_id(states),
        _ => None,
    };
    let opencode_session = match kind {
        AgentKind::Opencode => find_opencode_session_state(states),
        _ => None,
    };

    RuntimeStartRequest {
        agent_id: agent_id.clone(),
        session_name: record.agent.display_name().to_string(),
        agent_kind: kind,
        working_dir,
        codex_thread_id,
        opencode_server_url: opencode_session.as_ref().map(|s| s.server_url.clone()),
        opencode_session_id: opencode_session.map(|s| s.session_id),
    }
}

#[cfg(test)]
mod tests {
    use super::build_runtime_start_request;
    use crate::domain::{
        Agent, AgentKind, AgentRuntimeRecord, AgentStateBinding, AgentStateKind,
        AgentStateProvider, PRIMARY_STATE_BINDING_KEY,
    };

    fn fixture_record(kind: AgentKind) -> AgentRuntimeRecord {
        AgentRuntimeRecord {
            agent: Agent::new("dev".to_string(), kind, 1),
            binding: None,
        }
    }

    fn working_dir_state(record: &AgentRuntimeRecord, path: &str) -> AgentStateBinding {
        AgentStateBinding::new(
            record.agent.id(),
            AgentStateKind::WorkingDirectory,
            AgentStateProvider::Git,
            PRIMARY_STATE_BINDING_KEY.to_string(),
            "opaque-ref".to_string(),
            serde_json::json!({ "path": path }).to_string(),
            1,
        )
    }

    fn codex_thread_state(record: &AgentRuntimeRecord, thread_id: &str) -> AgentStateBinding {
        AgentStateBinding::new(
            record.agent.id(),
            AgentStateKind::CodexThread,
            AgentStateProvider::Codex,
            PRIMARY_STATE_BINDING_KEY.to_string(),
            thread_id.to_string(),
            "{}".to_string(),
            1,
        )
    }

    fn opencode_session_state(
        record: &AgentRuntimeRecord,
        server_url: &str,
        session_id: &str,
    ) -> AgentStateBinding {
        AgentStateBinding::new(
            record.agent.id(),
            AgentStateKind::OpencodeSession,
            AgentStateProvider::Opencode,
            PRIMARY_STATE_BINDING_KEY.to_string(),
            format!("{server_url}::{session_id}"),
            serde_json::json!({
                "server_url": server_url,
                "session_id": session_id,
            })
            .to_string(),
            1,
        )
    }

    #[test]
    fn codex_request_populates_thread_and_ignores_opencode_state() {
        let record = fixture_record(AgentKind::Codex);
        let states = vec![
            working_dir_state(&record, "/repo/codex"),
            codex_thread_state(&record, "thread_123"),
            opencode_session_state(&record, "http://127.0.0.1:4096", "session_1"),
        ];

        let request = build_runtime_start_request(&record, &states);

        assert_eq!(request.agent_kind, AgentKind::Codex);
        assert_eq!(
            request.working_dir,
            Some(std::path::PathBuf::from("/repo/codex"))
        );
        assert_eq!(request.codex_thread_id.as_deref(), Some("thread_123"));
        assert!(request.opencode_server_url.is_none());
        assert!(request.opencode_session_id.is_none());
    }

    #[test]
    fn opencode_request_populates_session_and_ignores_codex_thread() {
        let record = fixture_record(AgentKind::Opencode);
        let states = vec![
            working_dir_state(&record, "/repo/opencode"),
            codex_thread_state(&record, "thread_456"),
            opencode_session_state(&record, "http://127.0.0.1:4096", "session_2"),
        ];

        let request = build_runtime_start_request(&record, &states);

        assert_eq!(request.agent_kind, AgentKind::Opencode);
        assert_eq!(
            request.working_dir,
            Some(std::path::PathBuf::from("/repo/opencode"))
        );
        assert!(request.codex_thread_id.is_none());
        assert_eq!(
            request.opencode_server_url.as_deref(),
            Some("http://127.0.0.1:4096")
        );
        assert_eq!(request.opencode_session_id.as_deref(), Some("session_2"));
    }

    #[test]
    fn shell_request_leaves_optional_runtime_fields_empty() {
        let record = fixture_record(AgentKind::Shell);

        let request = build_runtime_start_request(&record, &[]);

        assert_eq!(request.agent_kind, AgentKind::Shell);
        assert!(request.working_dir.is_none());
        assert!(request.codex_thread_id.is_none());
        assert!(request.opencode_server_url.is_none());
        assert!(request.opencode_session_id.is_none());
    }
}
