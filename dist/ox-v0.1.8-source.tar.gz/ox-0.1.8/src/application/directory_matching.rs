pub(crate) fn directory_matches(expected: Option<&str>, actual: Option<&str>) -> bool {
    match (expected, actual) {
        (Some(expected), Some(actual)) => same_directory(expected, actual),
        (Some(_), None) => false,
        _ => true,
    }
}

pub(crate) fn same_directory(left: &str, right: &str) -> bool {
    if left == right {
        return true;
    }

    match (
        std::fs::canonicalize(left).ok(),
        std::fs::canonicalize(right).ok(),
    ) {
        (Some(left), Some(right)) => left == right,
        _ => false,
    }
}
