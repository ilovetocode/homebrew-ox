use std::sync::Arc;

mod command_ops;
mod event_ops;
mod query_ops;

pub(crate) use self::event_ops::AppEventLogs;
use crate::application::DiagnosticsService;
use crate::application::ports::{AgentConversationPort, AgentStorePort};
use crate::application::types::{
    AgentView, AppSettings, ConversationReadResult, CreateAgentRequest, LoggedEvent,
    MessageDispatchResult,
};
use crate::application::{AppAgents, AppDiagnostics, TuiApi, TuiAttachReturn, TuiFleetSnapshot};
use crate::application::{DoctorReport, StatusReport};
use crate::domain::AgentId;
use crate::error::AppError;

/// Single application facade used by CLI and TUI.
pub(crate) struct AppService {
    agents: crate::application::AgentLifecycleService,
    runtime_agents: crate::application::AgentInteractionService,
    conversation_agents: Arc<dyn AgentConversationPort>,
    diagnostics: DiagnosticsService,
    event_logs: AppEventLogs,
    settings: AppSettings,
    store: Arc<dyn AgentStorePort>,
}

impl AppService {
    /// Build app service from injected subsystem dependencies.
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn new(
        agents: crate::application::AgentLifecycleService,
        runtime_agents: crate::application::AgentInteractionService,
        conversation_agents: Arc<dyn AgentConversationPort>,
        diagnostics: DiagnosticsService,
        event_logs: AppEventLogs,
        settings: AppSettings,
        store: Arc<dyn AgentStorePort>,
    ) -> Self {
        Self {
            agents,
            runtime_agents,
            conversation_agents,
            diagnostics,
            event_logs,
            settings,
            store,
        }
    }
}

impl AppDiagnostics for AppService {
    fn status_report(&self) -> Result<StatusReport, AppError> {
        query_ops::status_report(self)
    }

    fn doctor_report(&self, fix: bool) -> Result<DoctorReport, AppError> {
        query_ops::doctor_report(self, fix)
    }

    fn reconcile_pinned_sessions(&self) -> Result<(), AppError> {
        query_ops::reconcile_pinned_sessions(self)
    }

    fn recent_events(&self, limit: usize) -> Result<Vec<LoggedEvent>, AppError> {
        query_ops::recent_events(self, limit)
    }

    fn events_default_limit(&self) -> usize {
        query_ops::events_default_limit(self)
    }
}

impl TuiApi for AppService {
    fn tui_refresh_interval_ms(&self) -> u64 {
        query_ops::tui_refresh_interval_ms(self)
    }

    fn tui_list_agents(&self) -> Result<Vec<AgentView>, AppError> {
        query_ops::list_agents(self)
    }

    fn tui_status_report(&self) -> Result<StatusReport, AppError> {
        query_ops::status_report(self)
    }

    fn tui_create_agent(&self, request: CreateAgentRequest) -> Result<TuiFleetSnapshot, AppError> {
        command_ops::tui_create_agent(self, request)
    }

    fn tui_rename_agent(
        &self,
        id: &AgentId,
        new_display_name: &str,
    ) -> Result<TuiFleetSnapshot, AppError> {
        command_ops::tui_rename_agent(self, id, new_display_name)
    }

    fn tui_delete_agent(&self, id: &AgentId) -> Result<TuiFleetSnapshot, AppError> {
        command_ops::tui_delete_agent(self, id)
    }

    fn tui_switch_agent_to_worktree_shell(
        &self,
        id: &AgentId,
        branch_name: &str,
    ) -> Result<TuiFleetSnapshot, AppError> {
        command_ops::tui_switch_agent_to_worktree_shell(self, id, branch_name)
    }

    fn tui_connect_agent(&self, id: &AgentId) -> Result<(), AppError> {
        command_ops::connect_agent(self, id)
    }

    fn tui_resolve_attach_return(
        &self,
        requested_id: &AgentId,
        attach_started_at_unix_ms: u128,
    ) -> Result<TuiAttachReturn, AppError> {
        command_ops::tui_resolve_attach_return(self, requested_id, attach_started_at_unix_ms)
    }

    fn tui_capture_agent_output(&self, id: &AgentId, lines: u16) -> Result<String, AppError> {
        self.runtime_agents.capture_agent_output(id, lines)
    }

    fn tui_send_key_to_agent(&self, id: &AgentId, key: &str) -> Result<(), AppError> {
        self.runtime_agents.send_key_to_agent(id, key)
    }
}

impl AppAgents for AppService {
    fn list_agents(&self) -> Result<Vec<AgentView>, AppError> {
        query_ops::list_agents(self)
    }

    fn list_agents_for_picker(&self) -> Result<Vec<AgentView>, AppError> {
        query_ops::list_agents_for_picker(self)
    }

    fn resolve_agent_selector(&self, selector: &str) -> Result<AgentId, AppError> {
        query_ops::resolve_agent_selector(self, selector)
    }

    fn create_agent(&self, request: CreateAgentRequest) -> Result<AgentId, AppError> {
        command_ops::create_agent(self, request)
    }

    fn rename_agent(&self, id: &AgentId, new_display_name: &str) -> Result<(), AppError> {
        command_ops::rename_agent(self, id, new_display_name)
    }

    fn reorder_agent(&self, id: &AgentId, target_position: i64) -> Result<(), AppError> {
        command_ops::reorder_agent(self, id, target_position)
    }

    fn delete_agent(&self, id: &AgentId) -> Result<(), AppError> {
        command_ops::delete_agent(self, id)
    }

    fn switch_agent_to_worktree_shell(
        &self,
        id: &AgentId,
        branch_name: &str,
    ) -> Result<(), AppError> {
        command_ops::switch_agent_to_worktree_shell(self, id, branch_name)
    }

    fn connect_agent(&self, id: &AgentId) -> Result<(), AppError> {
        command_ops::connect_agent(self, id)
    }

    fn disconnect_to_dashboard(&self) -> Result<(), AppError> {
        command_ops::disconnect_to_dashboard(self)
    }

    fn send_key_to_agent(&self, id: &AgentId, key: &str) -> Result<(), AppError> {
        self.runtime_agents.send_key_to_agent(id, key)
    }

    fn send_message_to_agent(
        &self,
        id: &AgentId,
        message: &str,
    ) -> Result<MessageDispatchResult, AppError> {
        self.conversation_agents.send_message_to_agent(id, message)
    }

    fn send_slash_command_to_agent(
        &self,
        id: &AgentId,
        command: &str,
    ) -> Result<MessageDispatchResult, AppError> {
        self.conversation_agents
            .send_slash_command_to_agent(id, command)
    }

    fn read_last_message_from_agent(
        &self,
        id: &AgentId,
    ) -> Result<ConversationReadResult, AppError> {
        self.conversation_agents.read_last_message_from_agent(id)
    }

    fn read_full_conversation_from_agent(
        &self,
        id: &AgentId,
    ) -> Result<ConversationReadResult, AppError> {
        self.conversation_agents
            .read_full_conversation_from_agent(id)
    }
}

#[cfg(test)]
#[path = "app_service/test_support.rs"]
pub(super) mod test_support;

#[cfg(test)]
mod tests;
