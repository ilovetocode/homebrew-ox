use crate::domain::{
    Agent, AgentStateBinding, AgentStateKind, AgentStateProvider, PRIMARY_STATE_BINDING_KEY,
};

const CODEX_THREAD_BINDING_KEY: &str = PRIMARY_STATE_BINDING_KEY;

/// Build one durable Codex thread state binding owned by `ox`.
///
/// We persist the thread ID in both `external_ref` (for uniqueness/indexing)
/// and metadata (for explicit managed-mode semantics and diagnostics).
pub(crate) fn build_codex_thread_state_binding(
    agent: &Agent,
    thread_id: &str,
    bootstrap_event_count: usize,
    now_unix_ms: u128,
) -> AgentStateBinding {
    let metadata = serde_json::json!({
        "thread_id": thread_id,
        "managed": true,
        "bootstrap_event_count": bootstrap_event_count
    });
    AgentStateBinding::new(
        agent.id(),
        AgentStateKind::CodexThread,
        AgentStateProvider::Codex,
        CODEX_THREAD_BINDING_KEY.to_string(),
        thread_id.to_string(),
        metadata.to_string(),
        now_unix_ms,
    )
}

/// Resolve the canonical managed Codex thread ID from persisted state bindings.
pub(crate) fn find_codex_thread_id(states: &[AgentStateBinding]) -> Option<String> {
    states
        .iter()
        .find(|state| state.state_kind == AgentStateKind::CodexThread)
        .map(|state| state.external_ref.trim())
        .filter(|thread_id| !thread_id.is_empty())
        .map(ToString::to_string)
}
