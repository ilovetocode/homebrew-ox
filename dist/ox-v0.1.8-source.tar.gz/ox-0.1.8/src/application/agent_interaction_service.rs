use std::sync::Arc;

use crate::application::ports::{AgentRuntimePort, AgentStorePort};
use crate::application::runtime_binding_manager::{
    RuntimeBindingManager, should_retry_with_fresh_tmux_session,
};
use crate::domain::{AgentId, AgentRuntimeBinding, AgentRuntimeRecord};
use crate::error::{AgentError, AppError};

/// Layer order contract: `AppApi` -> `AppService` -> `AgentLifecycleService` ->
/// `AgentInteractionService`. Keep this service focused on runtime-oriented
/// operations, while lifecycle create/list/rename/delete stays in
/// `AgentLifecycleService`.
pub(crate) struct AgentInteractionService {
    store: Arc<dyn AgentStorePort>,
    runtime: Arc<dyn AgentRuntimePort>,
}

impl AgentInteractionService {
    /// Build runtime service from persistence + runtime ports.
    pub(crate) fn new(store: Arc<dyn AgentStorePort>, runtime: Arc<dyn AgentRuntimePort>) -> Self {
        Self { store, runtime }
    }

    /// Attach by agent ID, auto-starting runtime if needed.
    pub(crate) fn attach_agent(&self, id: &AgentId) -> Result<(), AppError> {
        let record = self
            .store
            .find_agent_runtime_record_by_id(id.clone())?
            .ok_or(AppError::Agent(AgentError::NotFound))?;
        if let Some(binding) = record.binding.as_ref() {
            match self.runtime.attach(binding) {
                Ok(()) => return Ok(()),
                Err(err) if should_retry_with_fresh_tmux_session(binding, &err) => {}
                Err(err) => return Err(err),
            }
        }
        let ensured_binding = self.ensure_runtime_binding(&record)?;
        self.runtime.attach(&ensured_binding)
    }

    /// Detach the current tmux client.
    ///
    /// The runtime adapter treats "not currently inside tmux" as a no-op so
    /// interface flows can always invoke this when the synthetic "dashboard"
    /// quick-switch target is selected.
    pub(crate) fn detach_client(&self) -> Result<(), AppError> {
        self.runtime.detach_client()
    }

    /// Capture recent output for one agent.
    ///
    /// This returns an empty string when the agent has no runtime binding yet,
    /// which lets dashboard previews render a stable placeholder.
    pub(crate) fn capture_agent_output(
        &self,
        id: &AgentId,
        lines: u16,
    ) -> Result<String, AppError> {
        let record = self
            .store
            .find_agent_runtime_record_by_id(id.clone())?
            .ok_or(AppError::Agent(AgentError::NotFound))?;
        let Some(binding) = record.binding.as_ref() else {
            return Ok(String::new());
        };
        match self.runtime.capture_output(binding, lines) {
            Ok(output) => Ok(output),
            Err(err) if should_retry_with_fresh_tmux_session(binding, &err) => {
                let ensured_binding = self.ensure_runtime_binding(&record)?;
                self.runtime.capture_output(&ensured_binding, lines)
            }
            Err(err) => Err(err),
        }
    }

    /// Send one key token to an agent runtime binding.
    pub(crate) fn send_key_to_agent(&self, id: &AgentId, key: &str) -> Result<(), AppError> {
        let record = self
            .store
            .find_agent_runtime_record_by_id(id.clone())?
            .ok_or(AppError::Agent(AgentError::NotFound))?;
        let binding = record
            .binding
            .as_ref()
            .ok_or(AppError::Agent(AgentError::BindingMissing))?;
        match self.runtime.send_key(binding, key) {
            Ok(()) => Ok(()),
            Err(err) if should_retry_with_fresh_tmux_session(binding, &err) => {
                let ensured_binding = self.ensure_runtime_binding(&record)?;
                self.runtime.send_key(&ensured_binding, key)
            }
            Err(err) => Err(err),
        }
    }

    fn ensure_runtime_binding(
        &self,
        record: &AgentRuntimeRecord,
    ) -> Result<AgentRuntimeBinding, AppError> {
        RuntimeBindingManager::new(self.store.as_ref(), self.runtime.as_ref())
            .ensure_binding(record)
    }
}

#[cfg(test)]
mod tests {
    use std::collections::VecDeque;
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::sync::{Arc, Mutex};

    use super::AgentInteractionService;
    use crate::application::ports::{AgentRuntimePort, AgentStorePort};
    use crate::application::runtime_binding_manager::should_retry_with_fresh_tmux_session;
    use crate::application::{RuntimeProbeResult, RuntimeStartRequest};
    use crate::domain::{
        Agent, AgentId, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding, RuntimeProvider,
    };
    use crate::error::{AgentError, AppError, TmuxError};

    fn stub_error(op: &str) -> AppError {
        AppError::Agent(AgentError::Unavailable {
            message: format!("stubbed method called: {op}"),
        })
    }

    struct StoreStub {
        record: Option<AgentRuntimeRecord>,
        states: Vec<AgentStateBinding>,
        list_state_calls: AtomicUsize,
        upsert_calls: AtomicUsize,
    }

    impl StoreStub {
        fn new(record: Option<AgentRuntimeRecord>, states: Vec<AgentStateBinding>) -> Self {
            Self {
                record,
                states,
                list_state_calls: AtomicUsize::new(0),
                upsert_calls: AtomicUsize::new(0),
            }
        }

        fn list_state_calls(&self) -> usize {
            self.list_state_calls.load(Ordering::Relaxed)
        }

        fn upsert_calls(&self) -> usize {
            self.upsert_calls.load(Ordering::Relaxed)
        }
    }

    impl AgentStorePort for StoreStub {
        fn insert_agent_with_binding(
            &self,
            _agent: &Agent,
            _binding: &AgentRuntimeBinding,
            _state_bindings: &[AgentStateBinding],
        ) -> Result<(), AppError> {
            Err(stub_error("insert_agent_with_binding"))
        }

        fn list_agent_runtime_records(&self) -> Result<Vec<AgentRuntimeRecord>, AppError> {
            Err(stub_error("list_agent_runtime_records"))
        }

        fn find_agent_runtime_record_by_id(
            &self,
            id: AgentId,
        ) -> Result<Option<AgentRuntimeRecord>, AppError> {
            Ok(self
                .record
                .as_ref()
                .filter(|record| record.agent.id().as_str() == id.as_str())
                .cloned())
        }

        fn list_state_bindings_by_agent_id(
            &self,
            id: AgentId,
        ) -> Result<Vec<AgentStateBinding>, AppError> {
            self.list_state_calls.fetch_add(1, Ordering::Relaxed);
            Ok(self
                .states
                .iter()
                .filter(|state| state.agent_id.as_str() == id.as_str())
                .cloned()
                .collect())
        }

        fn list_state_bindings_by_agent_ids(
            &self,
            _ids: &[AgentId],
        ) -> Result<Vec<AgentStateBinding>, AppError> {
            Err(stub_error("list_state_bindings_by_agent_ids"))
        }

        fn upsert_state_binding(&self, _binding: &AgentStateBinding) -> Result<(), AppError> {
            Ok(())
        }

        fn find_agent_by_display_name(
            &self,
            _display_name: &str,
        ) -> Result<Option<Agent>, AppError> {
            Err(stub_error("find_agent_by_display_name"))
        }

        fn update_agent(&self, _updated: &Agent, _expected_version: i64) -> Result<(), AppError> {
            Err(stub_error("update_agent"))
        }

        fn upsert_binding(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
            self.upsert_calls.fetch_add(1, Ordering::Relaxed);
            Ok(())
        }

        fn update_agent_runtime_context(
            &self,
            _updated: &Agent,
            _expected_version: i64,
            _binding: &AgentRuntimeBinding,
            _upsert_state_bindings: &[AgentStateBinding],
            _delete_state_kinds: &[crate::domain::AgentStateKind],
        ) -> Result<(), AppError> {
            Err(stub_error("update_agent_runtime_context"))
        }

        fn delete_agent(&self, _id: AgentId) -> Result<(), AppError> {
            Err(stub_error("delete_agent"))
        }

        fn next_display_order(&self) -> Result<i64, AppError> {
            Err(stub_error("next_display_order"))
        }

        fn swap_display_order(
            &self,
            _a: &Agent,
            _a_expected_version: i64,
            _b: &Agent,
            _b_expected_version: i64,
        ) -> Result<(), AppError> {
            Err(stub_error("swap_display_order"))
        }
    }

    struct RuntimeStub {
        attach_results: Mutex<VecDeque<Result<(), AppError>>>,
        send_key_results: Mutex<VecDeque<Result<(), AppError>>>,
        capture_results: Mutex<VecDeque<Result<String, AppError>>>,
        start_result: Mutex<Option<Result<AgentRuntimeBinding, AppError>>>,
        attach_calls: AtomicUsize,
        send_key_calls: AtomicUsize,
        capture_calls: AtomicUsize,
        start_calls: AtomicUsize,
    }

    impl RuntimeStub {
        fn new(
            attach_results: Vec<Result<(), AppError>>,
            start_result: Result<AgentRuntimeBinding, AppError>,
        ) -> Self {
            Self {
                attach_results: Mutex::new(VecDeque::from(attach_results)),
                send_key_results: Mutex::new(VecDeque::new()),
                capture_results: Mutex::new(VecDeque::new()),
                start_result: Mutex::new(Some(start_result)),
                attach_calls: AtomicUsize::new(0),
                send_key_calls: AtomicUsize::new(0),
                capture_calls: AtomicUsize::new(0),
                start_calls: AtomicUsize::new(0),
            }
        }

        fn set_send_key_results(&self, results: Vec<Result<(), AppError>>) {
            *self
                .send_key_results
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner) = VecDeque::from(results);
        }

        fn set_capture_results(&self, results: Vec<Result<String, AppError>>) {
            *self
                .capture_results
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner) = VecDeque::from(results);
        }

        fn attach_calls(&self) -> usize {
            self.attach_calls.load(Ordering::Relaxed)
        }

        fn start_calls(&self) -> usize {
            self.start_calls.load(Ordering::Relaxed)
        }

        fn send_key_calls(&self) -> usize {
            self.send_key_calls.load(Ordering::Relaxed)
        }

        fn capture_calls(&self) -> usize {
            self.capture_calls.load(Ordering::Relaxed)
        }
    }

    impl AgentRuntimePort for RuntimeStub {
        fn start(
            &self,
            _request: &RuntimeStartRequest,
            _binding: Option<&AgentRuntimeBinding>,
        ) -> Result<AgentRuntimeBinding, AppError> {
            self.start_calls.fetch_add(1, Ordering::Relaxed);
            self.start_result
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner)
                .take()
                .unwrap_or_else(|| Err(stub_error("start called more than configured")))
        }

        fn stop(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
            Err(stub_error("stop"))
        }

        fn attach(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
            self.attach_calls.fetch_add(1, Ordering::Relaxed);
            self.attach_results
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner)
                .pop_front()
                .unwrap_or(Ok(()))
        }

        fn detach_client(&self) -> Result<(), AppError> {
            Err(stub_error("detach_client"))
        }

        fn probe(
            &self,
            _bindings: &[AgentRuntimeBinding],
        ) -> Result<Vec<RuntimeProbeResult>, AppError> {
            Err(stub_error("probe"))
        }

        fn capture_output(
            &self,
            _binding: &AgentRuntimeBinding,
            _lines: u16,
        ) -> Result<String, AppError> {
            self.capture_calls.fetch_add(1, Ordering::Relaxed);
            self.capture_results
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner)
                .pop_front()
                .unwrap_or_else(|| Err(stub_error("capture_output")))
        }

        fn send_key(&self, _binding: &AgentRuntimeBinding, _key: &str) -> Result<(), AppError> {
            self.send_key_calls.fetch_add(1, Ordering::Relaxed);
            self.send_key_results
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner)
                .pop_front()
                .unwrap_or_else(|| Err(stub_error("send_key")))
        }

        fn rename(
            &self,
            _binding: &AgentRuntimeBinding,
            _new_external_ref: &str,
        ) -> Result<(), AppError> {
            Err(stub_error("rename"))
        }
    }

    fn tmux_retryable_error() -> AppError {
        AppError::Tmux(TmuxError::CommandFailed {
            stderr: "can't find session".to_string(),
        })
    }

    fn non_retryable_error() -> AppError {
        AppError::Agent(AgentError::Unavailable {
            message: "attach failed".to_string(),
        })
    }

    fn fixture_with_binding() -> (AgentId, AgentRuntimeRecord, AgentRuntimeBinding) {
        let agent = Agent::new("dev".to_string(), crate::domain::AgentKind::Shell, 1);
        let id = agent.id();
        let binding =
            AgentRuntimeBinding::new(id.clone(), RuntimeProvider::Tmux, "dev".to_string(), 1);
        let record = AgentRuntimeRecord {
            agent,
            binding: Some(binding.clone()),
        };
        (id, record, binding)
    }

    #[test]
    fn attach_success_with_existing_binding_skips_state_lookup_and_start() {
        let (id, record, binding) = fixture_with_binding();
        let store = Arc::new(StoreStub::new(Some(record), vec![]));
        let runtime = Arc::new(RuntimeStub::new(vec![Ok(())], Ok(binding)));
        let service = AgentInteractionService::new(store.clone(), runtime.clone());

        let result = service.attach_agent(&id);

        assert!(result.is_ok());
        assert_eq!(store.list_state_calls(), 0);
        assert_eq!(store.upsert_calls(), 0);
        assert_eq!(runtime.start_calls(), 0);
        assert_eq!(runtime.attach_calls(), 1);
    }

    #[test]
    fn attach_retryable_error_falls_back_to_start_and_reads_states() {
        let (id, record, binding) = fixture_with_binding();
        let store = Arc::new(StoreStub::new(Some(record), vec![]));
        let runtime = Arc::new(RuntimeStub::new(
            vec![Err(tmux_retryable_error()), Ok(())],
            Ok(binding),
        ));
        let service = AgentInteractionService::new(store.clone(), runtime.clone());

        let result = service.attach_agent(&id);

        assert!(result.is_ok());
        assert_eq!(store.list_state_calls(), 1);
        assert_eq!(store.upsert_calls(), 1);
        assert_eq!(runtime.start_calls(), 1);
        assert_eq!(runtime.attach_calls(), 2);
    }

    #[test]
    fn missing_binding_reads_states_and_starts_before_attach() {
        let agent = Agent::new("dev".to_string(), crate::domain::AgentKind::Shell, 1);
        let id = agent.id();
        let record = AgentRuntimeRecord {
            agent,
            binding: None,
        };
        let new_binding =
            AgentRuntimeBinding::new(id.clone(), RuntimeProvider::Tmux, "dev".to_string(), 1);
        let store = Arc::new(StoreStub::new(Some(record), vec![]));
        let runtime = Arc::new(RuntimeStub::new(vec![Ok(())], Ok(new_binding)));
        let service = AgentInteractionService::new(store.clone(), runtime.clone());

        let result = service.attach_agent(&id);

        assert!(result.is_ok());
        assert_eq!(store.list_state_calls(), 1);
        assert_eq!(store.upsert_calls(), 1);
        assert_eq!(runtime.start_calls(), 1);
        assert_eq!(runtime.attach_calls(), 1);
    }

    #[test]
    fn non_retryable_attach_error_returns_without_state_lookup_or_start() {
        let (id, record, binding) = fixture_with_binding();
        let store = Arc::new(StoreStub::new(Some(record), vec![]));
        let runtime = Arc::new(RuntimeStub::new(
            vec![Err(non_retryable_error())],
            Ok(binding),
        ));
        let service = AgentInteractionService::new(store.clone(), runtime.clone());

        let result = service.attach_agent(&id);

        assert!(matches!(
            result,
            Err(AppError::Agent(AgentError::Unavailable { message })) if message == "attach failed"
        ));
        assert_eq!(store.list_state_calls(), 0);
        assert_eq!(store.upsert_calls(), 0);
        assert_eq!(runtime.start_calls(), 0);
        assert_eq!(runtime.attach_calls(), 1);
    }

    #[test]
    fn send_key_retryable_error_recreates_runtime_and_retries() {
        let (id, record, binding) = fixture_with_binding();
        let store = Arc::new(StoreStub::new(Some(record), vec![]));
        let runtime = Arc::new(RuntimeStub::new(vec![], Ok(binding)));
        runtime.set_send_key_results(vec![Err(tmux_retryable_error()), Ok(())]);
        let service = AgentInteractionService::new(store.clone(), runtime.clone());

        let result = service.send_key_to_agent(&id, "Enter");

        assert!(result.is_ok());
        assert_eq!(store.list_state_calls(), 1);
        assert_eq!(store.upsert_calls(), 1);
        assert_eq!(runtime.start_calls(), 1);
        assert_eq!(runtime.send_key_calls(), 2);
    }

    #[test]
    fn capture_retryable_error_recreates_runtime_and_retries() {
        let (id, record, binding) = fixture_with_binding();
        let store = Arc::new(StoreStub::new(Some(record), vec![]));
        let runtime = Arc::new(RuntimeStub::new(vec![], Ok(binding)));
        runtime.set_capture_results(vec![Err(tmux_retryable_error()), Ok("ok".to_string())]);
        let service = AgentInteractionService::new(store.clone(), runtime.clone());

        let result = service.capture_agent_output(&id, 20);

        assert!(matches!(result, Ok(output) if output == "ok"));
        assert_eq!(store.list_state_calls(), 1);
        assert_eq!(store.upsert_calls(), 1);
        assert_eq!(runtime.start_calls(), 1);
        assert_eq!(runtime.capture_calls(), 2);
    }

    #[test]
    fn send_key_non_retryable_error_does_not_recreate() {
        let (id, record, binding) = fixture_with_binding();
        let store = Arc::new(StoreStub::new(Some(record), vec![]));
        let runtime = Arc::new(RuntimeStub::new(vec![], Ok(binding)));
        runtime.set_send_key_results(vec![Err(non_retryable_error())]);
        let service = AgentInteractionService::new(store.clone(), runtime.clone());

        let result = service.send_key_to_agent(&id, "Enter");

        assert!(matches!(
            result,
            Err(AppError::Agent(AgentError::Unavailable { message })) if message == "attach failed"
        ));
        assert_eq!(store.list_state_calls(), 0);
        assert_eq!(store.upsert_calls(), 0);
        assert_eq!(runtime.start_calls(), 0);
        assert_eq!(runtime.send_key_calls(), 1);
    }

    #[test]
    fn retryable_predicate_treats_missing_pane_as_recoverable() {
        let (_, _, binding) = fixture_with_binding();
        let err = AppError::Tmux(TmuxError::CommandFailed {
            stderr: "can't find pane: n5".to_string(),
        });

        assert!(should_retry_with_fresh_tmux_session(&binding, &err));
    }
}
