use std::collections::HashSet;
use std::sync::Mutex;
use std::sync::atomic::{AtomicUsize, Ordering};

use crate::application::{
    AgentRuntimePort, AgentStorePort, CodexThreadBootstrap, CodexThreadPort,
    CodexThreadStartRequest, ConversationReadResult, ConversationReadSource,
    MessageDispatchProvider, MessageDispatchSessionRef, OpencodeSessionBootstrapPort,
    ResolvedGitWorktreeSpec, RuntimeProbeResult, RuntimeStartRequest, RuntimeStatus, WorktreePort,
};
use crate::domain::{
    Agent, AgentId, AgentKind, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding,
    RuntimeProvider,
};
use crate::error::{AgentError, AppError};

#[derive(Default)]
pub(crate) struct FakeWorktree {
    pub(crate) create_state: Option<AgentStateBinding>,
    pub(crate) delete_calls: AtomicUsize,
    pub(crate) derived_root: Option<String>,
    pub(crate) seen_paths: Mutex<Vec<String>>,
}

impl WorktreePort for FakeWorktree {
    fn create_worktree(
        &self,
        _agent: &Agent,
        _spec: &ResolvedGitWorktreeSpec,
    ) -> Result<AgentStateBinding, AppError> {
        self.create_state.clone().ok_or(AppError::InvalidInput {
            message: "not configured for create".to_string(),
        })
    }

    fn delete_worktree(&self, _state: &AgentStateBinding) -> Result<(), AppError> {
        self.delete_calls.fetch_add(1, Ordering::Relaxed);
        Ok(())
    }

    fn current_branch(&self, _worktree_path: &str) -> Result<Option<String>, AppError> {
        Ok(None)
    }

    fn resolve_base_ref(&self, _path: &str) -> Result<Option<String>, AppError> {
        Ok(None)
    }

    fn parent_git_root(&self, path: &str) -> Result<Option<String>, AppError> {
        self.seen_paths
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .push(path.to_string());
        Ok(self.derived_root.clone())
    }
}

pub(crate) struct FakeRuntime {
    pub(crate) fail_start: bool,
    pub(crate) start_calls: AtomicUsize,
    pub(crate) stop_calls: AtomicUsize,
}

impl FakeRuntime {
    pub(crate) fn new(fail_start: bool) -> Self {
        Self {
            fail_start,
            start_calls: AtomicUsize::new(0),
            stop_calls: AtomicUsize::new(0),
        }
    }
}

impl AgentRuntimePort for FakeRuntime {
    fn start(
        &self,
        request: &RuntimeStartRequest,
        _binding: Option<&AgentRuntimeBinding>,
    ) -> Result<AgentRuntimeBinding, AppError> {
        self.start_calls.fetch_add(1, Ordering::Relaxed);
        if self.fail_start {
            return Err(AppError::Agent(AgentError::Unavailable {
                message: "start failed".to_string(),
            }));
        }
        Ok(AgentRuntimeBinding::new(
            request.agent_id.clone(),
            RuntimeProvider::Tmux,
            request.session_name.clone(),
            1,
        ))
    }

    fn stop(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
        self.stop_calls.fetch_add(1, Ordering::Relaxed);
        Ok(())
    }

    fn attach(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
        Ok(())
    }

    fn detach_client(&self) -> Result<(), AppError> {
        Ok(())
    }

    fn probe(
        &self,
        _bindings: &[AgentRuntimeBinding],
    ) -> Result<Vec<RuntimeProbeResult>, AppError> {
        Ok(Vec::new())
    }

    fn capture_output(
        &self,
        _binding: &AgentRuntimeBinding,
        _lines: u16,
    ) -> Result<String, AppError> {
        Ok(String::new())
    }

    fn send_key(&self, _binding: &AgentRuntimeBinding, _key: &str) -> Result<(), AppError> {
        Ok(())
    }

    fn rename(
        &self,
        _binding: &AgentRuntimeBinding,
        _new_external_ref: &str,
    ) -> Result<(), AppError> {
        Ok(())
    }
}

pub(crate) struct FakeCodexThreads;

impl CodexThreadPort for FakeCodexThreads {
    fn start_thread(
        &self,
        _request: &CodexThreadStartRequest,
    ) -> Result<CodexThreadBootstrap, AppError> {
        Ok(CodexThreadBootstrap {
            thread_id: "00000000-0000-0000-0000-000000000001".to_string(),
            event_count: 0,
        })
    }

    fn read_thread_statuses(
        &self,
        _thread_ids: &[String],
    ) -> Result<std::collections::HashMap<String, RuntimeStatus>, AppError> {
        Ok(std::collections::HashMap::new())
    }

    fn read_thread_conversation(
        &self,
        _thread_id: &str,
        _limit: Option<usize>,
    ) -> Result<ConversationReadResult, AppError> {
        Ok(ConversationReadResult {
            messages: Vec::new(),
            source: ConversationReadSource::CodexRollout,
            partial: false,
        })
    }
}

pub(crate) struct FakeOpencodeSessionBootstrap {
    pub(crate) ensure_calls: AtomicUsize,
    fail: bool,
}

impl FakeOpencodeSessionBootstrap {
    pub(crate) fn new(fail: bool) -> Self {
        Self {
            ensure_calls: AtomicUsize::new(0),
            fail,
        }
    }
}

impl OpencodeSessionBootstrapPort for FakeOpencodeSessionBootstrap {
    fn ensure_session_for_directory(
        &self,
        directory: &str,
    ) -> Result<MessageDispatchSessionRef, AppError> {
        self.ensure_calls.fetch_add(1, Ordering::Relaxed);
        if self.fail {
            return Err(AppError::Agent(AgentError::Unavailable {
                message: "bootstrap failed".to_string(),
            }));
        }
        Ok(MessageDispatchSessionRef {
            provider: MessageDispatchProvider::Opencode,
            server_url: "http://127.0.0.1:4096".to_string(),
            session_id: "fake-session-id".to_string(),
            directory: Some(directory.to_string()),
        })
    }
}

pub(crate) struct FakeStore {
    known_names: Mutex<HashSet<String>>,
    fail_insert_once_with_display_name_taken: Mutex<bool>,
}

impl FakeStore {
    pub(crate) fn new(fail_insert_once_with_display_name_taken: bool) -> Self {
        Self {
            known_names: Mutex::new(HashSet::new()),
            fail_insert_once_with_display_name_taken: Mutex::new(
                fail_insert_once_with_display_name_taken,
            ),
        }
    }

    pub(crate) fn with_known_names(names: &[&str]) -> Self {
        let mut known_names = HashSet::new();
        for name in names {
            known_names.insert((*name).to_string());
        }
        Self {
            known_names: Mutex::new(known_names),
            fail_insert_once_with_display_name_taken: Mutex::new(false),
        }
    }
}

impl AgentStorePort for FakeStore {
    fn insert_agent_with_binding(
        &self,
        agent: &Agent,
        _binding: &AgentRuntimeBinding,
        _state_bindings: &[AgentStateBinding],
    ) -> Result<(), AppError> {
        let mut fail_once = self
            .fail_insert_once_with_display_name_taken
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        if *fail_once {
            *fail_once = false;
            return Err(AppError::Agent(AgentError::DisplayNameTaken));
        }
        self.known_names
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .insert(agent.display_name().to_string());
        Ok(())
    }

    fn list_agent_runtime_records(&self) -> Result<Vec<AgentRuntimeRecord>, AppError> {
        let names = self
            .known_names
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .iter()
            .cloned()
            .collect::<Vec<_>>();
        let records = names
            .iter()
            .map(|name| AgentRuntimeRecord {
                agent: Agent::new(name.clone(), AgentKind::Shell, 1),
                binding: None,
            })
            .collect::<Vec<_>>();
        Ok(records)
    }

    fn find_agent_runtime_record_by_id(
        &self,
        _id: AgentId,
    ) -> Result<Option<AgentRuntimeRecord>, AppError> {
        Ok(None)
    }

    fn list_state_bindings_by_agent_id(
        &self,
        _id: AgentId,
    ) -> Result<Vec<AgentStateBinding>, AppError> {
        Ok(Vec::new())
    }

    fn list_state_bindings_by_agent_ids(
        &self,
        _ids: &[AgentId],
    ) -> Result<Vec<AgentStateBinding>, AppError> {
        Ok(Vec::new())
    }

    fn upsert_state_binding(&self, _binding: &AgentStateBinding) -> Result<(), AppError> {
        Ok(())
    }

    fn find_agent_by_display_name(&self, display_name: &str) -> Result<Option<Agent>, AppError> {
        let exists = self
            .known_names
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
            .contains(display_name);
        Ok(exists.then(|| Agent::new(display_name.to_string(), AgentKind::Shell, 1)))
    }

    fn update_agent(&self, _updated: &Agent, _expected_version: i64) -> Result<(), AppError> {
        Ok(())
    }

    fn upsert_binding(&self, _binding: &AgentRuntimeBinding) -> Result<(), AppError> {
        Ok(())
    }

    fn update_agent_runtime_context(
        &self,
        _updated: &Agent,
        _expected_version: i64,
        _binding: &AgentRuntimeBinding,
        _upsert_state_bindings: &[AgentStateBinding],
        _delete_state_kinds: &[crate::domain::AgentStateKind],
    ) -> Result<(), AppError> {
        Ok(())
    }

    fn delete_agent(&self, _id: AgentId) -> Result<(), AppError> {
        Ok(())
    }

    fn next_display_order(&self) -> Result<i64, AppError> {
        Ok(1)
    }

    fn swap_display_order(
        &self,
        _a: &Agent,
        _a_expected_version: i64,
        _b: &Agent,
        _b_expected_version: i64,
    ) -> Result<(), AppError> {
        Ok(())
    }
}
