//! Provisioning submodules for create-time agent setup.

pub(crate) mod cleanup;
pub(crate) mod materialize;
pub(crate) mod naming;
pub(crate) mod planning;
#[cfg(test)]
pub(crate) mod test_support;
pub(crate) mod util;

use crate::application::ports::{
    AgentRuntimePort, AgentStorePort, CodexThreadPort, OpencodeSessionBootstrapPort, WorktreePort,
};

/// Shared port bundle passed to provisioning helpers.
pub(crate) struct ProvisioningPorts<'a> {
    pub(crate) store: &'a dyn AgentStorePort,
    pub(crate) runtime: &'a dyn AgentRuntimePort,
    pub(crate) worktree: &'a dyn WorktreePort,
    pub(crate) codex_threads: &'a dyn CodexThreadPort,
    pub(crate) opencode_session_bootstrap: &'a dyn OpencodeSessionBootstrapPort,
}

impl<'a> ProvisioningPorts<'a> {
    pub(crate) fn new(
        store: &'a dyn AgentStorePort,
        runtime: &'a dyn AgentRuntimePort,
        worktree: &'a dyn WorktreePort,
        codex_threads: &'a dyn CodexThreadPort,
        opencode_session_bootstrap: &'a dyn OpencodeSessionBootstrapPort,
    ) -> Self {
        Self {
            store,
            runtime,
            worktree,
            codex_threads,
            opencode_session_bootstrap,
        }
    }
}
