use std::collections::HashSet;

use crate::application::ports::AgentStorePort;
use crate::domain::{AgentKind, AgentNamePolicy, AgentRuntimeRecord};
use crate::error::AppError;

pub(crate) fn next_available_generated_name(
    store: &dyn AgentStorePort,
    agent_kind: AgentKind,
) -> Result<String, AppError> {
    // We still choose the smallest available positive index, but we scan
    // existing names once and compute the first gap in-memory. This avoids
    // one storage query per candidate (`shell-1`, `shell-2`, ...), which
    // gets expensive in larger fleets.
    let prefix = AgentNamePolicy::generated_prefix(agent_kind);
    let prefix_with_dash = format!("{prefix}-");
    let records = store.list_agent_runtime_records()?;
    let used_indices = collect_used_generated_indices(&records, &prefix_with_dash);
    let candidate_index = first_available_index(&used_indices, prefix)?;

    Ok(AgentNamePolicy::generated_candidate(
        agent_kind,
        candidate_index,
    ))
}

fn collect_used_generated_indices(
    records: &[AgentRuntimeRecord],
    prefix_with_dash: &str,
) -> HashSet<u32> {
    let mut used_indices = HashSet::<u32>::new();
    for record in records {
        let Some(raw_suffix) = record.agent.display_name().strip_prefix(prefix_with_dash) else {
            continue;
        };
        if let Ok(parsed) = raw_suffix.parse::<u32>()
            && parsed > 0
        {
            used_indices.insert(parsed);
        }
    }
    used_indices
}

fn first_available_index(used_indices: &HashSet<u32>, prefix: &str) -> Result<u32, AppError> {
    let mut candidate_index: u32 = 1;
    while used_indices.contains(&candidate_index) {
        candidate_index = candidate_index
            .checked_add(1)
            .ok_or_else(|| no_available_generated_name_error(prefix))?;
    }
    Ok(candidate_index)
}

fn no_available_generated_name_error(prefix: &str) -> AppError {
    AppError::InvalidInput {
        message: format!("no available generated session names for prefix '{prefix}'"),
    }
}
