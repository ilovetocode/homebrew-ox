use std::path::PathBuf;

use serde::Deserialize;

use crate::application::codex_thread_state::build_codex_thread_state_binding;
use crate::application::opencode_session_state::build_opencode_session_state_binding;
use crate::application::{CodexThreadStartRequest, RuntimeStartRequest};
use crate::domain::{
    Agent, AgentKind, AgentRuntimeBinding, AgentStateBinding, AgentStateKind,
    PRIMARY_STATE_BINDING_KEY,
};
use crate::error::AppError;

use super::ProvisioningPorts;
use super::cleanup::ProvisioningCleanupTxn;
use super::planning::ProvisionPlan;
use super::util::{
    build_path_state_binding, canonicalize_path, current_unix_time_ms, derive_git_root_path,
};

pub(crate) struct ProvisionArtifacts {
    pub(crate) agent: Agent,
    pub(crate) runtime_binding: AgentRuntimeBinding,
    pub(crate) state_bindings: Vec<AgentStateBinding>,
}

/// Mutable context carried across materialization steps.
struct ProvisionContext {
    now: u128,
    agent: Agent,
    resolved_working_dir: String,
    managed_worktree_repo_root: Option<String>,
    state_bindings: Vec<AgentStateBinding>,
    codex_thread_id: Option<String>,
    opencode_server_url: Option<String>,
    opencode_session_id: Option<String>,
}

pub(crate) fn materialize_provision(
    ports: &ProvisioningPorts<'_>,
    plan: &ProvisionPlan,
    cleanup: &mut ProvisioningCleanupTxn<'_>,
) -> Result<ProvisionArtifacts, AppError> {
    let now = current_unix_time_ms();
    let agent = Agent::new(plan.candidate_name.clone(), plan.agent_kind, now)
        .with_initial_display_order(ports.store.next_display_order()?);
    let mut context = ProvisionContext {
        now,
        agent,
        resolved_working_dir: plan.resolved_working_dir.clone(),
        managed_worktree_repo_root: None,
        state_bindings: Vec::new(),
        codex_thread_id: None,
        opencode_server_url: None,
        opencode_session_id: None,
    };

    materialize_git_worktree(ports, plan, cleanup, &mut context)?;
    materialize_working_dir_state(cleanup, &mut context);
    materialize_git_root_state(ports, cleanup, &mut context)?;
    materialize_codex_thread_state(ports, cleanup, &mut context)?;
    materialize_opencode_session_state(ports, cleanup, &mut context)?;

    let start_request = RuntimeStartRequest {
        agent_id: context.agent.id(),
        session_name: context.agent.display_name().to_string(),
        agent_kind: context.agent.kind(),
        working_dir: Some(PathBuf::from(context.resolved_working_dir)),
        codex_thread_id: context.codex_thread_id,
        opencode_server_url: context.opencode_server_url,
        opencode_session_id: context.opencode_session_id,
    };
    let runtime_binding = ports.runtime.start(&start_request, None)?;
    cleanup.track_runtime_binding(runtime_binding.clone());

    Ok(ProvisionArtifacts {
        agent: context.agent,
        runtime_binding,
        state_bindings: context.state_bindings,
    })
}

fn materialize_git_worktree(
    ports: &ProvisioningPorts<'_>,
    plan: &ProvisionPlan,
    cleanup: &mut ProvisioningCleanupTxn<'_>,
    context: &mut ProvisionContext,
) -> Result<(), AppError> {
    if let Some(spec) = plan.resolved_git_worktree_spec.as_ref() {
        let state = ports.worktree.create_worktree(&context.agent, spec)?;
        context.resolved_working_dir = canonicalize_path(&state.external_ref)?;
        context.managed_worktree_repo_root = worktree_repo_root(&state);
        cleanup.track_state(state.clone());
        context.state_bindings.push(state);
    }
    Ok(())
}

fn materialize_working_dir_state(
    cleanup: &mut ProvisioningCleanupTxn<'_>,
    context: &mut ProvisionContext,
) {
    // The same git repository root may be shared by many agents, so this
    // state keeps the canonical path in metadata and uses a per-agent
    // external reference key to avoid cross-agent uniqueness collisions.
    let working_dir_state = build_path_state_binding(
        &context.agent,
        AgentStateKind::WorkingDirectory,
        PRIMARY_STATE_BINDING_KEY,
        &context.resolved_working_dir,
        context.now,
    );
    cleanup.track_state(working_dir_state.clone());
    context.state_bindings.push(working_dir_state);
}

fn materialize_git_root_state(
    ports: &ProvisioningPorts<'_>,
    cleanup: &mut ProvisioningCleanupTxn<'_>,
    context: &mut ProvisionContext,
) -> Result<(), AppError> {
    let resolved_git_root = if let Some(repo_root) = context.managed_worktree_repo_root.clone() {
        Some(repo_root)
    } else {
        derive_git_root_path(ports.worktree, &context.resolved_working_dir)?
    };
    if let Some(git_root) = resolved_git_root {
        let git_root_state = build_path_state_binding(
            &context.agent,
            AgentStateKind::GitRoot,
            PRIMARY_STATE_BINDING_KEY,
            &git_root,
            context.now,
        );
        cleanup.track_state(git_root_state.clone());
        context.state_bindings.push(git_root_state);
    }
    Ok(())
}

fn materialize_codex_thread_state(
    ports: &ProvisioningPorts<'_>,
    cleanup: &mut ProvisioningCleanupTxn<'_>,
    context: &mut ProvisionContext,
) -> Result<(), AppError> {
    // Codex agents are lifecycle-managed through app-server. We bootstrap a
    // durable thread here so runtime launch can deterministically call
    // `codex resume <thread_id>` without relying on tmux/session inference.
    if context.agent.kind() == AgentKind::Codex {
        let bootstrap = ports.codex_threads.start_thread(&CodexThreadStartRequest {
            working_dir: Some(PathBuf::from(context.resolved_working_dir.clone())),
        })?;
        let codex_state = build_codex_thread_state_binding(
            &context.agent,
            bootstrap.thread_id.as_str(),
            bootstrap.event_count,
            context.now,
        );
        cleanup.track_state(codex_state.clone());
        context.state_bindings.push(codex_state);
        context.codex_thread_id = Some(bootstrap.thread_id);
    }
    Ok(())
}

fn materialize_opencode_session_state(
    ports: &ProvisioningPorts<'_>,
    cleanup: &mut ProvisioningCleanupTxn<'_>,
    context: &mut ProvisionContext,
) -> Result<(), AppError> {
    // OpenCode agents get a provider-managed session created through the
    // HTTP API at provision time. The session reference is persisted as an
    // agent state binding so status resolution and messaging can look it up.
    if context.agent.kind() == AgentKind::Opencode {
        let session = ports
            .opencode_session_bootstrap
            .ensure_session_for_directory(&context.resolved_working_dir)?;
        let opencode_state = build_opencode_session_state_binding(
            &context.agent,
            &session.server_url,
            &session.session_id,
            "basic",
            session.directory.as_deref(),
            context.now,
        );
        cleanup.track_state(opencode_state.clone());
        context.state_bindings.push(opencode_state);
        context.opencode_server_url = Some(session.server_url);
        context.opencode_session_id = Some(session.session_id);
    }
    Ok(())
}

pub(crate) fn persist_provision(
    ports: &ProvisioningPorts<'_>,
    artifacts: &ProvisionArtifacts,
) -> Result<(), AppError> {
    ports.store.insert_agent_with_binding(
        &artifacts.agent,
        &artifacts.runtime_binding,
        &artifacts.state_bindings,
    )
}

#[derive(Deserialize)]
struct GitWorktreeStateMetadata {
    repo_root: Option<String>,
}

fn worktree_repo_root(state: &AgentStateBinding) -> Option<String> {
    serde_json::from_str::<GitWorktreeStateMetadata>(&state.metadata_json)
        .ok()
        .and_then(|metadata| metadata.repo_root)
}
