use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

use crate::application::ports::WorktreePort;
use crate::domain::{Agent, AgentStateBinding, AgentStateKind, AgentStateProvider};
use crate::error::AppError;

pub(crate) fn derive_git_root_path(
    worktree: &dyn WorktreePort,
    working_dir: &str,
) -> Result<Option<String>, AppError> {
    let Some(git_root) = worktree.parent_git_root(working_dir)? else {
        return Ok(None);
    };
    canonicalize_path(&git_root).map(Some)
}

pub(crate) fn canonicalize_path(path: &str) -> Result<String, AppError> {
    let canonical = std::fs::canonicalize(path).map_err(|source| AppError::InvalidInput {
        message: format!("invalid path '{path}': {source}"),
    })?;
    Ok(canonical.to_string_lossy().to_string())
}

pub(crate) fn build_path_state_binding(
    agent: &Agent,
    state_kind: AgentStateKind,
    binding_key: &str,
    path: &str,
    now_unix_ms: u128,
) -> AgentStateBinding {
    let metadata = serde_json::json!({ "path": path });
    AgentStateBinding::new(
        agent.id(),
        state_kind,
        AgentStateProvider::Git,
        binding_key.to_string(),
        format!("{}:{state_kind:?}:{binding_key}", agent.id().as_str()),
        metadata.to_string(),
        now_unix_ms,
    )
}

pub(crate) fn generate_worktree_label_token() -> String {
    static NEXT_ID: AtomicU64 = AtomicU64::new(1);
    let counter = u128::from(NEXT_ID.fetch_add(1, Ordering::Relaxed));
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_nanos());
    let mixed = nanos ^ (counter << 16);

    // This is UUID-shaped (8-4-4-4-12 hex) so default labels are easy to scan.
    let segment_1 = mixed & 0xffff_ffff;
    let segment_2 = (mixed >> 32) & 0xffff;
    let segment_3 = (mixed >> 48) & 0xffff;
    let segment_4 = (mixed >> 64) & 0xffff;
    let segment_5 = (mixed >> 80) & 0xfff_ffff_ffff;
    format!("{segment_1:08x}-{segment_2:04x}-{segment_3:04x}-{segment_4:04x}-{segment_5:012x}")
}

pub(crate) fn current_unix_time_ms() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_millis())
}
