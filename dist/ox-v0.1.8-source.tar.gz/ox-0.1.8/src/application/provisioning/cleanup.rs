use crate::application::ports::{AgentRuntimePort, WorktreePort};
use crate::domain::{AgentRuntimeBinding, AgentStateBinding, AgentStateKind};

/// Tracks create-time resources and performs rollback on error paths.
///
/// Rust calls `Drop::drop` automatically when this value leaves scope, so any
/// early `return`/`continue` still triggers best-effort cleanup unless `commit`
/// was called.
pub(crate) struct ProvisioningCleanupTxn<'a> {
    runtime: &'a dyn AgentRuntimePort,
    worktree: &'a dyn WorktreePort,
    state_bindings: Vec<AgentStateBinding>,
    runtime_binding: Option<AgentRuntimeBinding>,
    committed: bool,
}

impl<'a> ProvisioningCleanupTxn<'a> {
    pub(crate) fn begin(runtime: &'a dyn AgentRuntimePort, worktree: &'a dyn WorktreePort) -> Self {
        Self {
            runtime,
            worktree,
            state_bindings: Vec::new(),
            runtime_binding: None,
            committed: false,
        }
    }

    pub(crate) fn track_state(&mut self, state: AgentStateBinding) {
        self.state_bindings.push(state);
    }

    pub(crate) fn track_runtime_binding(&mut self, binding: AgentRuntimeBinding) {
        self.runtime_binding = Some(binding);
    }

    pub(crate) fn commit(&mut self) {
        self.committed = true;
    }
}

impl Drop for ProvisioningCleanupTxn<'_> {
    fn drop(&mut self) {
        if self.committed {
            return;
        }

        if let Some(binding) = self.runtime_binding.as_ref() {
            let _ = self.runtime.stop(binding);
        }
        for state in self.state_bindings.iter().rev() {
            if state.state_kind == AgentStateKind::GitWorktree {
                let _ = self.worktree.delete_worktree(state);
            }
        }
    }
}
