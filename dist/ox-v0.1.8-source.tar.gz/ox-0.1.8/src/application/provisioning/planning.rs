use std::convert::TryFrom;

use crate::application::{CreateAgentRequest, GitWorktreeCreateSpec, ResolvedGitWorktreeSpec};
use crate::domain::{
    AgentDisplayName, AgentKind, GitWorktreeSpecInput,
    ResolvedGitWorktreeSpec as DomainResolvedGitWorktreeSpec,
};
use crate::error::{AgentError, AppError};

use super::ProvisioningPorts;
use super::util::{canonicalize_path, generate_worktree_label_token};

pub(crate) struct ProvisionInput {
    pub(crate) requested_name: String,
    pub(crate) agent_kind: AgentKind,
    pub(crate) working_dir: Option<String>,
    pub(crate) git_worktree: Option<GitWorktreeCreateSpec>,
    pub(crate) generated_name: bool,
}

pub(crate) struct ProvisionPlan {
    pub(crate) candidate_name: String,
    pub(crate) agent_kind: AgentKind,
    pub(crate) resolved_working_dir: String,
    pub(crate) resolved_git_worktree_spec: Option<ResolvedGitWorktreeSpec>,
}

impl ProvisionInput {
    pub(crate) fn from_request(request: CreateAgentRequest) -> Self {
        let CreateAgentRequest {
            display_name,
            agent_kind,
            working_dir,
            state_spec,
            ..
        } = request;
        let requested_name = display_name.trim().to_string();
        let generated_name = requested_name.is_empty();

        Self {
            requested_name,
            agent_kind,
            working_dir,
            git_worktree: state_spec.git_worktree,
            generated_name,
        }
    }
}

pub(crate) fn plan_provision(
    ports: &ProvisioningPorts<'_>,
    input: &ProvisionInput,
    candidate_name: &str,
) -> Result<ProvisionPlan, AppError> {
    validate_display_name(candidate_name)?;
    if ports
        .store
        .find_agent_by_display_name(candidate_name)?
        .is_some()
    {
        return Err(AppError::Agent(AgentError::DisplayNameTaken));
    }

    let resolved_working_dir = resolve_working_dir_path(input.working_dir.as_deref())?;
    let resolved_git_worktree_spec = input
        .git_worktree
        .as_ref()
        .map(|spec| {
            let mut resolved_spec = spec.clone();
            if resolved_spec.repo_root.is_none() {
                resolved_spec.repo_root = Some(resolved_working_dir.clone());
            }
            resolve_git_worktree_spec(&resolved_spec)
        })
        .transpose()?;

    Ok(ProvisionPlan {
        candidate_name: candidate_name.to_string(),
        agent_kind: input.agent_kind,
        resolved_working_dir,
        resolved_git_worktree_spec,
    })
}

pub(crate) fn validate_display_name(display_name: &str) -> Result<(), AppError> {
    AgentDisplayName::try_from(display_name)
        .map(|_| ())
        .map_err(|message| AppError::InvalidInput {
            message: message.to_string(),
        })
}

pub(crate) fn resolve_git_worktree_spec(
    spec: &GitWorktreeCreateSpec,
) -> Result<ResolvedGitWorktreeSpec, AppError> {
    let input = GitWorktreeSpecInput {
        worktree_name: spec.worktree_name.clone(),
        branch_name: spec.branch_name.clone(),
        base_ref: spec.base_ref.clone(),
        repo_root: spec.repo_root.clone(),
    };
    let resolved = input
        .resolve(generate_worktree_label_token())
        .map_err(|message| AppError::InvalidInput {
            message: message.to_string(),
        })?;
    Ok(from_domain_resolved_worktree_spec(resolved))
}

fn from_domain_resolved_worktree_spec(
    value: DomainResolvedGitWorktreeSpec,
) -> ResolvedGitWorktreeSpec {
    ResolvedGitWorktreeSpec {
        worktree_label: value.worktree_label,
        base_ref: value.base_ref,
        repo_root: value.repo_root,
    }
}

pub(crate) fn resolve_working_dir_path(
    requested_working_dir: Option<&str>,
) -> Result<String, AppError> {
    if let Some(path) = requested_working_dir {
        return canonicalize_path(path);
    }

    let cwd = std::env::current_dir().map_err(|source| {
        AppError::Agent(AgentError::Unavailable {
            message: format!("failed to resolve process working directory: {source}"),
        })
    })?;
    canonicalize_path(cwd.to_string_lossy().as_ref())
}

pub(crate) fn resolve_create_display_name(
    requested_name: &str,
    agent_kind: AgentKind,
    next_available_generated_name: impl Fn(AgentKind) -> Result<String, AppError>,
) -> Result<String, AppError> {
    if requested_name.is_empty() {
        return next_available_generated_name(agent_kind);
    }
    Ok(requested_name.to_string())
}

pub(crate) fn should_retry_generated_name_conflict(err: &AppError, generated_name: bool) -> bool {
    generated_name && matches!(err, AppError::Agent(AgentError::DisplayNameTaken))
}
