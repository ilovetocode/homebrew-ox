//! Shared application boundary consumed by both frontends.
//!
//! This module defines the single frontend contract for the whole app. CLI and
//! TUI each depend on `dyn AppApi` instead of reaching into subsystem
//! implementations directly.

use crate::application::{
    AgentView, ConversationReadResult, CreateAgentRequest, DoctorReport, LoggedEvent,
    MessageDispatchResult, StatusReport,
};
use crate::domain::AgentId;
use crate::error::AppError;

/// TUI-specific result for mutations that must immediately reconcile the fleet.
///
/// The TUI needs a refreshed fleet snapshot after create/rename/delete so the
/// interface can preserve stable selection without performing a second round of
/// refresh orchestration itself.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct TuiFleetSnapshot {
    pub(crate) agents: Vec<AgentView>,
    pub(crate) selected_agent_id: Option<AgentId>,
}

/// Agent selection the dashboard should restore after a tmux attach returns.
///
/// The attach request can start on one agent, then the user can quick-switch to
/// another session from inside tmux before detaching. The TUI needs the final
/// detached target so it does not jump back to stale selection.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct TuiAttachReturn {
    pub(crate) id: AgentId,
    pub(crate) name: String,
}

/// Focused application contract consumed by the TUI runtime.
///
/// This keeps interactive interface code dependent on the smallest surface it
/// actually needs rather than the full CLI-facing application facade.
pub(crate) trait TuiApi: Send + Sync {
    fn tui_refresh_interval_ms(&self) -> u64;
    fn tui_list_agents(&self) -> Result<Vec<AgentView>, AppError>;
    fn tui_status_report(&self) -> Result<StatusReport, AppError>;
    fn tui_create_agent(&self, request: CreateAgentRequest) -> Result<TuiFleetSnapshot, AppError>;
    fn tui_rename_agent(
        &self,
        id: &AgentId,
        new_display_name: &str,
    ) -> Result<TuiFleetSnapshot, AppError>;
    fn tui_delete_agent(&self, id: &AgentId) -> Result<TuiFleetSnapshot, AppError>;
    fn tui_switch_agent_to_worktree_shell(
        &self,
        id: &AgentId,
        branch_name: &str,
    ) -> Result<TuiFleetSnapshot, AppError>;
    fn tui_connect_agent(&self, id: &AgentId) -> Result<(), AppError>;
    fn tui_resolve_attach_return(
        &self,
        requested_id: &AgentId,
        attach_started_at_unix_ms: u128,
    ) -> Result<TuiAttachReturn, AppError>;
    fn tui_capture_agent_output(&self, id: &AgentId, lines: u16) -> Result<String, AppError>;
    fn tui_send_key_to_agent(&self, id: &AgentId, key: &str) -> Result<(), AppError>;
}

/// Diagnostics and shared read operations exposed to frontends.
pub(crate) trait AppDiagnostics: Send + Sync {
    fn status_report(&self) -> Result<StatusReport, AppError>;
    fn doctor_report(&self, fix: bool) -> Result<DoctorReport, AppError>;
    fn reconcile_pinned_sessions(&self) -> Result<(), AppError>;
    fn recent_events(&self, limit: usize) -> Result<Vec<LoggedEvent>, AppError>;
    fn events_default_limit(&self) -> usize;
}

/// Agent-facing application capabilities exposed to frontends.
pub(crate) trait AppAgents: Send + Sync {
    fn list_agents(&self) -> Result<Vec<AgentView>, AppError>;

    /// Return a minimal agent list for quick-switch style UIs.
    fn list_agents_for_picker(&self) -> Result<Vec<AgentView>, AppError> {
        self.list_agents()
    }

    fn resolve_agent_selector(&self, selector: &str) -> Result<AgentId, AppError>;
    fn create_agent(&self, request: CreateAgentRequest) -> Result<AgentId, AppError>;
    fn rename_agent(&self, id: &AgentId, new_display_name: &str) -> Result<(), AppError>;
    fn reorder_agent(&self, id: &AgentId, target_position: i64) -> Result<(), AppError>;
    fn delete_agent(&self, id: &AgentId) -> Result<(), AppError>;
    fn switch_agent_to_worktree_shell(
        &self,
        id: &AgentId,
        branch_name: &str,
    ) -> Result<(), AppError>;
    fn connect_agent(&self, id: &AgentId) -> Result<(), AppError>;
    fn disconnect_to_dashboard(&self) -> Result<(), AppError>;
    fn send_key_to_agent(&self, id: &AgentId, key: &str) -> Result<(), AppError>;
    fn send_message_to_agent(
        &self,
        id: &AgentId,
        message: &str,
    ) -> Result<MessageDispatchResult, AppError>;
    fn send_slash_command_to_agent(
        &self,
        id: &AgentId,
        command: &str,
    ) -> Result<MessageDispatchResult, AppError>;
    fn read_last_message_from_agent(
        &self,
        id: &AgentId,
    ) -> Result<ConversationReadResult, AppError>;
    fn read_full_conversation_from_agent(
        &self,
        id: &AgentId,
    ) -> Result<ConversationReadResult, AppError>;
}

/// Single global application interface used by CLI and TUI.
pub(crate) trait AppApi: TuiApi + AppDiagnostics + AppAgents + Send + Sync {}

impl<T> AppApi for T where T: TuiApi + AppDiagnostics + AppAgents + Send + Sync {}
