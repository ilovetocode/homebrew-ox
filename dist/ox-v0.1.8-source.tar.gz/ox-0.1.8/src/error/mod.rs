//! Error types used by the `ox` application and library entrypoint.
//!
//! `AppError` is the top-level error returned by [`crate::run`], while the
//! other enums keep failure causes grouped by domain (tmux, startup, storage,
//! and agent lifecycle).

/// Top-level error type for user-facing command execution.
///
/// This enum intentionally wraps lower-level error categories so interface
/// layers can render one consistent error channel without losing root cause.
#[derive(Debug, thiserror::Error)]
pub enum AppError {
    /// Tmux configuration resolution failures.
    #[error(transparent)]
    Config(#[from] ConfigError),
    /// Terminal I/O failures in TUI mode.
    #[error(transparent)]
    Io(#[from] std::io::Error),
    /// Tmux command execution or parsing failures.
    #[error(transparent)]
    Tmux(#[from] TmuxError),
    /// Startup preflight failures for external dependencies.
    #[error(transparent)]
    Startup(#[from] StartupError),
    /// Invalid user input, such as an invalid session name.
    #[error("invalid input: {message}")]
    InvalidInput { message: String },
    /// Persistent app-state file system failures.
    #[error(transparent)]
    Storage(#[from] StorageError),
    /// Domain/application-level agent workflow errors.
    #[error(transparent)]
    Agent(#[from] AgentError),
    /// Error output was already rendered by the CLI in structured form.
    ///
    /// This preserves non-zero exits without printing duplicate error text.
    #[error("")]
    AlreadyReported,
}

/// Closed set of agent-domain/application errors.
///
/// These errors describe business-level agent workflow failures and are
/// converted into [`AppError::Agent`] at the application boundary.
#[derive(Debug, thiserror::Error)]
pub enum AgentError {
    /// Agent row does not exist.
    #[error("agent not found")]
    NotFound,
    /// A conflicting display name already exists.
    #[error("display name is already taken")]
    DisplayNameTaken,
    /// Runtime binding is required but missing.
    #[error("agent runtime binding is missing")]
    BindingMissing,
    /// Optimistic-concurrency update/delete failed.
    #[error("agent version conflict")]
    VersionConflict,
    /// Runtime provider could not be reached or reconciled.
    #[error("agent runtime unavailable: {message}")]
    Unavailable { message: String },
    /// Provider session was created in an unexpected directory.
    #[error(
        "opencode directory mismatch: requested '{requested_directory}' but server '{server_url}' returned '{returned_directory}'"
    )]
    DirectoryAffinityMismatch {
        server_url: String,
        requested_directory: String,
        returned_directory: String,
    },
}

/// Errors related to resolving tmux config file paths.
///
/// These failures happen while preparing or reconciling managed tmux config
/// state before runtime commands execute.
#[derive(Debug, thiserror::Error)]
pub enum ConfigError {
    /// The process environment lacks `HOME` while `~` expansion is requested.
    #[error("HOME is not set; cannot expand '~' in tmux config path")]
    HomeMissing,
    /// Unsupported path style was provided.
    #[error("paths like ~user/... are not supported; use ~/... or an absolute path")]
    UnsupportedTildeForm,
    /// Failed creating the parent directory for the tmux config file.
    #[error("could not create tmux config directory '{path}': {source}")]
    CreateDir {
        path: std::path::PathBuf,
        source: std::io::Error,
    },
    /// Failed creating or initializing the tmux config file.
    #[error("could not create tmux config file '{path}': {source}")]
    CreateFile {
        path: std::path::PathBuf,
        source: std::io::Error,
    },
    /// Failed creating the lock file used to serialize managed writes.
    #[error("could not create tmux config lock file '{path}': {source}")]
    LockFile {
        path: std::path::PathBuf,
        source: std::io::Error,
    },
    /// Another process held the lock for too long.
    #[error("timed out waiting for tmux config lock '{path}'")]
    LockTimeout { path: std::path::PathBuf },
}

/// Errors related to tmux command execution and output parsing.
///
/// `TmuxError` is used for both command invocation failures and parser errors
/// from expected tmux row formats.
#[derive(Debug, thiserror::Error)]
pub enum TmuxError {
    /// Process execution failed before tmux returned an exit code.
    #[error(transparent)]
    Io(#[from] std::io::Error),
    /// Tmux returned a non-success exit code.
    #[error("tmux command failed: {stderr}")]
    CommandFailed { stderr: String },
    /// Output row could not be parsed into expected fields.
    #[error("invalid tmux output: {message}")]
    Parse { message: String },
    /// External command did not complete within the allowed deadline.
    #[error("command timed out after {seconds}s")]
    Timeout { seconds: u64 },
}

/// Return true when tmux stderr indicates the target session no longer exists.
pub(crate) fn tmux_stderr_is_missing_session(stderr: &str) -> bool {
    stderr.contains("can't find session")
}

/// Return true when tmux stderr indicates the target pane no longer exists.
pub(crate) fn tmux_stderr_is_missing_pane(stderr: &str) -> bool {
    stderr.contains("can't find pane")
}

/// Return true when tmux stderr indicates no daemon is reachable.
pub(crate) fn tmux_stderr_is_no_server(stderr: &str) -> bool {
    stderr.contains("no server running")
        || stderr.contains("failed to connect")
        // Newer tmux builds on macOS can report a missing socket using
        // "error connecting to ... (No such file or directory)" instead of
        // the older "no server running" wording. Treat both as the same
        // recoverable "no server" condition.
        || stderr.contains("error connecting to")
}

/// Return true when tmux stderr indicates there is no attached client.
pub(crate) fn tmux_stderr_is_no_current_client(stderr: &str) -> bool {
    stderr.contains("no current client")
}

/// Return true when tmux stderr describes a recoverable missing-runtime case.
pub(crate) fn tmux_stderr_is_recoverable_missing_runtime(stderr: &str) -> bool {
    tmux_stderr_is_missing_session(stderr)
        || tmux_stderr_is_missing_pane(stderr)
        || tmux_stderr_is_no_server(stderr)
}

/// Return true when an app error is a recoverable missing tmux runtime failure.
pub(crate) fn app_error_is_recoverable_missing_tmux_runtime(err: &AppError) -> bool {
    matches!(
        err,
        AppError::Tmux(TmuxError::CommandFailed { stderr })
            if tmux_stderr_is_recoverable_missing_runtime(stderr)
    )
}

/// Errors from startup preflight checks.
///
/// Startup checks run before command execution to fail fast when required
/// external dependencies are unavailable or misconfigured.
#[derive(Debug, thiserror::Error)]
pub enum StartupError {
    /// `tmux` binary is not available on PATH.
    #[error(
        "startup check failed: ox cannot start because tmux is not on PATH.\n\
         external requirements:\n\
         - install tmux\n\
         - ensure `tmux` is available in PATH\n\
         - ensure tmux config path is writable (managed path: ~/.config/ox/tmux.conf)"
    )]
    MissingTmux,
    /// Probing `tmux -V` failed for another IO reason.
    #[error("startup check failed while probing tmux (`tmux -V`): {source}")]
    ProbeIo { source: std::io::Error },
    /// Probing `tmux -V` returned a non-success exit code.
    #[error(
        "startup check failed: `tmux -V` exited with non-zero status (code: {code:?}). \
         ensure tmux is installed and working correctly"
    )]
    ProbeFailed { code: Option<i32> },
}

/// Errors related to persistent runtime state and logs.
///
/// These errors cover file-system access, `SQLite` operations, and config JSON
/// parsing/serialization used by persistent app state.
#[derive(Debug, thiserror::Error)]
pub enum StorageError {
    /// The process environment lacks `HOME` while resolving managed storage paths.
    #[error("HOME is not set; cannot resolve managed data directory path")]
    HomeMissing,
    /// Failed creating the persistent data directory.
    #[error("could not create data directory '{path}': {source}")]
    CreateDir {
        path: std::path::PathBuf,
        source: std::io::Error,
    },
    /// Failed while executing a `SQLite` operation.
    #[error("sqlite error while trying to {context}: {source}")]
    Sqlite {
        context: String,
        source: rusqlite::Error,
    },
    /// In-memory lock for the `SQLite` connection was poisoned.
    #[error("sqlite connection lock poisoned: {message}")]
    LockPoisoned { message: String },
    /// Failed reading or writing `config.json`.
    #[error("could not access config file '{path}': {source}")]
    ConfigFileIo {
        path: std::path::PathBuf,
        source: std::io::Error,
    },
    /// Failed parsing `config.json`.
    #[error("invalid config JSON in '{path}': {source}")]
    ConfigParse {
        path: std::path::PathBuf,
        source: serde_json::Error,
    },
    /// Failed serializing `config.json`.
    #[error("could not serialize config JSON: {source}")]
    ConfigSerialize { source: serde_json::Error },
    /// Failed reading or writing pinned sessions YAML.
    #[error("could not access pinned sessions file '{path}': {source}")]
    PinnedSessionsFileIo {
        path: std::path::PathBuf,
        source: std::io::Error,
    },
    /// Failed parsing pinned sessions YAML.
    #[error("invalid pinned sessions YAML in '{path}': {source}")]
    PinnedSessionsParse {
        path: std::path::PathBuf,
        source: serde_yaml::Error,
    },
    /// Failed serializing pinned sessions YAML.
    #[error("could not serialize pinned sessions YAML: {source}")]
    PinnedSessionsSerialize { source: serde_yaml::Error },
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn agent_error_not_found_display() {
        let err = AgentError::NotFound;
        assert_eq!(err.to_string(), "agent not found");
    }

    #[test]
    fn agent_error_display_name_taken() {
        let err = AgentError::DisplayNameTaken;
        assert_eq!(err.to_string(), "display name is already taken");
    }

    #[test]
    fn agent_error_binding_missing() {
        let err = AgentError::BindingMissing;
        assert_eq!(err.to_string(), "agent runtime binding is missing");
    }

    #[test]
    fn agent_error_version_conflict() {
        let err = AgentError::VersionConflict;
        assert_eq!(err.to_string(), "agent version conflict");
    }

    #[test]
    fn agent_error_unavailable() {
        let err = AgentError::Unavailable {
            message: "tmux not running".to_string(),
        };
        assert_eq!(
            err.to_string(),
            "agent runtime unavailable: tmux not running"
        );
    }

    #[test]
    fn agent_error_directory_affinity_mismatch() {
        let err = AgentError::DirectoryAffinityMismatch {
            server_url: "http://127.0.0.1:4096".to_string(),
            requested_directory: "/tmp/ox".to_string(),
            returned_directory: "/tmp/vault".to_string(),
        };
        assert!(err.to_string().contains("requested '/tmp/ox'"));
        assert!(err.to_string().contains("returned '/tmp/vault'"));
    }

    #[test]
    fn config_error_home_missing() {
        let err = ConfigError::HomeMissing;
        assert!(err.to_string().contains("HOME is not set"));
    }

    #[test]
    fn config_error_unsupported_tilde_form() {
        let err = ConfigError::UnsupportedTildeForm;
        assert!(err.to_string().contains("~user/..."));
    }

    #[test]
    fn tmux_error_command_failed() {
        let err = TmuxError::CommandFailed {
            stderr: "no server running".to_string(),
        };
        assert!(err.to_string().contains("no server running"));
    }

    #[test]
    fn tmux_error_parse() {
        let err = TmuxError::Parse {
            message: "bad row".to_string(),
        };
        assert_eq!(err.to_string(), "invalid tmux output: bad row");
    }

    #[test]
    fn tmux_error_timeout() {
        let err = TmuxError::Timeout { seconds: 10 };
        assert_eq!(err.to_string(), "command timed out after 10s");
    }

    #[test]
    fn tmux_stderr_no_server_accepts_missing_socket_connect_error() {
        assert!(tmux_stderr_is_no_server(
            "error connecting to /tmp/tmux-1000/default (No such file or directory)"
        ));
    }

    #[test]
    fn startup_error_missing_tmux() {
        let err = StartupError::MissingTmux;
        assert!(err.to_string().contains("tmux is not on PATH"));
    }

    #[test]
    fn startup_error_probe_failed() {
        let err = StartupError::ProbeFailed { code: Some(1) };
        assert!(err.to_string().contains("non-zero status"));
    }

    #[test]
    fn app_error_invalid_input() {
        let err = AppError::InvalidInput {
            message: "bad name".to_string(),
        };
        assert_eq!(err.to_string(), "invalid input: bad name");
    }

    #[test]
    fn app_error_already_reported() {
        let err = AppError::AlreadyReported;
        assert_eq!(err.to_string(), "");
    }

    #[test]
    fn app_error_from_agent_error() {
        let agent_err = AgentError::NotFound;
        let app_err = AppError::from(agent_err);
        assert!(
            matches!(app_err, AppError::Agent(AgentError::NotFound)),
            "should convert from AgentError"
        );
        assert_eq!(app_err.to_string(), "agent not found");
    }

    #[test]
    fn storage_error_home_missing() {
        let err = StorageError::HomeMissing;
        assert!(err.to_string().contains("HOME is not set"));
    }

    #[test]
    fn storage_error_lock_poisoned() {
        let err = StorageError::LockPoisoned {
            message: "poisoned".to_string(),
        };
        assert!(err.to_string().contains("poisoned"));
    }
}
