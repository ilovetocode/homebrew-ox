//! Binary entrypoint for the `ox` CLI.
//!
//! This crate delegates business behavior to the library crate and keeps
//! process exit handling at the executable boundary.
//!
#![deny(clippy::unwrap_used)]
#![deny(clippy::expect_used)]
#![deny(clippy::panic)]
#![deny(clippy::todo)]
#![deny(clippy::unimplemented)]
#![deny(clippy::dbg_macro)]
#![forbid(unsafe_code)]

#[cfg(feature = "dhat-heap")]
#[global_allocator]
static ALLOC: dhat::Alloc = dhat::Alloc;

fn main() {
    #[cfg(feature = "dhat-heap")]
    let _profiler = dhat::Profiler::new_heap();

    if let Err(err) = ox::run() {
        let message = err.to_string();
        if !message.is_empty() {
            eprintln!("error: {message}");
        }
        std::process::exit(1);
    }
}
