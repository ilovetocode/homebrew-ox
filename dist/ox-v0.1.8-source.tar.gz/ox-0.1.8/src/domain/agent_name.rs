use std::convert::TryFrom;

use crate::domain::{AgentKind, SessionName};

/// Strongly typed display name for one agent/session.
///
/// This wraps `SessionName` so agent naming rules are defined once in the
/// domain and reused by application services.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct AgentDisplayName(SessionName);

impl TryFrom<&str> for AgentDisplayName {
    type Error = &'static str;

    fn try_from(value: &str) -> Result<Self, Self::Error> {
        SessionName::try_from(value).map(Self)
    }
}

impl TryFrom<String> for AgentDisplayName {
    type Error = &'static str;

    fn try_from(value: String) -> Result<Self, Self::Error> {
        AgentDisplayName::try_from(value.as_str())
    }
}

/// Domain naming policy for generated display names.
pub(crate) struct AgentNamePolicy;

impl AgentNamePolicy {
    /// Return the stable generated-name prefix for one agent kind.
    pub(crate) fn generated_prefix(agent_kind: AgentKind) -> &'static str {
        agent_kind.as_str()
    }

    /// Build one generated candidate using `<prefix>-<index>`.
    pub(crate) fn generated_candidate(agent_kind: AgentKind, index: u32) -> String {
        format!("{}-{index}", Self::generated_prefix(agent_kind))
    }
}

#[cfg(test)]
mod tests {
    use super::{AgentDisplayName, AgentNamePolicy};
    use crate::domain::AgentKind;
    use std::convert::TryFrom;

    #[test]
    fn display_name_reuses_session_name_validation() {
        assert!(AgentDisplayName::try_from("ok-name_1").is_ok());
        assert!(AgentDisplayName::try_from("bad name").is_err());
    }

    #[test]
    fn generated_prefix_matches_kind() {
        assert_eq!(AgentNamePolicy::generated_prefix(AgentKind::Shell), "shell");
        assert_eq!(AgentNamePolicy::generated_prefix(AgentKind::Codex), "codex");
        assert_eq!(
            AgentNamePolicy::generated_prefix(AgentKind::Opencode),
            "opencode"
        );
        assert_eq!(
            AgentNamePolicy::generated_prefix(AgentKind::Claude),
            "claude"
        );
    }

    #[test]
    fn generated_candidate_uses_prefix_and_index() {
        assert_eq!(
            AgentNamePolicy::generated_candidate(AgentKind::Shell, 7),
            "shell-7"
        );
    }
}
