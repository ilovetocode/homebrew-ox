use crate::domain::AgentDisplayName;

/// Input settings for resolving one managed git worktree create request.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct GitWorktreeSpecInput {
    pub(crate) worktree_name: Option<String>,
    pub(crate) branch_name: Option<String>,
    pub(crate) base_ref: Option<String>,
    pub(crate) repo_root: Option<String>,
}

/// Fully resolved worktree settings after domain-level defaulting.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct ResolvedGitWorktreeSpec {
    pub(crate) worktree_label: String,
    pub(crate) base_ref: String,
    pub(crate) repo_root: Option<String>,
}

impl GitWorktreeSpecInput {
    /// Resolve one create specification into canonical values.
    ///
    /// `generated_label` is only used when neither worktree nor branch names
    /// are explicitly provided.
    pub(crate) fn resolve(
        &self,
        generated_label: String,
    ) -> Result<ResolvedGitWorktreeSpec, &'static str> {
        let worktree_name = self.worktree_name.as_deref().map(str::trim);
        let branch_name = self.branch_name.as_deref().map(str::trim);

        let resolved_label = match (worktree_name, branch_name) {
            (Some(name), Some(branch)) if name != branch => {
                return Err("worktree name and branch name must match when both are provided");
            }
            (Some(name), _) if !name.is_empty() => name.to_string(),
            (_, Some(branch)) if !branch.is_empty() => branch.to_string(),
            _ => generated_label,
        };
        AgentDisplayName::try_from(resolved_label.as_str())?;

        let base_ref = self
            .base_ref
            .as_deref()
            .map(str::trim)
            .filter(|value| !value.is_empty())
            .unwrap_or("HEAD")
            .to_string();

        Ok(ResolvedGitWorktreeSpec {
            worktree_label: resolved_label,
            base_ref,
            repo_root: self.repo_root.clone(),
        })
    }
}

#[cfg(test)]
mod tests {
    use super::GitWorktreeSpecInput;

    #[test]
    fn resolve_rejects_mismatched_names() {
        let spec = GitWorktreeSpecInput {
            worktree_name: Some("a".to_string()),
            branch_name: Some("b".to_string()),
            base_ref: None,
            repo_root: None,
        };
        assert!(spec.resolve("generated".to_string()).is_err());
    }

    #[test]
    fn resolve_defaults_base_ref_to_head() {
        let spec = GitWorktreeSpecInput {
            worktree_name: Some("dev".to_string()),
            branch_name: Some("dev".to_string()),
            base_ref: None,
            repo_root: None,
        };
        let resolved = spec.resolve("generated".to_string());
        assert!(resolved.is_ok(), "expected valid resolved spec");
        let Ok(resolved) = resolved else { return };
        assert_eq!(resolved.base_ref, "HEAD");
    }

    #[test]
    fn resolve_uses_generated_label_when_missing_names() {
        let spec = GitWorktreeSpecInput {
            worktree_name: None,
            branch_name: None,
            base_ref: None,
            repo_root: None,
        };
        let resolved = spec.resolve("gen-1".to_string());
        assert!(resolved.is_ok(), "expected valid resolved spec");
        let Ok(resolved) = resolved else { return };
        assert_eq!(resolved.worktree_label, "gen-1");
    }
}
