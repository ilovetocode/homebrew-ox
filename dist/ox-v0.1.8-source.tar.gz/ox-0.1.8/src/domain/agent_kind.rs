/// Supported agent runtimes that can be launched inside a tmux session.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum AgentKind {
    // `Shell` is retained for now even though it is not an AI agent, so list
    // output can represent "no agent detected" without an `Option`.
    Shell,
    Codex,
    Opencode,
    Claude,
}

/// Canonical comma-separated list used in validation error messages.
pub(crate) const AGENT_KIND_VALUES_CSV: &str = "shell, codex, opencode, claude";

impl AgentKind {
    /// Return the canonical lowercase token used for persistence and labels.
    pub(crate) fn as_str(self) -> &'static str {
        match self {
            AgentKind::Shell => "shell",
            AgentKind::Codex => "codex",
            AgentKind::Opencode => "opencode",
            AgentKind::Claude => "claude",
        }
    }

    /// Parse an exact persisted token without trimming or case folding.
    pub(crate) fn parse_exact(raw: &str) -> Option<Self> {
        match raw {
            "shell" => Some(AgentKind::Shell),
            "codex" => Some(AgentKind::Codex),
            "opencode" => Some(AgentKind::Opencode),
            "claude" => Some(AgentKind::Claude),
            _ => None,
        }
    }

    /// Parse user input with trim + ASCII lowercase normalization.
    pub(crate) fn parse_user_input(raw: &str) -> Option<Self> {
        let normalized = raw.trim().to_ascii_lowercase();
        Self::parse_exact(normalized.as_str())
    }
}

#[cfg(test)]
mod tests {
    use super::AgentKind;

    #[test]
    fn as_str_uses_canonical_lowercase_tokens() {
        assert_eq!(AgentKind::Shell.as_str(), "shell");
        assert_eq!(AgentKind::Codex.as_str(), "codex");
        assert_eq!(AgentKind::Opencode.as_str(), "opencode");
        assert_eq!(AgentKind::Claude.as_str(), "claude");
    }

    #[test]
    fn parse_exact_requires_canonical_token() {
        assert_eq!(AgentKind::parse_exact("codex"), Some(AgentKind::Codex));
        assert_eq!(AgentKind::parse_exact(" Codex "), None);
        assert_eq!(AgentKind::parse_exact("CODEX"), None);
    }

    #[test]
    fn parse_user_input_normalizes_case_and_whitespace() {
        assert_eq!(
            AgentKind::parse_user_input("  OpEnCoDe\n"),
            Some(AgentKind::Opencode)
        );
        assert_eq!(AgentKind::parse_user_input(""), None);
    }

    #[test]
    fn as_str_covers_all_supported_variants() {
        let labels = [
            AgentKind::Shell.as_str(),
            AgentKind::Codex.as_str(),
            AgentKind::Opencode.as_str(),
            AgentKind::Claude.as_str(),
        ];
        assert_eq!(labels, ["shell", "codex", "opencode", "claude"]);
    }
}
