//! Domain types that represent core business concepts.

mod agent_binding;
mod agent_instance;
mod agent_kind;
mod agent_name;
mod git_worktree_spec;
mod session_name;

pub(crate) use agent_binding::{
    AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding, AgentStateKind, AgentStateProvider,
    PRIMARY_STATE_BINDING_KEY, RuntimeProvider,
};
pub(crate) use agent_instance::{Agent, AgentId};
pub(crate) use agent_kind::{AGENT_KIND_VALUES_CSV, AgentKind};
pub(crate) use agent_name::{AgentDisplayName, AgentNamePolicy};
pub(crate) use git_worktree_spec::{GitWorktreeSpecInput, ResolvedGitWorktreeSpec};
pub(crate) use session_name::SessionName;
