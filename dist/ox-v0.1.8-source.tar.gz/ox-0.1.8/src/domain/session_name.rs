use std::convert::TryFrom;

/// Strongly-typed tmux session name.
///
/// We validate once at the CLI boundary, then pass this type through the app.
/// That way, lower layers do not need to repeat string validation logic.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct SessionName(String);

impl SessionName {
    /// Borrow the validated session name as a string slice.
    pub(crate) fn as_str(&self) -> &str {
        &self.0
    }
}

impl TryFrom<&str> for SessionName {
    type Error = &'static str;

    fn try_from(value: &str) -> Result<Self, Self::Error> {
        // Reject empty input early so callers get a precise error message.
        if value.is_empty() {
            return Err("session name cannot be empty");
        }

        // Keep names intentionally strict so they are unambiguous in CLI parsing,
        // terminal output, tmux targeting, and logs over time.
        if value.len() > 64 {
            return Err("session name cannot exceed 64 characters");
        }

        // Accept only ASCII letters, digits, '.', '_' and '-'. This rejects
        // whitespace, control characters, separators, and escape-like symbols.
        if !value
            .chars()
            .all(|ch| ch.is_ascii_alphanumeric() || matches!(ch, '.' | '_' | '-'))
        {
            return Err(
                "session name cannot contain characters other than ASCII letters, digits, '.', '_', and '-'",
            );
        }

        Ok(Self(value.to_string()))
    }
}

impl TryFrom<String> for SessionName {
    type Error = &'static str;

    fn try_from(value: String) -> Result<Self, Self::Error> {
        SessionName::try_from(value.as_str())
    }
}

#[cfg(test)]
mod tests {
    use super::SessionName;
    use std::convert::TryFrom;

    #[test]
    fn accepts_valid_name() {
        let parsed = SessionName::try_from("work");
        assert!(parsed.is_ok(), "valid name should parse");
        let Ok(name) = parsed else {
            return;
        };
        assert_eq!(name.as_str(), "work");
    }

    #[test]
    fn rejects_empty_name() {
        let parsed = SessionName::try_from("");
        assert!(parsed.is_err(), "empty name should fail");
        let Err(err) = parsed else {
            return;
        };
        assert_eq!(err, "session name cannot be empty");
    }

    #[test]
    fn rejects_space_character() {
        let parsed = SessionName::try_from("work room");
        assert!(parsed.is_err(), "name with spaces should fail");
        let Err(err) = parsed else {
            return;
        };
        assert_eq!(
            err,
            "session name cannot contain characters other than ASCII letters, digits, '.', '_', and '-'"
        );
    }

    #[test]
    fn rejects_control_character() {
        let parsed = SessionName::try_from("work\n1");
        assert!(parsed.is_err(), "name with control chars should fail");
        let Err(err) = parsed else {
            return;
        };
        assert_eq!(
            err,
            "session name cannot contain characters other than ASCII letters, digits, '.', '_', and '-'"
        );
    }

    #[test]
    fn rejects_non_ascii_character() {
        let parsed = SessionName::try_from("snowman_☃");
        assert!(parsed.is_err(), "name with non-ascii chars should fail");
        let Err(err) = parsed else {
            return;
        };
        assert_eq!(
            err,
            "session name cannot contain characters other than ASCII letters, digits, '.', '_', and '-'"
        );
    }

    #[test]
    fn rejects_name_longer_than_64_chars() {
        let parsed = SessionName::try_from(
            "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        );
        assert!(parsed.is_err(), "name longer than 64 should fail");
        let Err(err) = parsed else {
            return;
        };
        assert_eq!(err, "session name cannot exceed 64 characters");
    }

    #[test]
    fn try_from_string_works_same_as_str() {
        let parsed = SessionName::try_from("valid-name".to_string());
        assert!(parsed.is_ok());
        let Ok(name) = parsed else { return };
        assert_eq!(name.as_str(), "valid-name");
    }

    #[test]
    fn try_from_string_rejects_empty() {
        let parsed = SessionName::try_from(String::new());
        assert!(parsed.is_err());
    }

    #[test]
    fn accepts_dots_underscores_dashes() {
        let parsed = SessionName::try_from("my.agent_name-1");
        assert!(parsed.is_ok(), "dots, underscores, dashes should be valid");
        let Ok(name) = parsed else { return };
        assert_eq!(name.as_str(), "my.agent_name-1");
    }

    #[test]
    fn accepts_exactly_64_chars() {
        let name = "a".repeat(64);
        let parsed = SessionName::try_from(name.as_str());
        assert!(parsed.is_ok(), "exactly 64 chars should be valid");
    }

    #[test]
    fn accepts_single_character() {
        let parsed = SessionName::try_from("x");
        assert!(parsed.is_ok(), "single character should be valid");
    }
}
