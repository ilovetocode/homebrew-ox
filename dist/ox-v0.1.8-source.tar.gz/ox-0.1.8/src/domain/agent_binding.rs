use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

use crate::domain::{Agent, AgentId};

/// Canonical binding key for the primary state row per state kind.
pub(crate) const PRIMARY_STATE_BINDING_KEY: &str = "primary";

/// Runtime provider implementation type.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum RuntimeProvider {
    Tmux,
}

/// Generalized external state kind an agent can live inside.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum AgentStateKind {
    TmuxSession,
    CodexThread,
    OpencodeSession,
    WorkingDirectory,
    GitRoot,
    GitWorktree,
}

/// Provider implementation for generalized external states.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum AgentStateProvider {
    Tmux,
    Codex,
    Opencode,
    Git,
}

/// Durable binding between a domain agent and an external runtime reference.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct AgentRuntimeBinding {
    pub(crate) id: String,
    pub(crate) agent_id: AgentId,
    pub(crate) provider: RuntimeProvider,
    pub(crate) external_ref: String,
    pub(crate) version: i64,
    pub(crate) last_seen_at_unix_ms: Option<u128>,
    pub(crate) created_at_unix_ms: u128,
    pub(crate) updated_at_unix_ms: u128,
}

impl AgentRuntimeBinding {
    /// Build a new binding created by runtime provisioning.
    pub(crate) fn new(
        agent_id: AgentId,
        provider: RuntimeProvider,
        external_ref: String,
        now_unix_ms: u128,
    ) -> Self {
        Self {
            id: new_opaque_id("bind"),
            agent_id,
            provider,
            external_ref,
            version: 1,
            last_seen_at_unix_ms: None,
            created_at_unix_ms: now_unix_ms,
            updated_at_unix_ms: now_unix_ms,
        }
    }

    /// Return a copy with refreshed observation timestamp and incremented version.
    pub(crate) fn observed(&self, now_unix_ms: u128) -> Self {
        Self {
            id: self.id.clone(),
            agent_id: self.agent_id.clone(),
            provider: self.provider,
            external_ref: self.external_ref.clone(),
            version: self.version.saturating_add(1),
            last_seen_at_unix_ms: Some(now_unix_ms),
            created_at_unix_ms: self.created_at_unix_ms,
            updated_at_unix_ms: now_unix_ms,
        }
    }
}

/// Durable binding between an agent and one generalized external state.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct AgentStateBinding {
    pub(crate) id: String,
    pub(crate) agent_id: AgentId,
    pub(crate) state_kind: AgentStateKind,
    pub(crate) provider: AgentStateProvider,
    pub(crate) binding_key: String,
    pub(crate) external_ref: String,
    pub(crate) metadata_json: String,
    pub(crate) version: i64,
    pub(crate) last_seen_at_unix_ms: Option<u128>,
    pub(crate) created_at_unix_ms: u128,
    pub(crate) updated_at_unix_ms: u128,
}

impl AgentStateBinding {
    /// Build a new external-state binding row with default metadata.
    pub(crate) fn new(
        agent_id: AgentId,
        state_kind: AgentStateKind,
        provider: AgentStateProvider,
        binding_key: String,
        external_ref: String,
        metadata_json: String,
        now_unix_ms: u128,
    ) -> Self {
        Self {
            id: new_opaque_id("state"),
            agent_id,
            state_kind,
            provider,
            binding_key,
            external_ref,
            metadata_json,
            version: 1,
            last_seen_at_unix_ms: None,
            created_at_unix_ms: now_unix_ms,
            updated_at_unix_ms: now_unix_ms,
        }
    }
}

/// Persistence read model that carries one agent row plus optional runtime binding.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct AgentRuntimeRecord {
    pub(crate) agent: Agent,
    pub(crate) binding: Option<AgentRuntimeBinding>,
}

fn new_opaque_id(prefix: &str) -> String {
    static NEXT_ID: AtomicU64 = AtomicU64::new(1);
    let counter = NEXT_ID.fetch_add(1, Ordering::Relaxed);
    let now_nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_nanos());
    let pid = std::process::id();
    format!("{prefix}_{now_nanos}_{pid}_{counter}")
}

#[cfg(test)]
mod tests {
    use super::{AgentRuntimeBinding, AgentStateBinding, AgentStateKind, AgentStateProvider};
    use crate::domain::{AgentId, RuntimeProvider};
    use std::collections::HashSet;

    #[test]
    fn runtime_binding_new_sets_version_one() {
        let Some(agent_id) = AgentId::parse("agent_abc") else {
            return;
        };
        let binding = AgentRuntimeBinding::new(
            agent_id,
            RuntimeProvider::Tmux,
            "sess_abc".to_string(),
            1000,
        );
        assert_eq!(binding.version, 1);
        assert!(binding.last_seen_at_unix_ms.is_none());
        assert_eq!(binding.created_at_unix_ms, 1000);
        assert_eq!(binding.updated_at_unix_ms, 1000);
    }

    #[test]
    fn runtime_binding_observed_increments_version() {
        let Some(agent_id) = AgentId::parse("agent_abc") else {
            return;
        };
        let binding = AgentRuntimeBinding::new(
            agent_id,
            RuntimeProvider::Tmux,
            "sess_abc".to_string(),
            1000,
        );
        let observed = binding.observed(2000);
        assert_eq!(observed.version, 2);
        assert_eq!(observed.last_seen_at_unix_ms, Some(2000));
        assert_eq!(observed.updated_at_unix_ms, 2000);
        assert_eq!(observed.created_at_unix_ms, 1000);
    }

    #[test]
    fn runtime_binding_observed_preserves_identity() {
        let Some(agent_id) = AgentId::parse("agent_abc") else {
            return;
        };
        let binding = AgentRuntimeBinding::new(
            agent_id.clone(),
            RuntimeProvider::Tmux,
            "sess_abc".to_string(),
            1000,
        );
        let observed = binding.observed(2000);
        assert_eq!(observed.id, binding.id);
        assert_eq!(observed.agent_id, agent_id);
        assert_eq!(observed.external_ref, "sess_abc");
    }

    #[test]
    fn agent_state_binding_new_sets_fields() {
        let Some(agent_id) = AgentId::parse("agent_xyz") else {
            return;
        };
        let binding = AgentStateBinding::new(
            agent_id.clone(),
            AgentStateKind::GitWorktree,
            AgentStateProvider::Git,
            "worktree".to_string(),
            "/tmp/wt".to_string(),
            "{}".to_string(),
            5000,
        );
        assert_eq!(binding.agent_id, agent_id);
        assert_eq!(binding.state_kind, AgentStateKind::GitWorktree);
        assert_eq!(binding.provider, AgentStateProvider::Git);
        assert_eq!(binding.version, 1);
        assert!(binding.last_seen_at_unix_ms.is_none());
        assert_eq!(binding.created_at_unix_ms, 5000);
    }

    #[test]
    fn binding_ids_are_unique_across_many_generations() {
        let Some(agent_id) = AgentId::parse("agent_xyz") else {
            return;
        };
        let mut ids = HashSet::new();
        for _ in 0..1024 {
            let binding = AgentStateBinding::new(
                agent_id.clone(),
                AgentStateKind::OpencodeSession,
                AgentStateProvider::Opencode,
                "session".to_string(),
                "external".to_string(),
                "{}".to_string(),
                5000,
            );
            assert!(ids.insert(binding.id));
        }
    }
}
