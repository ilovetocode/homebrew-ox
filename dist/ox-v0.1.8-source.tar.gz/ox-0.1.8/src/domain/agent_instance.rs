use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

use crate::domain::AgentKind;

/// Stable agent identifier used across storage and runtime projections.
#[derive(Clone, Debug, PartialEq, Eq, Hash)]
pub(crate) struct AgentId(String);

impl AgentId {
    /// Create a new random-like opaque identifier.
    pub(crate) fn new() -> Self {
        static NEXT_ID: AtomicU64 = AtomicU64::new(1);
        let counter = NEXT_ID.fetch_add(1, Ordering::Relaxed);
        let now_nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos());
        Self(format!("ag_{now_nanos}_{counter}"))
    }

    /// Build an identifier from persisted text.
    pub(crate) fn parse(raw: &str) -> Option<Self> {
        if raw.trim().is_empty() {
            return None;
        }
        Some(Self(raw.to_string()))
    }

    /// Borrow identifier as canonical text.
    pub(crate) fn as_str(&self) -> &str {
        &self.0
    }
}

/// Durable domain aggregate representing one managed agent.
#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) struct Agent {
    id: AgentId,
    display_name: String,
    kind: AgentKind,
    display_order: i64,
    version: i64,
    created_at_unix_ms: u128,
    updated_at_unix_ms: u128,
}

impl Agent {
    /// Build a newly created agent aggregate.
    pub(crate) fn new(display_name: String, kind: AgentKind, now_unix_ms: u128) -> Self {
        Self {
            id: AgentId::new(),
            display_name,
            kind,
            display_order: 0,
            version: 1,
            created_at_unix_ms: now_unix_ms,
            updated_at_unix_ms: now_unix_ms,
        }
    }

    /// Return a renamed copy with optimistic-concurrency version bump.
    pub(crate) fn renamed(&self, new_display_name: String, now_unix_ms: u128) -> Self {
        Self {
            id: self.id.clone(),
            display_name: new_display_name,
            kind: self.kind,
            display_order: self.display_order,
            version: self.version.saturating_add(1),
            created_at_unix_ms: self.created_at_unix_ms,
            updated_at_unix_ms: now_unix_ms,
        }
    }

    /// Rebuild an aggregate from persisted fields.
    pub(crate) fn from_persisted(
        id: AgentId,
        display_name: String,
        kind: AgentKind,
        display_order: i64,
        version: i64,
        created_at_unix_ms: u128,
        updated_at_unix_ms: u128,
    ) -> Self {
        Self {
            id,
            display_name,
            kind,
            display_order,
            version,
            created_at_unix_ms,
            updated_at_unix_ms,
        }
    }

    /// Build a view projection with a different runtime-observed kind.
    ///
    /// This keeps durable fields intact and is used only for read models where
    /// live runtime detection should override creation-time kind.
    pub(crate) fn with_kind(&self, kind: AgentKind) -> Self {
        Self {
            id: self.id.clone(),
            display_name: self.display_name.clone(),
            kind,
            display_order: self.display_order,
            version: self.version,
            created_at_unix_ms: self.created_at_unix_ms,
            updated_at_unix_ms: self.updated_at_unix_ms,
        }
    }

    /// Return a copy with a new persisted kind and version bump.
    ///
    /// Unlike `with_kind`, this is for durable lifecycle mutations and must
    /// advance optimistic-concurrency versioning even if the kind value stays
    /// the same.
    #[allow(dead_code)]
    #[allow(dead_code)]
    pub(crate) fn retyped(&self, kind: AgentKind, now_unix_ms: u128) -> Self {
        Self {
            id: self.id.clone(),
            display_name: self.display_name.clone(),
            kind,
            display_order: self.display_order,
            version: self.version.saturating_add(1),
            created_at_unix_ms: self.created_at_unix_ms,
            updated_at_unix_ms: now_unix_ms,
        }
    }

    /// Set `display_order` during creation (no version bump).
    pub(crate) fn with_initial_display_order(mut self, order: i64) -> Self {
        self.display_order = order;
        self
    }

    /// Return a copy with a new `display_order` and version bump.
    pub(crate) fn with_display_order(self, order: i64, now_unix_ms: u128) -> Self {
        Self {
            display_order: order,
            version: self.version.saturating_add(1),
            updated_at_unix_ms: now_unix_ms,
            ..self
        }
    }

    pub(crate) fn id(&self) -> AgentId {
        self.id.clone()
    }

    pub(crate) fn display_name(&self) -> &str {
        &self.display_name
    }

    pub(crate) fn kind(&self) -> AgentKind {
        self.kind
    }

    pub(crate) fn display_order(&self) -> i64 {
        self.display_order
    }

    pub(crate) fn version(&self) -> i64 {
        self.version
    }

    pub(crate) fn created_at_unix_ms(&self) -> u128 {
        self.created_at_unix_ms
    }

    pub(crate) fn updated_at_unix_ms(&self) -> u128 {
        self.updated_at_unix_ms
    }
}

#[cfg(test)]
mod tests {
    use crate::domain::{Agent, AgentKind};

    #[test]
    fn new_sets_expected_defaults() {
        let agent = Agent::new("alpha".to_string(), AgentKind::Codex, 10);
        assert_eq!(agent.display_name(), "alpha");
        assert_eq!(agent.kind(), AgentKind::Codex);
        assert_eq!(agent.display_order(), 0);
        assert_eq!(agent.version(), 1);
        assert_eq!(agent.created_at_unix_ms(), 10);
        assert_eq!(agent.updated_at_unix_ms(), 10);
    }

    #[test]
    fn with_initial_display_order_sets_order_without_version_bump() {
        let agent =
            Agent::new("alpha".to_string(), AgentKind::Shell, 10).with_initial_display_order(5);
        assert_eq!(agent.display_order(), 5);
        assert_eq!(agent.version(), 1);
    }

    #[test]
    fn with_display_order_bumps_version() {
        let agent = Agent::new("alpha".to_string(), AgentKind::Shell, 10).with_display_order(3, 20);
        assert_eq!(agent.display_order(), 3);
        assert_eq!(agent.version(), 2);
        assert_eq!(agent.updated_at_unix_ms(), 20);
    }

    #[test]
    fn renamed_updates_name_version_and_timestamp() {
        let renamed =
            Agent::new("alpha".to_string(), AgentKind::Claude, 10).renamed("beta".to_string(), 20);

        assert_eq!(renamed.display_name(), "beta");
        assert_eq!(renamed.kind(), AgentKind::Claude);
        assert_eq!(renamed.version(), 2);
        assert_eq!(renamed.created_at_unix_ms(), 10);
        assert_eq!(renamed.updated_at_unix_ms(), 20);
    }

    #[test]
    fn retyped_updates_kind_version_and_timestamp() {
        let original = Agent::new("alpha".to_string(), AgentKind::Opencode, 10);
        let retyped = original.retyped(AgentKind::Shell, 20);

        assert_eq!(retyped.display_name(), "alpha");
        assert_eq!(retyped.kind(), AgentKind::Shell);
        assert_eq!(retyped.version(), 2);
        assert_eq!(retyped.created_at_unix_ms(), 10);
        assert_eq!(retyped.updated_at_unix_ms(), 20);
    }
}
