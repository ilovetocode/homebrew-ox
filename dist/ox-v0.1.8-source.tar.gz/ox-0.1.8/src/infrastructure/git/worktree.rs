use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::{Mutex, OnceLock};
use std::time::{Duration, Instant, SystemTime, UNIX_EPOCH};

use serde_json::json;

use crate::application::{ResolvedGitWorktreeSpec, WorktreePort};
use crate::domain::{
    Agent, AgentStateBinding, AgentStateKind, AgentStateProvider, PRIMARY_STATE_BINDING_KEY,
};
use crate::error::{AgentError, AppError};
use crate::infrastructure::command_timeout::{SUBPROCESS_TIMEOUT, run_with_timeout};

const GIT_METADATA_CACHE_TTL: Duration = Duration::from_millis(500);

#[derive(Clone)]
struct GitMetadataCacheEntry {
    value: String,
    present: bool,
    expires_at: Instant,
}

type GitMetadataCacheMap = Mutex<HashMap<String, GitMetadataCacheEntry>>;

enum GitMetadataCacheLookup {
    Hit(Option<String>),
    Miss,
}

static BRANCH_CACHE: OnceLock<GitMetadataCacheMap> = OnceLock::new();
static ROOT_CACHE: OnceLock<GitMetadataCacheMap> = OnceLock::new();

/// Git-backed implementation for managed agent worktree state.
pub(crate) struct GitWorktreeAdapter;

impl WorktreePort for GitWorktreeAdapter {
    fn create_worktree(
        &self,
        agent: &Agent,
        spec: &ResolvedGitWorktreeSpec,
    ) -> Result<AgentStateBinding, AppError> {
        let repo_root = detect_repo_root(spec.repo_root.as_deref())?;
        let repo_root_display = repo_root.to_string_lossy().to_string();
        let metadata_base_ref =
            resolve_create_metadata_base_ref(repo_root_display.as_str(), &spec.base_ref)?;
        let worktrees_root = repo_root.join(".ox").join("worktrees");
        fs::create_dir_all(&worktrees_root).map_err(|source| {
            AppError::Agent(AgentError::Unavailable {
                message: format!(
                    "failed to create managed worktrees directory '{}': {source}",
                    worktrees_root.display()
                ),
            })
        })?;

        let worktree_path = worktrees_root.join(&spec.worktree_label);
        if worktree_path.exists() {
            return Err(AppError::InvalidInput {
                message: format!(
                    "managed worktree path already exists: {}",
                    worktree_path.display()
                ),
            });
        }

        // Reuse an existing local branch when present so callers can reopen a
        // named worktree branch without forcing branch creation to fail.
        let mut command = Command::new("git");
        command.arg("-C").arg(&repo_root).arg("worktree").arg("add");
        if branch_exists(repo_root.as_path(), &spec.worktree_label)? {
            command.arg(&worktree_path).arg(&spec.worktree_label);
        } else {
            command
                .arg("-b")
                .arg(&spec.worktree_label)
                .arg(&worktree_path)
                .arg(&spec.base_ref);
        }

        let output = run_with_timeout(&mut command, SUBPROCESS_TIMEOUT).map_err(|source| {
            AppError::Agent(AgentError::Unavailable {
                message: format!("failed to execute `git worktree add`: {source}"),
            })
        })?;
        if !output.status.success() {
            return Err(AppError::Agent(AgentError::Unavailable {
                message: format!(
                    "git worktree add failed: {}",
                    String::from_utf8_lossy(&output.stderr).trim()
                ),
            }));
        }

        clear_git_metadata_cache();

        let metadata = json!({
            "repo_root": repo_root_display,
            "worktree_path": worktree_path.to_string_lossy().to_string(),
            "worktree_label": spec.worktree_label,
            "base_ref": metadata_base_ref
        });
        Ok(AgentStateBinding::new(
            agent.id(),
            AgentStateKind::GitWorktree,
            AgentStateProvider::Git,
            PRIMARY_STATE_BINDING_KEY.to_string(),
            worktree_path.to_string_lossy().to_string(),
            metadata.to_string(),
            unix_time_ms(),
        ))
    }

    fn delete_worktree(&self, state: &AgentStateBinding) -> Result<(), AppError> {
        if state.state_kind != AgentStateKind::GitWorktree {
            return Ok(());
        }

        let path = PathBuf::from(state.external_ref.as_str());
        if !path.exists() {
            return Ok(());
        }

        let output = run_with_timeout(
            Command::new("git")
                .arg("-C")
                .arg(&path)
                .arg("worktree")
                .arg("remove")
                .arg("--force")
                .arg(&path),
            SUBPROCESS_TIMEOUT,
        )
        .map_err(|source| {
            AppError::Agent(AgentError::Unavailable {
                message: format!("failed to execute `git worktree remove`: {source}"),
            })
        })?;
        if !output.status.success() {
            return Err(AppError::Agent(AgentError::Unavailable {
                message: format!(
                    "git worktree remove failed: {}",
                    String::from_utf8_lossy(&output.stderr).trim()
                ),
            }));
        }

        clear_git_metadata_cache();

        Ok(())
    }

    fn current_branch(&self, worktree_path: &str) -> Result<Option<String>, AppError> {
        if let GitMetadataCacheLookup::Hit(cached) = cache_get(branch_cache(), worktree_path) {
            return Ok(cached);
        }

        let Some(branch) = probe_git_text_field(
            branch_cache(),
            worktree_path,
            &["rev-parse", "--abbrev-ref", "HEAD"],
        ) else {
            return Ok(None);
        };

        if branch == "HEAD" {
            cache_put_none(branch_cache(), worktree_path);
            return Ok(None);
        }
        cache_put(
            branch_cache(),
            worktree_path.to_string(),
            Some(branch.clone()),
        );
        Ok(Some(branch))
    }

    fn resolve_base_ref(&self, path: &str) -> Result<Option<String>, AppError> {
        if let Some(branch) = self.current_branch(path)? {
            return Ok(Some(branch));
        }

        resolve_head_commit(path)
    }

    fn parent_git_root(&self, path: &str) -> Result<Option<String>, AppError> {
        if let GitMetadataCacheLookup::Hit(cached) = cache_get(root_cache(), path) {
            return Ok(cached);
        }

        let Some(repo_root) =
            probe_git_text_field(root_cache(), path, &["rev-parse", "--show-toplevel"])
        else {
            return Ok(None);
        };

        if repo_root.is_empty() {
            cache_put_none(root_cache(), path);
            return Ok(None);
        }
        cache_put(root_cache(), path.to_string(), Some(repo_root.clone()));
        Ok(Some(repo_root))
    }
}

fn branch_cache() -> &'static GitMetadataCacheMap {
    BRANCH_CACHE.get_or_init(|| Mutex::new(HashMap::new()))
}

fn root_cache() -> &'static GitMetadataCacheMap {
    ROOT_CACHE.get_or_init(|| Mutex::new(HashMap::new()))
}

fn clear_git_metadata_cache() {
    branch_cache()
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
        .clear();
    root_cache()
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
        .clear();
}

fn cache_get(cache: &GitMetadataCacheMap, key: &str) -> GitMetadataCacheLookup {
    let now = Instant::now();
    let mut guard = cache
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    guard.retain(|_, entry| entry.expires_at > now);
    let entry = guard
        .get(key)
        .filter(|entry| entry.expires_at > now)
        .cloned();
    let Some(entry) = entry else {
        return GitMetadataCacheLookup::Miss;
    };
    if entry.present {
        GitMetadataCacheLookup::Hit(Some(entry.value))
    } else {
        GitMetadataCacheLookup::Hit(None)
    }
}

fn cache_put(cache: &GitMetadataCacheMap, key: String, value: Option<String>) {
    let mut guard = cache
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    let (stored_value, present) = match value {
        Some(value) => (value, true),
        None => (String::new(), false),
    };
    guard.insert(
        key,
        GitMetadataCacheEntry {
            value: stored_value,
            present,
            expires_at: Instant::now() + GIT_METADATA_CACHE_TTL,
        },
    );
}

fn cache_put_none(cache: &GitMetadataCacheMap, key: &str) {
    cache_put(cache, key.to_string(), None);
}

fn probe_git_text_field(cache: &GitMetadataCacheMap, path: &str, args: &[&str]) -> Option<String> {
    let mut command = Command::new("git");
    command.arg("-C").arg(path);
    for arg in args {
        command.arg(arg);
    }

    let Ok(output) = run_with_timeout(&mut command, SUBPROCESS_TIMEOUT) else {
        cache_put_none(cache, path);
        return None;
    };
    if !output.status.success() {
        cache_put_none(cache, path);
        return None;
    }

    let value = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if value.is_empty() {
        cache_put_none(cache, path);
        return None;
    }

    Some(value)
}

fn branch_exists(repo_root: &Path, branch_name: &str) -> Result<bool, AppError> {
    let output = run_with_timeout(
        Command::new("git")
            .arg("-C")
            .arg(repo_root)
            .arg("show-ref")
            .arg("--verify")
            .arg("--quiet")
            .arg(format!("refs/heads/{branch_name}")),
        SUBPROCESS_TIMEOUT,
    )
    .map_err(|source| {
        AppError::Agent(AgentError::Unavailable {
            message: format!("failed to execute `git show-ref`: {source}"),
        })
    })?;

    Ok(output.status.success())
}

fn detect_repo_root(candidate_root: Option<&str>) -> Result<PathBuf, AppError> {
    let mut command = Command::new("git");
    if let Some(root) = candidate_root {
        command.arg("-C").arg(root);
    }
    let output = run_with_timeout(
        command.arg("rev-parse").arg("--show-toplevel"),
        SUBPROCESS_TIMEOUT,
    )
    .map_err(|source| {
        AppError::Agent(AgentError::Unavailable {
            message: format!("failed to execute `git rev-parse --show-toplevel`: {source}"),
        })
    })?;
    if !output.status.success() {
        return Err(AppError::InvalidInput {
            message: if let Some(root) = candidate_root {
                format!("worktree creation requires a git repository root: {root}")
            } else {
                "worktree creation requires running `ox` inside a git repository".to_string()
            },
        });
    }

    let repo_root = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if repo_root.is_empty() {
        return Err(AppError::Agent(AgentError::Unavailable {
            message: "git returned empty repository root".to_string(),
        }));
    }

    Ok(Path::new(repo_root.as_str()).to_path_buf())
}

fn unix_time_ms() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_millis())
}

fn resolve_create_metadata_base_ref(
    repo_root: &str,
    requested_base_ref: &str,
) -> Result<String, AppError> {
    let requested_base_ref = requested_base_ref.trim();
    if !is_symbolic_head_ref(requested_base_ref) {
        return Ok(requested_base_ref.to_string());
    }

    let adapter = GitWorktreeAdapter;
    Ok(adapter
        .current_branch(repo_root)?
        .unwrap_or_else(|| "HEAD".to_string()))
}

#[allow(dead_code)]
fn resolve_head_commit(path: &str) -> Result<Option<String>, AppError> {
    let output = run_with_timeout(
        Command::new("git")
            .arg("-C")
            .arg(path)
            .arg("rev-parse")
            .arg("HEAD"),
        SUBPROCESS_TIMEOUT,
    )
    .map_err(|source| {
        AppError::Agent(AgentError::Unavailable {
            message: format!("failed to execute `git rev-parse HEAD`: {source}"),
        })
    })?;

    if !output.status.success() {
        return Ok(None);
    }

    let value = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if value.is_empty() {
        return Ok(None);
    }

    Ok(Some(value))
}

fn is_symbolic_head_ref(base_ref: &str) -> bool {
    base_ref.is_empty() || base_ref == "HEAD"
}

#[cfg(test)]
mod tests {
    use std::fs;
    use std::path::{Path, PathBuf};
    use std::process::Command;
    use std::time::{SystemTime, UNIX_EPOCH};

    use super::{GitWorktreeAdapter, resolve_create_metadata_base_ref};
    use crate::application::WorktreePort;

    fn make_temp_repo(name: &str) -> Result<PathBuf, Box<dyn std::error::Error>> {
        let unique = SystemTime::now()
            .duration_since(UNIX_EPOCH)?
            .as_nanos()
            .to_string();
        let path = std::env::temp_dir().join(format!("ox-{name}-{}-{unique}", std::process::id()));
        fs::create_dir_all(&path)?;
        run_git(&path, &["init"])?;
        run_git(&path, &["branch", "-M", "main"])?;
        run_git(&path, &["config", "user.email", "ox-tests@example.com"])?;
        run_git(&path, &["config", "user.name", "ox tests"])?;
        Ok(path)
    }

    fn run_git(path: &Path, args: &[&str]) -> Result<(), Box<dyn std::error::Error>> {
        let output = Command::new("git")
            .arg("-C")
            .arg(path)
            .args(args)
            .output()?;
        if output.status.success() {
            return Ok(());
        }
        Err(format!(
            "git command failed in '{}': {:?}; stderr={}",
            path.display(),
            args,
            String::from_utf8_lossy(&output.stderr).trim()
        )
        .into())
    }

    #[test]
    fn resolve_create_metadata_base_ref_uses_current_branch_for_head()
    -> Result<(), Box<dyn std::error::Error>> {
        let repo = make_temp_repo("persist-head-base-ref")?;
        run_git(&repo, &["commit", "--allow-empty", "-m", "base"])?;

        let base_ref = resolve_create_metadata_base_ref(repo.to_string_lossy().as_ref(), "HEAD")?;

        assert_eq!(base_ref, "main");
        Ok(())
    }

    #[test]
    fn resolve_base_ref_falls_back_to_head_commit_for_detached_head()
    -> Result<(), Box<dyn std::error::Error>> {
        let repo = make_temp_repo("resolve-base-ref-detached")?;
        run_git(&repo, &["commit", "--allow-empty", "-m", "base"])?;
        let head = Command::new("git")
            .arg("-C")
            .arg(&repo)
            .arg("rev-parse")
            .arg("HEAD")
            .output()?;
        let head = String::from_utf8_lossy(&head.stdout).trim().to_string();
        run_git(&repo, &["checkout", "--detach"])?;

        let adapter = GitWorktreeAdapter;
        let resolved = adapter.resolve_base_ref(repo.to_string_lossy().as_ref())?;

        assert_eq!(resolved.as_deref(), Some(head.as_str()));
        Ok(())
    }
}
