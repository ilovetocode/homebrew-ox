mod worktree;

pub(crate) use worktree::GitWorktreeAdapter;
