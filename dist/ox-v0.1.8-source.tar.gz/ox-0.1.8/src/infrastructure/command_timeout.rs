//! Subprocess execution with a wall-clock timeout.

use std::process::{Command, Output, Stdio};
use std::sync::mpsc;
use std::time::Duration;

use crate::error::TmuxError;

/// Default deadline for non-interactive subprocesses (`tmux`, `ps`, `git`).
pub(crate) const SUBPROCESS_TIMEOUT: Duration = Duration::from_secs(10);

/// Spawn `cmd` and wait up to `timeout` for it to finish.
///
/// On timeout the child process is killed on a best-effort basis and
/// [`TmuxError::Timeout`] is returned.
///
/// # Errors
///
/// Returns [`TmuxError::Io`] when the command cannot be spawned or waited on,
/// and [`TmuxError::Timeout`] when the deadline expires.
pub(crate) fn run_with_timeout(cmd: &mut Command, timeout: Duration) -> Result<Output, TmuxError> {
    let child = cmd
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .map_err(TmuxError::Io)?;
    let pid = child.id();
    let (tx, rx) = mpsc::channel();

    std::thread::spawn(move || {
        // `wait_with_output` consumes the child and blocks until exit.
        let result = child.wait_with_output();
        let _ = tx.send(result);
    });

    match rx.recv_timeout(timeout) {
        Ok(result) => result.map_err(TmuxError::Io),
        Err(mpsc::RecvTimeoutError::Timeout) => {
            // Best-effort kill so the zombie does not linger.
            let _ = Command::new("kill").arg("-9").arg(pid.to_string()).output();
            Err(TmuxError::Timeout {
                seconds: timeout.as_secs(),
            })
        }
        Err(mpsc::RecvTimeoutError::Disconnected) => Err(TmuxError::Io(std::io::Error::new(
            std::io::ErrorKind::BrokenPipe,
            "subprocess monitoring thread disconnected",
        ))),
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use super::*;

    #[test]
    fn fast_command_succeeds() {
        let output =
            run_with_timeout(Command::new("echo").arg("hello"), Duration::from_secs(5)).unwrap();
        assert!(output.status.success());
        assert!(String::from_utf8_lossy(&output.stdout).contains("hello"));
    }

    #[test]
    fn slow_command_times_out() {
        let result = run_with_timeout(Command::new("sleep").arg("60"), Duration::from_millis(100));
        assert!(result.is_err());
        let err = result.unwrap_err();
        assert!(
            err.to_string().contains("timed out"),
            "expected timeout error, got: {err}"
        );
    }
}
