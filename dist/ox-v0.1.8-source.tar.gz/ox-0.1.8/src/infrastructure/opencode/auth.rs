use base64::Engine;
use base64::engine::general_purpose::STANDARD as BASE64;

/// Build a Basic authorization header from credential env var names.
///
/// Returns `None` when either env var is missing, or both values are empty.
pub(crate) fn build_basic_auth_header(username_env: &str, password_env: &str) -> Option<String> {
    let username = std::env::var(username_env).ok();
    let password = std::env::var(password_env).ok();
    build_basic_auth_header_from_values(username.as_deref(), password.as_deref())
}

fn build_basic_auth_header_from_values(
    username: Option<&str>,
    password: Option<&str>,
) -> Option<String> {
    let username = username?;
    let password = password?;
    if username.is_empty() && password.is_empty() {
        return None;
    }
    let encoded = BASE64.encode(format!("{username}:{password}"));
    Some(format!("Basic {encoded}"))
}

#[cfg(test)]
mod tests {
    use super::build_basic_auth_header_from_values;

    #[test]
    fn missing_either_value_returns_none() {
        assert!(build_basic_auth_header_from_values(Some("alice"), None).is_none());
        assert!(build_basic_auth_header_from_values(None, Some("secret")).is_none());
    }

    #[test]
    fn both_empty_returns_none() {
        assert!(build_basic_auth_header_from_values(Some(""), Some("")).is_none());
    }

    #[test]
    fn username_only_value_is_allowed_when_password_exists() {
        assert!(build_basic_auth_header_from_values(Some("alice"), Some(" ")).is_some());
    }

    #[test]
    fn password_only_value_is_allowed_when_username_exists() {
        assert!(build_basic_auth_header_from_values(Some(" "), Some("secret")).is_some());
    }

    #[test]
    fn both_set_returns_basic_header() {
        let header = build_basic_auth_header_from_values(Some("alice"), Some("secret"));
        assert_eq!(header.as_deref(), Some("Basic YWxpY2U6c2VjcmV0"));
    }
}
