use std::time::Duration;

use crate::application::OpencodeSettings;

use super::auth::build_basic_auth_header;

const QUICK_ACK_TIMEOUT_MS_CAP: u64 = 1_000;

/// Small request builder used by `OpenCode` infrastructure adapters.
pub(crate) struct OpencodeHttpClient {
    read_agent: ureq::Agent,
    write_agent: ureq::Agent,
    short_write_agent: ureq::Agent,
    auth_header: Option<String>,
}

impl OpencodeHttpClient {
    /// Build a preconfigured `ureq` client for `OpenCode` API calls.
    pub(crate) fn new(settings: &OpencodeSettings) -> Self {
        let read_timeout = Duration::from_millis(settings.read_request_timeout_ms);
        let write_timeout = Duration::from_millis(settings.request_timeout_ms);
        let quick_ack_timeout = Duration::from_millis(quick_ack_timeout_ms(settings));
        let read_agent = build_agent(read_timeout);
        let write_agent = build_agent(write_timeout);
        let short_write_agent = build_agent(quick_ack_timeout);
        let auth_header = build_basic_auth_header(&settings.username_env, &settings.password_env);
        Self {
            read_agent,
            write_agent,
            short_write_agent,
            auth_header,
        }
    }

    /// Build an authenticated GET request.
    pub(crate) fn get(&self, url: &str) -> ureq::Request {
        let request = self.read_agent.get(url);
        if let Some(header) = &self.auth_header {
            return request.set("Authorization", header);
        }
        request
    }

    /// Build an authenticated POST request.
    pub(crate) fn post(&self, url: &str) -> ureq::Request {
        let request = self.write_agent.post(url);
        if let Some(header) = &self.auth_header {
            return request.set("Authorization", header);
        }
        request
    }

    /// Build an authenticated short-timeout POST request.
    pub(crate) fn fast_post(&self, url: &str) -> ureq::Request {
        let request = self.short_write_agent.post(url);
        if let Some(header) = &self.auth_header {
            return request.set("Authorization", header);
        }
        request
    }
}

fn quick_ack_timeout_ms(settings: &OpencodeSettings) -> u64 {
    settings
        .read_request_timeout_ms
        .min(QUICK_ACK_TIMEOUT_MS_CAP)
}

fn build_agent(timeout: Duration) -> ureq::Agent {
    ureq::AgentBuilder::new()
        .timeout_connect(timeout)
        .timeout_read(timeout)
        .timeout_write(timeout)
        .timeout(timeout)
        // Local sidecar calls are short-lived and numerous across many ports.
        // Avoid reusing pooled sockets so one stale keepalive connection cannot
        // freeze the single-threaded workflow daemon.
        .max_idle_connections(0)
        .max_idle_connections_per_host(0)
        .build()
}

#[cfg(test)]
mod tests {
    use super::quick_ack_timeout_ms;
    use crate::application::OpencodeSettings;

    fn settings() -> OpencodeSettings {
        OpencodeSettings {
            server_url: "http://127.0.0.1:4096".to_string(),
            username_env: "OPENCODE_SERVER_USERNAME".to_string(),
            password_env: "OPENCODE_SERVER_PASSWORD".to_string(),
            request_timeout_ms: 180_000,
            read_request_timeout_ms: 15_000,
            status_poll_interval_ms: 150,
            conversation_page_size: 50,
        }
    }

    #[test]
    fn quick_ack_timeout_caps_at_one_second() {
        let settings = settings();
        assert_eq!(quick_ack_timeout_ms(&settings), 1_000);
    }

    #[test]
    fn quick_ack_timeout_uses_shorter_read_timeout_when_configured() {
        let mut settings = settings();
        settings.read_request_timeout_ms = 250;
        assert_eq!(quick_ack_timeout_ms(&settings), 250);
    }
}
