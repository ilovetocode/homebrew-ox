//! Lightweight `opencode serve` process supervision.
//!
//! This module intentionally manages only the minimum lifecycle needed for
//! reliability: ensure one reachable sidecar per workspace path and restart it
//! when dead or unreachable.

use std::collections::HashMap;
use std::sync::Arc;
use std::sync::Mutex;
use std::thread;
use std::time::{Duration, Instant};

use crate::application::{AuxSessionPort, OpencodeSettings};
use crate::error::{AgentError, AppError};

use super::auth::build_basic_auth_header;

const SIDECAR_START_TIMEOUT: Duration = Duration::from_secs(10);
const SIDECAR_HEALTH_POLL_INTERVAL: Duration = Duration::from_millis(150);

/// Thin in-process sidecar manager for workspace-scoped `opencode serve`.
pub(crate) struct OpencodeSidecarManager {
    settings: OpencodeSettings,
    aux_sessions: Arc<dyn AuxSessionPort>,
    tracked_sidecars_by_directory: Mutex<HashMap<String, TrackedSidecar>>,
}

struct TrackedSidecar {
    server_url: String,
    session_name: String,
}

enum TrackedSidecarState {
    Dead,
    Candidate(String),
}

impl OpencodeSidecarManager {
    /// Build a sidecar manager from app settings.
    pub(crate) fn new(settings: OpencodeSettings, aux_sessions: Arc<dyn AuxSessionPort>) -> Self {
        Self {
            settings,
            aux_sessions,
            tracked_sidecars_by_directory: Mutex::new(HashMap::new()),
        }
    }

    fn canonical_directory(directory: &str) -> Result<String, AppError> {
        let canonical =
            std::fs::canonicalize(directory).map_err(|source| AppError::InvalidInput {
                message: format!("invalid path '{directory}': {source}"),
            })?;
        Ok(canonical.to_string_lossy().to_string())
    }

    fn sidecar_available(&self, server_url: &str) -> bool {
        self.health_request(server_url).call().is_ok()
    }

    fn health_request(&self, server_url: &str) -> ureq::Request {
        self.http_get(&format!("{server_url}/session/status"))
    }

    fn http_get(&self, url: &str) -> ureq::Request {
        let timeout = Duration::from_millis(self.settings.read_request_timeout_ms);
        let agent = ureq::AgentBuilder::new().timeout(timeout).build();
        let request = agent.get(url);
        if let Some(header) = self.auth_header() {
            return request.set("Authorization", &header);
        }
        request
    }

    fn auth_header(&self) -> Option<String> {
        build_basic_auth_header(&self.settings.username_env, &self.settings.password_env)
    }

    fn start_sidecar_for_directory(&self, directory: &str) -> Result<String, AppError> {
        let port = reserve_free_port()?;
        let server_url = format!("http://127.0.0.1:{port}");
        let session_name = format!("ox-opencode-sidecar-{port}");
        let argv = vec![
            "opencode".to_string(),
            "serve".to_string(),
            "--port".to_string(),
            port.to_string(),
        ];
        self.aux_sessions
            .ensure_detached_command_session(&session_name, Some(directory), &argv)
            .map_err(|source| {
                AppError::Agent(AgentError::Unavailable {
                    message: format!(
                        "failed to launch tmux-managed 'opencode serve' in '{directory}': {source}"
                    ),
                })
            })?;

        self.wait_for_sidecar(&server_url)?;
        let mut guard = self
            .tracked_sidecars_by_directory
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner);
        guard.insert(
            directory.to_string(),
            TrackedSidecar {
                server_url: server_url.clone(),
                session_name,
            },
        );
        Ok(server_url)
    }

    fn wait_for_sidecar(&self, server_url: &str) -> Result<(), AppError> {
        let deadline = Instant::now() + SIDECAR_START_TIMEOUT;
        while Instant::now() < deadline {
            if self.sidecar_available(server_url) {
                return Ok(());
            }
            thread::sleep(SIDECAR_HEALTH_POLL_INTERVAL);
        }
        Err(AppError::Agent(AgentError::Unavailable {
            message: format!("opencode sidecar did not become healthy at '{server_url}'"),
        }))
    }

    fn tracked_server_if_healthy(&self, canonical_directory: &str) -> Option<String> {
        let state = {
            let guard = self
                .tracked_sidecars_by_directory
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner);
            let sidecar = guard.get(canonical_directory)?;
            if self
                .aux_sessions
                .session_exists(&sidecar.session_name)
                .unwrap_or(false)
            {
                TrackedSidecarState::Candidate(sidecar.server_url.clone())
            } else {
                TrackedSidecarState::Dead
            }
        };

        match state {
            TrackedSidecarState::Dead => {
                let mut guard = self
                    .tracked_sidecars_by_directory
                    .lock()
                    .unwrap_or_else(std::sync::PoisonError::into_inner);
                guard.remove(canonical_directory);
                None
            }
            TrackedSidecarState::Candidate(server_url) => {
                if self.sidecar_available(&server_url) {
                    Some(server_url)
                } else {
                    None
                }
            }
        }
    }
}

impl OpencodeSidecarManager {
    pub(crate) fn ensure_server_for_directory(
        &self,
        directory: &str,
        preferred_server_url: &str,
    ) -> Result<String, AppError> {
        let canonical_directory = Self::canonical_directory(directory)?;
        if let Some(server_url) = self.tracked_server_if_healthy(&canonical_directory) {
            return Ok(server_url);
        }

        // Prefer the configured default endpoint when it is reachable. If it is
        // later detected as directory-mismatched, callers can force a restart.
        if self.sidecar_available(preferred_server_url) {
            return Ok(preferred_server_url.to_string());
        }

        self.start_sidecar_for_directory(&canonical_directory)
    }

    pub(crate) fn force_restart_server_for_directory(
        &self,
        directory: &str,
    ) -> Result<String, AppError> {
        let canonical_directory = Self::canonical_directory(directory)?;

        let existing = {
            let mut guard = self
                .tracked_sidecars_by_directory
                .lock()
                .unwrap_or_else(std::sync::PoisonError::into_inner);
            guard.remove(&canonical_directory)
        };

        if let Some(sidecar) = existing {
            let _ = self.aux_sessions.kill_session(&sidecar.session_name);
        }

        self.start_sidecar_for_directory(&canonical_directory)
    }
}

fn reserve_free_port() -> Result<u16, AppError> {
    let listener = std::net::TcpListener::bind("127.0.0.1:0").map_err(|source| {
        AppError::Agent(AgentError::Unavailable {
            message: format!("failed to reserve localhost port for opencode sidecar: {source}"),
        })
    })?;
    let port = listener.local_addr().map_err(|source| {
        AppError::Agent(AgentError::Unavailable {
            message: format!("failed to read reserved sidecar port: {source}"),
        })
    })?;
    Ok(port.port())
}
