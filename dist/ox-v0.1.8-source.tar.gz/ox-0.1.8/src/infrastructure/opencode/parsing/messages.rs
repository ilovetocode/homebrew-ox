use serde_json::Value;

use crate::application::ConversationMessage;

/// Extract messages from the `/session/{id}/message` response.
///
/// The endpoint returns a JSON array directly. Each element has an `info`
/// object (role, id, time) and a `parts` array. Falls back to wrapped
/// `{"messages": [...]}` or `{"conversation": [...]}` shapes so the adapter
/// survives minor API revisions.
pub(crate) fn parse_messages(value: &Value) -> Vec<ConversationMessage> {
    // Primary: top-level JSON array (current opencode serve format).
    if let Some(arr) = value.as_array() {
        return arr.iter().map(parse_one_message).collect();
    }
    // Fallback: wrapped in "messages" or "conversation" key.
    let arr = value
        .get("messages")
        .and_then(Value::as_array)
        .or_else(|| value.get("conversation").and_then(Value::as_array));
    let Some(messages) = arr else {
        return Vec::new();
    };
    messages.iter().map(parse_one_message).collect()
}

#[derive(Default)]
struct ExtractedMessageContent {
    text: String,
    tool_names: Vec<String>,
    patch_files: Vec<String>,
    synthesized_text: bool,
}

fn parse_one_message(msg: &Value) -> ConversationMessage {
    // Current opencode format nests metadata under `info`.
    let info = msg.get("info").unwrap_or(msg);
    let finish_reason = extract_finish_reason(msg, info);

    let message_id = info
        .get("id")
        .and_then(Value::as_str)
        .unwrap_or_default()
        .to_string();
    let role = info
        .get("role")
        .and_then(Value::as_str)
        .unwrap_or("unknown")
        .to_string();
    let content = extract_message_content(msg, finish_reason.as_deref());

    // Time fields live under `info.time` in the current format, with
    // fallbacks to top-level `createdAt`/`completedAt`.
    let time = info.get("time");
    let created_at = time
        .and_then(|t| t.get("created"))
        .and_then(Value::as_u64)
        .or_else(|| info.get("createdAt").and_then(Value::as_u64))
        .map_or(0, u128::from);
    let completed_at = time
        .and_then(|t| t.get("completed"))
        .and_then(Value::as_u64)
        .or_else(|| info.get("completedAt").and_then(Value::as_u64))
        .map(u128::from);

    ConversationMessage {
        message_id,
        role,
        created_at_unix_ms: created_at,
        completed_at_unix_ms: completed_at,
        text: content.text,
        tool_names: content.tool_names,
        patch_files: content.patch_files,
        finish_reason,
        synthesized_text: content.synthesized_text,
    }
}

fn extract_finish_reason(msg: &Value, info: &Value) -> Option<String> {
    info.get("finish")
        .and_then(Value::as_str)
        .map(ToString::to_string)
        .or_else(|| {
            msg.get("parts")
                .and_then(Value::as_array)
                .and_then(|parts| {
                    parts.iter().find_map(|part| {
                        (part.get("type").and_then(Value::as_str) == Some("step-finish"))
                            .then(|| {
                                part.get("reason")
                                    .and_then(Value::as_str)
                                    .map(ToString::to_string)
                            })
                            .flatten()
                    })
                })
        })
}

/// Extract a stable display summary plus structured metadata from one message.
fn extract_message_content(msg: &Value, finish_reason: Option<&str>) -> ExtractedMessageContent {
    if let Some(text) = msg
        .get("text")
        .and_then(Value::as_str)
        .filter(|text| !text.trim().is_empty())
    {
        return ExtractedMessageContent {
            text: text.to_string(),
            ..ExtractedMessageContent::default()
        };
    }

    if let Some(text) = msg
        .get("content")
        .and_then(Value::as_str)
        .filter(|text| !text.trim().is_empty())
    {
        return ExtractedMessageContent {
            text: text.to_string(),
            ..ExtractedMessageContent::default()
        };
    }

    let mut text_segments = Vec::new();
    let mut reasoning_segments = Vec::new();
    let mut tool_names = Vec::new();
    let mut patch_files = Vec::new();

    if let Some(parts) = msg.get("parts").and_then(Value::as_array) {
        for part in parts {
            match part.get("type").and_then(Value::as_str) {
                Some("text") => {
                    push_non_empty(&mut text_segments, part.get("text").and_then(Value::as_str));
                }
                Some("reasoning") => push_non_empty(
                    &mut reasoning_segments,
                    part.get("text").and_then(Value::as_str),
                ),
                Some("tool") => {
                    push_unique(&mut tool_names, part.get("tool").and_then(Value::as_str));
                }
                Some("patch") => {
                    if let Some(files) = part.get("files").and_then(Value::as_array) {
                        for file in files {
                            push_unique(&mut patch_files, file.as_str());
                        }
                    }
                }
                _ => {}
            }
        }
    }

    if let Some(parts) = msg.get("content").and_then(Value::as_array) {
        for part in parts {
            if part.get("type").and_then(Value::as_str) == Some("text") {
                push_non_empty(&mut text_segments, part.get("text").and_then(Value::as_str));
            }
        }
    }

    if !text_segments.is_empty() {
        return ExtractedMessageContent {
            text: text_segments.join("\n"),
            tool_names,
            patch_files,
            synthesized_text: false,
        };
    }

    if !reasoning_segments.is_empty() {
        return ExtractedMessageContent {
            text: reasoning_segments.join("\n"),
            tool_names,
            patch_files,
            synthesized_text: true,
        };
    }

    let fallback = summarize_non_text_parts(&tool_names, &patch_files, finish_reason);
    ExtractedMessageContent {
        synthesized_text: !fallback.is_empty(),
        text: fallback,
        tool_names,
        patch_files,
    }
}

fn summarize_non_text_parts(
    tool_names: &[String],
    patch_files: &[String],
    finish_reason: Option<&str>,
) -> String {
    let mut segments = Vec::new();
    if !tool_names.is_empty() {
        segments.push(format!("tool calls: {}", tool_names.join(", ")));
    }
    if !patch_files.is_empty() {
        segments.push(format!("patch touched {} files", patch_files.len()));
    }
    if segments.is_empty()
        && let Some(reason) = finish_reason.filter(|reason| !reason.trim().is_empty())
    {
        segments.push(format!("assistant turn completed via {reason}"));
    }
    if segments.is_empty() {
        String::new()
    } else {
        format!("[{}]", segments.join("; "))
    }
}

fn push_non_empty(out: &mut Vec<String>, text: Option<&str>) {
    if let Some(text) = text.map(str::trim).filter(|text| !text.is_empty()) {
        out.push(text.to_string());
    }
}

fn push_unique(out: &mut Vec<String>, text: Option<&str>) {
    if let Some(text) = text.map(str::trim).filter(|text| !text.is_empty())
        && !out.iter().any(|item| item == text)
    {
        out.push(text.to_string());
    }
}

#[cfg(test)]
mod tests {
    use serde_json::json;

    use super::parse_messages;

    #[test]
    fn parse_messages_keeps_plain_text_turns() {
        let payload = json!([{
            "info": {
                "id": "msg_1",
                "role": "assistant",
                "time": { "created": 1, "completed": 2 },
                "finish": "stop"
            },
            "parts": [{ "type": "text", "text": "done" }]
        }]);

        let messages = parse_messages(&payload);
        assert_eq!(messages.len(), 1);
        assert_eq!(messages[0].text, "done");
        assert!(!messages[0].synthesized_text);
        assert!(messages[0].tool_names.is_empty());
    }

    #[test]
    fn parse_messages_summarizes_tool_only_turns() {
        let payload = json!([{
            "info": {
                "id": "msg_2",
                "role": "assistant",
                "time": { "created": 1, "completed": 2 },
                "finish": "tool-calls"
            },
            "parts": [
                { "type": "step-start" },
                { "type": "tool", "tool": "read" },
                { "type": "tool", "tool": "bash" },
                { "type": "step-finish", "reason": "tool-calls" }
            ]
        }]);

        let messages = parse_messages(&payload);
        assert_eq!(messages.len(), 1);
        assert_eq!(messages[0].text, "[tool calls: read, bash]");
        assert_eq!(messages[0].tool_names, vec!["read", "bash"]);
        assert_eq!(messages[0].finish_reason.as_deref(), Some("tool-calls"));
        assert!(messages[0].synthesized_text);
    }

    #[test]
    fn parse_messages_uses_reasoning_when_text_is_absent() {
        let payload = json!([{
            "info": {
                "id": "msg_3",
                "role": "assistant",
                "time": { "created": 1, "completed": 2 }
            },
            "parts": [
                { "type": "reasoning", "text": "thinking out loud" },
                { "type": "tool", "tool": "bash" }
            ]
        }]);

        let messages = parse_messages(&payload);
        assert_eq!(messages.len(), 1);
        assert_eq!(messages[0].text, "thinking out loud");
        assert_eq!(messages[0].tool_names, vec!["bash"]);
        assert!(messages[0].synthesized_text);
    }

    #[test]
    fn parse_messages_tracks_patch_files_in_summary() {
        let payload = json!([{
            "info": {
                "id": "msg_4",
                "role": "assistant",
                "time": { "created": 1, "completed": 2 }
            },
            "parts": [
                {
                    "type": "patch",
                    "files": ["src/a.rs", "src/b.rs"]
                }
            ]
        }]);

        let messages = parse_messages(&payload);
        assert_eq!(messages.len(), 1);
        assert_eq!(messages[0].text, "[patch touched 2 files]");
        assert_eq!(messages[0].patch_files, vec!["src/a.rs", "src/b.rs"]);
        assert!(messages[0].synthesized_text);
    }

    #[test]
    fn parse_messages_supports_wrapped_payloads() {
        let payload = json!({
            "messages": [{
                "info": {
                    "id": "msg_5",
                    "role": "assistant",
                    "time": { "created": 1, "completed": 2 }
                },
                "parts": [{ "type": "tool", "tool": "apply_patch" }]
            }]
        });

        let messages = parse_messages(&payload);
        assert_eq!(messages.len(), 1);
        assert_eq!(messages[0].text, "[tool calls: apply_patch]");
    }

    #[test]
    fn parse_messages_marks_compaction_completion_as_synthesized_summary() {
        let payload = json!([{
            "info": {
                "id": "msg_6",
                "role": "assistant",
                "time": { "created": 1, "completed": 2 },
                "finish": "stop"
            },
            "summary": true
        }]);

        let messages = parse_messages(&payload);
        assert_eq!(messages.len(), 1);
        assert_eq!(messages[0].text, "[assistant turn completed via stop]");
        assert!(messages[0].synthesized_text);
    }
}
