use std::collections::HashMap;

use serde_json::Value;

use crate::application::{
    MessageDispatchProvider, MessageDispatchSessionRef, MessageDispatchSessionSummary,
    RuntimeStatus,
};

/// Parse a `/session/status` response into a full map.
///
/// Response shapes vary by server version. We accept:
/// - object keyed by session ID (`{"<id>": "idle"}`)
/// - object keyed by session ID with nested status (`{"<id>": {"status": "busy"}}`)
/// - arrays of rows (`[{"sessionId": "...", "status": "idle"}]`)
/// - nested arrays under `sessions`.
pub(crate) fn extract_status_map(resp: &Value) -> HashMap<String, RuntimeStatus> {
    let mut statuses = HashMap::new();

    if let Some(obj) = resp.as_object() {
        for (key, value) in obj {
            if key == "sessions" {
                continue;
            }
            if let Some(status) = value.as_str() {
                statuses.insert(key.clone(), map_opencode_status(status));
                continue;
            }
            if let Some(status) = nested_status_value(value) {
                let session_id = value
                    .get("sessionId")
                    .and_then(Value::as_str)
                    .or_else(|| value.get("session_id").and_then(Value::as_str))
                    .or_else(|| value.get("id").and_then(Value::as_str))
                    .unwrap_or(key.as_str());
                statuses.insert(session_id.to_string(), map_opencode_status(status));
            }
        }

        if let Some(arr) = obj.get("sessions").and_then(Value::as_array) {
            extend_statuses_from_array(&mut statuses, arr);
        }
        return statuses;
    }

    if let Some(arr) = resp.as_array() {
        extend_statuses_from_array(&mut statuses, arr);
    }

    statuses
}

/// Extract session directory from `/session` creation response.
///
/// Newer server versions return `directory`, while older variants may use
/// `dir` or nest values in a `session` object.
pub(crate) fn extract_session_directory(resp: &Value) -> Option<String> {
    resp.get("directory")
        .and_then(Value::as_str)
        .or_else(|| resp.get("dir").and_then(Value::as_str))
        .or_else(|| {
            resp.get("session")
                .and_then(|s| s.get("directory"))
                .and_then(Value::as_str)
        })
        .or_else(|| {
            resp.get("session")
                .and_then(|s| s.get("dir"))
                .and_then(Value::as_str)
        })
        .map(ToString::to_string)
}

/// Parse one `/session` or `/session/{id}/children` response into session summaries.
pub(crate) fn parse_session_summaries(
    value: &Value,
    server_url: &str,
) -> Vec<MessageDispatchSessionSummary> {
    let entries = value
        .as_array()
        .or_else(|| value.get("sessions").and_then(Value::as_array));
    let Some(entries) = entries else {
        return Vec::new();
    };

    entries
        .iter()
        .filter_map(|entry| {
            let session_id = entry
                .get("id")
                .and_then(Value::as_str)
                .or_else(|| entry.get("sessionId").and_then(Value::as_str))
                .or_else(|| entry.get("session_id").and_then(Value::as_str))?;
            Some(MessageDispatchSessionSummary {
                session: MessageDispatchSessionRef {
                    provider: MessageDispatchProvider::Opencode,
                    server_url: server_url.to_string(),
                    session_id: session_id.to_string(),
                    directory: extract_session_directory(entry),
                },
                title: entry
                    .get("title")
                    .and_then(Value::as_str)
                    .map(ToString::to_string),
                slug: entry
                    .get("slug")
                    .and_then(Value::as_str)
                    .map(ToString::to_string),
                parent_session_id: entry
                    .get("parentID")
                    .and_then(Value::as_str)
                    .or_else(|| entry.get("parent_id").and_then(Value::as_str))
                    .map(ToString::to_string),
                updated_at_unix_ms: entry
                    .get("time")
                    .and_then(|time| time.get("updated"))
                    .and_then(Value::as_u64)
                    .map(u128::from),
            })
        })
        .collect()
}

/// Compare two directory strings with canonicalization fallback.
pub(crate) fn same_directory(left: &str, right: &str) -> bool {
    if left == right {
        return true;
    }
    let left_canonical = std::fs::canonicalize(left).ok();
    let right_canonical = std::fs::canonicalize(right).ok();
    match (left_canonical, right_canonical) {
        (Some(l), Some(r)) => l == r,
        _ => false,
    }
}

/// Map an `OpenCode` status string to [`RuntimeStatus`].
///
/// Per the status resolution contract:
/// - `busy` / `retry` → `Running` (never false-idle)
/// - `idle` → `Waiting`
/// - anything else → `Unknown`
pub(crate) fn map_opencode_status(status: &str) -> RuntimeStatus {
    match status {
        "busy" | "retry" => RuntimeStatus::Running,
        "idle" => RuntimeStatus::Waiting,
        _ => RuntimeStatus::Unknown,
    }
}

fn nested_status_value(value: &Value) -> Option<&str> {
    value
        .get("status")
        .and_then(Value::as_str)
        .or_else(|| value.get("type").and_then(Value::as_str))
}

/// Merge status rows from one array payload into an output map.
fn extend_statuses_from_array(statuses: &mut HashMap<String, RuntimeStatus>, arr: &[Value]) {
    for entry in arr {
        let session_id = entry
            .get("sessionId")
            .and_then(Value::as_str)
            .or_else(|| entry.get("session_id").and_then(Value::as_str))
            .or_else(|| entry.get("id").and_then(Value::as_str));
        let status = nested_status_value(entry);
        if let (Some(session_id), Some(status)) = (session_id, status) {
            statuses.insert(session_id.to_string(), map_opencode_status(status));
        }
    }
}

#[cfg(test)]
mod tests {
    use serde_json::json;

    use super::{extract_status_map, map_opencode_status, parse_session_summaries};
    use crate::application::{MessageDispatchProvider, RuntimeStatus};

    #[test]
    fn extract_status_map_parses_object_keyed_status_values() {
        let payload = json!({
            "session_a": "idle",
            "session_b": "busy",
            "session_c": { "status": "retry" },
            "session_d": { "type": "busy" }
        });

        let statuses = extract_status_map(&payload);
        assert_eq!(statuses.get("session_a"), Some(&RuntimeStatus::Waiting));
        assert_eq!(statuses.get("session_b"), Some(&RuntimeStatus::Running));
        assert_eq!(statuses.get("session_c"), Some(&RuntimeStatus::Running));
        assert_eq!(statuses.get("session_d"), Some(&RuntimeStatus::Running));
    }

    #[test]
    fn extract_status_map_parses_nested_sessions_array() {
        let payload = json!({
            "sessions": [
                { "sessionId": "s1", "status": "idle" },
                { "id": "s2", "status": "busy" },
                { "session_id": "s3", "type": "retry" }
            ]
        });

        let statuses = extract_status_map(&payload);
        assert_eq!(statuses.get("s1"), Some(&RuntimeStatus::Waiting));
        assert_eq!(statuses.get("s2"), Some(&RuntimeStatus::Running));
        assert_eq!(statuses.get("s3"), Some(&RuntimeStatus::Running));
    }

    #[test]
    fn map_opencode_status_handles_known_and_unknown() {
        assert_eq!(map_opencode_status("idle"), RuntimeStatus::Waiting);
        assert_eq!(map_opencode_status("busy"), RuntimeStatus::Running);
        assert_eq!(map_opencode_status("retry"), RuntimeStatus::Running);
        assert_eq!(map_opencode_status("other"), RuntimeStatus::Unknown);
    }

    #[test]
    fn parse_session_summaries_accept_array_payload() {
        let payload = json!([
            {
                "id": "s1",
                "directory": "/tmp/a",
                "title": "Session A",
                "slug": "quiet-star",
                "time": { "updated": 42 }
            },
            { "sessionId": "s2", "dir": "/tmp/b" }
        ]);

        let sessions = parse_session_summaries(&payload, "http://127.0.0.1:61103");
        assert_eq!(sessions.len(), 2);
        assert_eq!(
            sessions[0].session.provider,
            MessageDispatchProvider::Opencode
        );
        assert_eq!(sessions[0].session.session_id, "s1");
        assert_eq!(sessions[0].session.directory.as_deref(), Some("/tmp/a"));
        assert_eq!(sessions[0].title.as_deref(), Some("Session A"));
        assert_eq!(sessions[0].slug.as_deref(), Some("quiet-star"));
        assert_eq!(sessions[0].updated_at_unix_ms, Some(42));
        assert_eq!(sessions[1].session.session_id, "s2");
        assert_eq!(sessions[1].session.directory.as_deref(), Some("/tmp/b"));
    }
}
