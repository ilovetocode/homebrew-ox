use crate::error::{AgentError, AppError};

/// Map a `ureq::Error` to `AppError::Agent(Unavailable)`.
pub(crate) fn map_ureq_error(context: &str, err: ureq::Error) -> AppError {
    // Keep stable key=value tokens (`context=`, `http_status=`,
    // `transport_error=`) so application-layer retry classification does not
    // depend on provider body prose.
    let message = match err {
        ureq::Error::Status(code, resp) => {
            let body = resp.into_string().unwrap_or_default();
            let normalized_context = context.replace(' ', "_");
            format!("opencode context={normalized_context} http_status={code} detail={body}")
        }
        ureq::Error::Transport(transport) => {
            let normalized_context = context.replace(' ', "_");
            format!("opencode context={normalized_context} transport_error={transport}")
        }
    };
    AppError::Agent(AgentError::Unavailable { message })
}

/// Build an unavailable error for adapter-level failures.
pub(crate) fn opencode_unavailable(detail: &str) -> AppError {
    AppError::Agent(AgentError::Unavailable {
        message: format!("opencode: {detail}"),
    })
}
