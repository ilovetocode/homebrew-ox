//! HTTP adapter for the `opencode serve` API.

use std::collections::HashMap;
use std::sync::Mutex;
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::{SystemTime, UNIX_EPOCH};

use serde_json::{Value, json};

use crate::application::{
    ConversationMessage, ConversationReadResult, ConversationReadSource,
    MessageDispatchCreateSessionRequest, MessageDispatchCreateSessionResult, MessageDispatchPort,
    MessageDispatchProvider, MessageDispatchResult, MessageDispatchSendRequest,
    MessageDispatchSessionRef, MessageDispatchSessionSummary, MessageDispatchSlashCommandRequest,
    MessageReadRequest, OpencodeSettings, RuntimeStatus,
};
use crate::error::{AgentError, AppError};

use super::errors::{map_ureq_error, opencode_unavailable};
use super::http::OpencodeHttpClient;
use super::parsing::{
    extract_session_directory, extract_status_map, parse_messages, parse_session_summaries,
    same_directory,
};
use super::status_cache::SessionStatusCache;

/// HTTP adapter for the `opencode serve` API.
///
/// Implements [`MessageDispatchPort`] using `ureq` for synchronous HTTP calls.
pub(crate) struct OpencodeApiAdapter {
    settings: OpencodeSettings,
    http: OpencodeHttpClient,
    status_cache: Mutex<SessionStatusCache>,
}

impl OpencodeApiAdapter {
    /// Build an adapter configured from persisted [`OpencodeSettings`].
    pub(crate) fn new(settings: OpencodeSettings) -> Self {
        let http = OpencodeHttpClient::new(&settings);
        Self {
            settings,
            http,
            status_cache: Mutex::new(SessionStatusCache::new()),
        }
    }

    /// Resolve status rows for all sessions on one server.
    fn read_server_statuses(
        &self,
        server_url: &str,
    ) -> Result<HashMap<String, RuntimeStatus>, AppError> {
        self.lock_status_cache()
            .get_or_fetch(&self.settings, server_url, || {
                self.fetch_server_statuses(server_url)
            })
    }

    /// Fetch and parse one server's `/session/status` payload.
    fn fetch_server_statuses(
        &self,
        server_url: &str,
    ) -> Result<HashMap<String, RuntimeStatus>, AppError> {
        let url = format!("{server_url}/session/status");
        let resp: Value = self
            .http
            .get(&url)
            .call()
            .map_err(|e| map_ureq_error("read session status", e))?
            .into_json()
            .map_err(|e| opencode_unavailable(&format!("parse status response: {e}")))?;

        Ok(extract_status_map(&resp))
    }

    fn lock_status_cache(&self) -> std::sync::MutexGuard<'_, SessionStatusCache> {
        self.status_cache
            .lock()
            .unwrap_or_else(std::sync::PoisonError::into_inner)
    }

    fn refresh_server_statuses(
        &self,
        server_url: &str,
    ) -> Result<HashMap<String, RuntimeStatus>, AppError> {
        let fresh = self.fetch_server_statuses(server_url);
        self.lock_status_cache()
            .replace(&self.settings, server_url, &fresh);
        fresh
    }
}

impl MessageDispatchPort for OpencodeApiAdapter {
    fn create_session(
        &self,
        request: &MessageDispatchCreateSessionRequest,
    ) -> Result<MessageDispatchCreateSessionResult, AppError> {
        let url = format!("{}/session", request.server_url);
        let body = match &request.directory {
            Some(dir) => json!({"dir": dir}),
            None => json!({}),
        };
        let resp: Value = self
            .http
            .post(&url)
            .send_json(body)
            .map_err(|e| map_ureq_error("create session", e))?
            .into_json()
            .map_err(|e| opencode_unavailable(&format!("parse create session response: {e}")))?;

        let session_id = resp
            .get("id")
            .and_then(Value::as_str)
            .filter(|s| !s.is_empty())
            .ok_or_else(|| opencode_unavailable("create session response missing 'id'"))?
            .to_string();

        // OpenCode servers can be directory-affine based on how `opencode
        // serve` was started. We enforce strict directory agreement here so
        // callers can recover by selecting/restarting a workspace-local sidecar
        // instead of silently binding to the wrong repository.
        let returned_directory = extract_session_directory(&resp);
        if let (Some(requested_directory), Some(returned_directory)) =
            (request.directory.as_deref(), returned_directory.as_deref())
            && !same_directory(requested_directory, returned_directory)
        {
            return Err(AppError::Agent(AgentError::DirectoryAffinityMismatch {
                server_url: request.server_url.clone(),
                requested_directory: requested_directory.to_string(),
                returned_directory: returned_directory.to_string(),
            }));
        }

        Ok(MessageDispatchCreateSessionResult {
            session: MessageDispatchSessionRef {
                provider: MessageDispatchProvider::Opencode,
                server_url: request.server_url.clone(),
                session_id,
                directory: returned_directory.or_else(|| request.directory.clone()),
            },
        })
    }

    fn list_sessions(
        &self,
        server_url: &str,
    ) -> Result<Vec<MessageDispatchSessionSummary>, AppError> {
        let url = format!("{server_url}/session");
        let resp: Value = self
            .http
            .get(&url)
            .call()
            .map_err(|e| map_ureq_error("list sessions", e))?
            .into_json()
            .map_err(|e| opencode_unavailable(&format!("parse list sessions response: {e}")))?;
        Ok(parse_session_summaries(&resp, server_url))
    }

    fn list_child_sessions(
        &self,
        session: &MessageDispatchSessionRef,
    ) -> Result<Vec<MessageDispatchSessionSummary>, AppError> {
        let url = format!(
            "{}/session/{}/children",
            session.server_url, session.session_id
        );
        let resp: Value = self
            .http
            .get(&url)
            .call()
            .map_err(|e| map_ureq_error("list child sessions", e))?
            .into_json()
            .map_err(|e| {
                opencode_unavailable(&format!("parse list child sessions response: {e}"))
            })?;
        Ok(parse_session_summaries(&resp, &session.server_url))
    }

    fn send_message(
        &self,
        request: &MessageDispatchSendRequest,
    ) -> Result<MessageDispatchResult, AppError> {
        // Use prompt_async to avoid blocking until the LLM finishes its
        // response. The endpoint returns 204 No Content immediately.
        let url = format!(
            "{}/session/{}/prompt_async",
            request.session.server_url, request.session.session_id,
        );
        let body = json!({
            "parts": [{
                "type": "text",
                "text": request.message
            }]
        });
        let resp = self
            .http
            .fast_post(&url)
            .send_json(body)
            .map_err(|e| map_ureq_error("send message", e))?;

        // prompt_async returns 204 with no body; extract message ID only when
        // the server returns a JSON payload (future-proofing).
        let provider_message_id = if resp.status() == 204 {
            None
        } else {
            resp.into_json::<Value>()
                .ok()
                .and_then(|v| v.get("id").and_then(Value::as_str).map(ToString::to_string))
        };

        Ok(MessageDispatchResult {
            dispatch_id: new_dispatch_id(),
            accepted_at_unix_ms: now_unix_ms(),
            provider_message_id,
        })
    }

    fn send_slash_command(
        &self,
        request: &MessageDispatchSlashCommandRequest,
    ) -> Result<MessageDispatchResult, AppError> {
        let url = format!(
            "{}/session/{}/command",
            request.session.server_url, request.session.session_id,
        );
        let resp = self
            .http
            .fast_post(&url)
            .send_json(json!({
                "command": request.command,
                "arguments": request.arguments,
            }))
            .map_err(|e| map_ureq_error("send slash command", e))?;

        let status = resp.status();
        let provider_message_id = if status == 204 {
            None
        } else {
            resp.into_json::<Value>()
                .ok()
                .and_then(|v| v.get("id").and_then(Value::as_str).map(ToString::to_string))
        };

        Ok(MessageDispatchResult {
            dispatch_id: new_dispatch_id(),
            accepted_at_unix_ms: now_unix_ms(),
            provider_message_id,
        })
    }

    fn read_last_message(
        &self,
        request: &MessageReadRequest,
    ) -> Result<Option<ConversationMessage>, AppError> {
        let conversation = self.read_full_conversation(request)?;
        let last_assistant = conversation
            .messages
            .into_iter()
            .rev()
            .find(|m| m.role == "assistant");
        Ok(last_assistant)
    }

    fn read_full_conversation(
        &self,
        request: &MessageReadRequest,
    ) -> Result<ConversationReadResult, AppError> {
        let url = conversation_messages_url(&request.session, request.limit);
        let resp: Value = self
            .http
            .get(&url)
            .call()
            .map_err(|e| map_ureq_error("read conversation", e))?
            .into_json()
            .map_err(|e| opencode_unavailable(&format!("parse conversation response: {e}")))?;

        let mut messages = parse_messages(&resp);
        if let Some(limit) = request.limit
            && messages.len() > limit
        {
            let split_at = messages.len().saturating_sub(limit);
            messages = messages.split_off(split_at);
        }
        Ok(ConversationReadResult {
            messages,
            source: ConversationReadSource::OpencodeSession,
            partial: false,
        })
    }

    fn read_session_status(
        &self,
        session: &MessageDispatchSessionRef,
    ) -> Result<RuntimeStatus, AppError> {
        let statuses = self.read_server_statuses(&session.server_url)?;
        if let Some(status) = statuses.get(&session.session_id).copied() {
            return Ok(status);
        }

        let fresh = self.refresh_server_statuses(&session.server_url)?;
        Ok(fresh
            .get(&session.session_id)
            .copied()
            .unwrap_or(RuntimeStatus::Unknown))
    }
}

/// Generate a unique dispatch identifier.
fn new_dispatch_id() -> String {
    static NEXT: AtomicU64 = AtomicU64::new(1);
    let counter = NEXT.fetch_add(1, Ordering::Relaxed);
    let ts = now_unix_ms();
    format!("dispatch_{ts}_{counter}")
}

/// Current wall-clock time as unix milliseconds.
fn now_unix_ms() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |d| d.as_millis())
}

fn conversation_messages_url(session: &MessageDispatchSessionRef, limit: Option<usize>) -> String {
    let base_url = format!(
        "{}/session/{}/message",
        session.server_url, session.session_id
    );
    match limit {
        Some(limit) => format!("{base_url}?limit={limit}"),
        None => base_url,
    }
}

#[cfg(test)]
mod tests {
    use super::{conversation_messages_url, new_dispatch_id};
    use crate::application::{MessageDispatchProvider, MessageDispatchSessionRef};

    fn session() -> MessageDispatchSessionRef {
        MessageDispatchSessionRef {
            provider: MessageDispatchProvider::Opencode,
            server_url: "http://127.0.0.1:4096".to_string(),
            session_id: "session-123".to_string(),
            directory: None,
        }
    }

    #[test]
    fn conversation_messages_url_omits_limit_when_absent() {
        let url = conversation_messages_url(&session(), None);
        assert_eq!(url, "http://127.0.0.1:4096/session/session-123/message");
    }

    #[test]
    fn conversation_messages_url_includes_limit_query() {
        let url = conversation_messages_url(&session(), Some(50));
        assert_eq!(
            url,
            "http://127.0.0.1:4096/session/session-123/message?limit=50"
        );
    }

    #[test]
    fn dispatch_id_is_non_empty() {
        assert!(!new_dispatch_id().is_empty());
    }
}
