use std::collections::HashMap;
use std::time::{Duration, Instant};

use crate::application::{OpencodeSettings, RuntimeStatus};
use crate::error::{AgentError, AppError};

/// Cached `/session/status` response keyed by server URL.
#[derive(Clone)]
struct SessionStatusCacheEntry {
    payload: SessionStatusCachePayload,
    expires_at: Instant,
}

/// Cached status payload for one server.
#[derive(Clone)]
enum SessionStatusCachePayload {
    Ok(HashMap<String, RuntimeStatus>),
    Err(String),
}

/// In-memory TTL cache for one `OpenCode` adapter instance.
pub(crate) struct SessionStatusCache {
    entries: HashMap<String, SessionStatusCacheEntry>,
}

impl SessionStatusCache {
    pub(crate) fn new() -> Self {
        Self {
            entries: HashMap::new(),
        }
    }

    /// Return cached statuses when fresh, otherwise fetch and cache.
    pub(crate) fn get_or_fetch<F>(
        &mut self,
        settings: &OpencodeSettings,
        server_url: &str,
        fetch: F,
    ) -> Result<HashMap<String, RuntimeStatus>, AppError>
    where
        F: FnOnce() -> Result<HashMap<String, RuntimeStatus>, AppError>,
    {
        let now = Instant::now();
        self.entries.retain(|_, entry| entry.expires_at > now);

        if let Some(entry) = self.entries.get(server_url)
            && entry.expires_at > now
        {
            return clone_cached_status_payload(&entry.payload);
        }

        let fetched = fetch();
        let entry = SessionStatusCacheEntry {
            payload: match &fetched {
                Ok(statuses) => SessionStatusCachePayload::Ok(statuses.clone()),
                Err(err) => SessionStatusCachePayload::Err(err.to_string()),
            },
            expires_at: Instant::now() + status_cache_ttl(settings),
        };
        self.entries.insert(server_url.to_string(), entry);

        fetched
    }

    pub(crate) fn replace(
        &mut self,
        settings: &OpencodeSettings,
        server_url: &str,
        payload: &Result<HashMap<String, RuntimeStatus>, AppError>,
    ) {
        let entry = SessionStatusCacheEntry {
            payload: match payload {
                Ok(statuses) => SessionStatusCachePayload::Ok(statuses.clone()),
                Err(err) => SessionStatusCachePayload::Err(err.to_string()),
            },
            expires_at: Instant::now() + status_cache_ttl(settings),
        };
        self.entries.insert(server_url.to_string(), entry);
    }
}

pub(crate) fn status_cache_ttl(settings: &OpencodeSettings) -> Duration {
    // Reuse the provider poll interval setting for cache freshness so reads are
    // bounded but still very fresh for interactive dashboards.
    Duration::from_millis(settings.status_poll_interval_ms.max(1))
}

fn clone_cached_status_payload(
    payload: &SessionStatusCachePayload,
) -> Result<HashMap<String, RuntimeStatus>, AppError> {
    match payload {
        SessionStatusCachePayload::Ok(statuses) => Ok(statuses.clone()),
        SessionStatusCachePayload::Err(message) => Err(AppError::Agent(AgentError::Unavailable {
            message: message.clone(),
        })),
    }
}

#[cfg(test)]
mod tests {
    use std::sync::atomic::{AtomicUsize, Ordering};
    use std::time::Duration;

    use super::{SessionStatusCache, status_cache_ttl};
    use crate::application::{OpencodeSettings, RuntimeStatus};
    use crate::error::{AgentError, AppError};

    fn test_settings() -> OpencodeSettings {
        OpencodeSettings {
            server_url: "http://127.0.0.1:4096".to_string(),
            username_env: "USER_ENV".to_string(),
            password_env: "PASS_ENV".to_string(),
            request_timeout_ms: 1_000,
            read_request_timeout_ms: 1_000,
            status_poll_interval_ms: 150,
            conversation_page_size: 200,
        }
    }

    #[test]
    fn status_cache_ttl_uses_minimum_of_one_millisecond() {
        let mut settings = test_settings();
        settings.status_poll_interval_ms = 0;
        assert_eq!(status_cache_ttl(&settings), Duration::from_millis(1));
    }

    #[test]
    fn get_or_fetch_returns_cached_value_within_ttl() {
        let settings = test_settings();
        let mut cache = SessionStatusCache::new();
        let calls = AtomicUsize::new(0);

        let first = cache.get_or_fetch(&settings, "http://127.0.0.1:4096", || {
            calls.fetch_add(1, Ordering::Relaxed);
            let mut rows = std::collections::HashMap::new();
            rows.insert("s1".to_string(), RuntimeStatus::Waiting);
            Ok(rows)
        });
        assert!(first.is_ok());

        let second = cache.get_or_fetch(&settings, "http://127.0.0.1:4096", || {
            calls.fetch_add(1, Ordering::Relaxed);
            Ok(std::collections::HashMap::new())
        });
        assert!(second.is_ok());
        assert_eq!(calls.load(Ordering::Relaxed), 1);
    }

    #[test]
    fn get_or_fetch_caches_errors_within_ttl() {
        let settings = test_settings();
        let mut cache = SessionStatusCache::new();
        let calls = AtomicUsize::new(0);

        let first = cache.get_or_fetch(&settings, "http://127.0.0.1:4096", || {
            calls.fetch_add(1, Ordering::Relaxed);
            Err(AppError::Agent(AgentError::Unavailable {
                message: "boom".to_string(),
            }))
        });
        assert!(first.is_err());

        let second = cache.get_or_fetch(&settings, "http://127.0.0.1:4096", || {
            calls.fetch_add(1, Ordering::Relaxed);
            Ok(std::collections::HashMap::new())
        });
        assert!(second.is_err());
        assert_eq!(calls.load(Ordering::Relaxed), 1);
    }
}
