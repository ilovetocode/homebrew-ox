use std::sync::Arc;

use crate::application::{
    AuxSessionPort, MessageDispatchCreateSessionRequest, MessageDispatchPort,
    MessageDispatchProvider, MessageDispatchSessionRef, OpencodeSessionBootstrapPort,
    OpencodeSettings,
};
use crate::error::{AgentError, AppError};

use super::sidecar::OpencodeSidecarManager;

/// `OpenCode` session bootstrap adapter that ensures directory-affine sessions.
pub(crate) struct OpencodeSessionBootstrapAdapter {
    dispatch: Arc<dyn MessageDispatchPort>,
    sidecar: OpencodeSidecarManager,
    default_server_url: String,
}

impl OpencodeSessionBootstrapAdapter {
    /// Build a bootstrap adapter from provider settings + dispatch adapter.
    pub(crate) fn new(
        settings: OpencodeSettings,
        dispatch: Arc<dyn MessageDispatchPort>,
        aux_sessions: Arc<dyn AuxSessionPort>,
    ) -> Self {
        Self {
            sidecar: OpencodeSidecarManager::new(settings.clone(), aux_sessions),
            default_server_url: settings.server_url,
            dispatch,
        }
    }

    fn create_session_for_directory(
        &self,
        server_url: &str,
        directory: &str,
    ) -> Result<MessageDispatchSessionRef, AppError> {
        self.dispatch
            .create_session(&MessageDispatchCreateSessionRequest {
                provider: MessageDispatchProvider::Opencode,
                server_url: server_url.to_string(),
                directory: Some(directory.to_string()),
            })
            .map(|result| result.session)
    }
}

impl OpencodeSessionBootstrapPort for OpencodeSessionBootstrapAdapter {
    fn ensure_session_for_directory(
        &self,
        directory: &str,
    ) -> Result<MessageDispatchSessionRef, AppError> {
        let mut server_url = self
            .sidecar
            .ensure_server_for_directory(directory, &self.default_server_url)?;

        match self.create_session_for_directory(&server_url, directory) {
            Ok(session) => Ok(session),
            Err(AppError::Agent(AgentError::DirectoryAffinityMismatch { .. })) => {
                server_url = self.sidecar.force_restart_server_for_directory(directory)?;
                self.create_session_for_directory(&server_url, directory)
            }
            Err(err) => Err(err),
        }
    }
}
