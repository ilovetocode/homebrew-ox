use crate::error::{AgentError, AppError};
use serde_json::{Value, json};
use std::io::{BufRead, BufReader, Write};
use std::process::{Child, ChildStdin, ChildStdout, Command, Stdio};
use std::sync::atomic::{AtomicU64, Ordering};
use std::thread;
use std::time::{Duration, Instant};

/// Process-bound JSON-RPC session over stdio with one `codex app-server`.
pub(super) struct JsonRpcSession {
    child: Child,
    stdin: ChildStdin,
    stdout: BufReader<ChildStdout>,
    events: Vec<Value>,
}

impl JsonRpcSession {
    pub(super) fn spawn() -> Result<Self, AppError> {
        let mut child = Command::new("codex")
            .arg("app-server")
            .arg("--listen")
            .arg("stdio://")
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|source| {
                codex_unavailable(format!("failed to start `codex app-server`: {source}"))
            })?;

        let stdin = child.stdin.take().ok_or_else(|| {
            codex_unavailable("failed to capture codex app-server stdin".to_string())
        })?;
        let stdout = child.stdout.take().ok_or_else(|| {
            codex_unavailable("failed to capture codex app-server stdout".to_string())
        })?;

        Ok(Self {
            child,
            stdin,
            stdout: BufReader::new(stdout),
            events: Vec::new(),
        })
    }

    pub(super) fn request(&mut self, method: &str, params: &Value) -> Result<Value, AppError> {
        let request_id = next_request_id();
        let request = json!({
            "id": request_id,
            "method": method,
            "params": params
        });
        self.write_message(&request)?;
        self.read_until_response(&request_id)
    }

    pub(super) fn notify(&mut self, method: &str, params: Option<Value>) -> Result<(), AppError> {
        let notification = if let Some(params) = params {
            json!({ "method": method, "params": params })
        } else {
            json!({ "method": method })
        };
        self.write_message(&notification)
    }

    pub(super) fn shutdown(mut self) -> Vec<Value> {
        drop(self.stdin);
        // Give app-server a brief chance to flush durable session metadata after
        // stdin closes. Immediate `kill` can race persistence and produce IDs
        // that `codex resume <id>` cannot resolve yet.
        let deadline = Instant::now() + Duration::from_secs(2);
        loop {
            match self.child.try_wait() {
                Ok(Some(_status)) => break,
                Ok(None) if Instant::now() < deadline => thread::sleep(Duration::from_millis(25)),
                Ok(None) | Err(_) => {
                    let _ = self.child.kill();
                    let _ = self.child.wait();
                    break;
                }
            }
        }
        self.events
    }

    fn write_message(&mut self, value: &Value) -> Result<(), AppError> {
        let encoded = serde_json::to_string(value)
            .map_err(|source| codex_unavailable(format!("failed to encode JSON-RPC: {source}")))?;
        self.stdin
            .write_all(encoded.as_bytes())
            .map_err(|source| codex_unavailable(format!("failed to write request: {source}")))?;
        self.stdin
            .write_all(b"\n")
            .map_err(|source| codex_unavailable(format!("failed to write newline: {source}")))?;
        self.stdin
            .flush()
            .map_err(|source| codex_unavailable(format!("failed to flush request: {source}")))
    }

    fn read_until_response(&mut self, request_id: &str) -> Result<Value, AppError> {
        loop {
            let message = self.read_one_message()?;
            let Some(message_object) = message.as_object() else {
                self.events.push(message);
                continue;
            };
            let Some(response_id) = message_object.get("id").and_then(Value::as_str) else {
                self.events.push(Value::Object(message_object.clone()));
                continue;
            };
            if response_id != request_id {
                self.events.push(Value::Object(message_object.clone()));
                continue;
            }

            if let Some(error) = message_object.get("error") {
                return Err(codex_unavailable(format!(
                    "codex app-server request '{request_id}' failed: {error}"
                )));
            }
            let Some(result) = message_object.get("result") else {
                return Err(codex_unavailable(format!(
                    "codex app-server request '{request_id}' response missing result"
                )));
            };
            return Ok(result.clone());
        }
    }

    fn read_one_message(&mut self) -> Result<Value, AppError> {
        let mut line = String::new();
        loop {
            line.clear();
            // `read_line` reads one newline-delimited JSON-RPC message from the
            // process stdio transport.
            let bytes = self.stdout.read_line(&mut line).map_err(|source| {
                codex_unavailable(format!("failed reading response: {source}"))
            })?;
            if bytes == 0 {
                return Err(codex_unavailable(
                    "codex app-server closed stdout before response".to_string(),
                ));
            }
            if line.trim().is_empty() {
                continue;
            }
            let parsed = serde_json::from_str::<Value>(&line).map_err(|source| {
                codex_unavailable(format!(
                    "invalid JSON-RPC message from codex app-server: {source}"
                ))
            })?;
            return Ok(parsed);
        }
    }
}

pub(super) fn codex_unavailable(message: String) -> AppError {
    AppError::Agent(AgentError::Unavailable { message })
}

fn next_request_id() -> String {
    static NEXT_ID: AtomicU64 = AtomicU64::new(1);
    let id = NEXT_ID.fetch_add(1, Ordering::Relaxed);
    format!("ox-{id}")
}
