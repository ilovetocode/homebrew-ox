use super::json_rpc::{JsonRpcSession, codex_unavailable};
use super::rollout::{ensure_rollout_metadata, summary_runtime_status};
use crate::application::RuntimeStatus;
use crate::error::AppError;
use serde_json::{Value, json};
use std::collections::HashMap;
use std::path::Path;

pub(super) struct StartedThread {
    pub(super) thread_id: String,
    pub(super) rollout_path: String,
}

/// Perform the standard app-server handshake before sending protocol methods.
pub(super) fn initialize_client(client: &mut JsonRpcSession) -> Result<(), AppError> {
    let init_params = json!({
        "clientInfo": {
            "name": "ox",
            "title": "ox",
            "version": env!("CARGO_PKG_VERSION")
        },
        "capabilities": {
            "experimentalApi": true,
            "optOutNotificationMethods": Value::Null
        }
    });
    let _initialize_response = client.request("initialize", &init_params)?;
    client.notify("initialized", None)
}

pub(super) fn start_thread(
    client: &mut JsonRpcSession,
    working_dir: Option<&Path>,
) -> Result<StartedThread, AppError> {
    let response = client.request(
        "thread/start",
        &json!({
            "cwd": working_dir.map(|cwd_path| cwd_path.to_string_lossy().to_string())
        }),
    )?;
    parse_current_thread_start_response(&response)
}

/// Finish rollout persistence after the thread has started.
pub(super) fn finalize_bootstrap_persistence(
    _client: &mut JsonRpcSession,
    started: &StartedThread,
    working_dir: Option<&Path>,
) -> Result<(), AppError> {
    ensure_rollout_metadata(
        started.rollout_path.as_str(),
        started.thread_id.as_str(),
        working_dir,
    )
}

/// Read many Codex conversation summaries in one app-server process.
pub(super) fn read_thread_runtime_statuses(
    thread_ids: &[String],
) -> Result<HashMap<String, RuntimeStatus>, AppError> {
    if thread_ids.is_empty() {
        return Ok(HashMap::new());
    }

    let mut client = JsonRpcSession::spawn()?;
    initialize_client(&mut client)?;

    let mut statuses = HashMap::new();
    for thread_id in thread_ids {
        let response = match client.request(
            "getConversationSummary",
            &json!({
                "conversationId": thread_id
            }),
        ) {
            Ok(response) => response,
            Err(err) if is_retryable_summary_lookup_error(&err) => {
                statuses.insert(thread_id.clone(), RuntimeStatus::Waiting);
                continue;
            }
            Err(err) => return Err(err),
        };
        statuses.insert(thread_id.clone(), summary_runtime_status(&response));
    }
    let _events = client.shutdown();
    Ok(statuses)
}

pub(super) fn read_thread_rollout_path(thread_id: &str) -> Result<Option<String>, AppError> {
    let mut client = JsonRpcSession::spawn()?;
    initialize_client(&mut client)?;
    let response = match client.request(
        "getConversationSummary",
        &json!({
            "conversationId": thread_id
        }),
    ) {
        Ok(response) => Some(response),
        Err(err) if is_retryable_summary_lookup_error(&err) => None,
        Err(err) => return Err(err),
    };
    let _events = client.shutdown();
    Ok(response.and_then(|response| {
        response
            .get("summary")
            .and_then(|summary| summary.get("path"))
            .and_then(Value::as_str)
            .map(str::trim)
            .filter(|path| !path.is_empty())
            .map(ToString::to_string)
    }))
}

fn is_retryable_summary_lookup_error(err: &AppError) -> bool {
    let message = err.to_string();
    message.contains("no rollout found for conversation id")
        || (message.contains("rollout at") && message.contains("is empty"))
}

pub(super) fn parse_current_thread_start_response(
    response: &Value,
) -> Result<StartedThread, AppError> {
    let thread = response.get("thread").ok_or_else(|| {
        codex_unavailable("codex app-server 'thread/start' missing thread".to_string())
    })?;
    let thread_id = thread
        .get("id")
        .and_then(Value::as_str)
        .filter(|value| !value.trim().is_empty())
        .map(ToString::to_string)
        .ok_or_else(|| {
            codex_unavailable("codex app-server 'thread/start' missing thread.id".to_string())
        })?;
    let rollout_path = thread
        .get("path")
        .and_then(Value::as_str)
        .map(str::trim)
        .filter(|value| !value.is_empty())
        .map(ToString::to_string)
        .ok_or_else(|| {
            codex_unavailable("codex app-server 'thread/start' missing thread.path".to_string())
        })?;

    Ok(StartedThread {
        thread_id,
        rollout_path,
    })
}

#[cfg(test)]
mod tests {
    use super::parse_current_thread_start_response;
    use serde_json::json;
    use std::error::Error;

    type TestResult = Result<(), Box<dyn Error>>;

    #[test]
    fn start_thread_current_protocol_extracts_thread_id_and_rollout_path() -> TestResult {
        let response = json!({
            "thread": {
                "id": "thread_123",
                "path": "/tmp/rollout.jsonl"
            }
        });
        let started = parse_current_thread_start_response(&response)?;

        assert_eq!(started.thread_id, "thread_123");
        assert_eq!(started.rollout_path, "/tmp/rollout.jsonl");
        Ok(())
    }

    #[test]
    fn start_thread_current_protocol_requires_rollout_path() {
        let response = json!({
            "thread": {
                "id": "thread_123"
            }
        });

        let result = parse_current_thread_start_response(&response);
        assert!(result.is_err(), "expected missing thread.path error");
        let Err(err) = result else {
            unreachable!("asserted missing thread.path error");
        };
        assert!(
            err.to_string().contains("missing thread.path"),
            "expected current protocol to require thread.path; err={err}"
        );
    }
}
