use super::json_rpc::codex_unavailable;
use crate::application::{
    ConversationMessage, ConversationReadResult, ConversationReadSource, RuntimeStatus,
};
use crate::error::AppError;
use serde_json::{Value, json};
use std::collections::HashMap;
use std::fs::{self, File};
use std::io::{BufRead, BufReader, ErrorKind};
use std::path::Path;

const SESSION_META_FALLBACK_TIMESTAMP: &str = "1970-01-01T00:00:00.000Z";

/// Write a minimal `session_meta` scaffold when Codex reports an empty rollout.
///
/// `codex resume <thread_id>` only needs durable rollout metadata. Creating a
/// session-meta line avoids opening a synthetic in-progress turn.
pub(super) fn ensure_rollout_metadata(
    rollout_path: &str,
    thread_id: &str,
    working_dir: Option<&Path>,
) -> Result<(), AppError> {
    let path = Path::new(rollout_path);
    if let Ok(metadata) = fs::metadata(path)
        && metadata.len() > 0
    {
        return Ok(());
    }

    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent).map_err(|source| {
            codex_unavailable(format!(
                "failed creating rollout parent directory: {source}"
            ))
        })?;
    }

    let timestamp = rollout_timestamp_from_path(path)
        .unwrap_or_else(|| SESSION_META_FALLBACK_TIMESTAMP.to_string());
    let cwd = working_dir
        .map(|path| path.to_string_lossy().to_string())
        .unwrap_or_default();
    let session_meta = json!({
        "timestamp": timestamp,
        "type": "session_meta",
        "payload": {
            "id": thread_id,
            "timestamp": timestamp,
            "cwd": cwd,
            "originator": "ox",
            "cli_version": env!("CARGO_PKG_VERSION"),
            "source": "vscode"
        }
    });
    let encoded = serde_json::to_string(&session_meta).map_err(|source| {
        codex_unavailable(format!(
            "failed encoding rollout session_meta scaffold: {source}"
        ))
    })?;
    fs::write(path, format!("{encoded}\n"))
        .map_err(|source| codex_unavailable(format!("failed writing rollout scaffold: {source}")))
}

pub(super) fn rollout_timestamp_from_path(path: &Path) -> Option<String> {
    let file_name = path.file_name()?.to_str()?;
    let token = file_name.strip_prefix("rollout-")?;
    if token.len() < 19 {
        return None;
    }
    let timestamp_token = &token[..19];
    let (date, raw_time) = timestamp_token.split_once('T')?;
    if raw_time.len() != 8 {
        return None;
    }
    let formatted_time = raw_time.replace('-', ":");
    Some(format!("{date}T{formatted_time}.000Z"))
}

/// Map one summary response into runtime status.
///
/// `getConversationSummary` does not currently expose explicit turn-running
/// metadata, so we use its `summary.path` rollout reference and infer status
/// from lifecycle events in that file.
pub(super) fn summary_runtime_status(summary_response: &Value) -> RuntimeStatus {
    let Some(rollout_path) = rollout_path_from_summary(summary_response) else {
        return RuntimeStatus::Waiting;
    };

    match rollout_turn_lifecycle(Path::new(rollout_path)) {
        Ok(lifecycle) => {
            if lifecycle.latest_turn_running {
                RuntimeStatus::Running
            } else {
                RuntimeStatus::Waiting
            }
        }
        Err(source) if source.kind() == ErrorKind::NotFound => RuntimeStatus::Waiting,
        Err(_) => RuntimeStatus::Unknown,
    }
}

pub(super) fn read_rollout_conversation(
    path: &Path,
    limit: Option<usize>,
) -> Result<ConversationReadResult, AppError> {
    let file = File::open(path)
        .map_err(|source| codex_unavailable(format!("failed opening codex rollout: {source}")))?;
    let reader = BufReader::new(file);
    let mut messages = Vec::new();

    for (line_index, line_result) in reader.lines().enumerate() {
        let line = line_result.map_err(|source| {
            codex_unavailable(format!("failed reading codex rollout: {source}"))
        })?;
        if line.trim().is_empty() {
            continue;
        }
        let Ok(value) = serde_json::from_str::<Value>(&line) else {
            continue;
        };
        if let Some(message) = rollout_message_from_value(&value, line_index + 1) {
            messages.push(message);
        }
    }

    let mut partial = false;
    if let Some(limit) = limit
        && messages.len() > limit
    {
        let split_at = messages.len().saturating_sub(limit);
        messages = messages.split_off(split_at);
        partial = true;
    }

    Ok(ConversationReadResult {
        messages,
        source: ConversationReadSource::CodexRollout,
        partial,
    })
}

fn rollout_path_from_summary(summary_response: &Value) -> Option<&str> {
    summary_response
        .get("summary")
        .and_then(|summary| summary.get("path"))
        .and_then(Value::as_str)
        .map(str::trim)
        .filter(|path| !path.is_empty())
}

fn rollout_message_from_value(value: &Value, line_index: usize) -> Option<ConversationMessage> {
    if value.get("type").and_then(Value::as_str) != Some("event_msg") {
        return None;
    }
    let payload = value.get("payload")?;
    let payload_type = payload.get("type").and_then(Value::as_str)?;
    let role = match payload_type {
        "user_message" => "user",
        "agent_message" => "assistant",
        _ => return None,
    };
    let text = payload.get("message").and_then(Value::as_str)?.trim();
    if text.is_empty() {
        return None;
    }

    let created_at_unix_ms = value
        .get("timestamp")
        .and_then(Value::as_str)
        .and_then(parse_rollout_timestamp_unix_ms)
        .unwrap_or(0);
    let finish_reason = payload
        .get("phase")
        .and_then(Value::as_str)
        .map(ToString::to_string);
    Some(ConversationMessage {
        message_id: format!("codex_rollout_{line_index}"),
        role: role.to_string(),
        created_at_unix_ms,
        completed_at_unix_ms: Some(created_at_unix_ms),
        text: text.to_string(),
        tool_names: Vec::new(),
        patch_files: Vec::new(),
        finish_reason,
        synthesized_text: role == "assistant",
    })
}

fn parse_rollout_timestamp_unix_ms(raw: &str) -> Option<u128> {
    let raw = raw.strip_suffix('Z')?;
    let (date, time) = raw.split_once('T')?;
    let (year, month, day) = parse_date(date)?;
    let (hour, minute, second, millis) = parse_time(time)?;
    let days = days_from_civil(year, month, day);
    if days < 0 {
        return None;
    }
    let seconds = days
        .saturating_mul(86_400)
        .saturating_add(i64::from(hour) * 3_600)
        .saturating_add(i64::from(minute) * 60)
        .saturating_add(i64::from(second));
    Some(u128::try_from(seconds).ok()?.saturating_mul(1_000) + u128::from(millis))
}

fn parse_date(raw: &str) -> Option<(i64, i64, i64)> {
    let mut parts = raw.split('-');
    Some((
        parts.next()?.parse().ok()?,
        parts.next()?.parse().ok()?,
        parts.next()?.parse().ok()?,
    ))
}

fn parse_time(raw: &str) -> Option<(u32, u32, u32, u32)> {
    let (clock, fraction) = raw.split_once('.').unwrap_or((raw, ""));
    let mut parts = clock.split(':');
    let hour = parts.next()?.parse().ok()?;
    let minute = parts.next()?.parse().ok()?;
    let second = parts.next()?.parse().ok()?;
    let millis = parse_fractional_millis(fraction)?;
    Some((hour, minute, second, millis))
}

fn parse_fractional_millis(raw: &str) -> Option<u32> {
    if raw.is_empty() {
        return Some(0);
    }
    let digits = raw
        .chars()
        .take_while(char::is_ascii_digit)
        .collect::<String>();
    if digits.is_empty() {
        return Some(0);
    }
    let padded = match digits.len() {
        0 => "000".to_string(),
        1 => format!("{digits}00"),
        2 => format!("{digits}0"),
        _ => digits.chars().take(3).collect(),
    };
    padded.parse().ok()
}

// Convert one civil date to a unix-epoch day offset using the same
// year/month/day arithmetic as Howard Hinnant's public-domain algorithm.
fn days_from_civil(year: i64, month: i64, day: i64) -> i64 {
    let year = year - i64::from(month <= 2);
    let era = if year >= 0 { year } else { year - 399 } / 400;
    let year_of_era = year - era * 400;
    let month_prime = month + if month > 2 { -3 } else { 9 };
    let day_of_year = (153 * month_prime + 2) / 5 + day - 1;
    let day_of_era = year_of_era * 365 + year_of_era / 4 - year_of_era / 100 + day_of_year;
    era * 146_097 + day_of_era - 719_468
}

#[derive(Default)]
struct RolloutTurnLifecycle {
    latest_turn_running: bool,
}

fn rollout_turn_lifecycle(path: &Path) -> Result<RolloutTurnLifecycle, std::io::Error> {
    let file = File::open(path)?;
    let reader = BufReader::new(file);
    // Keep turn state by ID, but report status from the latest turn seen in
    // lifecycle events. Older dangling turns should not pin runtime forever.
    let mut lifecycle = RolloutTurnLifecycle::default();
    let mut latest_turn_id = String::new();
    let mut running_by_turn_id = HashMap::<String, bool>::new();

    for line_result in reader.lines() {
        let line = line_result?;
        if line.trim().is_empty() {
            continue;
        }
        let Ok(value) = serde_json::from_str::<Value>(&line) else {
            continue;
        };
        if value.get("type").and_then(Value::as_str) != Some("event_msg") {
            continue;
        }
        let Some(payload) = value.get("payload") else {
            continue;
        };
        let Some(event_type) = payload.get("type").and_then(Value::as_str) else {
            continue;
        };
        let Some(turn_id) = payload
            .get("turn_id")
            .and_then(Value::as_str)
            .or_else(|| payload.get("turnId").and_then(Value::as_str))
        else {
            continue;
        };
        if turn_id.is_empty() {
            continue;
        }

        match event_type {
            "task_started" => {
                latest_turn_id.clear();
                latest_turn_id.push_str(turn_id);
                running_by_turn_id.insert(turn_id.to_string(), true);
            }
            // `turn_aborted` is a terminal turn state from Codex's perspective.
            "task_complete" | "turn_aborted" => {
                latest_turn_id.clear();
                latest_turn_id.push_str(turn_id);
                running_by_turn_id.insert(turn_id.to_string(), false);
            }
            _ => {}
        }
    }

    if latest_turn_id.is_empty() {
        return Ok(lifecycle);
    }
    lifecycle.latest_turn_running = *running_by_turn_id.get(&latest_turn_id).unwrap_or(&false);
    Ok(lifecycle)
}

#[cfg(test)]
mod tests {
    use super::{ensure_rollout_metadata, rollout_timestamp_from_path, summary_runtime_status};
    use crate::application::RuntimeStatus;
    use serde_json::{Value, json};
    use std::error::Error;
    use std::fs;
    use std::path::Path;
    use std::time::{SystemTime, UNIX_EPOCH};

    type TestResult = Result<(), Box<dyn Error>>;

    fn temp_dir(prefix: &str) -> std::path::PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos());
        std::env::temp_dir().join(format!("{prefix}-{nanos}"))
    }

    #[test]
    fn summary_runtime_status_running_when_latest_turn_started() -> TestResult {
        let root = temp_dir("ox-codex-summary-running");
        fs::create_dir_all(&root)?;
        let rollout = root.join("rollout.jsonl");
        fs::write(
            &rollout,
            "{\"type\":\"event_msg\",\"payload\":{\"type\":\"task_started\",\"turn_id\":\"t1\"}}\n",
        )?;
        let summary = json!({
            "summary": {
                "path": rollout.to_string_lossy().to_string()
            }
        });

        assert_eq!(summary_runtime_status(&summary), RuntimeStatus::Running);
        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn summary_runtime_status_waiting_when_latest_turn_completes() -> TestResult {
        let root = temp_dir("ox-codex-summary-waiting");
        fs::create_dir_all(&root)?;
        let rollout = root.join("rollout.jsonl");
        fs::write(
            &rollout,
            "{\"type\":\"event_msg\",\"payload\":{\"type\":\"task_started\",\"turn_id\":\"t1\"}}\n\
             {\"type\":\"event_msg\",\"payload\":{\"type\":\"task_complete\",\"turn_id\":\"t1\"}}\n",
        )?;
        let summary = json!({
            "summary": {
                "path": rollout.to_string_lossy().to_string()
            }
        });

        assert_eq!(summary_runtime_status(&summary), RuntimeStatus::Waiting);
        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn summary_runtime_status_waiting_when_latest_turn_completes_but_older_turn_is_unfinished()
    -> TestResult {
        let root = temp_dir("ox-codex-summary-waiting-stale");
        fs::create_dir_all(&root)?;
        let rollout = root.join("rollout.jsonl");
        fs::write(
            &rollout,
            "{\"type\":\"event_msg\",\"payload\":{\"type\":\"task_started\",\"turn_id\":\"old\"}}\n\
             {\"type\":\"event_msg\",\"payload\":{\"type\":\"task_started\",\"turn_id\":\"latest\"}}\n\
             {\"type\":\"event_msg\",\"payload\":{\"type\":\"task_complete\",\"turn_id\":\"latest\"}}\n",
        )?;
        let summary = json!({
            "summary": {
                "path": rollout.to_string_lossy().to_string()
            }
        });

        assert_eq!(summary_runtime_status(&summary), RuntimeStatus::Waiting);
        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn summary_runtime_status_waiting_when_rollout_has_no_turn_lifecycle_events() -> TestResult {
        let root = temp_dir("ox-codex-summary-no-turns");
        fs::create_dir_all(&root)?;
        let rollout = root.join("rollout.jsonl");
        fs::write(
            &rollout,
            "{\"type\":\"session_meta\",\"payload\":{\"id\":\"conversation\"}}\n",
        )?;
        let summary = json!({
            "summary": {
                "path": rollout.to_string_lossy().to_string()
            }
        });

        assert_eq!(summary_runtime_status(&summary), RuntimeStatus::Waiting);
        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn summary_runtime_status_waiting_when_rollout_path_missing() {
        let summary = json!({
            "summary": {
                "conversationId": "abc"
            }
        });
        assert_eq!(summary_runtime_status(&summary), RuntimeStatus::Waiting);
    }

    #[test]
    fn summary_runtime_status_waiting_when_rollout_file_missing() {
        let summary = json!({
            "summary": {
                "path": "/path/that/does/not/exist/rollout.jsonl"
            }
        });
        assert_eq!(summary_runtime_status(&summary), RuntimeStatus::Waiting);
    }

    #[test]
    fn summary_runtime_status_unknown_when_rollout_path_is_not_a_file() -> TestResult {
        let root = temp_dir("ox-codex-summary-unreadable");
        fs::create_dir_all(&root)?;
        let summary = json!({
            "summary": {
                "path": root.to_string_lossy().to_string()
            }
        });

        assert_eq!(summary_runtime_status(&summary), RuntimeStatus::Unknown);
        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn rollout_timestamp_from_path_extracts_rfc3339() {
        let path = Path::new("/tmp/rollout-2026-02-26T07-36-05-019c98e0-56a7.jsonl");
        assert_eq!(
            rollout_timestamp_from_path(path).as_deref(),
            Some("2026-02-26T07:36:05.000Z")
        );
    }

    #[test]
    fn ensure_rollout_metadata_writes_session_meta_scaffold() -> TestResult {
        let root = temp_dir("ox-codex-rollout-meta");
        let rollout = root.join("rollout-2026-02-26T07-36-05-seeded.jsonl");

        ensure_rollout_metadata(
            rollout.to_string_lossy().as_ref(),
            "thread_123",
            Some(Path::new("/tmp/worktree")),
        )?;

        let encoded = fs::read_to_string(&rollout)?;
        let written: Value = serde_json::from_str(encoded.trim())?;
        assert_eq!(written["type"], "session_meta");
        assert_eq!(written["payload"]["id"], "thread_123");
        assert_eq!(written["payload"]["cwd"], "/tmp/worktree");
        assert_eq!(written["timestamp"], "2026-02-26T07:36:05.000Z");

        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn ensure_rollout_metadata_preserves_existing_non_empty_file() -> TestResult {
        let root = temp_dir("ox-codex-rollout-existing");
        fs::create_dir_all(&root)?;
        let rollout = root.join("rollout-existing.jsonl");
        fs::write(&rollout, "existing\n")?;

        ensure_rollout_metadata(rollout.to_string_lossy().as_ref(), "thread_123", None)?;

        assert_eq!(fs::read_to_string(&rollout)?, "existing\n");
        fs::remove_dir_all(root)?;
        Ok(())
    }
}
