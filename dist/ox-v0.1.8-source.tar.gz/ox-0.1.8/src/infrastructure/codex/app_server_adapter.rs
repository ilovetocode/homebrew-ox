mod json_rpc;
mod protocol;
mod rollout;

use crate::application::{
    CodexThreadBootstrap, CodexThreadPort, CodexThreadStartRequest, ConversationReadResult,
    ConversationReadSource, RuntimeStatus,
};
use crate::error::AppError;
use protocol::{
    finalize_bootstrap_persistence, initialize_client, read_thread_rollout_path,
    read_thread_runtime_statuses, start_thread,
};
use std::collections::HashMap;
use std::path::Path;

use self::json_rpc::JsonRpcSession;

/// Native Codex app-server protocol adapter used by runtime orchestration.
pub(crate) struct CodexAppServerAdapter;

impl CodexThreadPort for CodexAppServerAdapter {
    fn start_thread(
        &self,
        request: &CodexThreadStartRequest,
    ) -> Result<CodexThreadBootstrap, AppError> {
        bootstrap_thread(request.working_dir.as_deref())
    }

    fn read_thread_statuses(
        &self,
        thread_ids: &[String],
    ) -> Result<HashMap<String, RuntimeStatus>, AppError> {
        read_thread_runtime_statuses(thread_ids)
    }

    fn read_thread_conversation(
        &self,
        thread_id: &str,
        limit: Option<usize>,
    ) -> Result<ConversationReadResult, AppError> {
        let Some(rollout_path) = read_thread_rollout_path(thread_id)? else {
            return Ok(ConversationReadResult {
                messages: Vec::new(),
                source: ConversationReadSource::CodexRollout,
                partial: true,
            });
        };
        let path = Path::new(&rollout_path);
        match rollout::read_rollout_conversation(path, limit) {
            Ok(result) => Ok(result),
            Err(AppError::Agent(crate::error::AgentError::Unavailable { .. }))
                if !path.exists() =>
            {
                Ok(ConversationReadResult {
                    messages: Vec::new(),
                    source: ConversationReadSource::CodexRollout,
                    partial: true,
                })
            }
            Err(err) => Err(err),
        }
    }
}

/// Start one Codex thread through `codex app-server`.
///
/// This keeps MVP scope intentionally narrow:
/// - initialize one JSON-RPC session
/// - require the current `thread/start` API
/// - write any missing rollout metadata so `codex resume <id>` can attach
/// - read all non-matching messages as raw events so callers can reason about
///   protocol activity at bootstrap time
fn bootstrap_thread(working_dir: Option<&Path>) -> Result<CodexThreadBootstrap, AppError> {
    let mut client = JsonRpcSession::spawn()?;
    initialize_client(&mut client)?;

    let bootstrap = start_thread(&mut client, working_dir)?;
    finalize_bootstrap_persistence(&mut client, &bootstrap, working_dir)?;
    let events = client.shutdown();
    Ok(CodexThreadBootstrap {
        thread_id: bootstrap.thread_id,
        event_count: events.len(),
    })
}
