use std::path::Path;
use std::sync::Arc;

use crate::application::AuxSessionPort;
use crate::error::{AppError, TmuxError, tmux_stderr_is_missing_session, tmux_stderr_is_no_server};

use super::{TmuxClient, TmuxConfig};

/// Adapter for named non-agent tmux sessions (for example daemon + sidecar).
pub(crate) struct TmuxAuxSessionAdapter {
    _tmux_config: Arc<TmuxConfig>,
}

impl TmuxAuxSessionAdapter {
    pub(crate) fn new(tmux_config: Arc<TmuxConfig>) -> Self {
        Self {
            _tmux_config: tmux_config,
        }
    }

    fn session_exists_raw(session_name: &str) -> Result<bool, TmuxError> {
        match TmuxClient::run_system_ok(&["has-session", "-t", session_name]) {
            Ok(()) => Ok(true),
            // A missing tmux server means the session is absent, not that the
            // sidecar startup should hard-fail before we even try `new-session`.
            Err(TmuxError::CommandFailed { stderr })
                if tmux_stderr_is_missing_session(&stderr) || tmux_stderr_is_no_server(&stderr) =>
            {
                Ok(false)
            }
            Err(err) => Err(err),
        }
    }

    fn session_matches_command(session_name: &str, argv: &[String]) -> Result<bool, TmuxError> {
        let expected = argv
            .first()
            .and_then(|value| Path::new(value).file_name())
            .and_then(|value| value.to_str())
            .unwrap_or_default();
        if expected.is_empty() {
            return Ok(false);
        }

        let output = TmuxClient::run_system(&[
            "list-panes",
            "-t",
            session_name,
            "-F",
            "#{pane_current_command}\t#{pane_dead}",
        ])?;
        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr).into_owned();
            if tmux_stderr_is_no_server(&stderr) {
                return Ok(false);
            }
            return Err(TmuxError::CommandFailed { stderr });
        }

        let stdout = String::from_utf8_lossy(&output.stdout);
        let Some(first_line) = stdout.lines().next() else {
            return Ok(false);
        };
        let mut parts = first_line.split('\t');
        let current_command = parts.next().unwrap_or_default().trim();
        let pane_dead = parts.next().unwrap_or_default().trim() == "1";
        if pane_dead {
            return Ok(false);
        }

        Ok(current_command == expected)
    }
}

impl AuxSessionPort for TmuxAuxSessionAdapter {
    fn session_exists(&self, session_name: &str) -> Result<bool, AppError> {
        Self::session_exists_raw(session_name).map_err(AppError::Tmux)
    }

    fn ensure_detached_command_session(
        &self,
        session_name: &str,
        working_dir: Option<&str>,
        argv: &[String],
    ) -> Result<(), AppError> {
        if Self::session_exists_raw(session_name).map_err(AppError::Tmux)? {
            if Self::session_matches_command(session_name, argv).map_err(AppError::Tmux)? {
                return Ok(());
            }
            self.kill_session(session_name)?;
        }

        let mut tmux_args = vec![
            "new-session".to_string(),
            "-d".to_string(),
            "-s".to_string(),
        ];
        tmux_args.push(session_name.to_string());
        if let Some(cwd) = working_dir {
            tmux_args.push("-c".to_string());
            tmux_args.push(cwd.to_string());
        }
        tmux_args.extend(argv.iter().cloned());
        let arg_refs = tmux_args.iter().map(String::as_str).collect::<Vec<_>>();

        match TmuxClient::run_system_ok(&arg_refs) {
            Ok(()) => Ok(()),
            Err(TmuxError::CommandFailed { stderr }) if stderr.contains("duplicate session") => {
                Ok(())
            }
            Err(err) => {
                if Self::session_exists_raw(session_name).map_err(AppError::Tmux)? {
                    Ok(())
                } else {
                    Err(AppError::Tmux(err))
                }
            }
        }
    }

    fn kill_session(&self, session_name: &str) -> Result<(), AppError> {
        match TmuxClient::run_system_ok(&["kill-session", "-t", session_name]) {
            Ok(()) => Ok(()),
            Err(TmuxError::CommandFailed { stderr })
                if tmux_stderr_is_missing_session(&stderr) || tmux_stderr_is_no_server(&stderr) =>
            {
                Ok(())
            }
            Err(err) => Err(AppError::Tmux(err)),
        }
    }
}
