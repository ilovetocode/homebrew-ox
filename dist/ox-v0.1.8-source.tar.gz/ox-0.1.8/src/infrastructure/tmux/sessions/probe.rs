use super::TmuxClient;
use crate::application::{AgentKind, HostSessionSnapshot, RuntimeStatus};
use crate::error::TmuxError;
use crate::infrastructure::tmux::TmuxConfig;
use crate::infrastructure::tmux::agent_detection::classify_agent_kind_from_command;
use std::collections::HashMap;
use std::sync::{Mutex, OnceLock};
use std::time::{Duration, Instant};

const SESSION_PROBE_CACHE_TTL: Duration = Duration::from_millis(300);
// Older tmux builds such as Debian's 3.3a rewrite tab/control separators in
// `list-* -F` output, so use a printable token that survives unchanged.
const LIST_SESSIONS_FORMAT: &str =
    "#{session_name}<<OX>>#{session_windows}<<OX>>#{session_attached}";
const LIST_PANES_FORMAT: &str = "#{session_name}<<OX>>#{pane_id}<<OX>>#{pane_pid}<<OX>>#{pane_tty}<<OX>>#{window_active}<<OX>>#{pane_active}<<OX>>#{pane_current_command}<<OX>>#{pane_current_path}";

#[derive(Clone)]
struct SessionProbeCacheEntry {
    sessions: Vec<HostSessionSnapshot>,
    current_paths: HashMap<String, String>,
    expires_at: Instant,
}

static SESSION_PROBE_CACHE: OnceLock<
    Mutex<std::collections::HashMap<String, SessionProbeCacheEntry>>,
> = OnceLock::new();

pub(super) fn list_sessions(conf: &TmuxConfig) -> Result<Vec<HostSessionSnapshot>, TmuxError> {
    let cache_key = conf.tmux_conf_path.to_string_lossy().to_string();
    if let Some(cached) = cached_sessions(&cache_key) {
        return Ok(cached);
    }

    let client = TmuxClient::new(conf);
    let raw_sessions =
        client.run_output_allow_no_server_empty(&["list-sessions", "-F", LIST_SESSIONS_FORMAT])?;
    let mut sessions = super::super::parsers::parse_sessions(&raw_sessions)?;
    if sessions.is_empty() {
        return Ok(sessions);
    }

    // Query pane metadata so we can map tmux pane -> Codex thread -> turn
    // state. This avoids reporting "running" just because a `codex` process is
    // present while it is actually waiting for input.
    let panes = list_all_panes(&client)?;
    let current_paths = current_paths_from_panes(&panes);
    let active_agents = detect_active_agent_by_session(&panes);

    for session in &mut sessions {
        if let Some(active) = active_agents.get(&session.name) {
            session.agent_kind = *active;
            // Active-pane command inspection tells us which tool owns the pane,
            // but it does not prove whether the tool is currently working or
            // sitting at a prompt. Keep tmux probe status coarse here and let
            // the higher-level pane/provider classifiers decide the activity
            // state from captured output.
            session.runtime_status = RuntimeStatus::Unknown;
            continue;
        }

        // Shell sessions intentionally skip agent status computation.
        session.agent_kind = AgentKind::Shell;
        session.runtime_status = RuntimeStatus::Unknown;
    }

    cache_sessions(cache_key, sessions.clone(), current_paths);
    Ok(sessions)
}

pub(super) fn session_current_paths(
    conf: &TmuxConfig,
) -> Result<HashMap<String, String>, TmuxError> {
    let cache_key = conf.tmux_conf_path.to_string_lossy().to_string();
    if let Some(cached) = cached_current_paths(&cache_key) {
        return Ok(cached);
    }

    let client = TmuxClient::new(conf);
    let panes = list_all_panes(&client)?;
    Ok(current_paths_from_panes(&panes))
}

pub(super) fn invalidate_session_cache() {
    let mut cache = cache_map()
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    cache.clear();
}

fn list_all_panes(client: &TmuxClient) -> Result<Vec<super::super::parsers::PaneRow>, TmuxError> {
    let raw =
        client.run_output_allow_no_server_empty(&["list-panes", "-a", "-F", LIST_PANES_FORMAT])?;
    super::super::parsers::parse_panes(&raw)
}

fn cache_map() -> &'static Mutex<std::collections::HashMap<String, SessionProbeCacheEntry>> {
    SESSION_PROBE_CACHE.get_or_init(|| Mutex::new(std::collections::HashMap::new()))
}

fn cached_sessions(cache_key: &str) -> Option<Vec<HostSessionSnapshot>> {
    with_cached_entry(cache_key, |entry| entry.sessions.clone())
}

fn cached_current_paths(cache_key: &str) -> Option<HashMap<String, String>> {
    with_cached_entry(cache_key, |entry| entry.current_paths.clone())
}

fn with_cached_entry<T>(
    cache_key: &str,
    project: impl FnOnce(&SessionProbeCacheEntry) -> T,
) -> Option<T> {
    let now = Instant::now();
    let mut cache = cache_map()
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    cache.retain(|_, entry| entry.expires_at > now);
    cache
        .get(cache_key)
        .filter(|entry| entry.expires_at > now)
        .map(project)
}

fn cache_sessions(
    cache_key: String,
    sessions: Vec<HostSessionSnapshot>,
    current_paths: HashMap<String, String>,
) {
    let expires_at = Instant::now() + SESSION_PROBE_CACHE_TTL;
    let mut cache = cache_map()
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner);
    cache.insert(
        cache_key,
        SessionProbeCacheEntry {
            sessions,
            current_paths,
            expires_at,
        },
    );
}

fn current_paths_from_panes(panes: &[super::super::parsers::PaneRow]) -> HashMap<String, String> {
    let mut selected = HashMap::<String, (u8, String)>::new();
    for pane in panes {
        let Some(path) = pane.pane_current_path.as_ref() else {
            continue;
        };
        if pane.session_name.is_empty() || path.is_empty() {
            continue;
        }

        let mut score = 0;
        if pane.window_active {
            score += 1;
        }
        if pane.pane_active {
            score += 1;
        }

        let entry = selected
            .entry(pane.session_name.clone())
            .or_insert((score, path.clone()));
        if score > entry.0 {
            *entry = (score, path.clone());
        }
    }

    selected
        .into_iter()
        .map(|(session, (_, path))| (session, path))
        .collect()
}

fn detect_active_agent_by_session(
    panes: &[super::super::parsers::PaneRow],
) -> HashMap<String, AgentKind> {
    panes
        .iter()
        .filter(|pane| pane.window_active && pane.pane_active)
        .map(|pane| {
            let agent_kind = pane
                .pane_current_command
                .as_deref()
                .map_or(AgentKind::Shell, classify_agent_kind_from_command);
            (pane.session_name.clone(), agent_kind)
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::detect_active_agent_by_session;
    use crate::domain::AgentKind;
    use crate::infrastructure::tmux::parsers::PaneRow;

    #[test]
    fn active_pane_detection_classifies_agent_kind_without_assigning_activity_state() {
        let panes = vec![PaneRow {
            session_name: "planner".to_string(),
            pane_id: "%1".to_string(),
            pane_pid: 42,
            pane_tty: "ttys001".to_string(),
            window_active: true,
            pane_active: true,
            pane_current_command: Some("opencode".to_string()),
            pane_current_path: Some("/tmp".to_string()),
        }];

        let by_session = detect_active_agent_by_session(&panes);
        assert_eq!(by_session.get("planner"), Some(&AgentKind::Opencode));
    }
}
