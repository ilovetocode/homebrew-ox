mod cache;
mod rollout_index;
mod snapshot_index;
mod turn_detection;

use std::collections::{HashMap, HashSet};
use std::path::{Path, PathBuf};

use crate::application::RuntimeStatus;
use snapshot_index::load_latest_thread_id_by_pane;
use turn_detection::detect_thread_status;

pub(super) fn detect_codex_status_by_pane(
    pane_ids: &HashSet<String>,
    shell_snapshots_dir: &Path,
    codex_sessions_root: &Path,
) -> HashMap<String, RuntimeStatus> {
    if pane_ids.is_empty() {
        return HashMap::new();
    }

    let threads_by_pane = load_latest_thread_id_by_pane(shell_snapshots_dir, pane_ids);
    let mut status_by_thread = HashMap::<String, RuntimeStatus>::new();
    let mut status_by_pane = HashMap::new();

    for pane_id in pane_ids {
        let Some(thread_id) = threads_by_pane.get(pane_id) else {
            status_by_pane.insert(pane_id.clone(), RuntimeStatus::Unknown);
            continue;
        };
        let status = *status_by_thread
            .entry(thread_id.clone())
            .or_insert_with(|| detect_thread_status(thread_id, codex_sessions_root));
        status_by_pane.insert(pane_id.clone(), status);
    }

    status_by_pane
}

pub(super) fn default_shell_snapshots_path() -> PathBuf {
    default_codex_root_path().join("shell_snapshots")
}

pub(super) fn default_codex_sessions_root_path() -> PathBuf {
    default_codex_root_path().join("sessions")
}

fn default_codex_root_path() -> PathBuf {
    std::env::var_os("HOME")
        .map_or_else(|| PathBuf::from("/"), PathBuf::from)
        .join(".codex")
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod tests {
    use std::collections::HashSet;
    use std::error::Error;
    use std::fs;
    use std::time::{SystemTime, UNIX_EPOCH};

    use crate::application::RuntimeStatus;

    use super::detect_codex_status_by_pane;

    type TestResult = Result<(), Box<dyn Error>>;

    fn temp_dir(prefix: &str) -> std::path::PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos());
        std::env::temp_dir().join(format!("{prefix}-{nanos}"))
    }

    #[test]
    fn detect_codex_status_by_pane_uses_turn_state_from_rollout() -> TestResult {
        let root = temp_dir("ox-codex-turn-state");
        let snapshots = root.join("shell_snapshots");
        let sessions = root.join("sessions/2026/02/14");
        fs::create_dir_all(&snapshots)?;
        fs::create_dir_all(&sessions)?;

        let running_thread = "00000000-0000-0000-0000-000000000001";
        let idle_thread = "00000000-0000-0000-0000-000000000002";
        fs::write(
            snapshots.join(format!("{running_thread}.sh")),
            "export TMUX_PANE=%1\n",
        )?;
        fs::write(
            snapshots.join(format!("{idle_thread}.sh")),
            "export TMUX_PANE=%2\n",
        )?;

        fs::write(
            sessions.join(format!(
                "rollout-2026-02-14T00-00-00-{running_thread}.jsonl"
            )),
            "{\"type\":\"event_msg\",\"payload\":{\"type\":\"task_started\",\"turn_id\":\"t1\"}}\n",
        )?;
        fs::write(
            sessions.join(format!("rollout-2026-02-14T00-00-00-{idle_thread}.jsonl")),
            "{\"type\":\"event_msg\",\"payload\":{\"type\":\"task_started\",\"turn_id\":\"t2\"}}\n\
             {\"type\":\"event_msg\",\"payload\":{\"type\":\"task_complete\",\"turn_id\":\"t2\"}}\n",
        )?;

        let pane_ids = ["%1".to_string(), "%2".to_string()]
            .into_iter()
            .collect::<HashSet<_>>();
        let status_by_pane =
            detect_codex_status_by_pane(&pane_ids, &snapshots, &root.join("sessions"));
        assert_eq!(status_by_pane.get("%1"), Some(&RuntimeStatus::Running));
        assert_eq!(status_by_pane.get("%2"), Some(&RuntimeStatus::Waiting));

        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn extract_thread_id_from_valid_filename() {
        let file = "rollout-2026-02-14T00-00-00-00000000-0000-0000-0000-000000000001.jsonl";
        let result = super::rollout_index::extract_thread_id_from_rollout_filename(file);
        assert_eq!(
            result,
            Some("00000000-0000-0000-0000-000000000001".to_string())
        );
    }

    #[test]
    fn extract_thread_id_rejects_non_rollout_file() {
        let file = "snapshot-abc.jsonl";
        assert_eq!(
            super::rollout_index::extract_thread_id_from_rollout_filename(file),
            None
        );
    }

    #[test]
    fn extract_thread_id_rejects_non_jsonl_extension() {
        let file = "rollout-2026-02-14T00-00-00-00000000-0000-0000-0000-000000000001.txt";
        assert_eq!(
            super::rollout_index::extract_thread_id_from_rollout_filename(file),
            None
        );
    }

    #[test]
    fn extract_thread_id_rejects_short_payload() {
        let file = "rollout-short.jsonl";
        assert_eq!(
            super::rollout_index::extract_thread_id_from_rollout_filename(file),
            None
        );
    }

    #[test]
    fn extract_thread_id_rejects_non_uuid_suffix() {
        let file = "rollout-2026-02-14T00-00-00-not-a-valid-uuid-format-xxxxxxxxxx.jsonl";
        assert_eq!(
            super::rollout_index::extract_thread_id_from_rollout_filename(file),
            None
        );
    }

    #[test]
    fn is_probable_thread_id_accepts_valid_uuid() {
        assert!(super::rollout_index::is_probable_thread_id(
            "00000000-0000-0000-0000-000000000001"
        ));
        assert!(super::rollout_index::is_probable_thread_id(
            "abcdef12-3456-7890-abcd-ef1234567890"
        ));
    }

    #[test]
    fn is_probable_thread_id_rejects_wrong_hyphen_count() {
        assert!(!super::rollout_index::is_probable_thread_id(
            "00000000000000000000000000000001"
        ));
        assert!(!super::rollout_index::is_probable_thread_id(
            "0000-0000-0000-0000-0000-00000001"
        ));
    }

    #[test]
    fn is_probable_thread_id_rejects_non_hex_chars() {
        assert!(!super::rollout_index::is_probable_thread_id(
            "zzzzzzzz-zzzz-zzzz-zzzz-zzzzzzzzzzzz"
        ));
    }

    #[test]
    fn default_codex_root_path_ends_with_codex() {
        let path = super::default_codex_root_path();
        assert!(
            path.to_string_lossy().ends_with(".codex"),
            "expected path to end with .codex, got: {}",
            path.display()
        );
    }

    #[test]
    fn rollout_has_unfinished_turn_detects_started_without_complete() -> TestResult {
        let root = temp_dir("ox-rollout-unfinished");
        fs::create_dir_all(&root)?;
        let rollout = root.join("rollout.jsonl");
        fs::write(
            &rollout,
            "{\"type\":\"event_msg\",\"payload\":{\"type\":\"task_started\",\"turn_id\":\"t1\"}}\n",
        )?;
        let result = super::turn_detection::rollout_has_unfinished_turn(&rollout)?;
        assert!(result, "should detect unfinished turn");
        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn rollout_has_unfinished_turn_returns_false_when_all_complete() -> TestResult {
        let root = temp_dir("ox-rollout-complete");
        fs::create_dir_all(&root)?;
        let rollout = root.join("rollout.jsonl");
        fs::write(
            &rollout,
            "{\"type\":\"event_msg\",\"payload\":{\"type\":\"task_started\",\"turn_id\":\"t1\"}}\n\
             {\"type\":\"event_msg\",\"payload\":{\"type\":\"task_complete\",\"turn_id\":\"t1\"}}\n",
        )?;
        let result = super::turn_detection::rollout_has_unfinished_turn(&rollout)?;
        assert!(!result, "all turns complete should return false");
        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn rollout_has_unfinished_turn_skips_non_event_lines() -> TestResult {
        let root = temp_dir("ox-rollout-skip");
        fs::create_dir_all(&root)?;
        let rollout = root.join("rollout.jsonl");
        fs::write(
            &rollout,
            "{\"type\":\"other\",\"data\":{}}\n\
             \n\
             not-json\n\
             {\"type\":\"event_msg\",\"payload\":{\"type\":\"task_started\",\"turn_id\":\"t2\"}}\n\
             {\"type\":\"event_msg\",\"payload\":{\"type\":\"task_complete\",\"turn_id\":\"t2\"}}\n",
        )?;
        let result = super::turn_detection::rollout_has_unfinished_turn(&rollout)?;
        assert!(!result, "non-event lines should be skipped");
        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn rollout_has_unfinished_turn_handles_empty_file() -> TestResult {
        let root = temp_dir("ox-rollout-empty");
        fs::create_dir_all(&root)?;
        let rollout = root.join("rollout.jsonl");
        fs::write(&rollout, "")?;
        let result = super::turn_detection::rollout_has_unfinished_turn(&rollout)?;
        assert!(!result, "empty file should return false");
        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn rollout_has_unfinished_turn_handles_turn_id_in_camel_case() -> TestResult {
        let root = temp_dir("ox-rollout-camel");
        fs::create_dir_all(&root)?;
        let rollout = root.join("rollout.jsonl");
        fs::write(
            &rollout,
            "{\"type\":\"event_msg\",\"payload\":{\"type\":\"task_started\",\"turnId\":\"t3\"}}\n",
        )?;
        let result = super::turn_detection::rollout_has_unfinished_turn(&rollout)?;
        assert!(result, "camelCase turnId should be recognized");
        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn detect_codex_status_by_pane_empty_pane_ids() {
        let root = temp_dir("ox-codex-empty-panes");
        let empty_set = HashSet::new();
        let result = detect_codex_status_by_pane(&empty_set, &root.join("s"), &root.join("r"));
        assert!(result.is_empty());
    }

    #[test]
    fn detect_codex_status_by_pane_treats_turn_aborted_as_waiting() -> TestResult {
        let root = temp_dir("ox-codex-turn-aborted");
        let snapshots = root.join("shell_snapshots");
        let sessions = root.join("sessions/2026/02/14");
        fs::create_dir_all(&snapshots)?;
        fs::create_dir_all(&sessions)?;

        let thread = "00000000-0000-0000-0000-000000000003";
        fs::write(
            snapshots.join(format!("{thread}.sh")),
            "export TMUX_PANE=%3\n",
        )?;
        fs::write(
            sessions.join(format!("rollout-2026-02-14T00-00-00-{thread}.jsonl")),
            "{\"type\":\"event_msg\",\"payload\":{\"type\":\"task_started\",\"turn_id\":\"t3\"}}\n\
             {\"type\":\"event_msg\",\"payload\":{\"type\":\"turn_aborted\",\"turn_id\":\"t3\"}}\n",
        )?;

        let pane_ids = ["%3".to_string()].into_iter().collect::<HashSet<_>>();
        let status_by_pane =
            detect_codex_status_by_pane(&pane_ids, &snapshots, &root.join("sessions"));
        assert_eq!(status_by_pane.get("%3"), Some(&RuntimeStatus::Waiting));

        fs::remove_dir_all(root)?;
        Ok(())
    }

    #[test]
    fn detect_codex_status_by_pane_returns_unknown_without_snapshot_or_rollout() -> TestResult {
        let root = temp_dir("ox-codex-unknown");
        let snapshots = root.join("shell_snapshots");
        fs::create_dir_all(&snapshots)?;

        // `%9` has no snapshot mapping and should be unknown.
        // `%7` has a snapshot mapping but no rollout file and should also be unknown.
        let thread = "00000000-0000-0000-0000-000000000007";
        fs::write(
            snapshots.join(format!("{thread}.sh")),
            "export TMUX_PANE=%7\n",
        )?;

        let pane_ids = ["%7".to_string(), "%9".to_string()]
            .into_iter()
            .collect::<HashSet<_>>();
        let status_by_pane =
            detect_codex_status_by_pane(&pane_ids, &snapshots, &root.join("sessions"));
        assert_eq!(status_by_pane.get("%7"), Some(&RuntimeStatus::Unknown));
        assert_eq!(status_by_pane.get("%9"), Some(&RuntimeStatus::Unknown));

        fs::remove_dir_all(root)?;
        Ok(())
    }
}
