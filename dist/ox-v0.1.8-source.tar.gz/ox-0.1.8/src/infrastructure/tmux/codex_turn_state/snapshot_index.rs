use std::collections::{HashMap, HashSet};
use std::fs;
use std::path::Path;
use std::time::{SystemTime, UNIX_EPOCH};

use super::cache::{ShellSnapshotIndex, lock_cache};
use crate::infrastructure::tmux::parsers::parse_tmux_pane_from_snapshot;

pub(super) fn load_latest_thread_id_by_pane(
    shell_snapshots_dir: &Path,
    pane_ids: &HashSet<String>,
) -> HashMap<String, String> {
    let dir_modified = fs::metadata(shell_snapshots_dir)
        .ok()
        .and_then(|metadata| metadata.modified().ok())
        .unwrap_or(UNIX_EPOCH);
    let Ok(entries) = fs::read_dir(shell_snapshots_dir) else {
        return HashMap::new();
    };
    let entries = entries.flatten().collect::<Vec<_>>();
    let latest_snapshot_modified = entries
        .iter()
        .filter_map(|entry| entry.metadata().ok())
        .filter_map(|metadata| metadata.modified().ok())
        .max()
        .unwrap_or(UNIX_EPOCH);
    let snapshot_count = entries.len();
    {
        let cache = lock_cache();
        if let Some(index) = &cache.snapshot_index
            && index.shell_snapshots_dir == shell_snapshots_dir
            && index.dir_modified == dir_modified
            && index.latest_snapshot_modified == latest_snapshot_modified
            && index.snapshot_count == snapshot_count
        {
            return pane_ids
                .iter()
                .filter_map(|pane_id| {
                    index
                        .threads_by_pane
                        .get(pane_id)
                        .map(|thread| (pane_id.clone(), thread.clone()))
                })
                .collect();
        }
    }

    let mut latest_by_pane = HashMap::<String, (SystemTime, String)>::new();
    for entry in entries {
        let path = entry.path();
        if path.extension().and_then(|ext| ext.to_str()) != Some("sh") {
            continue;
        }
        let Ok(contents) = fs::read_to_string(&path) else {
            continue;
        };
        let Some(pane_id) = parse_tmux_pane_from_snapshot(&contents) else {
            continue;
        };
        if !pane_ids.contains(&pane_id) {
            continue;
        }

        let Some(thread_id) = path
            .file_stem()
            .and_then(|stem| stem.to_str())
            .map(ToString::to_string)
        else {
            continue;
        };

        let modified = entry
            .metadata()
            .ok()
            .and_then(|metadata| metadata.modified().ok())
            .unwrap_or(UNIX_EPOCH);

        match latest_by_pane.get(&pane_id) {
            Some((existing_time, _)) if modified <= *existing_time => {}
            _ => {
                latest_by_pane.insert(pane_id, (modified, thread_id));
            }
        }
    }

    let threads_by_pane = latest_by_pane
        .into_iter()
        .map(|(pane_id, (_, thread_id))| (pane_id, thread_id))
        .collect::<HashMap<_, _>>();
    {
        let mut cache = lock_cache();
        cache.snapshot_index = Some(ShellSnapshotIndex {
            shell_snapshots_dir: shell_snapshots_dir.to_path_buf(),
            dir_modified,
            latest_snapshot_modified,
            snapshot_count,
            threads_by_pane: threads_by_pane.clone(),
        });
    }
    pane_ids
        .iter()
        .filter_map(|pane_id| {
            threads_by_pane
                .get(pane_id)
                .map(|thread| (pane_id.clone(), thread.clone()))
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use std::collections::HashSet;
    use std::error::Error;
    use std::fs;
    use std::thread;
    use std::time::{Duration, SystemTime, UNIX_EPOCH};

    use super::load_latest_thread_id_by_pane;

    type TestResult = Result<(), Box<dyn Error>>;

    fn temp_dir(prefix: &str) -> std::path::PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos());
        std::env::temp_dir().join(format!("{prefix}-{nanos}"))
    }

    #[test]
    fn load_latest_thread_id_by_pane_refreshes_when_snapshot_file_changes() -> TestResult {
        let root = temp_dir("ox-snapshot-rebind");
        fs::create_dir_all(&root)?;

        let thread_id = "00000000-0000-0000-0000-000000000099";
        let snapshot = root.join(format!("{thread_id}.sh"));
        fs::write(&snapshot, "export TMUX_PANE=%1\n")?;

        let pane_ids = ["%1".to_string(), "%2".to_string()]
            .into_iter()
            .collect::<HashSet<_>>();
        let first = load_latest_thread_id_by_pane(&root, &pane_ids);
        assert_eq!(first.get("%1"), Some(&thread_id.to_string()));
        assert!(!first.contains_key("%2"));

        // Keep the same filename and rewrite content to simulate pane/thread
        // rebinding updates in place.
        thread::sleep(Duration::from_millis(2));
        fs::write(&snapshot, "export TMUX_PANE=%2\n")?;

        let second = load_latest_thread_id_by_pane(&root, &pane_ids);
        assert!(!second.contains_key("%1"));
        assert_eq!(second.get("%2"), Some(&thread_id.to_string()));

        fs::remove_dir_all(root)?;
        Ok(())
    }
}
