use serde_json::Value;
use std::collections::HashSet;
use std::fs::{self, File};
use std::io::{BufRead, BufReader};
use std::path::Path;
use std::time::UNIX_EPOCH;

use crate::application::RuntimeStatus;

use super::cache::{RolloutStatusEntry, lock_cache};
use super::rollout_index::find_rollout_path_for_thread;

pub(super) fn detect_thread_status(thread_id: &str, codex_sessions_root: &Path) -> RuntimeStatus {
    let Some(rollout_path) = find_rollout_path_for_thread(codex_sessions_root, thread_id) else {
        return RuntimeStatus::Unknown;
    };
    match cached_rollout_has_unfinished_turn(&rollout_path) {
        Some(true) => RuntimeStatus::Running,
        Some(false) => RuntimeStatus::Waiting,
        None => RuntimeStatus::Unknown,
    }
}

fn cached_rollout_has_unfinished_turn(path: &Path) -> Option<bool> {
    let modified = fs::metadata(path)
        .ok()
        .and_then(|metadata| metadata.modified().ok())
        .unwrap_or(UNIX_EPOCH);
    {
        let cache = lock_cache();
        if let Some(entry) = cache.rollout_status_by_path.get(path)
            && entry.modified == modified
        {
            return entry.has_unfinished_turn;
        }
    }

    let has_unfinished_turn = rollout_has_unfinished_turn(path).ok();
    let mut cache = lock_cache();
    cache.rollout_status_by_path.insert(
        path.to_path_buf(),
        RolloutStatusEntry {
            modified,
            has_unfinished_turn,
        },
    );
    has_unfinished_turn
}

pub(super) fn rollout_has_unfinished_turn(path: &Path) -> Result<bool, std::io::Error> {
    let file = File::open(path)?;
    let reader = BufReader::new(file);
    let mut unfinished_turn_ids = HashSet::<String>::new();

    for line_result in reader.lines() {
        let Ok(line) = line_result else {
            continue;
        };
        if line.trim().is_empty() {
            continue;
        }
        let Ok(value) = serde_json::from_str::<Value>(&line) else {
            continue;
        };
        if value.get("type").and_then(Value::as_str) != Some("event_msg") {
            continue;
        }
        let Some(payload) = value.get("payload") else {
            continue;
        };
        let Some(event_type) = payload.get("type").and_then(Value::as_str) else {
            continue;
        };
        let Some(turn_id) = payload
            .get("turn_id")
            .and_then(Value::as_str)
            .or_else(|| payload.get("turnId").and_then(Value::as_str))
        else {
            continue;
        };
        if turn_id.is_empty() {
            continue;
        }

        match event_type {
            "task_started" => {
                unfinished_turn_ids.insert(turn_id.to_string());
            }
            // `turn_aborted` is a terminal state from Codex's perspective.
            // Treat it like completion so stale aborted turns do not pin
            // session status to `codex: running`.
            "task_complete" | "turn_aborted" => {
                unfinished_turn_ids.remove(turn_id);
            }
            _ => {}
        }
    }

    Ok(!unfinished_turn_ids.is_empty())
}
