use std::collections::HashMap;
use std::fs;
use std::path::{Path, PathBuf};
use std::time::{Instant, SystemTime, UNIX_EPOCH};

use super::cache::{ROLLOUT_INDEX_CACHE_TTL, RolloutPathIndex, lock_cache};

pub(super) fn find_rollout_path_for_thread(
    codex_sessions_root: &Path,
    thread_id: &str,
) -> Option<PathBuf> {
    let root_modified = fs::metadata(codex_sessions_root)
        .ok()
        .and_then(|metadata| metadata.modified().ok())
        .unwrap_or(UNIX_EPOCH);
    {
        let cache = lock_cache();
        if let Some(index) = &cache.rollout_index
            && index.codex_sessions_root == codex_sessions_root
            && (index.root_modified == root_modified
                || index.refreshed_at.elapsed() < ROLLOUT_INDEX_CACHE_TTL)
        {
            return index.rollout_path_by_thread.get(thread_id).cloned();
        }
    }

    let rollout_path_by_thread = build_rollout_path_index(codex_sessions_root);
    let rollout_path = rollout_path_by_thread.get(thread_id).cloned();
    let mut cache = lock_cache();
    cache.rollout_index = Some(RolloutPathIndex {
        codex_sessions_root: codex_sessions_root.to_path_buf(),
        root_modified,
        refreshed_at: Instant::now(),
        rollout_path_by_thread,
    });
    rollout_path
}

pub(super) fn build_rollout_path_index(codex_sessions_root: &Path) -> HashMap<String, PathBuf> {
    let mut by_thread = HashMap::<String, (SystemTime, PathBuf)>::new();
    let Ok(years) = fs::read_dir(codex_sessions_root) else {
        return HashMap::new();
    };
    for year in years.flatten() {
        let year_path = year.path();
        if !year_path.is_dir() {
            continue;
        }
        let Ok(months) = fs::read_dir(&year_path) else {
            continue;
        };
        for month in months.flatten() {
            let month_path = month.path();
            if !month_path.is_dir() {
                continue;
            }
            let Ok(days) = fs::read_dir(&month_path) else {
                continue;
            };
            for day in days.flatten() {
                let day_path = day.path();
                if !day_path.is_dir() {
                    continue;
                }
                let Ok(files) = fs::read_dir(&day_path) else {
                    continue;
                };
                for file in files.flatten() {
                    let file_path = file.path();
                    let Some(file_name) = file_path.file_name().and_then(|name| name.to_str())
                    else {
                        continue;
                    };
                    let Some(thread_id) = extract_thread_id_from_rollout_filename(file_name) else {
                        continue;
                    };
                    let modified = file
                        .metadata()
                        .ok()
                        .and_then(|metadata| metadata.modified().ok())
                        .unwrap_or(UNIX_EPOCH);
                    match by_thread.get(&thread_id) {
                        Some((existing, _)) if *existing >= modified => {}
                        _ => {
                            by_thread.insert(thread_id, (modified, file_path));
                        }
                    }
                }
            }
        }
    }

    by_thread
        .into_iter()
        .map(|(thread_id, (_, path))| (thread_id, path))
        .collect()
}

pub(super) fn extract_thread_id_from_rollout_filename(file_name: &str) -> Option<String> {
    if !file_name.starts_with("rollout-")
        || !Path::new(file_name)
            .extension()
            .is_some_and(|ext| ext.eq_ignore_ascii_case("jsonl"))
    {
        return None;
    }
    let stem = file_name.strip_suffix(".jsonl")?;
    let payload = stem.strip_prefix("rollout-")?;
    if payload.len() < 36 {
        return None;
    }
    let candidate = &payload[payload.len() - 36..];
    is_probable_thread_id(candidate).then(|| candidate.to_string())
}

pub(super) fn is_probable_thread_id(candidate: &str) -> bool {
    let hyphen_count = candidate.chars().filter(|ch| *ch == '-').count();
    hyphen_count == 4
        && candidate
            .chars()
            .all(|ch| ch.is_ascii_hexdigit() || ch == '-')
}
