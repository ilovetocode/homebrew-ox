use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::{Mutex, MutexGuard, OnceLock};
use std::time::{Duration, Instant, SystemTime};

pub(super) const ROLLOUT_INDEX_CACHE_TTL: Duration = Duration::from_secs(2);

#[derive(Default)]
pub(super) struct CodexTurnStateCache {
    pub(super) snapshot_index: Option<ShellSnapshotIndex>,
    pub(super) rollout_index: Option<RolloutPathIndex>,
    pub(super) rollout_status_by_path: HashMap<PathBuf, RolloutStatusEntry>,
}

pub(super) struct ShellSnapshotIndex {
    pub(super) shell_snapshots_dir: PathBuf,
    pub(super) dir_modified: SystemTime,
    pub(super) latest_snapshot_modified: SystemTime,
    pub(super) snapshot_count: usize,
    pub(super) threads_by_pane: HashMap<String, String>,
}

pub(super) struct RolloutPathIndex {
    pub(super) codex_sessions_root: PathBuf,
    pub(super) root_modified: SystemTime,
    pub(super) refreshed_at: Instant,
    pub(super) rollout_path_by_thread: HashMap<String, PathBuf>,
}

pub(super) struct RolloutStatusEntry {
    pub(super) modified: SystemTime,
    pub(super) has_unfinished_turn: Option<bool>,
}

static TURN_STATE_CACHE: OnceLock<Mutex<CodexTurnStateCache>> = OnceLock::new();

pub(super) fn lock_cache() -> MutexGuard<'static, CodexTurnStateCache> {
    TURN_STATE_CACHE
        .get_or_init(|| Mutex::new(CodexTurnStateCache::default()))
        .lock()
        .unwrap_or_else(std::sync::PoisonError::into_inner)
}
