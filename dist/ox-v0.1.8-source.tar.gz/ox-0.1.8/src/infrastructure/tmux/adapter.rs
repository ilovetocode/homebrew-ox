use std::collections::HashMap;
use std::sync::Arc;
use std::time::{SystemTime, UNIX_EPOCH};

use crate::application::{
    AgentRuntimePort, ConfigPort, HostSessionSnapshot, RuntimePort, RuntimeProbeResult,
    RuntimeStartRequest, SessionPort,
};
use crate::domain::{AgentRuntimeBinding, RuntimeProvider, SessionName};
use crate::error::{AgentError, AppError, StartupError};
use crate::error::{
    tmux_stderr_is_missing_session, tmux_stderr_is_no_current_client, tmux_stderr_is_no_server,
};
use crate::infrastructure::tmux::TmuxConfig;

mod launch;

const CODEX_THREAD_OPTION_KEY: &str = "@ox_codex_thread_id";

/// Real tmux adapter implementing all application tmux capability ports.
pub(crate) struct TmuxAdapter {
    conf: Arc<TmuxConfig>,
    tmux_conf_path: String,
}

impl TmuxAdapter {
    /// Build a concrete adapter from resolved tmux config.
    pub(crate) fn new(conf: Arc<TmuxConfig>) -> Self {
        let tmux_conf_path = conf.tmux_conf_path.display().to_string();
        Self {
            conf,
            tmux_conf_path,
        }
    }
}

impl SessionPort for TmuxAdapter {
    fn list_sessions(&self) -> Result<Vec<HostSessionSnapshot>, AppError> {
        super::sessions::list_sessions(&self.conf).map_err(AppError::Tmux)
    }
}

impl RuntimePort for TmuxAdapter {
    fn ensure_tmux_on_path(&self) -> Result<(), StartupError> {
        probe_tmux_on_path()
    }

    fn tmux_available(&self) -> bool {
        probe_tmux_on_path().is_ok()
    }
}

impl AgentRuntimePort for TmuxAdapter {
    fn start(
        &self,
        request: &RuntimeStartRequest,
        binding: Option<&AgentRuntimeBinding>,
    ) -> Result<AgentRuntimeBinding, AppError> {
        let session_name = if let Some(existing) = binding {
            parse_session_name(&existing.external_ref)?
        } else {
            parse_session_name(&request.session_name)?
        };

        let mut created_session = false;
        match super::sessions::create_session(
            &self.conf,
            &session_name,
            request.agent_kind,
            request.working_dir.as_deref(),
        ) {
            Ok(()) => created_session = true,
            Err(crate::error::TmuxError::CommandFailed { stderr })
                if stderr.contains("duplicate session") => {}
            Err(err) => return Err(AppError::Tmux(err)),
        }
        if created_session {
            launch::start_new_session_agent(self, &session_name, request)?;
        }

        let now = unix_time_ms();
        Ok(match binding {
            Some(existing) => existing.observed(now),
            None => AgentRuntimeBinding::new(
                request.agent_id.clone(),
                RuntimeProvider::Tmux,
                session_name.as_str().to_string(),
                now,
            ),
        })
    }

    fn stop(&self, binding: &AgentRuntimeBinding) -> Result<(), AppError> {
        let session_name = parse_session_name(&binding.external_ref)?;
        tolerate_missing_session_or_no_server(super::sessions::delete_session(
            &self.conf,
            &session_name,
        ))
    }

    fn attach(&self, binding: &AgentRuntimeBinding) -> Result<(), AppError> {
        let session_name = parse_session_name(&binding.external_ref)?;
        super::sessions::attach_session(&self.conf, &session_name)?;
        Ok(())
    }

    fn detach_client(&self) -> Result<(), AppError> {
        self.conf.managed_tmux_config().reconcile()?;
        // "dashboard" quick-switch should not hard-fail when this
        // process is outside tmux or tmux has no active client.
        tolerate_no_current_client_or_no_server(super::sessions::detach_client(&self.conf))
    }

    fn probe(&self, bindings: &[AgentRuntimeBinding]) -> Result<Vec<RuntimeProbeResult>, AppError> {
        let sessions = super::sessions::list_sessions(&self.conf)?;
        let cwd_by_name = super::sessions::session_current_paths(&self.conf)?;
        let by_name = sessions
            .into_iter()
            .map(|session| {
                (
                    session.name,
                    (session.runtime_status, session.agent_kind, session.attached),
                )
            })
            .collect::<HashMap<_, _>>();

        let observed = unix_time_ms();
        Ok(bindings
            .iter()
            // Missing tmux sessions are omitted from the probe result entirely.
            // The application projects those agents as `unknown` instead of
            // pretending "not observed" is one more live runtime state.
            .filter_map(|binding| {
                let (runtime_status, agent_kind, attached) =
                    by_name.get(binding.external_ref.as_str())?;
                Some(RuntimeProbeResult {
                    binding_id: binding.id.clone(),
                    runtime_status: *runtime_status,
                    attached: *attached,
                    agent_kind: *agent_kind,
                    current_working_dir: cwd_by_name.get(binding.external_ref.as_str()).cloned(),
                    observed_at_unix_ms: observed,
                })
            })
            .collect())
    }

    fn capture_output(
        &self,
        binding: &AgentRuntimeBinding,
        lines: u16,
    ) -> Result<String, AppError> {
        let session_name = parse_session_name(&binding.external_ref)?;
        super::sessions::capture_session_output(&self.conf, &session_name, lines)
            .map_err(AppError::Tmux)
    }

    fn send_key(&self, binding: &AgentRuntimeBinding, key: &str) -> Result<(), AppError> {
        let session_name = parse_session_name(&binding.external_ref)?;
        super::sessions::send_key_to_session(&self.conf, &session_name, key).map_err(AppError::Tmux)
    }

    fn rename(
        &self,
        binding: &AgentRuntimeBinding,
        new_external_ref: &str,
    ) -> Result<(), AppError> {
        let old_name = parse_session_name(&binding.external_ref)?;
        let new_name = parse_session_name(new_external_ref)?;
        tolerate_missing_session_or_no_server(super::sessions::rename_session(
            &self.conf, &old_name, &new_name,
        ))
    }
}

impl ConfigPort for TmuxAdapter {
    fn tmux_conf_path(&self) -> String {
        self.tmux_conf_path.clone()
    }

    fn is_in_sync(&self) -> bool {
        self.conf.managed_tmux_config().is_in_sync()
    }

    fn reconcile(&self) -> Result<(), AppError> {
        self.conf.managed_tmux_config().reconcile()?;
        Ok(())
    }
}

fn parse_session_name(raw: &str) -> Result<SessionName, AppError> {
    SessionName::try_from(raw).map_err(|message| {
        AppError::Agent(AgentError::Unavailable {
            message: message.to_string(),
        })
    })
}

fn unix_time_ms() -> u128 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_millis())
}

fn shell_single_quote(raw: &str) -> String {
    raw.replace('\'', "'\\''")
}

fn tolerate_missing_session_or_no_server(
    result: Result<(), crate::error::TmuxError>,
) -> Result<(), AppError> {
    match result {
        Ok(()) => Ok(()),
        Err(crate::error::TmuxError::CommandFailed { stderr })
            if tmux_stderr_is_missing_session(&stderr) || tmux_stderr_is_no_server(&stderr) =>
        {
            Ok(())
        }
        Err(err) => Err(AppError::Tmux(err)),
    }
}

fn tolerate_no_current_client_or_no_server(
    result: Result<(), crate::error::TmuxError>,
) -> Result<(), AppError> {
    match result {
        Ok(()) => Ok(()),
        Err(crate::error::TmuxError::CommandFailed { stderr })
            if tmux_stderr_is_no_current_client(&stderr) || tmux_stderr_is_no_server(&stderr) =>
        {
            Ok(())
        }
        Err(err) => Err(AppError::Tmux(err)),
    }
}

fn probe_tmux_on_path() -> Result<(), StartupError> {
    use crate::error::TmuxError;

    match super::client::TmuxClient::run_system(&["-V"]) {
        Ok(output) if output.status.success() => Ok(()),
        Ok(output) => Err(StartupError::ProbeFailed {
            code: output.status.code(),
        }),
        Err(TmuxError::Io(err)) if err.kind() == std::io::ErrorKind::NotFound => {
            Err(StartupError::MissingTmux)
        }
        Err(TmuxError::Timeout { .. } | TmuxError::Parse { .. }) => {
            Err(StartupError::ProbeFailed { code: None })
        }
        Err(TmuxError::Io(err)) => Err(StartupError::ProbeIo { source: err }),
        Err(TmuxError::CommandFailed { stderr }) => Err(StartupError::ProbeFailed {
            code: Some(stderr.len().try_into().unwrap_or(1)),
        }),
    }
}
