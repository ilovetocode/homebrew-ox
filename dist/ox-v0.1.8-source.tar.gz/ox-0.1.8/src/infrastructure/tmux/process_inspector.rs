use std::collections::HashMap;

use crate::application::AgentKind;

use super::agent_detection::classify_agent_kind_from_command;
use super::parsers::{PaneRow, ProcessRow};

#[derive(Clone, Debug, PartialEq, Eq)]
pub(super) struct ActivePaneAgentSnapshot {
    pub(super) pane_id: String,
    pub(super) agent_kind: AgentKind,
}

pub(super) fn detect_active_pane_agent_snapshots_by_session(
    panes: &[PaneRow],
    process_rows: &[ProcessRow],
) -> HashMap<String, ActivePaneAgentSnapshot> {
    let process_rows_by_pid = process_rows
        .iter()
        .map(|process| (process.pid, process))
        .collect::<HashMap<_, _>>();
    let mut process_rows_by_tty_and_pgid = HashMap::<(String, i32), Vec<&ProcessRow>>::new();
    for process in process_rows {
        process_rows_by_tty_and_pgid
            .entry((process.tty.clone(), process.pgid))
            .or_default()
            .push(process);
    }

    panes
        .iter()
        .filter(|pane| pane.window_active && pane.pane_active)
        .map(|pane| {
            let agent_kind = infer_active_pane_agent_kind(
                pane,
                &process_rows_by_pid,
                &process_rows_by_tty_and_pgid,
            );
            (
                pane.session_name.clone(),
                ActivePaneAgentSnapshot {
                    pane_id: pane.pane_id.clone(),
                    agent_kind,
                },
            )
        })
        .collect()
}

fn infer_active_pane_agent_kind(
    pane: &PaneRow,
    process_rows_by_pid: &HashMap<i32, &ProcessRow>,
    process_rows_by_tty_and_pgid: &HashMap<(String, i32), Vec<&ProcessRow>>,
) -> AgentKind {
    let Some(pane_root_process) = process_rows_by_pid.get(&pane.pane_pid) else {
        return AgentKind::Shell;
    };
    if pane_root_process.tty != pane.pane_tty || pane_root_process.tpgid <= 0 {
        return AgentKind::Shell;
    }

    let tty_and_foreground_group = (pane.pane_tty.clone(), pane_root_process.tpgid);
    let Some(foreground_group_processes) =
        process_rows_by_tty_and_pgid.get(&tty_and_foreground_group)
    else {
        return AgentKind::Shell;
    };

    classify_agent_kind_from_foreground_group_processes(
        foreground_group_processes,
        pane_root_process.tpgid,
    )
}

fn classify_agent_kind_from_foreground_group_processes(
    foreground_group_processes: &[&ProcessRow],
    foreground_group_id: i32,
) -> AgentKind {
    // Prefer the foreground group leader when it is a recognized agent.
    // When the leader is a wrapper/launcher process, fall back to scanning
    // children in the same foreground group and pick the first recognized
    // coding agent process.
    if let Some(leader_kind) = foreground_group_processes
        .iter()
        .copied()
        .find(|process| process.pid == foreground_group_id)
        .map(|process| classify_agent_kind_from_command(&process.command))
        && leader_kind != AgentKind::Shell
    {
        return leader_kind;
    }

    foreground_group_processes
        .iter()
        .map(|process| classify_agent_kind_from_command(&process.command))
        .find(|kind| *kind != AgentKind::Shell)
        .unwrap_or(AgentKind::Shell)
}

#[cfg(test)]
mod tests {
    use std::error::Error;

    use crate::application::AgentKind;

    use super::detect_active_pane_agent_snapshots_by_session;
    use crate::infrastructure::tmux::parsers::{ProcessRow, parse_panes};

    type TestResult = Result<(), Box<dyn Error>>;

    #[test]
    fn detect_active_pane_agent_snapshots_by_session_uses_foreground_group_leader() -> TestResult {
        let panes = parse_panes(
            "dev\t%1\t101\t/dev/ttys001\t1\t1\t/tmp/dev\nshell\t%2\t201\t/dev/ttys002\t1\t1\t/tmp/shell\n",
        )?;
        let process_rows = vec![
            ProcessRow {
                pid: 101,
                pgid: 101,
                tpgid: 150,
                tty: "ttys001".to_string(),
                command: "-zsh".to_string(),
            },
            ProcessRow {
                pid: 150,
                pgid: 150,
                tpgid: 150,
                tty: "ttys001".to_string(),
                command: "codex".to_string(),
            },
            ProcessRow {
                pid: 151,
                pgid: 150,
                tpgid: 150,
                tty: "ttys001".to_string(),
                command: "node /tmp/helper.js".to_string(),
            },
            ProcessRow {
                pid: 201,
                pgid: 201,
                tpgid: 201,
                tty: "ttys002".to_string(),
                command: "-zsh".to_string(),
            },
        ];

        let detected = detect_active_pane_agent_snapshots_by_session(&panes, &process_rows);
        assert_eq!(
            detected.get("dev").map(|active| active.agent_kind),
            Some(AgentKind::Codex)
        );
        assert_eq!(
            detected.get("shell").map(|active| active.agent_kind),
            Some(AgentKind::Shell)
        );
        Ok(())
    }

    #[test]
    fn detect_active_pane_agent_snapshots_by_session_detects_startup_claude_process() -> TestResult
    {
        let panes = parse_panes("ai\t%3\t300\t/dev/ttys003\t1\t1\t/tmp/ai\n")?;
        let process_rows = vec![ProcessRow {
            pid: 300,
            pgid: 300,
            tpgid: 300,
            tty: "ttys003".to_string(),
            command: "claude --dangerously-skip-permissions".to_string(),
        }];

        let detected = detect_active_pane_agent_snapshots_by_session(&panes, &process_rows);
        assert_eq!(
            detected.get("ai").map(|active| active.agent_kind),
            Some(AgentKind::Claude)
        );
        Ok(())
    }

    #[test]
    fn detect_active_pane_agent_snapshots_by_session_uses_foreground_child_agent_when_leader_is_wrapper()
    -> TestResult {
        let panes = parse_panes("dev\t%1\t101\t/dev/ttys001\t1\t1\t/tmp/dev\n")?;
        let process_rows = vec![
            ProcessRow {
                pid: 101,
                pgid: 101,
                tpgid: 150,
                tty: "ttys001".to_string(),
                command: "-zsh".to_string(),
            },
            ProcessRow {
                pid: 150,
                pgid: 150,
                tpgid: 150,
                tty: "ttys001".to_string(),
                command: "ox tui".to_string(),
            },
            ProcessRow {
                pid: 151,
                pgid: 150,
                tpgid: 150,
                tty: "ttys001".to_string(),
                command: "codex".to_string(),
            },
        ];

        let detected = detect_active_pane_agent_snapshots_by_session(&panes, &process_rows);
        assert_eq!(
            detected.get("dev").map(|active| active.agent_kind),
            Some(AgentKind::Codex)
        );
        Ok(())
    }
}
