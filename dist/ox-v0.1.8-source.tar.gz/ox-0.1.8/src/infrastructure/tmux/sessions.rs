use super::TmuxClient;
use crate::application::{AgentKind, HostSessionSnapshot};
use crate::domain::SessionName;
use crate::error::TmuxError;
use crate::infrastructure::tmux::TmuxConfig;
use std::collections::HashMap;
use std::path::Path;
mod probe;

/// Run `tmux list-sessions` using the configured tmux conf path.
pub(crate) fn list_sessions(conf: &TmuxConfig) -> Result<Vec<HostSessionSnapshot>, TmuxError> {
    probe::list_sessions(conf)
}

/// Run `tmux new-session -d -s <name>` using the configured tmux conf path.
pub(crate) fn create_session(
    conf: &TmuxConfig,
    name: &SessionName,
    agent_kind: AgentKind,
    working_dir: Option<&Path>,
) -> Result<(), TmuxError> {
    let mut args = vec!["new-session", "-d", "-s", name.as_str()];
    let working_dir_owned = working_dir.map(|path| path.to_string_lossy().to_string());
    if let Some(ref dir) = working_dir_owned {
        args.push("-c");
        args.push(dir.as_str());
    }

    match agent_kind {
        AgentKind::Shell | AgentKind::Codex | AgentKind::Opencode => {}
        AgentKind::Claude => {
            args.push("claude");
            // Keep permissions bypass opt-in available on startup so Claude can
            // be switched into that mode without restarting the session.
            args.push("--allow-dangerously-skip-permissions");
        }
    }

    run_mutating(conf, &args)?;
    Ok(())
}

/// Run `tmux rename-session -t <old> <new>` using the configured tmux conf path.
pub(crate) fn rename_session(
    conf: &TmuxConfig,
    old_name: &SessionName,
    new_name: &SessionName,
) -> Result<(), TmuxError> {
    probe::invalidate_session_cache();
    run_mutating(
        conf,
        &["rename-session", "-t", old_name.as_str(), new_name.as_str()],
    )
}

/// Run `tmux kill-session -t <name>` using the configured tmux conf path.
pub(crate) fn delete_session(conf: &TmuxConfig, name: &SessionName) -> Result<(), TmuxError> {
    run_mutating(conf, &["kill-session", "-t", name.as_str()])
}

/// Run `tmux attach-session -t <name>` using the configured tmux conf path.
pub(crate) fn attach_session(conf: &TmuxConfig, name: &SessionName) -> Result<(), TmuxError> {
    let client = TmuxClient::new(conf);
    // When already inside tmux, switching clients avoids nested-session attach
    // behavior and gives the expected "jump to target session" UX.
    if std::env::var_os("TMUX").is_some() {
        return client.run_ok(&["switch-client", "-t", name.as_str()]);
    }
    client.run_interactive_ok(&["attach-session", "-t", name.as_str()])
}

/// Run `tmux detach-client` using the configured tmux conf path.
pub(crate) fn detach_client(conf: &TmuxConfig) -> Result<(), TmuxError> {
    run_mutating(conf, &["detach-client"])
}

/// Capture recent output from a session's active pane.
pub(crate) fn capture_session_output(
    conf: &TmuxConfig,
    name: &SessionName,
    lines: u16,
) -> Result<String, TmuxError> {
    let client = TmuxClient::new(conf);
    let start_line = format!("-{lines}");
    client.run_output_allow_no_server_empty(&[
        "capture-pane",
        "-p",
        "-S",
        start_line.as_str(),
        "-t",
        name.as_str(),
    ])
}

/// Send one key token to a session's active pane.
pub(crate) fn send_key_to_session(
    conf: &TmuxConfig,
    name: &SessionName,
    key: &str,
) -> Result<(), TmuxError> {
    run_mutating(conf, &["send-keys", "-t", name.as_str(), key])
}

/// Send one full command line followed by Enter to the active pane.
pub(crate) fn send_line_to_session(
    conf: &TmuxConfig,
    name: &SessionName,
    line: &str,
) -> Result<(), TmuxError> {
    run_mutating(conf, &["send-keys", "-t", name.as_str(), line, "Enter"])
}

/// Persist one tmux session-scoped option value.
pub(crate) fn set_session_option(
    conf: &TmuxConfig,
    name: &SessionName,
    option_key: &str,
    option_value: &str,
) -> Result<(), TmuxError> {
    run_mutating(
        conf,
        &["set-option", "-t", name.as_str(), option_key, option_value],
    )
}

/// Resolve active-pane current paths keyed by session name.
///
/// We prefer the pane in the active window and active pane slot for each
/// session, then fall back to the first observed pane path.
pub(crate) fn session_current_paths(
    conf: &TmuxConfig,
) -> Result<HashMap<String, String>, TmuxError> {
    probe::session_current_paths(conf)
}

fn run_mutating(conf: &TmuxConfig, args: &[&str]) -> Result<(), TmuxError> {
    let client = TmuxClient::new(conf);
    client.run_ok(args)
}
