use crate::application::AgentKind;

/// Classify an executable command string into a known `AgentKind`.
///
/// tmux and `ps` can return full paths and quoted command tokens, so this
/// helper normalizes to a lowercase basename before matching known runtimes.
pub(super) fn classify_agent_kind_from_command(command: &str) -> AgentKind {
    let executable = normalize_command_executable(command);
    if is_codex_executable(executable.as_str()) {
        return AgentKind::Codex;
    }
    if is_opencode_executable(executable.as_str()) {
        return AgentKind::Opencode;
    }
    if is_claude_executable(executable.as_str()) {
        return AgentKind::Claude;
    }
    AgentKind::Shell
}

fn normalize_command_executable(command: &str) -> String {
    command
        .split_whitespace()
        .next()
        .unwrap_or_default()
        .trim_matches(['"', '\''])
        .rsplit(['/', '\\'])
        .next()
        .unwrap_or_default()
        .to_ascii_lowercase()
}

fn is_codex_executable(executable: &str) -> bool {
    // tmux may report `codex`, `codex.exe`, or platform-specific executable
    // names such as `codex-aarch64-a` depending on how Codex was launched.
    executable == "codex" || executable == "codex.exe" || executable.starts_with("codex-")
}

fn is_opencode_executable(executable: &str) -> bool {
    executable == "opencode" || executable == "opencode.exe"
}

fn is_claude_executable(executable: &str) -> bool {
    executable == "claude" || executable == "claude.exe"
}

#[cfg(test)]
mod tests {
    use super::classify_agent_kind_from_command;
    use crate::application::AgentKind;

    #[test]
    fn classify_agent_kind_recognizes_supported_executables() {
        assert_eq!(
            classify_agent_kind_from_command("/usr/local/bin/codex-aarch64-a"),
            AgentKind::Codex
        );
        assert_eq!(
            classify_agent_kind_from_command("opencode --sandbox danger"),
            AgentKind::Opencode
        );
        assert_eq!(
            classify_agent_kind_from_command("claude --dangerously-skip-permissions"),
            AgentKind::Claude
        );
        assert_eq!(classify_agent_kind_from_command("-zsh"), AgentKind::Shell);
    }
}
