use crate::application::RuntimeStartRequest;
use crate::domain::{AgentKind, SessionName};
use crate::error::AppError;

use super::TmuxAdapter;

/// Launch a newly created session based on provider-specific startup data.
pub(super) fn start_new_session_agent(
    adapter: &TmuxAdapter,
    session_name: &SessionName,
    request: &RuntimeStartRequest,
) -> Result<(), AppError> {
    let launch_result = match request.agent_kind {
        AgentKind::Codex => {
            if let Some(thread_id) = request.codex_thread_id.as_deref() {
                resume_codex_thread(adapter, session_name, thread_id)
            } else {
                start_unmanaged_codex(adapter, session_name)
            }
        }
        AgentKind::Opencode => {
            if let (Some(server_url), Some(session_id)) = (
                request.opencode_server_url.as_deref(),
                request.opencode_session_id.as_deref(),
            ) {
                start_opencode_attached(adapter, session_name, server_url, session_id)
            } else {
                Ok(())
            }
        }
        AgentKind::Claude | AgentKind::Shell => Ok(()),
    };

    if let Err(error) = launch_result {
        let _ = super::super::sessions::delete_session(&adapter.conf, session_name);
        return Err(error);
    }

    Ok(())
}

/// Launch Codex TUI for one managed thread inside the tmux session.
fn resume_codex_thread(
    adapter: &TmuxAdapter,
    session_name: &SessionName,
    thread_id: &str,
) -> Result<(), AppError> {
    // For now this startup path is the only lifecycle owner.
    // If a user runs `/new` inside Codex, it switches to a new thread that ox
    // did not create, so we lose strict lifecycle control until explicit
    // thread-change reconciliation is implemented.
    let command = if let Some(codex_home) = std::env::var_os("CODEX_HOME") {
        let codex_home = super::shell_single_quote(codex_home.to_string_lossy().as_ref());
        format!("CODEX_HOME='{codex_home}' codex resume {thread_id}")
    } else {
        format!("codex resume {thread_id}")
    };
    super::super::sessions::send_line_to_session(&adapter.conf, session_name, command.as_str())
        .map_err(AppError::Tmux)?;

    super::super::sessions::set_session_option(
        &adapter.conf,
        session_name,
        super::CODEX_THREAD_OPTION_KEY,
        thread_id,
    )
    .map_err(AppError::Tmux)
}

/// Launch the opencode TUI attached to an existing API session.
fn start_opencode_attached(
    adapter: &TmuxAdapter,
    session_name: &SessionName,
    server_url: &str,
    session_id: &str,
) -> Result<(), AppError> {
    let server_url = super::shell_single_quote(server_url);
    let session_id = super::shell_single_quote(session_id);
    let command = format!("opencode attach '{server_url}' --session '{session_id}'");
    super::super::sessions::send_line_to_session(&adapter.conf, session_name, command.as_str())
        .map_err(AppError::Tmux)
}

/// Legacy fallback when no managed Codex thread binding exists yet.
///
/// This keeps old agents attachable while the system migrates to explicit
/// `codex_thread` state bindings.
fn start_unmanaged_codex(
    adapter: &TmuxAdapter,
    session_name: &SessionName,
) -> Result<(), AppError> {
    let command = if let Some(codex_home) = std::env::var_os("CODEX_HOME") {
        let codex_home = super::shell_single_quote(codex_home.to_string_lossy().as_ref());
        format!("CODEX_HOME='{codex_home}' codex")
    } else {
        "codex".to_string()
    };
    super::super::sessions::send_line_to_session(&adapter.conf, session_name, command.as_str())
        .map_err(AppError::Tmux)
}
