use crate::error::TmuxError;

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::infrastructure::tmux) struct ProcessRow {
    pub(in crate::infrastructure::tmux) pid: i32,
    pub(in crate::infrastructure::tmux) pgid: i32,
    pub(in crate::infrastructure::tmux) tpgid: i32,
    pub(in crate::infrastructure::tmux) tty: String,
    pub(in crate::infrastructure::tmux) command: String,
}

pub(in crate::infrastructure::tmux) fn parse_process_rows(
    raw: &str,
) -> Result<Vec<ProcessRow>, TmuxError> {
    let mut rows = Vec::new();

    for line in raw.lines() {
        if line.trim().is_empty() {
            continue;
        }

        // `split_whitespace` gives stable parsing for the first fixed columns.
        // Everything after `tty` belongs to the full command string.
        let mut parts = line.split_whitespace();
        let process_id_str = parts.next().ok_or_else(|| TmuxError::Parse {
            message: format!("missing process pid in line: {line}"),
        })?;
        let process_group_id_str = parts.next().ok_or_else(|| TmuxError::Parse {
            message: format!("missing process pgid in line: {line}"),
        })?;
        let tpgid_str = parts.next().ok_or_else(|| TmuxError::Parse {
            message: format!("missing process tpgid in line: {line}"),
        })?;
        let tty_str = parts.next().ok_or_else(|| TmuxError::Parse {
            message: format!("missing process tty in line: {line}"),
        })?;
        let command = parts.collect::<Vec<_>>().join(" ");
        if command.is_empty() {
            return Err(TmuxError::Parse {
                message: format!("missing process command in line: {line}"),
            });
        }

        let process_id = process_id_str
            .parse::<i32>()
            .map_err(|err| TmuxError::Parse {
                message: format!("invalid process pid '{process_id_str}': {err}"),
            })?;
        let process_group_id =
            process_group_id_str
                .parse::<i32>()
                .map_err(|err| TmuxError::Parse {
                    message: format!("invalid process pgid '{process_group_id_str}': {err}"),
                })?;
        let foreground_group_id = tpgid_str.parse::<i32>().map_err(|err| TmuxError::Parse {
            message: format!("invalid process tpgid '{tpgid_str}': {err}"),
        })?;

        rows.push(ProcessRow {
            pid: process_id,
            pgid: process_group_id,
            tpgid: foreground_group_id,
            tty: tty_str.to_string(),
            command,
        });
    }

    Ok(rows)
}
