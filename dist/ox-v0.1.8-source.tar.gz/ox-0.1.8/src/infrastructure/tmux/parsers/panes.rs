use crate::error::TmuxError;

const FIELD_SEPARATOR: &str = "<<OX>>";

#[derive(Clone, Debug, PartialEq, Eq)]
pub(in crate::infrastructure::tmux) struct PaneRow {
    pub(in crate::infrastructure::tmux) session_name: String,
    pub(in crate::infrastructure::tmux) pane_id: String,
    pub(in crate::infrastructure::tmux) pane_pid: i32,
    pub(in crate::infrastructure::tmux) pane_tty: String,
    pub(in crate::infrastructure::tmux) window_active: bool,
    pub(in crate::infrastructure::tmux) pane_active: bool,
    pub(in crate::infrastructure::tmux) pane_current_command: Option<String>,
    pub(in crate::infrastructure::tmux) pane_current_path: Option<String>,
}

pub(in crate::infrastructure::tmux) fn parse_panes(raw: &str) -> Result<Vec<PaneRow>, TmuxError> {
    let mut panes = Vec::new();

    for line in raw.lines() {
        if line.trim().is_empty() {
            continue;
        }

        let fields = split_pane_fields(line)?;
        let session_name = fields[0];
        let pane_id = fields[1];
        let pane_process_id_str = fields[2];
        let pane_tty = fields[3];
        let window_active = fields[4];
        let pane_active = fields[5];
        let pane_current_command =
            (!fields[6].trim().is_empty()).then(|| fields[6].trim().to_string());
        let pane_current_path =
            (!fields[7].trim().is_empty()).then(|| fields[7].trim().to_string());

        let pane_process_id =
            pane_process_id_str
                .parse::<i32>()
                .map_err(|err| TmuxError::Parse {
                    message: format!("invalid pane pid '{pane_process_id_str}': {err}"),
                })?;

        let window_active = parse_tmux_binary_flag(window_active, "window active flag")?;
        let pane_active = parse_tmux_binary_flag(pane_active, "pane active flag")?;
        let pane_tty = normalize_tty(pane_tty);
        if pane_tty.is_empty() {
            return Err(TmuxError::Parse {
                message: format!("invalid empty pane tty in line: {line}"),
            });
        }

        panes.push(PaneRow {
            session_name: session_name.to_string(),
            pane_id: pane_id.to_string(),
            pane_pid: pane_process_id,
            pane_tty,
            window_active,
            pane_active,
            pane_current_command,
            pane_current_path,
        });
    }

    Ok(panes)
}

fn split_pane_fields(line: &str) -> Result<[&str; 8], TmuxError> {
    if line.contains(FIELD_SEPARATOR) {
        return split_pane_fields_with(line, FIELD_SEPARATOR);
    }

    split_pane_fields_with(line, "\t")
}

fn split_pane_fields_with<'a>(line: &'a str, separator: &str) -> Result<[&'a str; 8], TmuxError> {
    let mut parts = line.splitn(8, separator);
    let session_name = parts.next().ok_or_else(|| TmuxError::Parse {
        message: format!("missing pane session name in line: {line}"),
    })?;
    let pane_id = parts.next().ok_or_else(|| TmuxError::Parse {
        message: format!("missing pane id in line: {line}"),
    })?;
    let pane_process_id_str = parts.next().ok_or_else(|| TmuxError::Parse {
        message: format!("missing pane pid in line: {line}"),
    })?;
    let pane_tty = parts.next().ok_or_else(|| TmuxError::Parse {
        message: format!("missing pane tty in line: {line}"),
    })?;
    let window_active = parts.next().ok_or_else(|| TmuxError::Parse {
        message: format!("missing window active flag in line: {line}"),
    })?;
    let pane_active = parts.next().ok_or_else(|| TmuxError::Parse {
        message: format!("missing pane active flag in line: {line}"),
    })?;
    let pane_current_command = parts.next().unwrap_or("");
    let pane_current_path = parts.next().unwrap_or("");

    Ok([
        session_name,
        pane_id,
        pane_process_id_str,
        pane_tty,
        window_active,
        pane_active,
        pane_current_command,
        pane_current_path,
    ])
}

pub(super) fn parse_tmux_binary_flag(raw: &str, field_name: &str) -> Result<bool, TmuxError> {
    match raw {
        "0" => Ok(false),
        "1" => Ok(true),
        other => Err(TmuxError::Parse {
            message: format!("invalid {field_name} '{other}'"),
        }),
    }
}

pub(super) fn normalize_tty(raw: &str) -> String {
    raw.strip_prefix("/dev/")
        .unwrap_or(raw)
        .trim_matches('"')
        .trim()
        .to_string()
}
