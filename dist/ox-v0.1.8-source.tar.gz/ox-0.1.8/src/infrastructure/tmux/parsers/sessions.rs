use crate::application::{AgentKind, HostSessionSnapshot, RuntimeStatus};
use crate::error::TmuxError;

const FIELD_SEPARATOR: &str = "<<OX>>";

pub(in crate::infrastructure::tmux) fn parse_sessions(
    raw: &str,
) -> Result<Vec<HostSessionSnapshot>, TmuxError> {
    let mut sessions = Vec::new();

    for line in raw.lines() {
        if line.trim().is_empty() {
            continue;
        }

        let (name, windows_str, attached_str) = split_session_fields(line)?;

        let windows = windows_str.parse::<u32>().map_err(|err| TmuxError::Parse {
            message: format!("invalid windows count '{windows_str}': {err}"),
        })?;

        let attached = match attached_str {
            "0" => false,
            "1" => true,
            other => {
                return Err(TmuxError::Parse {
                    message: format!("invalid attached flag '{other}'"),
                });
            }
        };

        sessions.push(HostSessionSnapshot {
            name: name.to_string(),
            windows,
            attached,
            agent_kind: AgentKind::Shell,
            runtime_status: RuntimeStatus::Unknown,
        });
    }

    Ok(sessions)
}

fn split_session_fields(line: &str) -> Result<(&str, &str, &str), TmuxError> {
    if let Some((name, windows_str, attached_str)) =
        split_session_fields_with_str(line, FIELD_SEPARATOR)
    {
        return Ok((name, windows_str, attached_str));
    }

    if let Some((name, windows_str, attached_str)) = split_session_fields_with(line, '\t') {
        return Ok((name, windows_str, attached_str));
    }

    // tmux 3.3a on Debian renders literal tab separators in `list-sessions -F`
    // output as underscores. Split from the right so session names that
    // already contain underscores still round-trip correctly.
    if let Some((name, windows_str, attached_str)) = split_session_fields_with(line, '_') {
        return Ok((name, windows_str, attached_str));
    }

    Err(TmuxError::Parse {
        message: format!("missing windows count in line: {line}"),
    })
}

fn split_session_fields_with_str<'a>(
    line: &'a str,
    separator: &str,
) -> Option<(&'a str, &'a str, &'a str)> {
    let mut parts = line.splitn(3, separator);
    let name = parts.next()?;
    let windows_str = parts.next()?;
    let attached_str = parts.next()?;

    (!name.is_empty() && !windows_str.is_empty() && !attached_str.is_empty()).then_some((
        name,
        windows_str,
        attached_str,
    ))
}

fn split_session_fields_with(line: &str, separator: char) -> Option<(&str, &str, &str)> {
    let mut parts = line.rsplitn(3, separator);
    let attached_str = parts.next()?;
    let windows_str = parts.next()?;
    let name = parts.next()?;

    (!name.is_empty() && !windows_str.is_empty() && !attached_str.is_empty()).then_some((
        name,
        windows_str,
        attached_str,
    ))
}
