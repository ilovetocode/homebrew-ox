use std::fs::{self, OpenOptions};
use std::io::Write;
use std::path::{Path, PathBuf};
use std::thread;
use std::time::{Duration, Instant};

use crate::error::ConfigError;

// Intentional compatibility boundary: this managed config assumes a tmux build
// that supports `display-popup` (tmux 3.2+). We intentionally do not include a
// fallback binding for older tmux versions. `switch-client -l` is tmux's
// built-in "jump back to the last session" command.
const MANAGED_TMUX_CONF_CONTENTS: &str = "# managed-by: ox\nbind-key -n C-w detach-client\nbind-key -n C-r display-popup -E \"ox agents pick\"\nbind-key -n C-s switch-client -l\n";
const LOCK_WAIT_TIMEOUT: Duration = Duration::from_secs(5);
const LOCK_RETRY_INTERVAL: Duration = Duration::from_millis(25);

/// Resolved runtime configuration for tmux invocation.
#[derive(Clone, Debug)]
pub(crate) struct TmuxConfig {
    /// Absolute path to the tmux configuration file used with `tmux -f`.
    pub(crate) tmux_conf_path: PathBuf,
}

impl TmuxConfig {
    /// Resolve managed tmux config path from the default location.
    pub(crate) fn resolve() -> Result<Self, ConfigError> {
        Self::resolve_from_path(default_tmux_conf_path())
    }

    fn resolve_from_path(path: PathBuf) -> Result<Self, ConfigError> {
        let expanded = expand_tilde(path)?;

        let managed_tmux_config = ManagedTmuxConfig::new(expanded.clone());
        managed_tmux_config.reconcile()?;

        Ok(Self {
            tmux_conf_path: expanded,
        })
    }

    /// Build the managed tmux config owner for this resolved path.
    pub(crate) fn managed_tmux_config(&self) -> ManagedTmuxConfig {
        ManagedTmuxConfig::new(self.tmux_conf_path.clone())
    }
}

/// Canonical owner for the fully managed tmux configuration file.
#[derive(Clone, Debug)]
pub(crate) struct ManagedTmuxConfig {
    path: PathBuf,
}

impl ManagedTmuxConfig {
    /// Create a managed config owner for a specific file path.
    pub(crate) fn new(path: PathBuf) -> Self {
        Self { path }
    }

    /// Return the exact desired bytes for the managed tmux.conf file.
    pub(crate) fn desired_contents() -> &'static str {
        MANAGED_TMUX_CONF_CONTENTS
    }

    /// Reconcile the file on disk to exactly match the managed bytes.
    pub(crate) fn reconcile(&self) -> Result<(), ConfigError> {
        if let Some(parent) = self.path.parent() {
            fs::create_dir_all(parent).map_err(|source| ConfigError::CreateDir {
                path: parent.to_path_buf(),
                source,
            })?;
        }

        let lock_path = lock_path_for(&self.path);
        let lock_file = acquire_lock_file(&lock_path)?;
        let write_result = self.reconcile_locked();

        // Always best-effort unlock by removing lock file.
        let _ = fs::remove_file(&lock_path);
        drop(lock_file);

        write_result
    }

    /// Check whether the on-disk file already matches managed contents.
    pub(crate) fn is_in_sync(&self) -> bool {
        match fs::read(&self.path) {
            Ok(current) => current == Self::desired_contents().as_bytes(),
            Err(_) => false,
        }
    }

    fn reconcile_locked(&self) -> Result<(), ConfigError> {
        let desired = Self::desired_contents().as_bytes();
        if let Ok(current) = fs::read(&self.path)
            && current == desired
        {
            return Ok(());
        }

        let parent = self.path.parent().ok_or_else(|| ConfigError::CreateFile {
            path: self.path.clone(),
            source: std::io::Error::other("tmux config path has no parent directory"),
        })?;

        // Use a unique temp path per write attempt so concurrent processes/tests never
        // fight over the same intermediate file name.
        let pid = std::process::id();
        let nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos());
        let tmp_path = parent.join(format!(".ox-tmux.{pid}.{nanos}.tmp"));
        {
            let mut tmp = OpenOptions::new()
                .create(true)
                .truncate(true)
                .write(true)
                .open(&tmp_path)
                .map_err(|source| ConfigError::CreateFile {
                    path: tmp_path.clone(),
                    source,
                })?;
            tmp.write_all(desired)
                .map_err(|source| ConfigError::CreateFile {
                    path: tmp_path.clone(),
                    source,
                })?;
            tmp.sync_all().map_err(|source| ConfigError::CreateFile {
                path: tmp_path.clone(),
                source,
            })?;
        }

        fs::rename(&tmp_path, &self.path).map_err(|source| ConfigError::CreateFile {
            path: self.path.clone(),
            source,
        })?;
        Ok(())
    }
}

fn lock_path_for(path: &Path) -> PathBuf {
    let file_name = path.file_name().map_or_else(
        || "tmux.conf".to_string(),
        |part| part.to_string_lossy().to_string(),
    );
    path.with_file_name(format!("{file_name}.lock"))
}

fn acquire_lock_file(lock_path: &Path) -> Result<std::fs::File, ConfigError> {
    let start = Instant::now();
    loop {
        match OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(lock_path)
        {
            Ok(file) => return Ok(file),
            Err(err) if err.kind() == std::io::ErrorKind::AlreadyExists => {
                if start.elapsed() >= LOCK_WAIT_TIMEOUT {
                    return Err(ConfigError::LockTimeout {
                        path: lock_path.to_path_buf(),
                    });
                }
                thread::sleep(LOCK_RETRY_INTERVAL);
            }
            Err(source) => {
                return Err(ConfigError::LockFile {
                    path: lock_path.to_path_buf(),
                    source,
                });
            }
        }
    }
}

fn default_tmux_conf_path() -> PathBuf {
    PathBuf::from("~/.config/ox/tmux.conf")
}

fn expand_tilde(path: PathBuf) -> Result<PathBuf, ConfigError> {
    let path_str = path.to_string_lossy();
    if !path_str.starts_with('~') {
        return Ok(path);
    }

    let home = std::env::var("HOME").map_err(|_| ConfigError::HomeMissing)?;
    if path_str == "~" {
        return Ok(PathBuf::from(home));
    }
    if let Some(rest) = path_str.strip_prefix("~/") {
        return Ok(PathBuf::from(home).join(rest));
    }

    Err(ConfigError::UnsupportedTildeForm)
}

#[cfg(test)]
mod tests {
    use super::{MANAGED_TMUX_CONF_CONTENTS, ManagedTmuxConfig, TmuxConfig};
    use std::error::Error;
    use std::fs;
    use std::path::PathBuf;
    use std::sync::Arc;
    use std::thread;
    use std::time::{SystemTime, UNIX_EPOCH};

    fn temp_file(prefix: &str) -> PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos());
        std::env::temp_dir().join(format!("{prefix}-{nanos}.conf"))
    }

    #[test]
    fn resolve_creates_missing_file() -> Result<(), Box<dyn Error>> {
        let path = temp_file("ox-missing-conf");
        if path.exists() {
            fs::remove_file(&path)?;
        }

        let config = TmuxConfig::resolve_from_path(path.clone())?;
        assert_eq!(config.tmux_conf_path, path);
        assert!(config.tmux_conf_path.exists());
        let contents = fs::read_to_string(&config.tmux_conf_path)?;
        assert_eq!(contents, MANAGED_TMUX_CONF_CONTENTS);

        fs::remove_file(path)?;
        Ok(())
    }

    #[test]
    fn reconcile_overwrites_existing_file_with_managed_contents() -> Result<(), Box<dyn Error>> {
        let path = temp_file("ox-existing-conf");
        fs::write(&path, "set -g status off\nbind-key x kill-pane\n")?;

        let managed_tmux_config = ManagedTmuxConfig::new(path.clone());
        managed_tmux_config.reconcile()?;
        let contents = fs::read_to_string(&path)?;
        assert_eq!(contents, MANAGED_TMUX_CONF_CONTENTS);

        fs::remove_file(path)?;
        Ok(())
    }

    #[test]
    fn reconcile_noops_when_file_is_already_managed() -> Result<(), Box<dyn Error>> {
        let path = temp_file("ox-noop-conf");
        fs::write(&path, MANAGED_TMUX_CONF_CONTENTS)?;
        let before = fs::read(&path)?;

        let managed_tmux_config = ManagedTmuxConfig::new(path.clone());
        managed_tmux_config.reconcile()?;
        let after = fs::read(&path)?;
        assert_eq!(before, after);

        fs::remove_file(path)?;
        Ok(())
    }

    #[test]
    fn desired_contents_bind_ctrl_s_to_last_session() {
        assert!(
            ManagedTmuxConfig::desired_contents().contains("bind-key -n C-s switch-client -l\n")
        );
    }

    #[test]
    fn concurrent_reconcile_keeps_canonical_contents() -> Result<(), Box<dyn Error>> {
        let path = temp_file("ox-concurrent-conf");
        fs::write(&path, "set -g status off\n")?;
        let shared = Arc::new(ManagedTmuxConfig::new(path.clone()));

        let mut handles = Vec::new();
        for _ in 0..8 {
            let managed_tmux_config = Arc::clone(&shared);
            handles.push(thread::spawn(move || managed_tmux_config.reconcile()));
        }

        for handle in handles {
            let joined = handle
                .join()
                .map_err(|_| std::io::Error::other("thread should not panic"))?;
            joined?;
        }

        let contents = fs::read_to_string(&path)?;
        assert_eq!(contents, MANAGED_TMUX_CONF_CONTENTS);
        fs::remove_file(path)?;
        Ok(())
    }

    #[test]
    fn is_in_sync_reports_false_for_mismatch() -> Result<(), Box<dyn Error>> {
        let path = temp_file("ox-sync-mismatch");
        fs::write(&path, "set -g status off\n")?;
        let managed_tmux_config = ManagedTmuxConfig::new(path.clone());
        assert!(!managed_tmux_config.is_in_sync());
        fs::remove_file(path)?;
        Ok(())
    }
}
