use std::process::Command;

use crate::error::TmuxError;
use crate::error::tmux_stderr_is_no_server;
use crate::infrastructure::command_timeout::{SUBPROCESS_TIMEOUT, run_with_timeout};
use crate::infrastructure::tmux::TmuxConfig;

/// Thin wrapper around `tmux` process execution.
pub(crate) struct TmuxClient<'a> {
    tmux_config: &'a TmuxConfig,
}

impl<'a> TmuxClient<'a> {
    /// Construct a client that always uses `tmux -f <conf>`.
    pub(crate) fn new(tmux_config: &'a TmuxConfig) -> Self {
        Self { tmux_config }
    }

    /// Run `tmux -f <conf> ...args` and return process output.
    fn run(&self, args: &[&str]) -> Result<std::process::Output, TmuxError> {
        let mut cmd = Command::new("tmux");
        cmd.arg("-f").arg(&self.tmux_config.tmux_conf_path);
        for arg in args {
            cmd.arg(arg);
        }
        run_with_timeout(&mut cmd, SUBPROCESS_TIMEOUT)
    }

    /// Run a tmux command that should only report success/failure.
    pub(crate) fn run_ok(&self, args: &[&str]) -> Result<(), TmuxError> {
        let output = self.run(args)?;
        if output.status.success() {
            return Ok(());
        }

        Err(TmuxError::CommandFailed {
            stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
        })
    }

    /// Run a tmux command and return stdout if the command succeeds.
    /// If tmux reports there is no running server, return an empty string.
    pub(crate) fn run_output_allow_no_server_empty(
        &self,
        args: &[&str],
    ) -> Result<String, TmuxError> {
        let output = self.run(args)?;
        if output.status.success() {
            return Ok(String::from_utf8_lossy(&output.stdout).into_owned());
        }

        let stderr = String::from_utf8_lossy(&output.stderr);
        // Normalize the common tmux "daemon/socket missing" variants into the
        // same empty-output behavior so list/read probes can treat "no server"
        // as an empty fleet instead of a hard failure.
        if tmux_stderr_is_no_server(&stderr) {
            return Ok(String::new());
        }

        Err(TmuxError::CommandFailed {
            stderr: stderr.into_owned(),
        })
    }

    /// Run a tmux command in the current terminal (interactive mode).
    pub(crate) fn run_interactive_ok(&self, args: &[&str]) -> Result<(), TmuxError> {
        let mut cmd = Command::new("tmux");
        cmd.arg("-f").arg(&self.tmux_config.tmux_conf_path);
        for arg in args {
            cmd.arg(arg);
        }

        let status = cmd.status().map_err(TmuxError::Io)?;
        if status.success() {
            return Ok(());
        }

        Err(TmuxError::CommandFailed {
            stderr: format!("tmux exited with status: {status}"),
        })
    }

    /// Run `tmux ...args` without `-f <managed-conf>` and return raw output.
    pub(crate) fn run_system(args: &[&str]) -> Result<std::process::Output, TmuxError> {
        let mut cmd = Command::new("tmux");
        for arg in args {
            cmd.arg(arg);
        }
        run_with_timeout(&mut cmd, SUBPROCESS_TIMEOUT)
    }

    /// Run `tmux ...args` without `-f <managed-conf>` and report success/failure.
    pub(crate) fn run_system_ok(args: &[&str]) -> Result<(), TmuxError> {
        let output = Self::run_system(args)?;
        if output.status.success() {
            return Ok(());
        }

        Err(TmuxError::CommandFailed {
            stderr: String::from_utf8_lossy(&output.stderr).into_owned(),
        })
    }
}
