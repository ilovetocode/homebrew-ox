mod panes;
#[cfg(any(test, feature = "bench"))]
mod process_rows;
mod sessions;

pub(super) use panes::{PaneRow, parse_panes};
#[cfg(any(test, feature = "bench"))]
pub(super) use process_rows::{ProcessRow, parse_process_rows};
pub(super) use sessions::parse_sessions;

#[cfg(test)]
mod tests {
    use std::error::Error;

    use crate::application::{AgentKind, RuntimeStatus};

    use super::{parse_panes, parse_process_rows, parse_sessions};

    type TestResult = Result<(), Box<dyn Error>>;

    #[test]
    fn parse_valid_rows() {
        let raw = "work\t3\t1\nops\t1\t0\n";
        let parsed = parse_sessions(raw);
        assert!(parsed.is_ok(), "parser should accept valid rows");
        let Ok(sessions) = parsed else {
            return;
        };
        assert_eq!(sessions.len(), 2);
        assert_eq!(sessions[0].name, "work");
        assert_eq!(sessions[0].windows, 3);
        assert!(sessions[0].attached);
        assert_eq!(sessions[0].agent_kind, AgentKind::Shell);
        assert_eq!(sessions[0].runtime_status, RuntimeStatus::Unknown);
        assert_eq!(sessions[1].name, "ops");
        assert_eq!(sessions[1].windows, 1);
        assert!(!sessions[1].attached);
        assert_eq!(sessions[1].agent_kind, AgentKind::Shell);
        assert_eq!(sessions[1].runtime_status, RuntimeStatus::Unknown);
    }

    #[test]
    fn parse_rejects_invalid_attached_flag() {
        let raw = "work\t3\tyes\n";
        let parsed = parse_sessions(raw);
        assert!(
            parsed.is_err(),
            "parser should reject invalid attached flag"
        );
        let Err(err) = parsed else {
            return;
        };
        assert!(err.to_string().contains("invalid attached flag"));
    }

    #[test]
    fn parse_panes_accepts_valid_rows() -> TestResult {
        let raw = "work\t%1\t42\t/dev/ttys001\t1\t1\tcodex\t/tmp/work\nops\t%2\t77\t/dev/ttys002\t0\t0\tbash\t/tmp/ops\n";
        let parsed = parse_panes(raw)?;
        assert_eq!(parsed.len(), 2);
        assert_eq!(parsed[0].session_name, "work".to_string());
        assert_eq!(parsed[0].pane_id, "%1".to_string());
        assert_eq!(parsed[0].pane_pid, 42);
        assert_eq!(parsed[0].pane_tty, "ttys001".to_string());
        assert!(parsed[0].window_active);
        assert!(parsed[0].pane_active);
        assert_eq!(parsed[0].pane_current_command.as_deref(), Some("codex"));
        assert_eq!(parsed[0].pane_current_path.as_deref(), Some("/tmp/work"));
        assert!(!parsed[1].window_active);
        assert!(!parsed[1].pane_active);
        assert_eq!(parsed[1].pane_current_command.as_deref(), Some("bash"));
        assert_eq!(parsed[1].pane_current_path.as_deref(), Some("/tmp/ops"));
        Ok(())
    }

    #[test]
    fn parse_panes_accepts_printable_separator_rows() -> TestResult {
        let raw = "ops_room<<OX>>%2<<OX>>77<<OX>>/dev/ttys002<<OX>>0<<OX>>1<<OX>>cargo_watch<<OX>>/tmp/ops_room\n";
        let parsed = parse_panes(raw)?;
        assert_eq!(parsed.len(), 1);
        assert_eq!(parsed[0].session_name, "ops_room".to_string());
        assert_eq!(parsed[0].pane_id, "%2".to_string());
        assert_eq!(parsed[0].pane_pid, 77);
        assert_eq!(parsed[0].pane_tty, "ttys002".to_string());
        assert!(!parsed[0].window_active);
        assert!(parsed[0].pane_active);
        assert_eq!(
            parsed[0].pane_current_command.as_deref(),
            Some("cargo_watch")
        );
        assert_eq!(
            parsed[0].pane_current_path.as_deref(),
            Some("/tmp/ops_room")
        );
        Ok(())
    }

    #[test]
    fn parse_process_rows_accepts_valid_rows() -> TestResult {
        let raw = "50338 50338 50542 ttys013 claude --dangerously-skip-permissions\n\
                   50313 50313 50448 ttys011 codex\n";
        let parsed = parse_process_rows(raw)?;
        assert_eq!(parsed.len(), 2);
        assert_eq!(parsed[0].pid, 50338);
        assert_eq!(parsed[0].pgid, 50338);
        assert_eq!(parsed[0].tpgid, 50542);
        assert_eq!(parsed[0].tty, "ttys013".to_string());
        assert_eq!(
            parsed[0].command,
            "claude --dangerously-skip-permissions".to_string()
        );
        Ok(())
    }

    #[test]
    fn parse_sessions_handles_empty_input() {
        let parsed = parse_sessions("");
        assert!(parsed.is_ok());
        let Ok(sessions) = parsed else { return };
        assert!(sessions.is_empty());
    }

    #[test]
    fn parse_sessions_skips_blank_lines() {
        let raw = "\n  \nwork\t1\t0\n\n";
        let parsed = parse_sessions(raw);
        assert!(parsed.is_ok());
        let Ok(sessions) = parsed else { return };
        assert_eq!(sessions.len(), 1);
    }

    #[test]
    fn parse_sessions_accepts_older_tmux_underscore_separator() {
        let raw = "work_1_0\nops_room_3_1\n";
        let parsed = parse_sessions(raw);
        assert!(parsed.is_ok());
        let Ok(sessions) = parsed else { return };
        assert_eq!(sessions.len(), 2);
        assert_eq!(sessions[0].name, "work");
        assert_eq!(sessions[0].windows, 1);
        assert!(!sessions[0].attached);
        assert_eq!(sessions[1].name, "ops_room");
        assert_eq!(sessions[1].windows, 3);
        assert!(sessions[1].attached);
    }

    #[test]
    fn parse_sessions_accepts_printable_separator_rows() {
        let raw = "ops_room<<OX>>3<<OX>>1\n";
        let parsed = parse_sessions(raw);
        assert!(parsed.is_ok());
        let Ok(sessions) = parsed else { return };
        assert_eq!(sessions.len(), 1);
        assert_eq!(sessions[0].name, "ops_room");
        assert_eq!(sessions[0].windows, 3);
        assert!(sessions[0].attached);
    }

    #[test]
    fn parse_sessions_rejects_missing_windows_count() {
        let raw = "work\n";
        let parsed = parse_sessions(raw);
        assert!(parsed.is_err());
    }

    #[test]
    fn parse_sessions_rejects_non_numeric_windows() {
        let raw = "work\tabc\t1\n";
        let parsed = parse_sessions(raw);
        assert!(parsed.is_err());
        let Err(err) = parsed else { return };
        assert!(err.to_string().contains("invalid windows count"));
    }

    #[test]
    fn parse_panes_handles_empty_input() -> TestResult {
        let parsed = parse_panes("")?;
        assert!(parsed.is_empty());
        Ok(())
    }

    #[test]
    fn parse_panes_rejects_invalid_binary_flag() {
        let raw = "work\t%1\t42\t/dev/ttys001\tyes\t1\n";
        let parsed = parse_panes(raw);
        assert!(parsed.is_err());
        let Err(err) = parsed else { return };
        assert!(err.to_string().contains("invalid window active flag"));
    }

    #[test]
    fn parse_panes_rejects_empty_tty() {
        let raw = "work\t%1\t42\t\t1\t1\n";
        let parsed = parse_panes(raw);
        assert!(parsed.is_err());
        let Err(err) = parsed else { return };
        assert!(err.to_string().contains("invalid empty pane tty"));
    }

    #[test]
    fn parse_panes_rejects_non_numeric_pid() {
        let raw = "work\t%1\tabc\t/dev/ttys001\t1\t1\n";
        let parsed = parse_panes(raw);
        assert!(parsed.is_err());
        let Err(err) = parsed else { return };
        assert!(err.to_string().contains("invalid pane pid"));
    }

    #[test]
    fn parse_panes_without_current_path_still_parses() -> TestResult {
        let raw = "work\t%1\t42\t/dev/ttys001\t1\t1\n";
        let parsed = parse_panes(raw)?;
        assert_eq!(parsed.len(), 1);
        assert!(parsed[0].pane_current_command.is_none());
        assert!(parsed[0].pane_current_path.is_none());
        Ok(())
    }

    #[test]
    fn parse_process_rows_handles_empty_input() -> TestResult {
        let parsed = parse_process_rows("")?;
        assert!(parsed.is_empty());
        Ok(())
    }

    #[test]
    fn parse_process_rows_rejects_missing_command() {
        let raw = "100 100 100 ttys001\n";
        let parsed = parse_process_rows(raw);
        assert!(parsed.is_err());
        let Err(err) = parsed else { return };
        assert!(err.to_string().contains("missing process command"));
    }

    #[test]
    fn parse_process_rows_rejects_non_numeric_pid() {
        let raw = "abc 100 100 ttys001 bash\n";
        let parsed = parse_process_rows(raw);
        assert!(parsed.is_err());
        let Err(err) = parsed else { return };
        assert!(err.to_string().contains("invalid process pid"));
    }

    #[test]
    fn parse_process_rows_rejects_non_numeric_pgid() {
        let raw = "100 abc 100 ttys001 bash\n";
        let parsed = parse_process_rows(raw);
        assert!(parsed.is_err());
        let Err(err) = parsed else { return };
        assert!(err.to_string().contains("invalid process pgid"));
    }

    #[test]
    fn parse_process_rows_rejects_non_numeric_tpgid() {
        let raw = "100 100 abc ttys001 bash\n";
        let parsed = parse_process_rows(raw);
        assert!(parsed.is_err());
        let Err(err) = parsed else { return };
        assert!(err.to_string().contains("invalid process tpgid"));
    }

    #[test]
    fn normalize_tty_strips_dev_prefix() {
        assert_eq!(super::panes::normalize_tty("/dev/ttys001"), "ttys001");
    }

    #[test]
    fn normalize_tty_strips_quotes() {
        assert_eq!(super::panes::normalize_tty("\"ttys001\""), "ttys001");
    }

    #[test]
    fn normalize_tty_trims_whitespace() {
        assert_eq!(super::panes::normalize_tty("  ttys001  "), "ttys001");
    }

    #[test]
    fn normalize_tty_without_prefix() {
        assert_eq!(super::panes::normalize_tty("ttys001"), "ttys001");
    }

    #[test]
    fn parse_tmux_binary_flag_accepts_zero_and_one() {
        let Ok(zero) = super::panes::parse_tmux_binary_flag("0", "test") else {
            return;
        };
        assert!(!zero);
        let Ok(one) = super::panes::parse_tmux_binary_flag("1", "test") else {
            return;
        };
        assert!(one);
    }

    #[test]
    fn parse_tmux_binary_flag_rejects_other() {
        let result = super::panes::parse_tmux_binary_flag("2", "test flag");
        assert!(result.is_err());
        let Err(err) = result else { return };
        assert!(err.to_string().contains("invalid test flag"));
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used)]
mod proptests {
    use std::fmt::Write as _;

    use proptest::prelude::*;

    use super::{parse_panes, parse_process_rows, parse_sessions};

    // --- Generators ---

    fn valid_session_name() -> impl Strategy<Value = String> {
        "[a-zA-Z][a-zA-Z0-9_-]{0,15}".prop_map(|s| s)
    }

    fn valid_session_line() -> impl Strategy<Value = (String, u32, bool)> {
        (valid_session_name(), 1..100u32, proptest::bool::ANY)
            .prop_map(|(name, windows, attached)| (name, windows, attached))
    }

    fn valid_pane_line() -> impl Strategy<Value = (String, String, i32, String, bool, bool)> {
        (
            valid_session_name(),
            (1..1000u32).prop_map(|n| format!("%{n}")),
            1..65535i32,
            (1..999u32).prop_map(|n| format!("ttys{n:03}")),
            proptest::bool::ANY,
            proptest::bool::ANY,
        )
    }

    fn valid_process_line() -> impl Strategy<Value = (i32, i32, i32, String, String)> {
        (
            1..65535i32,
            1..65535i32,
            1..65535i32,
            (1..999u32).prop_map(|n| format!("ttys{n:03}")),
            "[a-z][a-z0-9_-]{1,15}".prop_map(|s| s),
        )
    }

    // --- parse_sessions ---

    proptest! {
        #[test]
        fn parse_sessions_valid_roundtrip(
            rows in proptest::collection::vec(valid_session_line(), 1..5)
        ) {
            let mut raw = String::new();
            for (name, windows, attached) in &rows {
                let _ = writeln!(raw, "{name}\t{windows}\t{}", if *attached { "1" } else { "0" });
            }
            let parsed = parse_sessions(&raw).unwrap();
            prop_assert_eq!(parsed.len(), rows.len());
        }

        #[test]
        fn parse_sessions_never_panics(raw in ".*") {
            let _ = parse_sessions(&raw);
        }

        #[test]
        fn parse_sessions_field_fidelity(
            (name, windows, attached) in valid_session_line()
        ) {
            let raw = format!("{name}\t{windows}\t{}\n", if attached { "1" } else { "0" });
            let parsed = parse_sessions(&raw).unwrap();
            prop_assert_eq!(parsed.len(), 1);
            prop_assert_eq!(&parsed[0].name, &name);
            prop_assert_eq!(parsed[0].windows, windows);
            prop_assert_eq!(parsed[0].attached, attached);
        }
    }

    // --- parse_panes ---

    proptest! {
        #[test]
        fn parse_panes_valid_roundtrip(
            rows in proptest::collection::vec(valid_pane_line(), 1..5)
        ) {
            let mut raw = String::new();
            for (session, pane_id, pid, tty, win_active, pane_active) in &rows {
                let _ = writeln!(
                    raw,
                    "{session}\t{pane_id}\t{pid}\t/dev/{tty}\t{}\t{}\tbash",
                    if *win_active { "1" } else { "0" },
                    if *pane_active { "1" } else { "0" },
                );
            }
            let parsed = parse_panes(&raw).unwrap();
            prop_assert_eq!(parsed.len(), rows.len());
        }

        #[test]
        fn parse_panes_never_panics(raw in ".*") {
            let _ = parse_panes(&raw);
        }

        #[test]
        fn parse_panes_field_fidelity(
            (session, pane_id, pid, tty, win_active, pane_active) in valid_pane_line()
        ) {
            let raw = format!(
                "{session}\t{pane_id}\t{pid}\t/dev/{tty}\t{}\t{}\n",
                if win_active { "1" } else { "0" },
                if pane_active { "1" } else { "0" },
            );
            let parsed = parse_panes(&raw).unwrap();
            prop_assert_eq!(parsed.len(), 1);
            prop_assert_eq!(&parsed[0].session_name, &session);
            prop_assert_eq!(&parsed[0].pane_id, &pane_id);
            prop_assert_eq!(parsed[0].pane_pid, pid);
            prop_assert_eq!(&parsed[0].pane_tty, &tty);
            prop_assert_eq!(parsed[0].window_active, win_active);
            prop_assert_eq!(parsed[0].pane_active, pane_active);
        }
    }

    // --- parse_process_rows ---

    proptest! {
        #[test]
        fn parse_process_rows_valid_roundtrip(
            rows in proptest::collection::vec(valid_process_line(), 1..5)
        ) {
            let mut raw = String::new();
            for (pid, pgid, tpgid, tty, cmd) in &rows {
                let _ = writeln!(raw, "{pid} {pgid} {tpgid} {tty} {cmd}");
            }
            let parsed = parse_process_rows(&raw).unwrap();
            prop_assert_eq!(parsed.len(), rows.len());
        }

        #[test]
        fn parse_process_rows_never_panics(raw in ".*") {
            let _ = parse_process_rows(&raw);
        }

        #[test]
        fn parse_process_rows_field_fidelity(
            (pid, pgid, tpgid, tty, cmd) in valid_process_line()
        ) {
            let raw = format!("{pid} {pgid} {tpgid} {tty} {cmd}\n");
            let parsed = parse_process_rows(&raw).unwrap();
            prop_assert_eq!(parsed.len(), 1);
            prop_assert_eq!(parsed[0].pid, pid);
            prop_assert_eq!(parsed[0].pgid, pgid);
            prop_assert_eq!(parsed[0].tpgid, tpgid);
            prop_assert_eq!(&parsed[0].tty, &tty);
            prop_assert_eq!(&parsed[0].command, &cmd);
        }
    }
}
