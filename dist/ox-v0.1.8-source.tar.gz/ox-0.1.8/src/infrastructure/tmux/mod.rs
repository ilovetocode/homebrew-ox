mod adapter;
mod agent_detection;
mod aux_sessions;
mod client;
mod config;
mod parsers;
#[cfg(any(test, feature = "bench"))]
mod process_inspector;
mod sessions;

pub(crate) use adapter::TmuxAdapter;
pub(crate) use aux_sessions::TmuxAuxSessionAdapter;
pub(crate) use client::TmuxClient;
pub(crate) use config::TmuxConfig;

/// Thin wrappers for criterion benchmarks behind the `bench` feature.
#[cfg(feature = "bench")]
pub(crate) mod bench {
    /// Parse tmux session listing and return the row count.
    pub(crate) fn parse_sessions(raw: &str) -> usize {
        super::parsers::parse_sessions(raw).map_or(0, |v| v.len())
    }

    /// Parse tmux pane listing and return the row count.
    pub(crate) fn parse_panes(raw: &str) -> usize {
        super::parsers::parse_panes(raw).map_or(0, |v| v.len())
    }

    /// Parse `ps` process rows and return the row count.
    pub(crate) fn parse_process_rows(raw: &str) -> usize {
        super::parsers::parse_process_rows(raw).map_or(0, |v| v.len())
    }

    /// Run the full agent-detection pipeline on raw inputs.
    pub(crate) fn detect_active_agents(panes_raw: &str, process_rows_raw: &str) -> usize {
        let panes = super::parsers::parse_panes(panes_raw).unwrap_or_default();
        let rows = super::parsers::parse_process_rows(process_rows_raw).unwrap_or_default();
        super::process_inspector::detect_active_pane_agent_snapshots_by_session(&panes, &rows).len()
    }
}
