use crate::error::{AppError, StorageError};

pub(super) fn storage_sqlite_error(context: &'static str, source: rusqlite::Error) -> AppError {
    AppError::Storage(StorageError::Sqlite {
        context: context.to_string(),
        source,
    })
}

pub(super) fn prepare_with_context<'conn>(
    conn: &'conn rusqlite::Connection,
    query: &str,
    context: &'static str,
) -> Result<rusqlite::Statement<'conn>, AppError> {
    conn.prepare(query)
        .map_err(|source| storage_sqlite_error(context, source))
}

pub(super) fn query_with_context<'stmt, P>(
    stmt: &'stmt mut rusqlite::Statement<'_>,
    params: P,
    context: &'static str,
) -> Result<rusqlite::Rows<'stmt>, AppError>
where
    P: rusqlite::Params,
{
    stmt.query(params)
        .map_err(|source| storage_sqlite_error(context, source))
}

pub(super) fn collect_query_map_rows<T, F>(
    rows_result: rusqlite::Result<rusqlite::MappedRows<'_, F>>,
    run_context: &'static str,
    decode_context: &'static str,
) -> Result<Vec<T>, AppError>
where
    F: FnMut(&rusqlite::Row<'_>) -> rusqlite::Result<T>,
{
    let rows = rows_result.map_err(|source| storage_sqlite_error(run_context, source))?;
    let mut out = Vec::new();
    for row in rows {
        let row = row.map_err(|source| storage_sqlite_error(decode_context, source))?;
        out.push(row);
    }
    Ok(out)
}

pub(super) fn decode_optional_row<T>(
    next_row: rusqlite::Result<Option<&rusqlite::Row<'_>>>,
    mut decode: impl FnMut(&rusqlite::Row<'_>) -> rusqlite::Result<T>,
    read_context: &'static str,
    decode_context: &'static str,
) -> Result<Option<T>, AppError> {
    let maybe_row = next_row.map_err(|source| storage_sqlite_error(read_context, source))?;
    maybe_row
        .map(|row| decode(row).map_err(|source| storage_sqlite_error(decode_context, source)))
        .transpose()
}
