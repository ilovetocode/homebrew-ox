use std::error::Error;
use std::fs;
use std::time::{SystemTime, UNIX_EPOCH};

use rusqlite::Connection;

use super::SqliteStore;
use crate::application::{AgentStorePort, AppEvent, EventLogPort};
use crate::domain::{Agent, AgentKind, AgentRuntimeBinding, RuntimeProvider};
use crate::error::{AgentError, AppError};

type TestResult = Result<(), Box<dyn Error>>;

fn temp_db_path(prefix: &str) -> std::path::PathBuf {
    let nanos = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_or(0, |duration| duration.as_nanos());
    std::env::temp_dir().join(format!("{prefix}-{nanos}.db"))
}

fn open_temp_store(prefix: &str) -> Result<(SqliteStore, std::path::PathBuf), AppError> {
    let path = temp_db_path(prefix);
    if path.exists() {
        fs::remove_file(&path).ok();
    }
    let store = SqliteStore::open(&path)?;
    Ok((store, path))
}

fn sample_agent(name: &str) -> Agent {
    Agent::new(name.to_string(), AgentKind::Shell, 100)
}

fn sample_agent_with_display_order(name: &str, display_order: i64) -> Agent {
    sample_agent(name).with_initial_display_order(display_order)
}

fn sample_binding(agent: &Agent) -> AgentRuntimeBinding {
    AgentRuntimeBinding::new(
        agent.id(),
        RuntimeProvider::Tmux,
        format!("ox_{}", agent.display_name()),
        100,
    )
}

#[test]
fn open_reconciles_tmux_runtime_binding_external_ref_to_agent_name() -> TestResult {
    let db_path = temp_db_path("ox-sqlite-reconcile-tmux-binding");
    if db_path.exists() {
        fs::remove_file(&db_path)?;
    }

    let conn = Connection::open(&db_path)?;
    conn.execute_batch(
        "CREATE TABLE events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp_unix_ms INTEGER NOT NULL,
            op_id TEXT NOT NULL,
            feature TEXT NOT NULL,
            action TEXT NOT NULL,
            target TEXT,
            outcome TEXT NOT NULL,
            detail TEXT
        );
        CREATE TABLE sessions (
            name TEXT PRIMARY KEY,
            windows INTEGER NOT NULL,
            attached INTEGER NOT NULL,
            agent_kind TEXT NOT NULL,
            is_running INTEGER NOT NULL,
            last_seen_unix_ms INTEGER NOT NULL
        );
        CREATE TABLE agents (
            agent_id TEXT PRIMARY KEY,
            display_name TEXT NOT NULL UNIQUE COLLATE BINARY,
            agent_kind TEXT NOT NULL,
            version INTEGER NOT NULL,
            created_at_unix_ms INTEGER NOT NULL,
            updated_at_unix_ms INTEGER NOT NULL
        );
        CREATE TABLE agent_runtime_bindings (
            binding_id TEXT PRIMARY KEY,
            agent_id TEXT NOT NULL UNIQUE,
            provider TEXT NOT NULL,
            external_ref TEXT NOT NULL,
            version INTEGER NOT NULL,
            last_seen_at_unix_ms INTEGER,
            created_at_unix_ms INTEGER NOT NULL,
            updated_at_unix_ms INTEGER NOT NULL,
            UNIQUE(provider, external_ref),
            FOREIGN KEY(agent_id) REFERENCES agents(agent_id) ON DELETE CASCADE
        );
        CREATE TABLE agent_state_bindings (
            binding_id TEXT PRIMARY KEY,
            agent_id TEXT NOT NULL,
            state_kind TEXT NOT NULL,
            provider TEXT NOT NULL,
            binding_key TEXT NOT NULL,
            external_ref TEXT NOT NULL,
            metadata_json TEXT NOT NULL,
            version INTEGER NOT NULL,
            last_seen_at_unix_ms INTEGER,
            created_at_unix_ms INTEGER NOT NULL,
            updated_at_unix_ms INTEGER NOT NULL,
            UNIQUE(agent_id, state_kind, binding_key),
            UNIQUE(state_kind, provider, external_ref),
            FOREIGN KEY(agent_id) REFERENCES agents(agent_id) ON DELETE CASCADE
        );
        INSERT INTO agents (
            agent_id,
            display_name,
            agent_kind,
            version,
            created_at_unix_ms,
            updated_at_unix_ms
        ) VALUES ('ag_test', 'renamed-agent', 'shell', 2, 10, 20);
        INSERT INTO agent_runtime_bindings (
            binding_id,
            agent_id,
            provider,
            external_ref,
            version,
            last_seen_at_unix_ms,
            created_at_unix_ms,
            updated_at_unix_ms
        ) VALUES ('binding_test', 'ag_test', 'tmux', 'stale-name', 1, -9223372036854775808, 10, 10);",
    )?;
    drop(conn);

    let store = SqliteStore::open(&db_path)?;
    let records = store.list_agent_runtime_records()?;
    assert_eq!(
        records.len(),
        1,
        "expected one runtime record after opening db"
    );
    let Some(binding) = &records[0].binding else {
        return Ok(());
    };
    assert_eq!(
        binding.external_ref, "renamed-agent",
        "startup reconciliation should align tmux external_ref with agent display name"
    );

    if db_path.exists() {
        fs::remove_file(db_path)?;
    }
    Ok(())
}

#[test]
fn codecs_round_trip_known_values() {
    let agent_kinds = [
        ("shell", AgentKind::Shell),
        ("codex", AgentKind::Codex),
        ("opencode", AgentKind::Opencode),
        ("claude", AgentKind::Claude),
    ];
    for (raw, kind) in agent_kinds {
        assert_eq!(super::codecs::parse_agent_kind(raw), Some(kind));
        assert_eq!(super::codecs::agent_kind_to_str(kind), raw);
    }

    assert_eq!(
        super::codecs::parse_runtime_provider("tmux"),
        Some(RuntimeProvider::Tmux)
    );
    assert_eq!(
        super::codecs::runtime_provider_to_str(RuntimeProvider::Tmux),
        "tmux"
    );
}

#[test]
fn codecs_reject_unknown_values() {
    assert_eq!(super::codecs::parse_agent_kind("unknown"), None);
    assert_eq!(super::codecs::parse_runtime_provider("bogus"), None);
    assert_eq!(super::codecs::parse_runtime_provider("mirror_tmux"), None);
}

#[test]
fn codecs_state_kind_round_trip() {
    use crate::domain::AgentStateKind;
    let kinds = [
        ("tmux_session", AgentStateKind::TmuxSession),
        ("codex_thread", AgentStateKind::CodexThread),
        ("opencode_session", AgentStateKind::OpencodeSession),
        ("working_directory", AgentStateKind::WorkingDirectory),
        ("git_root", AgentStateKind::GitRoot),
        ("git_worktree", AgentStateKind::GitWorktree),
    ];
    for (raw, kind) in kinds {
        assert_eq!(super::codecs::parse_state_kind(raw), Some(kind));
        assert_eq!(super::codecs::state_kind_to_str(kind), raw);
    }
}

#[test]
fn codecs_state_provider_round_trip() {
    use crate::domain::AgentStateProvider;
    let providers = [
        ("tmux", AgentStateProvider::Tmux),
        ("codex", AgentStateProvider::Codex),
        ("opencode", AgentStateProvider::Opencode),
        ("git", AgentStateProvider::Git),
    ];
    for (raw, provider) in providers {
        assert_eq!(super::codecs::parse_state_provider(raw), Some(provider));
        assert_eq!(super::codecs::state_provider_to_str(provider), raw);
    }
}

#[test]
fn codecs_state_kind_rejects_unknown() {
    assert_eq!(super::codecs::parse_state_kind("bogus"), None);
    assert_eq!(super::codecs::parse_state_kind(""), None);
    assert_eq!(super::codecs::parse_state_kind("docker_container"), None);
    assert_eq!(super::codecs::parse_state_kind("kubernetes_cluster"), None);
    assert_eq!(super::codecs::parse_state_kind("cloud_account"), None);
}

#[test]
fn codecs_state_provider_rejects_unknown() {
    assert_eq!(super::codecs::parse_state_provider("bogus"), None);
    assert_eq!(super::codecs::parse_state_provider(""), None);
    assert_eq!(super::codecs::parse_state_provider("docker"), None);
    assert_eq!(super::codecs::parse_state_provider("kubernetes"), None);
    assert_eq!(super::codecs::parse_state_provider("cloud"), None);
}

#[test]
fn decode_agent_row_rejects_unknown_kind() -> TestResult {
    let conn = Connection::open_in_memory()?;
    conn.execute_batch(
        "CREATE TABLE agent_rows (
            agent_id TEXT NOT NULL,
            display_name TEXT NOT NULL,
            agent_kind TEXT NOT NULL,
            display_order INTEGER NOT NULL DEFAULT 0,
            version INTEGER NOT NULL,
            created_at_unix_ms INTEGER NOT NULL,
            updated_at_unix_ms INTEGER NOT NULL
        );
        INSERT INTO agent_rows (
            agent_id,
            display_name,
            agent_kind,
            display_order,
            version,
            created_at_unix_ms,
            updated_at_unix_ms
        ) VALUES ('ag_test', 'alpha', 'invalid_kind', 0, 1, 10, 10);",
    )?;

    let decoded = conn.query_row(
        "SELECT agent_id, display_name, agent_kind, display_order, version, created_at_unix_ms, updated_at_unix_ms FROM agent_rows",
        [],
        super::rows::decode_agent_row,
    );

    assert!(
        matches!(decoded, Err(rusqlite::Error::FromSqlConversionFailure(..))),
        "expected conversion failure for invalid kind"
    );
    Ok(())
}

#[test]
fn decode_binding_row_rejects_unknown_provider() -> TestResult {
    let conn = Connection::open_in_memory()?;
    conn.execute_batch(
        "CREATE TABLE binding_rows (
            binding_id TEXT NOT NULL,
            agent_id TEXT NOT NULL,
            provider TEXT NOT NULL,
            external_ref TEXT NOT NULL,
            version INTEGER NOT NULL,
            last_seen_at_unix_ms INTEGER,
            created_at_unix_ms INTEGER NOT NULL,
            updated_at_unix_ms INTEGER NOT NULL
        );
        INSERT INTO binding_rows (
            binding_id,
            agent_id,
            provider,
            external_ref,
            version,
            last_seen_at_unix_ms,
            created_at_unix_ms,
            updated_at_unix_ms
        ) VALUES ('binding_1', 'ag_test', 'invalid_provider', 'alpha', 1, 10, 10, 10);",
    )?;

    let decoded = conn.query_row(
        "SELECT binding_id, agent_id, provider, external_ref, version, last_seen_at_unix_ms, created_at_unix_ms, updated_at_unix_ms FROM binding_rows",
        [],
        super::rows::decode_binding_row,
    );

    assert!(
        matches!(decoded, Err(rusqlite::Error::FromSqlConversionFailure(..))),
        "expected conversion failure for invalid provider"
    );
    Ok(())
}

// --- Agent CRUD tests ---

#[test]
fn agent_insert_and_list_round_trips() -> TestResult {
    let (store, path) = open_temp_store("ox-agent-insert-list")?;
    let agent = sample_agent("alpha");
    let binding = sample_binding(&agent);
    store.insert_agent_with_binding(&agent, &binding, &[])?;

    let records = store.list_agent_runtime_records()?;
    assert_eq!(records.len(), 1, "should have one agent after insert");
    assert_eq!(
        records[0].agent.display_name(),
        "alpha",
        "display name should round-trip"
    );
    assert_eq!(
        records[0].agent.kind(),
        AgentKind::Shell,
        "kind should round-trip"
    );
    assert!(
        records[0].binding.is_some(),
        "binding should be present after insert"
    );

    fs::remove_file(path).ok();
    Ok(())
}

#[test]
fn agent_find_by_id_returns_match() -> TestResult {
    let (store, path) = open_temp_store("ox-agent-find-id")?;
    let agent = sample_agent("beta");
    let binding = sample_binding(&agent);
    let agent_id = agent.id();
    store.insert_agent_with_binding(&agent, &binding, &[])?;

    let found = store.find_agent_runtime_record_by_id(agent_id.clone())?;
    assert!(found.is_some(), "should find agent by id");
    let Some(record) = found else {
        return Ok(());
    };
    assert_eq!(
        record.agent.display_name(),
        "beta",
        "found agent should have correct name"
    );

    fs::remove_file(path).ok();
    Ok(())
}

#[test]
fn swap_display_order_handles_unique_index_without_conflict() -> TestResult {
    let (store, path) = open_temp_store("ox-agent-swap-display-order")?;
    let alpha = sample_agent_with_display_order("alpha", 1);
    let beta = sample_agent_with_display_order("beta", 2);
    let alpha_binding = sample_binding(&alpha);
    let beta_binding = sample_binding(&beta);

    store.insert_agent_with_binding(&alpha, &alpha_binding, &[])?;
    store.insert_agent_with_binding(&beta, &beta_binding, &[])?;

    // The storage layer must swap these rows atomically even though
    // `agents.display_order` is backed by a unique index.
    let swapped_alpha = alpha.clone().with_display_order(2, 200);
    let swapped_beta = beta.clone().with_display_order(1, 200);
    store.swap_display_order(
        &swapped_alpha,
        alpha.version(),
        &swapped_beta,
        beta.version(),
    )?;

    let records = store.list_agent_runtime_records()?;
    assert_eq!(records.len(), 2, "expected both agents to remain present");
    assert_eq!(
        records[0].agent.display_name(),
        "beta",
        "expected beta to move into the first display slot"
    );
    assert_eq!(
        records[0].agent.display_order(),
        1,
        "expected beta to hold the swapped display order"
    );
    assert_eq!(
        records[1].agent.display_name(),
        "alpha",
        "expected alpha to move into the second display slot"
    );
    assert_eq!(
        records[1].agent.display_order(),
        2,
        "expected alpha to hold the swapped display order"
    );
    assert_eq!(
        records[0].agent.version(),
        2,
        "expected swap to bump beta's optimistic-lock version"
    );
    assert_eq!(
        records[1].agent.version(),
        2,
        "expected swap to bump alpha's optimistic-lock version"
    );

    fs::remove_file(path).ok();
    Ok(())
}

#[test]
fn agent_find_by_id_returns_none_for_missing() -> TestResult {
    let (store, path) = open_temp_store("ox-agent-find-missing")?;
    let id = crate::domain::AgentId::new();
    let found = store.find_agent_runtime_record_by_id(id)?;
    assert!(found.is_none(), "should return None for unknown id");

    fs::remove_file(path).ok();
    Ok(())
}

#[test]
fn agent_find_by_display_name_returns_match() -> TestResult {
    let (store, path) = open_temp_store("ox-agent-find-name")?;
    let agent = sample_agent("gamma");
    let binding = sample_binding(&agent);
    store.insert_agent_with_binding(&agent, &binding, &[])?;

    let found = store.find_agent_by_display_name("gamma")?;
    assert!(found.is_some(), "should find agent by display name");
    let Some(record) = found else {
        return Ok(());
    };
    assert_eq!(
        record.id(),
        agent.id(),
        "found agent should have matching id"
    );

    fs::remove_file(path).ok();
    Ok(())
}

#[test]
fn agent_update_bumps_version() -> TestResult {
    let (store, path) = open_temp_store("ox-agent-update")?;
    let agent = sample_agent("delta");
    let binding = sample_binding(&agent);
    store.insert_agent_with_binding(&agent, &binding, &[])?;

    let updated = agent.renamed("delta-v2".to_string(), 200);
    store.update_agent(&updated, agent.version())?;

    let result = store.find_agent_runtime_record_by_id(agent.id())?;
    assert!(result.is_some(), "agent should still exist after update");
    let Some(found) = result else {
        return Ok(());
    };
    assert_eq!(
        found.agent.display_name(),
        "delta-v2",
        "name should be updated"
    );
    assert_eq!(found.agent.version(), 2, "version should be bumped");

    fs::remove_file(path).ok();
    Ok(())
}

#[test]
fn agent_update_syncs_tmux_binding_external_ref() -> TestResult {
    let (store, path) = open_temp_store("ox-agent-update-binding-sync")?;
    let agent = sample_agent("delta-sync");
    let binding = sample_binding(&agent);
    store.insert_agent_with_binding(&agent, &binding, &[])?;

    let updated = agent.renamed("delta-sync-v2".to_string(), 200);
    store.update_agent(&updated, agent.version())?;

    let result = store.find_agent_runtime_record_by_id(agent.id())?;
    assert!(result.is_some(), "agent should still exist after update");
    let Some(found) = result else {
        return Ok(());
    };

    assert_eq!(
        found.agent.display_name(),
        "delta-sync-v2",
        "updated agent should persist new display name"
    );
    assert!(
        found.binding.is_some(),
        "updated agent should retain runtime binding"
    );
    let Some(binding) = found.binding else {
        return Ok(());
    };
    assert_eq!(
        binding.external_ref, "delta-sync-v2",
        "tmux runtime binding external_ref should track display name after rename"
    );

    fs::remove_file(path).ok();
    Ok(())
}

#[test]
fn agent_update_rejects_stale_version() -> TestResult {
    let (store, path) = open_temp_store("ox-agent-stale")?;
    let agent = sample_agent("epsilon");
    let binding = sample_binding(&agent);
    store.insert_agent_with_binding(&agent, &binding, &[])?;

    let updated = agent.renamed("epsilon-v2".to_string(), 200);
    let wrong_version = 999;
    let result = store.update_agent(&updated, wrong_version);
    assert!(
        matches!(result, Err(AppError::Agent(AgentError::VersionConflict))),
        "stale version should produce VersionConflict"
    );

    fs::remove_file(path).ok();
    Ok(())
}

#[test]
fn agent_delete_removes_agent_and_bindings() -> TestResult {
    let (store, path) = open_temp_store("ox-agent-delete")?;
    let agent = sample_agent("zeta");
    let binding = sample_binding(&agent);
    let agent_id = agent.id();
    store.insert_agent_with_binding(&agent, &binding, &[])?;

    store.delete_agent(agent_id.clone())?;

    let found = store.find_agent_runtime_record_by_id(agent_id)?;
    assert!(found.is_none(), "agent should be gone after delete");
    let records = store.list_agent_runtime_records()?;
    assert!(records.is_empty(), "list should be empty after delete");

    fs::remove_file(path).ok();
    Ok(())
}

#[test]
fn agent_delete_returns_not_found_for_missing() -> TestResult {
    let (store, path) = open_temp_store("ox-agent-del-missing")?;
    let id = crate::domain::AgentId::new();
    let result = store.delete_agent(id);
    assert!(
        matches!(result, Err(AppError::Agent(AgentError::NotFound))),
        "deleting unknown id should return NotFound"
    );

    fs::remove_file(path).ok();
    Ok(())
}

#[test]
fn duplicate_display_name_returns_taken() -> TestResult {
    let (store, path) = open_temp_store("ox-agent-dup-name")?;
    let agent1 = sample_agent("unique");
    let binding1 = sample_binding(&agent1);
    store.insert_agent_with_binding(&agent1, &binding1, &[])?;

    let agent2 = sample_agent("unique");
    let binding2 = sample_binding(&agent2);
    let result = store.insert_agent_with_binding(&agent2, &binding2, &[]);
    assert!(
        matches!(result, Err(AppError::Agent(AgentError::DisplayNameTaken))),
        "duplicate display name should return DisplayNameTaken"
    );

    fs::remove_file(path).ok();
    Ok(())
}

// --- Event log tests ---

#[test]
fn event_append_and_read_recent_round_trips() -> TestResult {
    let (store, path) = open_temp_store("ox-event-round-trip")?;
    let event = AppEvent::success("agents", "create", Some("ag_test".to_string()));
    store.append(&event)?;

    let rows = store.read_recent(10)?;
    assert_eq!(rows.len(), 1, "should have one event");
    assert_eq!(rows[0].feature, "agents", "feature should round-trip");
    assert_eq!(rows[0].action, "create", "action should round-trip");
    assert_eq!(
        rows[0].target.as_deref(),
        Some("ag_test"),
        "target should round-trip"
    );

    fs::remove_file(path).ok();
    Ok(())
}

#[test]
fn event_read_recent_respects_limit() -> TestResult {
    let (store, path) = open_temp_store("ox-event-limit")?;
    for i in 0..5 {
        let event = AppEvent::success("agents", "list", Some(format!("ev_{i}")));
        store.append(&event)?;
    }

    let rows = store.read_recent(2)?;
    assert_eq!(rows.len(), 2, "should respect limit of 2");

    fs::remove_file(path).ok();
    Ok(())
}

// --- Binding upsert tests ---

#[test]
fn binding_upsert_updates_existing() -> TestResult {
    let (store, path) = open_temp_store("ox-binding-upsert")?;
    let agent = sample_agent("eta");
    let binding = sample_binding(&agent);
    store.insert_agent_with_binding(&agent, &binding, &[])?;

    let updated_binding = binding.observed(500);
    store.upsert_binding(&updated_binding)?;

    let result = store.find_agent_runtime_record_by_id(agent.id())?;
    assert!(result.is_some(), "agent should exist");
    let Some(record) = result else {
        return Ok(());
    };
    assert!(record.binding.is_some(), "binding should exist");
    let Some(b) = record.binding else {
        return Ok(());
    };
    assert_eq!(
        b.version, 2,
        "binding version should be bumped after upsert"
    );
    assert_eq!(
        b.last_seen_at_unix_ms,
        Some(500),
        "last_seen should be updated"
    );

    fs::remove_file(path).ok();
    Ok(())
}
