use crate::application::AgentStorePort;
use crate::domain::{
    Agent, AgentId, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding, AgentStateKind,
};
use crate::error::{AgentError, AppError, StorageError};

use super::SqliteStore;

mod reads;
mod state_bindings;
mod writes;

pub(super) const SQLITE_BIND_PARAMETER_LIMIT_SAFE_CHUNK: usize = 500;

pub(super) const AGENT_RUNTIME_RECORD_SELECT: &str = "SELECT
    a.agent_id,
    a.display_name,
    a.agent_kind,
    a.display_order,
    a.version,
    a.created_at_unix_ms,
    a.updated_at_unix_ms,
    b.binding_id,
    b.agent_id,
    b.provider,
    b.external_ref,
    b.version,
    b.last_seen_at_unix_ms,
    b.created_at_unix_ms,
    b.updated_at_unix_ms
 FROM agents a
 LEFT JOIN agent_runtime_bindings b
   ON b.agent_id = a.agent_id";

pub(super) const STATE_BINDING_SELECT: &str = "SELECT
    binding_id,
    agent_id,
    state_kind,
    provider,
    binding_key,
    external_ref,
    metadata_json,
    version,
    last_seen_at_unix_ms,
    created_at_unix_ms,
    updated_at_unix_ms
 FROM agent_state_bindings";

impl AgentStorePort for SqliteStore {
    fn insert_agent_with_binding(
        &self,
        agent: &Agent,
        binding: &AgentRuntimeBinding,
        state_bindings: &[AgentStateBinding],
    ) -> Result<(), AppError> {
        writes::insert_agent_with_binding(self, agent, binding, state_bindings)
    }

    fn list_agent_runtime_records(&self) -> Result<Vec<AgentRuntimeRecord>, AppError> {
        reads::list_agent_runtime_records(self)
    }

    fn find_agent_runtime_record_by_id(
        &self,
        id: AgentId,
    ) -> Result<Option<AgentRuntimeRecord>, AppError> {
        reads::find_agent_runtime_record_by_id(self, &id)
    }

    fn find_agent_by_display_name(&self, display_name: &str) -> Result<Option<Agent>, AppError> {
        reads::find_agent_by_display_name(self, display_name)
    }

    fn list_state_bindings_by_agent_id(
        &self,
        id: AgentId,
    ) -> Result<Vec<AgentStateBinding>, AppError> {
        state_bindings::list_state_bindings_by_agent_id(self, &id)
    }

    fn list_state_bindings_by_agent_ids(
        &self,
        ids: &[AgentId],
    ) -> Result<Vec<AgentStateBinding>, AppError> {
        state_bindings::list_state_bindings_by_agent_ids(self, ids)
    }

    fn upsert_state_binding(&self, binding: &AgentStateBinding) -> Result<(), AppError> {
        state_bindings::upsert_state_binding(self, binding)
    }

    fn update_agent(&self, updated: &Agent, expected_version: i64) -> Result<(), AppError> {
        writes::update_agent(self, updated, expected_version)
    }

    fn upsert_binding(&self, binding: &AgentRuntimeBinding) -> Result<(), AppError> {
        writes::upsert_binding(self, binding)
    }

    fn update_agent_runtime_context(
        &self,
        updated: &Agent,
        expected_version: i64,
        binding: &AgentRuntimeBinding,
        upsert_state_bindings: &[AgentStateBinding],
        delete_state_kinds: &[AgentStateKind],
    ) -> Result<(), AppError> {
        writes::update_agent_runtime_context(
            self,
            updated,
            expected_version,
            binding,
            upsert_state_bindings,
            delete_state_kinds,
        )
    }

    fn delete_agent(&self, id: AgentId) -> Result<(), AppError> {
        writes::delete_agent(self, &id)
    }

    fn next_display_order(&self) -> Result<i64, AppError> {
        reads::next_display_order(self)
    }

    fn swap_display_order(
        &self,
        a: &Agent,
        a_expected_version: i64,
        b: &Agent,
        b_expected_version: i64,
    ) -> Result<(), AppError> {
        writes::swap_display_order(self, a, a_expected_version, b, b_expected_version)
    }
}

pub(super) fn map_agent_write_error(
    context: &'static str,
) -> impl FnOnce(rusqlite::Error) -> AppError + Send + 'static {
    move |source| {
        let is_unique = matches!(
            source,
            rusqlite::Error::SqliteFailure(ref err, _)
                if err.extended_code == rusqlite::ffi::SQLITE_CONSTRAINT_UNIQUE
        );
        if is_unique {
            return AppError::Agent(AgentError::DisplayNameTaken);
        }
        AppError::Storage(StorageError::Sqlite {
            context: context.to_string(),
            source,
        })
    }
}
