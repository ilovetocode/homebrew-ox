use rusqlite::params;

use crate::domain::{Agent, AgentId, AgentRuntimeRecord};
use crate::error::AppError;

use super::super::SqliteStore;
use super::super::query_helpers::{
    collect_query_map_rows, decode_optional_row, prepare_with_context, query_with_context,
    storage_sqlite_error,
};

pub(super) fn list_agent_runtime_records(
    store: &SqliteStore,
) -> Result<Vec<AgentRuntimeRecord>, AppError> {
    let conn = super::super::conn::lock_conn(&store.conn)?;
    let query = format!(
        "{}\n ORDER BY a.display_order ASC",
        super::AGENT_RUNTIME_RECORD_SELECT
    );
    let mut stmt = prepare_with_context(&conn, &query, "prepare list agent runtime records query")?;
    collect_query_map_rows(
        stmt.query_map([], super::super::rows::decode_agent_runtime_record_row),
        "run list agent runtime records query",
        "decode agent runtime record row",
    )
}

pub(super) fn find_agent_runtime_record_by_id(
    store: &SqliteStore,
    id: &AgentId,
) -> Result<Option<AgentRuntimeRecord>, AppError> {
    let conn = super::super::conn::lock_conn(&store.conn)?;
    let query = format!(
        "{}\n WHERE a.agent_id = ?1\n LIMIT 1",
        super::AGENT_RUNTIME_RECORD_SELECT
    );
    let mut stmt = prepare_with_context(
        &conn,
        &query,
        "prepare find agent runtime record by id query",
    )?;
    let mut rows = query_with_context(
        &mut stmt,
        params![id.as_str()],
        "run find agent runtime record by id query",
    )?;

    decode_optional_row(
        rows.next(),
        super::super::rows::decode_agent_runtime_record_row,
        "read find agent runtime record by id row",
        "decode find agent runtime record by id row",
    )
}

pub(super) fn find_agent_by_display_name(
    store: &SqliteStore,
    display_name: &str,
) -> Result<Option<Agent>, AppError> {
    let conn = super::super::conn::lock_conn(&store.conn)?;
    let mut stmt = prepare_with_context(
        &conn,
        "SELECT agent_id, display_name, agent_kind, display_order, version, created_at_unix_ms, updated_at_unix_ms
         FROM agents
         WHERE display_name = ?1
         LIMIT 1",
        "prepare find agent by display name query",
    )?;

    let mut rows = query_with_context(
        &mut stmt,
        params![display_name],
        "run find agent by display name query",
    )?;

    decode_optional_row(
        rows.next(),
        super::super::rows::decode_agent_row,
        "read find agent by display name row",
        "decode find agent by display name row",
    )
}

pub(super) fn next_display_order(store: &SqliteStore) -> Result<i64, AppError> {
    let conn = super::super::conn::lock_conn(&store.conn)?;
    let order: i64 = conn
        .query_row(
            "SELECT COALESCE(MAX(display_order), 0) + 1 FROM agents",
            [],
            |row| row.get(0),
        )
        .map_err(|source| storage_sqlite_error("query next display order", source))?;
    Ok(order)
}
