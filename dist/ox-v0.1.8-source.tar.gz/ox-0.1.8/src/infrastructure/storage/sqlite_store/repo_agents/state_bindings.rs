use rusqlite::params;

use crate::domain::{AgentId, AgentStateBinding};
use crate::error::AppError;

use super::super::SqliteStore;
use super::super::query_helpers::{
    collect_query_map_rows, prepare_with_context, storage_sqlite_error,
};

pub(super) fn list_state_bindings_by_agent_id(
    store: &SqliteStore,
    id: &AgentId,
) -> Result<Vec<AgentStateBinding>, AppError> {
    let conn = super::super::conn::lock_conn(&store.conn)?;
    let query = format!(
        "{}\n WHERE agent_id = ?1\n ORDER BY created_at_unix_ms ASC",
        super::STATE_BINDING_SELECT
    );
    let mut stmt = prepare_with_context(
        &conn,
        &query,
        "prepare list state bindings by agent id query",
    )?;
    collect_query_map_rows(
        stmt.query_map(
            params![id.as_str()],
            super::super::rows::decode_state_binding_row,
        ),
        "run list state bindings by agent id query",
        "decode state binding row",
    )
}

pub(super) fn list_state_bindings_by_agent_ids(
    store: &SqliteStore,
    ids: &[AgentId],
) -> Result<Vec<AgentStateBinding>, AppError> {
    if ids.is_empty() {
        return Ok(Vec::new());
    }

    let conn = super::super::conn::lock_conn(&store.conn)?;
    let mut out = Vec::new();

    for chunk in ids.chunks(super::SQLITE_BIND_PARAMETER_LIMIT_SAFE_CHUNK) {
        let placeholders = std::iter::repeat_n("?", chunk.len())
            .collect::<Vec<_>>()
            .join(",");
        let query = format!(
            "{}\n WHERE agent_id IN ({placeholders})\n ORDER BY created_at_unix_ms ASC",
            super::STATE_BINDING_SELECT
        );

        let mut stmt = prepare_with_context(
            &conn,
            &query,
            "prepare list state bindings by agent ids query",
        )?;
        let params = rusqlite::params_from_iter(chunk.iter().map(AgentId::as_str));
        let mut rows = collect_query_map_rows(
            stmt.query_map(params, super::super::rows::decode_state_binding_row),
            "run list state bindings by agent ids query",
            "decode state binding row",
        )?;
        out.append(&mut rows);
    }

    Ok(out)
}

pub(super) fn upsert_state_binding(
    store: &SqliteStore,
    binding: &AgentStateBinding,
) -> Result<(), AppError> {
    let conn = super::super::conn::lock_conn(&store.conn)?;
    conn.execute(
        "INSERT INTO agent_state_bindings (
            binding_id,
            agent_id,
            state_kind,
            provider,
            binding_key,
            external_ref,
            metadata_json,
            version,
            last_seen_at_unix_ms,
            created_at_unix_ms,
            updated_at_unix_ms
         ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11)
         ON CONFLICT(agent_id, state_kind, binding_key) DO UPDATE SET
            provider = excluded.provider,
            external_ref = excluded.external_ref,
            metadata_json = excluded.metadata_json,
            version = excluded.version,
            last_seen_at_unix_ms = excluded.last_seen_at_unix_ms,
            updated_at_unix_ms = excluded.updated_at_unix_ms",
        params![
            binding.id.as_str(),
            binding.agent_id.as_str(),
            super::super::codecs::state_kind_to_str(binding.state_kind),
            super::super::codecs::state_provider_to_str(binding.provider),
            binding.binding_key.as_str(),
            binding.external_ref.as_str(),
            binding.metadata_json.as_str(),
            binding.version,
            binding
                .last_seen_at_unix_ms
                .map_or(i64::MIN, |value| i64::try_from(value).unwrap_or(i64::MAX)),
            i64::try_from(binding.created_at_unix_ms).unwrap_or(i64::MAX),
            i64::try_from(binding.updated_at_unix_ms).unwrap_or(i64::MAX),
        ],
    )
    .map_err(|source| storage_sqlite_error("upsert state binding row", source))?;
    Ok(())
}

#[allow(dead_code)]
pub(super) fn upsert_state_binding_in_tx(
    tx: &rusqlite::Transaction<'_>,
    binding: &AgentStateBinding,
    context: &'static str,
) -> Result<(), AppError> {
    tx.execute(
        "INSERT INTO agent_state_bindings (
            binding_id,
            agent_id,
            state_kind,
            provider,
            binding_key,
            external_ref,
            metadata_json,
            version,
            last_seen_at_unix_ms,
            created_at_unix_ms,
            updated_at_unix_ms
         ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11)
         ON CONFLICT(agent_id, state_kind, binding_key) DO UPDATE SET
            provider = excluded.provider,
            external_ref = excluded.external_ref,
            metadata_json = excluded.metadata_json,
            version = excluded.version,
            last_seen_at_unix_ms = excluded.last_seen_at_unix_ms,
            updated_at_unix_ms = excluded.updated_at_unix_ms",
        params![
            binding.id.as_str(),
            binding.agent_id.as_str(),
            super::super::codecs::state_kind_to_str(binding.state_kind),
            super::super::codecs::state_provider_to_str(binding.provider),
            binding.binding_key.as_str(),
            binding.external_ref.as_str(),
            binding.metadata_json.as_str(),
            binding.version,
            binding
                .last_seen_at_unix_ms
                .map_or(i64::MIN, |value| i64::try_from(value).unwrap_or(i64::MAX)),
            i64::try_from(binding.created_at_unix_ms).unwrap_or(i64::MAX),
            i64::try_from(binding.updated_at_unix_ms).unwrap_or(i64::MAX),
        ],
    )
    .map_err(|source| storage_sqlite_error(context, source))?;
    Ok(())
}

pub(super) fn insert_state_binding_rows(
    tx: &rusqlite::Transaction<'_>,
    state_bindings: &[AgentStateBinding],
) -> Result<(), AppError> {
    for state in state_bindings {
        insert_state_binding_row(tx, state)?;
    }
    Ok(())
}

fn insert_state_binding_row(
    tx: &rusqlite::Transaction<'_>,
    state: &AgentStateBinding,
) -> Result<(), AppError> {
    tx.execute(
        "INSERT INTO agent_state_bindings (
            binding_id,
            agent_id,
            state_kind,
            provider,
            binding_key,
            external_ref,
            metadata_json,
            version,
            last_seen_at_unix_ms,
            created_at_unix_ms,
            updated_at_unix_ms
         ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11)",
        params![
            state.id.as_str(),
            state.agent_id.as_str(),
            super::super::codecs::state_kind_to_str(state.state_kind),
            super::super::codecs::state_provider_to_str(state.provider),
            state.binding_key.as_str(),
            state.external_ref.as_str(),
            state.metadata_json.as_str(),
            state.version,
            state
                .last_seen_at_unix_ms
                .map_or(i64::MIN, |value| i64::try_from(value).unwrap_or(i64::MAX)),
            i64::try_from(state.created_at_unix_ms).unwrap_or(i64::MAX),
            i64::try_from(state.updated_at_unix_ms).unwrap_or(i64::MAX),
        ],
    )
    .map_err(|source| {
        storage_sqlite_error(
            "insert state binding row in agent+binding transaction",
            source,
        )
    })?;
    Ok(())
}
