use rusqlite::params;

use crate::domain::{Agent, AgentId, AgentRuntimeBinding, AgentStateBinding, AgentStateKind};
use crate::error::{AgentError, AppError};

use super::super::SqliteStore;
use super::super::query_helpers::storage_sqlite_error;

pub(super) fn insert_agent_with_binding(
    store: &SqliteStore,
    agent: &Agent,
    binding: &AgentRuntimeBinding,
    state_bindings: &[AgentStateBinding],
) -> Result<(), AppError> {
    let mut conn = super::super::conn::lock_conn(&store.conn)?;
    let tx = conn
        .transaction()
        .map_err(|source| storage_sqlite_error("begin agent+binding transaction", source))?;

    tx.execute(
        "INSERT INTO agents (
            agent_id,
            display_name,
            agent_kind,
            display_order,
            version,
            created_at_unix_ms,
            updated_at_unix_ms
         ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
        params![
            agent.id().as_str(),
            agent.display_name(),
            super::super::codecs::agent_kind_to_str(agent.kind()),
            agent.display_order(),
            agent.version(),
            i64::try_from(agent.created_at_unix_ms()).unwrap_or(i64::MAX),
            i64::try_from(agent.updated_at_unix_ms()).unwrap_or(i64::MAX),
        ],
    )
    .map_err(super::map_agent_write_error(
        "insert agent row in agent+binding transaction",
    ))?;

    insert_runtime_binding_row(&tx, binding)?;
    super::state_bindings::insert_state_binding_rows(&tx, state_bindings)?;

    tx.commit()
        .map_err(|source| storage_sqlite_error("commit agent+binding transaction", source))?;
    Ok(())
}

pub(super) fn update_agent(
    store: &SqliteStore,
    updated: &Agent,
    expected_version: i64,
) -> Result<(), AppError> {
    let mut conn = super::super::conn::lock_conn(&store.conn)?;
    let tx = conn
        .transaction()
        .map_err(|source| storage_sqlite_error("begin update agent transaction", source))?;
    update_agent_row(
        &tx,
        updated,
        expected_version,
        "update agent row in update agent transaction",
    )?;

    // Keep tmux runtime identity in sync with agent display name so auto-generated
    // names can safely reuse gaps after a rename.
    tx.execute(
        "UPDATE agent_runtime_bindings
         SET external_ref = ?1,
             updated_at_unix_ms = ?2
         WHERE agent_id = ?3
           AND provider = 'tmux'",
        params![
            updated.display_name(),
            i64::try_from(updated.updated_at_unix_ms()).unwrap_or(i64::MAX),
            updated.id().as_str(),
        ],
    )
    .map_err(super::map_agent_write_error(
        "update tmux runtime binding in update agent transaction",
    ))?;

    tx.commit()
        .map_err(|source| storage_sqlite_error("commit update agent transaction", source))?;
    Ok(())
}

pub(super) fn upsert_binding(
    store: &SqliteStore,
    binding: &AgentRuntimeBinding,
) -> Result<(), AppError> {
    let conn = super::super::conn::lock_conn(&store.conn)?;
    conn.execute(
        "INSERT INTO agent_runtime_bindings (
            binding_id,
            agent_id,
            provider,
            external_ref,
            version,
            last_seen_at_unix_ms,
            created_at_unix_ms,
            updated_at_unix_ms
         ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)
         ON CONFLICT(agent_id) DO UPDATE SET
            provider = excluded.provider,
            external_ref = excluded.external_ref,
            version = excluded.version,
            last_seen_at_unix_ms = excluded.last_seen_at_unix_ms,
            updated_at_unix_ms = excluded.updated_at_unix_ms",
        params![
            binding.id.as_str(),
            binding.agent_id.as_str(),
            super::super::codecs::runtime_provider_to_str(binding.provider),
            binding.external_ref.as_str(),
            binding.version,
            binding
                .last_seen_at_unix_ms
                .map_or(i64::MIN, |value| i64::try_from(value).unwrap_or(i64::MAX)),
            i64::try_from(binding.created_at_unix_ms).unwrap_or(i64::MAX),
            i64::try_from(binding.updated_at_unix_ms).unwrap_or(i64::MAX),
        ],
    )
    .map_err(|source| storage_sqlite_error("upsert binding row", source))?;
    Ok(())
}

#[allow(dead_code)]
pub(super) fn update_agent_runtime_context(
    store: &SqliteStore,
    updated: &Agent,
    expected_version: i64,
    binding: &AgentRuntimeBinding,
    upsert_state_bindings: &[AgentStateBinding],
    delete_state_kinds: &[AgentStateKind],
) -> Result<(), AppError> {
    let mut conn = super::super::conn::lock_conn(&store.conn)?;
    let tx = conn.transaction().map_err(|source| {
        storage_sqlite_error("begin update agent runtime context transaction", source)
    })?;

    update_agent_row(
        &tx,
        updated,
        expected_version,
        "update agent row in runtime context transaction",
    )?;
    upsert_runtime_binding_row(
        &tx,
        binding,
        "upsert runtime binding in runtime context transaction",
    )?;
    delete_state_bindings_by_kind(
        &tx,
        updated.id().as_str(),
        delete_state_kinds,
        "delete state bindings in runtime context transaction",
    )?;
    for state in upsert_state_bindings {
        super::state_bindings::upsert_state_binding_in_tx(
            &tx,
            state,
            "upsert state binding in runtime context transaction",
        )?;
    }

    tx.commit().map_err(|source| {
        storage_sqlite_error("commit update agent runtime context transaction", source)
    })?;
    Ok(())
}

pub(super) fn delete_agent(store: &SqliteStore, id: &AgentId) -> Result<(), AppError> {
    let mut conn = super::super::conn::lock_conn(&store.conn)?;
    let tx = conn
        .transaction()
        .map_err(|source| storage_sqlite_error("begin delete agent transaction", source))?;

    tx.execute(
        "DELETE FROM agent_runtime_bindings WHERE agent_id = ?1",
        params![id.as_str()],
    )
    .map_err(|source| {
        storage_sqlite_error("delete binding row in delete agent transaction", source)
    })?;

    tx.execute(
        "DELETE FROM agent_state_bindings WHERE agent_id = ?1",
        params![id.as_str()],
    )
    .map_err(|source| {
        storage_sqlite_error(
            "delete state binding rows in delete agent transaction",
            source,
        )
    })?;

    let rows = tx
        .execute(
            "DELETE FROM agents WHERE agent_id = ?1",
            params![id.as_str()],
        )
        .map_err(|source| storage_sqlite_error("delete agent row", source))?;

    if rows == 0 {
        return Err(AppError::Agent(AgentError::NotFound));
    }

    tx.commit()
        .map_err(|source| storage_sqlite_error("commit delete agent transaction", source))?;
    Ok(())
}

pub(super) fn swap_display_order(
    store: &SqliteStore,
    a: &Agent,
    a_expected_version: i64,
    b: &Agent,
    b_expected_version: i64,
) -> Result<(), AppError> {
    let mut conn = super::super::conn::lock_conn(&store.conn)?;
    let tx = conn
        .transaction()
        .map_err(|source| storage_sqlite_error("begin swap display order transaction", source))?;

    // `agents.display_order` is globally unique, so we cannot move agent A
    // directly onto agent B's current slot. We first park A on a guaranteed
    // unused temporary value inside the same transaction, then write B's final
    // value, and finally write A's final value. Keeping the temporary write in
    // one transaction preserves atomicity while satisfying SQLite's immediate
    // unique-index checks.
    let temp_display_order = reserve_temporary_display_order(&tx)?;

    let rows_a_temp = tx
        .execute(
            "UPDATE agents
             SET display_order = ?1
             WHERE agent_id = ?2 AND version = ?3",
            params![temp_display_order, a.id().as_str(), a_expected_version,],
        )
        .map_err(|source| {
            storage_sqlite_error("swap display order: move agent A to temporary slot", source)
        })?;

    if rows_a_temp == 0 {
        return Err(AppError::Agent(AgentError::VersionConflict));
    }

    let rows_b = tx
        .execute(
            "UPDATE agents
             SET display_order = ?1, version = ?2, updated_at_unix_ms = ?3
             WHERE agent_id = ?4 AND version = ?5",
            params![
                b.display_order(),
                b.version(),
                i64::try_from(b.updated_at_unix_ms()).unwrap_or(i64::MAX),
                b.id().as_str(),
                b_expected_version,
            ],
        )
        .map_err(|source| storage_sqlite_error("swap display order: update agent B", source))?;

    if rows_b == 0 {
        return Err(AppError::Agent(AgentError::VersionConflict));
    }

    let rows_a = tx
        .execute(
            "UPDATE agents
             SET display_order = ?1, version = ?2, updated_at_unix_ms = ?3
             WHERE agent_id = ?4 AND version = ?5",
            params![
                a.display_order(),
                a.version(),
                i64::try_from(a.updated_at_unix_ms()).unwrap_or(i64::MAX),
                a.id().as_str(),
                a_expected_version,
            ],
        )
        .map_err(|source| storage_sqlite_error("swap display order: update agent A", source))?;

    if rows_a == 0 {
        return Err(AppError::Agent(AgentError::VersionConflict));
    }

    tx.commit()
        .map_err(|source| storage_sqlite_error("commit swap display order transaction", source))?;
    Ok(())
}

fn update_agent_row(
    tx: &rusqlite::Transaction<'_>,
    updated: &Agent,
    expected_version: i64,
    context: &'static str,
) -> Result<(), AppError> {
    let rows = tx
        .execute(
            "UPDATE agents
             SET display_name = ?1,
                 agent_kind = ?2,
                 display_order = ?3,
                 version = ?4,
                 updated_at_unix_ms = ?5
             WHERE agent_id = ?6
               AND version = ?7",
            params![
                updated.display_name(),
                super::super::codecs::agent_kind_to_str(updated.kind()),
                updated.display_order(),
                updated.version(),
                i64::try_from(updated.updated_at_unix_ms()).unwrap_or(i64::MAX),
                updated.id().as_str(),
                expected_version,
            ],
        )
        .map_err(super::map_agent_write_error(context))?;

    if rows == 0 {
        return Err(AppError::Agent(AgentError::VersionConflict));
    }

    Ok(())
}

#[allow(dead_code)]
fn upsert_runtime_binding_row(
    tx: &rusqlite::Transaction<'_>,
    binding: &AgentRuntimeBinding,
    context: &'static str,
) -> Result<(), AppError> {
    tx.execute(
        "INSERT INTO agent_runtime_bindings (
            binding_id,
            agent_id,
            provider,
            external_ref,
            version,
            last_seen_at_unix_ms,
            created_at_unix_ms,
            updated_at_unix_ms
         ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)
         ON CONFLICT(agent_id) DO UPDATE SET
            provider = excluded.provider,
            external_ref = excluded.external_ref,
            version = excluded.version,
            last_seen_at_unix_ms = excluded.last_seen_at_unix_ms,
            updated_at_unix_ms = excluded.updated_at_unix_ms",
        params![
            binding.id.as_str(),
            binding.agent_id.as_str(),
            super::super::codecs::runtime_provider_to_str(binding.provider),
            binding.external_ref.as_str(),
            binding.version,
            binding
                .last_seen_at_unix_ms
                .map_or(i64::MIN, |value| i64::try_from(value).unwrap_or(i64::MAX)),
            i64::try_from(binding.created_at_unix_ms).unwrap_or(i64::MAX),
            i64::try_from(binding.updated_at_unix_ms).unwrap_or(i64::MAX),
        ],
    )
    .map_err(|source| storage_sqlite_error(context, source))?;
    Ok(())
}

#[allow(dead_code)]
fn delete_state_bindings_by_kind(
    tx: &rusqlite::Transaction<'_>,
    agent_id: &str,
    delete_state_kinds: &[AgentStateKind],
    context: &'static str,
) -> Result<(), AppError> {
    if delete_state_kinds.is_empty() {
        return Ok(());
    }

    let placeholders = std::iter::repeat_n("?", delete_state_kinds.len())
        .collect::<Vec<_>>()
        .join(",");
    let query = format!(
        "DELETE FROM agent_state_bindings WHERE agent_id = ?1 AND state_kind IN ({placeholders})"
    );
    let mut params = vec![rusqlite::types::Value::from(agent_id.to_string())];
    params.extend(delete_state_kinds.iter().map(|kind| {
        rusqlite::types::Value::from(super::super::codecs::state_kind_to_str(*kind).to_string())
    }));
    tx.execute(&query, rusqlite::params_from_iter(params))
        .map_err(|source| storage_sqlite_error(context, source))?;
    Ok(())
}

fn reserve_temporary_display_order(tx: &rusqlite::Transaction<'_>) -> Result<i64, AppError> {
    let (min_display_order, max_display_order): (Option<i64>, Option<i64>) = tx
        .query_row(
            "SELECT MIN(display_order), MAX(display_order) FROM agents",
            [],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .map_err(|source| {
            storage_sqlite_error("swap display order: inspect display order range", source)
        })?;

    // Prefer a smaller temporary value so normal positive ordering remains
    // visually stable even if the process crashes before commit. Falling back
    // to `max + 1` keeps the helper correct for unusual databases that already
    // contain negative display-order values.
    if let Some(min) = min_display_order
        && min > i64::MIN
    {
        return Ok(min - 1);
    }

    if let Some(max) = max_display_order
        && max < i64::MAX
    {
        return Ok(max + 1);
    }

    Err(AppError::InvalidInput {
        message: "could not reserve a temporary display order".to_string(),
    })
}

fn insert_runtime_binding_row(
    tx: &rusqlite::Transaction<'_>,
    binding: &AgentRuntimeBinding,
) -> Result<(), AppError> {
    tx.execute(
        "INSERT INTO agent_runtime_bindings (
            binding_id,
            agent_id,
            provider,
            external_ref,
            version,
            last_seen_at_unix_ms,
            created_at_unix_ms,
            updated_at_unix_ms
         ) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8)",
        params![
            binding.id.as_str(),
            binding.agent_id.as_str(),
            super::super::codecs::runtime_provider_to_str(binding.provider),
            binding.external_ref.as_str(),
            binding.version,
            binding
                .last_seen_at_unix_ms
                .map_or(i64::MIN, |value| i64::try_from(value).unwrap_or(i64::MAX)),
            i64::try_from(binding.created_at_unix_ms).unwrap_or(i64::MAX),
            i64::try_from(binding.updated_at_unix_ms).unwrap_or(i64::MAX),
        ],
    )
    .map_err(|source| {
        storage_sqlite_error("insert binding row in agent+binding transaction", source)
    })?;
    Ok(())
}
