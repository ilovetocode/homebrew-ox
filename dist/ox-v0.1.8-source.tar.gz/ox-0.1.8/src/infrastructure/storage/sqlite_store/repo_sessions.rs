use rusqlite::params;

use crate::application::{HostSessionSnapshot, SessionStatePort};
use crate::error::AppError;

use super::SqliteStore;
use super::query_helpers::storage_sqlite_error;

impl SessionStatePort for SqliteStore {
    fn replace_sessions(&self, sessions: &[HostSessionSnapshot]) -> Result<(), AppError> {
        let now_ms = super::time::unix_time_ms();
        let mut conn = super::conn::lock_conn(&self.conn)?;
        let tx = conn
            .transaction()
            .map_err(|source| storage_sqlite_error("begin sessions transaction", source))?;
        tx.execute("DELETE FROM sessions", [])
            .map_err(|source| storage_sqlite_error("clear sessions snapshot", source))?;
        for session in sessions {
            tx.execute(
                "INSERT INTO sessions (name, windows, attached, agent_kind, is_running, last_seen_unix_ms)
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
                params![
                    session.name,
                    i64::from(session.windows),
                    i64::from(session.attached),
                    super::codecs::agent_kind_to_str(session.agent_kind),
                    // `is_running` persists "agent actively working a turn",
                    // not process presence.
                    i64::from(session.runtime_status.is_running()),
                    i64::try_from(now_ms).unwrap_or(i64::MAX),
                ],
            )
            .map_err(|source| storage_sqlite_error("insert sessions snapshot row", source))?;
        }
        tx.commit()
            .map_err(|source| storage_sqlite_error("commit sessions transaction", source))?;
        Ok(())
    }
}
