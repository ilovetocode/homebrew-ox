use rusqlite::Connection;

use crate::error::{AppError, StorageError};

#[allow(clippy::too_many_lines)]
pub(super) fn initialize_schema(conn: &Connection) -> Result<(), AppError> {
    conn.execute_batch(
        "CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp_unix_ms INTEGER NOT NULL,
            op_id TEXT NOT NULL,
            feature TEXT NOT NULL,
            action TEXT NOT NULL,
            target TEXT,
            outcome TEXT NOT NULL,
            detail TEXT
        );
        CREATE TABLE IF NOT EXISTS sessions (
            name TEXT PRIMARY KEY,
            windows INTEGER NOT NULL,
            attached INTEGER NOT NULL,
            agent_kind TEXT NOT NULL,
            is_running INTEGER NOT NULL,
            last_seen_unix_ms INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS agents (
            agent_id TEXT PRIMARY KEY,
            display_name TEXT NOT NULL UNIQUE COLLATE BINARY,
            agent_kind TEXT NOT NULL,
            display_order INTEGER NOT NULL DEFAULT 0,
            version INTEGER NOT NULL,
            created_at_unix_ms INTEGER NOT NULL,
            updated_at_unix_ms INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS agent_runtime_bindings (
            binding_id TEXT PRIMARY KEY,
            agent_id TEXT NOT NULL UNIQUE,
            provider TEXT NOT NULL,
            external_ref TEXT NOT NULL,
            version INTEGER NOT NULL,
            last_seen_at_unix_ms INTEGER,
            created_at_unix_ms INTEGER NOT NULL,
            updated_at_unix_ms INTEGER NOT NULL,
            UNIQUE(provider, external_ref),
            FOREIGN KEY(agent_id) REFERENCES agents(agent_id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS agent_state_bindings (
            binding_id TEXT PRIMARY KEY,
            agent_id TEXT NOT NULL,
            state_kind TEXT NOT NULL,
            provider TEXT NOT NULL,
            binding_key TEXT NOT NULL,
            external_ref TEXT NOT NULL,
            metadata_json TEXT NOT NULL,
            version INTEGER NOT NULL,
            last_seen_at_unix_ms INTEGER,
            created_at_unix_ms INTEGER NOT NULL,
            updated_at_unix_ms INTEGER NOT NULL,
            UNIQUE(agent_id, state_kind, binding_key),
             UNIQUE(state_kind, provider, external_ref),
             FOREIGN KEY(agent_id) REFERENCES agents(agent_id) ON DELETE CASCADE
        );",
    )
    .map_err(|source| {
        AppError::Storage(StorageError::Sqlite {
            context: "initialize sqlite schema".to_string(),
            source,
        })
    })?;
    migrate_agents_add_display_order(conn)?;
    reconcile_tmux_runtime_binding_refs(conn)?;
    Ok(())
}

fn migrate_agents_add_display_order(conn: &Connection) -> Result<(), AppError> {
    let mut stmt = conn
        .prepare("PRAGMA table_info(agents)")
        .map_err(|source| {
            AppError::Storage(StorageError::Sqlite {
                context: "prepare agents schema inspection query".to_string(),
                source,
            })
        })?;
    let mut rows = stmt.query([]).map_err(|source| {
        AppError::Storage(StorageError::Sqlite {
            context: "run agents schema inspection query".to_string(),
            source,
        })
    })?;

    let mut has_display_order = false;
    while let Some(row) = rows.next().map_err(|source| {
        AppError::Storage(StorageError::Sqlite {
            context: "read agents schema inspection row".to_string(),
            source,
        })
    })? {
        let column_name: String = row.get(1).map_err(|source| {
            AppError::Storage(StorageError::Sqlite {
                context: "decode agents schema column name".to_string(),
                source,
            })
        })?;
        if column_name == "display_order" {
            has_display_order = true;
            break;
        }
    }

    if has_display_order {
        return Ok(());
    }

    conn.execute(
        "ALTER TABLE agents ADD COLUMN display_order INTEGER NOT NULL DEFAULT 0",
        [],
    )
    .map_err(|source| {
        AppError::Storage(StorageError::Sqlite {
            context: "add missing agents.display_order column".to_string(),
            source,
        })
    })?;

    // Backfill display_order with stable alphabetical ordering.
    //
    // Runtime policy may later reconcile pinned sessions from YAML, but schema
    // migration keeps database evolution independent from that policy file.
    conn.execute_batch(
        "UPDATE agents SET display_order = (
            SELECT rn FROM (
                SELECT agent_id,
                       ROW_NUMBER() OVER (
                           ORDER BY display_name ASC
                       ) - 1 AS rn
                FROM agents
            ) ranked
            WHERE ranked.agent_id = agents.agent_id
        )",
    )
    .map_err(|source| {
        AppError::Storage(StorageError::Sqlite {
            context: "backfill agents.display_order values".to_string(),
            source,
        })
    })?;

    Ok(())
}

fn reconcile_tmux_runtime_binding_refs(conn: &Connection) -> Result<(), AppError> {
    conn.execute(
        "UPDATE agent_runtime_bindings
         SET external_ref = (
            SELECT agents.display_name
            FROM agents
            WHERE agents.agent_id = agent_runtime_bindings.agent_id
         )
         WHERE provider = 'tmux'
           AND external_ref <> (
            SELECT agents.display_name
            FROM agents
            WHERE agents.agent_id = agent_runtime_bindings.agent_id
         )",
        [],
    )
    .map_err(|source| {
        AppError::Storage(StorageError::Sqlite {
            context: "reconcile tmux runtime binding refs".to_string(),
            source,
        })
    })?;
    Ok(())
}
