use std::sync::{Mutex, MutexGuard};

use rusqlite::Connection;

use crate::error::{AppError, StorageError};

pub(super) fn lock_conn(conn: &Mutex<Connection>) -> Result<MutexGuard<'_, Connection>, AppError> {
    conn.lock().map_err(|_| {
        AppError::Storage(StorageError::LockPoisoned {
            message: "sqlite connection lock poisoned".to_string(),
        })
    })
}

/// Map one `rusqlite` failure into the app's storage error envelope.
pub(super) fn sqlite_error(context: impl Into<String>, source: rusqlite::Error) -> AppError {
    AppError::Storage(StorageError::Sqlite {
        context: context.into(),
        source,
    })
}

/// Build one reusable mapper for APIs like `map_err`.
pub(super) fn map_sqlite_error(
    context: &'static str,
) -> impl FnOnce(rusqlite::Error) -> AppError + Send + 'static {
    move |source| sqlite_error(context, source)
}

/// Collect mapped iterator rows while preserving a consistent decode context.
pub(super) fn collect_rows<T>(
    rows: rusqlite::MappedRows<'_, impl FnMut(&rusqlite::Row<'_>) -> rusqlite::Result<T>>,
    decode_context: &'static str,
) -> Result<Vec<T>, AppError> {
    rows.into_iter()
        .map(|row| row.map_err(map_sqlite_error(decode_context)))
        .collect()
}
