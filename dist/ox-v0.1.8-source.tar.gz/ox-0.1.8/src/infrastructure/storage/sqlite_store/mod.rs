mod codecs;
mod conn;
mod query_helpers;
mod repo_agents;
mod repo_events;
mod repo_sessions;
mod rows;
mod schema;
mod time;

use std::sync::Mutex;

use rusqlite::Connection;

use crate::error::{AppError, StorageError};

/// `SQLite`-backed persistence store for app state, bindings, and events.
pub(crate) struct SqliteStore {
    conn: Mutex<Connection>,
}

impl SqliteStore {
    /// Open/create a `SQLite` database and ensure required tables exist.
    pub(crate) fn open(path: &std::path::Path) -> Result<Self, AppError> {
        let conn = Connection::open(path).map_err(|source| {
            AppError::Storage(StorageError::Sqlite {
                context: format!("open database '{}'", path.display()),
                source,
            })
        })?;
        conn.execute_batch(
            "PRAGMA journal_mode = WAL;
             PRAGMA synchronous = NORMAL;",
        )
        .map_err(|source| {
            AppError::Storage(StorageError::Sqlite {
                context: "set performance pragmas".to_string(),
                source,
            })
        })?;
        schema::initialize_schema(&conn)?;
        Ok(Self {
            conn: Mutex::new(conn),
        })
    }
}

#[cfg(test)]
mod tests;
