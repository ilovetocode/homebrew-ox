use crate::domain::{AgentKind, AgentStateKind, AgentStateProvider, RuntimeProvider};

pub(super) fn agent_kind_to_str(agent_kind: AgentKind) -> &'static str {
    agent_kind.as_str()
}

pub(super) fn parse_agent_kind(raw: &str) -> Option<AgentKind> {
    AgentKind::parse_exact(raw)
}

pub(super) fn runtime_provider_to_str(provider: RuntimeProvider) -> &'static str {
    match provider {
        RuntimeProvider::Tmux => "tmux",
    }
}

pub(super) fn parse_runtime_provider(raw: &str) -> Option<RuntimeProvider> {
    match raw {
        "tmux" => Some(RuntimeProvider::Tmux),
        _ => None,
    }
}

pub(super) fn state_kind_to_str(kind: AgentStateKind) -> &'static str {
    match kind {
        AgentStateKind::TmuxSession => "tmux_session",
        AgentStateKind::CodexThread => "codex_thread",
        AgentStateKind::OpencodeSession => "opencode_session",
        AgentStateKind::WorkingDirectory => "working_directory",
        AgentStateKind::GitRoot => "git_root",
        AgentStateKind::GitWorktree => "git_worktree",
    }
}

pub(super) fn parse_state_kind(raw: &str) -> Option<AgentStateKind> {
    match raw {
        "tmux_session" => Some(AgentStateKind::TmuxSession),
        "codex_thread" => Some(AgentStateKind::CodexThread),
        "opencode_session" => Some(AgentStateKind::OpencodeSession),
        "working_directory" => Some(AgentStateKind::WorkingDirectory),
        "git_root" => Some(AgentStateKind::GitRoot),
        "git_worktree" => Some(AgentStateKind::GitWorktree),
        _ => None,
    }
}

pub(super) fn state_provider_to_str(provider: AgentStateProvider) -> &'static str {
    match provider {
        AgentStateProvider::Tmux => "tmux",
        AgentStateProvider::Codex => "codex",
        AgentStateProvider::Opencode => "opencode",
        AgentStateProvider::Git => "git",
    }
}

pub(super) fn parse_state_provider(raw: &str) -> Option<AgentStateProvider> {
    match raw {
        "tmux" => Some(AgentStateProvider::Tmux),
        "codex" => Some(AgentStateProvider::Codex),
        "opencode" => Some(AgentStateProvider::Opencode),
        "git" => Some(AgentStateProvider::Git),
        _ => None,
    }
}
