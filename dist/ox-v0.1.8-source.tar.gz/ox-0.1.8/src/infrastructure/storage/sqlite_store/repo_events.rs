use rusqlite::params;

use crate::application::{AppEvent, EventLogPort, EventOutcome, LoggedEvent};
use crate::error::AppError;

use super::SqliteStore;
use super::conn::{collect_rows, map_sqlite_error};

impl EventLogPort for SqliteStore {
    fn append(&self, event: &AppEvent) -> Result<(), AppError> {
        let timestamp_unix_ms = super::time::unix_time_ms();
        let outcome = match event.outcome {
            EventOutcome::Success => "success",
            EventOutcome::Failure => "failure",
        };
        let conn = super::conn::lock_conn(&self.conn)?;
        conn.execute(
            "INSERT INTO events (timestamp_unix_ms, op_id, feature, action, target, outcome, detail)
             VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
            params![
                i64::try_from(timestamp_unix_ms).unwrap_or(i64::MAX),
                event.op_id,
                event.feature,
                event.action,
                event.target,
                outcome,
                event.detail
            ],
        )
        .map_err(map_sqlite_error("insert event row"))?;
        Ok(())
    }

    fn read_recent(&self, limit: usize) -> Result<Vec<LoggedEvent>, AppError> {
        if limit == 0 {
            return Ok(Vec::new());
        }
        let conn = super::conn::lock_conn(&self.conn)?;
        let mut stmt = conn
            .prepare(
                "SELECT timestamp_unix_ms, op_id, feature, action, target, outcome, detail
                 FROM events
                 ORDER BY id DESC
                 LIMIT ?1",
            )
            .map_err(map_sqlite_error("prepare read events query"))?;
        let rows = stmt
            .query_map(params![i64::try_from(limit).unwrap_or(i64::MAX)], |row| {
                let outcome: String = row.get(5)?;
                let timestamp_unix_ms: i64 = row.get(0)?;
                Ok(LoggedEvent {
                    timestamp_unix_ms: u128::try_from(timestamp_unix_ms).unwrap_or(0),
                    op_id: row.get(1)?,
                    feature: row.get(2)?,
                    action: row.get(3)?,
                    target: row.get(4)?,
                    outcome: if outcome == "success" {
                        EventOutcome::Success
                    } else {
                        EventOutcome::Failure
                    },
                    detail: row.get(6)?,
                })
            })
            .map_err(map_sqlite_error("query recent events"))?;

        collect_rows(rows, "decode event row")
    }
}
