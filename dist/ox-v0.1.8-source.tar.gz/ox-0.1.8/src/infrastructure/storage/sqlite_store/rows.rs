use crate::domain::{Agent, AgentId, AgentRuntimeBinding, AgentRuntimeRecord, AgentStateBinding};

fn conversion_error(column: usize, message: &str) -> rusqlite::Error {
    rusqlite::Error::FromSqlConversionFailure(
        column,
        rusqlite::types::Type::Text,
        Box::new(std::io::Error::other(message.to_string())),
    )
}

fn parse_agent_id(raw: &str, column: usize) -> Result<AgentId, rusqlite::Error> {
    AgentId::parse(raw).ok_or_else(|| conversion_error(column, "invalid persisted agent_id"))
}

fn parse_agent_kind(raw: &str, column: usize) -> Result<crate::domain::AgentKind, rusqlite::Error> {
    super::codecs::parse_agent_kind(raw)
        .ok_or_else(|| conversion_error(column, "invalid persisted agent kind"))
}

fn parse_runtime_provider(
    raw: &str,
    column: usize,
) -> Result<crate::domain::RuntimeProvider, rusqlite::Error> {
    super::codecs::parse_runtime_provider(raw)
        .ok_or_else(|| conversion_error(column, "invalid persisted runtime provider"))
}

fn parse_state_kind(
    raw: &str,
    column: usize,
) -> Result<crate::domain::AgentStateKind, rusqlite::Error> {
    super::codecs::parse_state_kind(raw)
        .ok_or_else(|| conversion_error(column, "invalid persisted state kind"))
}

fn parse_state_provider(
    raw: &str,
    column: usize,
) -> Result<crate::domain::AgentStateProvider, rusqlite::Error> {
    super::codecs::parse_state_provider(raw)
        .ok_or_else(|| conversion_error(column, "invalid persisted state provider"))
}

fn decode_optional_last_seen(raw_last_seen: Option<i64>) -> Option<u128> {
    raw_last_seen.and_then(|value| {
        if value == i64::MIN {
            None
        } else {
            Some(u128::try_from(value).unwrap_or(0))
        }
    })
}

fn decode_timestamp(raw: i64) -> u128 {
    u128::try_from(raw).unwrap_or(0)
}

pub(super) fn decode_agent_row(row: &rusqlite::Row<'_>) -> Result<Agent, rusqlite::Error> {
    let raw_id: String = row.get(0)?;
    let display_name: String = row.get(1)?;
    let raw_kind: String = row.get(2)?;
    let display_order: i64 = row.get(3)?;
    let version: i64 = row.get(4)?;
    let created: i64 = row.get(5)?;
    let updated: i64 = row.get(6)?;

    let id = parse_agent_id(raw_id.as_str(), 0)?;
    let kind = parse_agent_kind(raw_kind.as_str(), 2)?;

    Ok(Agent::from_persisted(
        id,
        display_name,
        kind,
        display_order,
        version,
        decode_timestamp(created),
        decode_timestamp(updated),
    ))
}

#[cfg(test)]
pub(super) fn decode_binding_row(
    row: &rusqlite::Row<'_>,
) -> Result<AgentRuntimeBinding, rusqlite::Error> {
    let raw_binding_id: String = row.get(0)?;
    let raw_agent_id: String = row.get(1)?;
    let raw_provider: String = row.get(2)?;
    let external_ref: String = row.get(3)?;
    let version: i64 = row.get(4)?;
    let raw_last_seen: Option<i64> = row.get(5)?;
    let created: i64 = row.get(6)?;
    let updated: i64 = row.get(7)?;

    let binding_id = raw_binding_id;
    let agent_id = parse_agent_id(raw_agent_id.as_str(), 1)?;
    let provider = parse_runtime_provider(raw_provider.as_str(), 2)?;

    Ok(AgentRuntimeBinding {
        id: binding_id,
        agent_id,
        provider,
        external_ref,
        version,
        last_seen_at_unix_ms: decode_optional_last_seen(raw_last_seen),
        created_at_unix_ms: decode_timestamp(created),
        updated_at_unix_ms: decode_timestamp(updated),
    })
}

pub(super) fn decode_agent_runtime_record_row(
    row: &rusqlite::Row<'_>,
) -> Result<AgentRuntimeRecord, rusqlite::Error> {
    let agent = decode_agent_row(row)?;

    // This row decoder is used by LEFT JOIN queries where binding columns are
    // either fully populated or fully NULL for one agent.
    let maybe_binding_id: Option<String> = row.get(7)?;
    let binding = if let Some(binding_id) = maybe_binding_id {
        let raw_agent_id: String = row.get(8)?;
        let raw_provider: String = row.get(9)?;
        let external_ref: String = row.get(10)?;
        let version: i64 = row.get(11)?;
        let raw_last_seen: Option<i64> = row.get(12)?;
        let created: i64 = row.get(13)?;
        let updated: i64 = row.get(14)?;

        let agent_id = parse_agent_id(raw_agent_id.as_str(), 8)?;
        let provider = parse_runtime_provider(raw_provider.as_str(), 9)?;

        Some(AgentRuntimeBinding {
            id: binding_id,
            agent_id,
            provider,
            external_ref,
            version,
            last_seen_at_unix_ms: decode_optional_last_seen(raw_last_seen),
            created_at_unix_ms: decode_timestamp(created),
            updated_at_unix_ms: decode_timestamp(updated),
        })
    } else {
        None
    };

    Ok(AgentRuntimeRecord { agent, binding })
}

pub(super) fn decode_state_binding_row(
    row: &rusqlite::Row<'_>,
) -> Result<AgentStateBinding, rusqlite::Error> {
    let raw_binding_id: String = row.get(0)?;
    let raw_agent_id: String = row.get(1)?;
    let raw_state_kind: String = row.get(2)?;
    let raw_provider: String = row.get(3)?;
    let binding_key: String = row.get(4)?;
    let external_ref: String = row.get(5)?;
    let metadata_json: String = row.get(6)?;
    let version: i64 = row.get(7)?;
    let raw_last_seen: Option<i64> = row.get(8)?;
    let created: i64 = row.get(9)?;
    let updated: i64 = row.get(10)?;

    let agent_id = parse_agent_id(raw_agent_id.as_str(), 1)?;
    let state_kind = parse_state_kind(raw_state_kind.as_str(), 2)?;
    let provider = parse_state_provider(raw_provider.as_str(), 3)?;

    Ok(AgentStateBinding {
        id: raw_binding_id,
        agent_id,
        state_kind,
        provider,
        binding_key,
        external_ref,
        metadata_json,
        version,
        last_seen_at_unix_ms: decode_optional_last_seen(raw_last_seen),
        created_at_unix_ms: decode_timestamp(created),
        updated_at_unix_ms: decode_timestamp(updated),
    })
}
