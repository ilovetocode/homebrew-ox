use std::env;
use std::fs;
use std::path::{Path, PathBuf};

use crate::error::StorageError;

/// Canonical on-disk paths for persistent local runtime state.
#[allow(clippy::struct_field_names)]
#[derive(Clone, Debug)]
pub(crate) struct StoragePaths {
    /// `SQLite` database file path for app-managed state.
    pub(crate) sqlite_db_path: PathBuf,
    /// JSON config path for app settings.
    pub(crate) config_path: PathBuf,
    /// YAML config path for pinned session policies.
    pub(crate) pinned_sessions_path: PathBuf,
}

impl StoragePaths {
    /// Resolve and prepare persistent storage paths using the managed default path.
    pub(crate) fn resolve() -> Result<Self, StorageError> {
        let home = env::var("HOME").map_err(|_| StorageError::HomeMissing)?;
        let home = PathBuf::from(home);
        Self::resolve_from_home(home.as_path())
    }

    fn resolve_from_home(home: &Path) -> Result<Self, StorageError> {
        let data_dir = home.join(".local/state/ox");
        fs::create_dir_all(&data_dir).map_err(|source| StorageError::CreateDir {
            path: data_dir.clone(),
            source,
        })?;

        Ok(Self {
            sqlite_db_path: data_dir.join("ox.db"),
            config_path: data_dir.join("config.json"),
            pinned_sessions_path: data_dir.join("pinned_sessions.yaml"),
        })
    }
}

#[cfg(test)]
mod tests {
    use super::StoragePaths;
    use std::error::Error;
    use std::fs;
    use std::time::{SystemTime, UNIX_EPOCH};

    type TestResult = Result<(), Box<dyn Error>>;

    fn temp_dir(prefix: &str) -> std::path::PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos());
        std::env::temp_dir().join(format!("{prefix}-{nanos}"))
    }

    #[test]
    fn resolve_creates_data_directory() -> TestResult {
        let root = temp_dir("ox-data-create");
        if root.exists() {
            fs::remove_dir_all(&root)?;
        }
        let paths = StoragePaths::resolve_from_home(root.as_path())?;
        let data_dir = root.join(".local/state/ox");

        assert!(data_dir.exists());
        assert!(paths.sqlite_db_path.ends_with("ox.db"));
        assert!(paths.config_path.ends_with("config.json"));
        assert!(paths.pinned_sessions_path.ends_with("pinned_sessions.yaml"));
        assert_eq!(paths.sqlite_db_path, data_dir.join("ox.db"));
        assert_eq!(paths.config_path, data_dir.join("config.json"));
        assert_eq!(
            paths.pinned_sessions_path,
            data_dir.join("pinned_sessions.yaml")
        );

        if root.exists() {
            fs::remove_dir_all(root)?;
        }
        Ok(())
    }

    #[test]
    fn resolve_uses_managed_default_path() -> TestResult {
        let root = temp_dir("ox-data-default-home");
        if root.exists() {
            fs::remove_dir_all(&root)?;
        }
        let paths = StoragePaths::resolve_from_home(root.as_path())?;
        assert_eq!(paths.sqlite_db_path, root.join(".local/state/ox/ox.db"));
        assert_eq!(paths.config_path, root.join(".local/state/ox/config.json"));
        assert_eq!(
            paths.pinned_sessions_path,
            root.join(".local/state/ox/pinned_sessions.yaml")
        );
        if root.exists() {
            fs::remove_dir_all(root)?;
        }
        Ok(())
    }
}
