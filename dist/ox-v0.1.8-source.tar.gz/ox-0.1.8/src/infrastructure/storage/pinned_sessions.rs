use std::collections::HashSet;
use std::fs;
use std::path::Path;
use std::process::Command;

use serde::{Deserialize, Serialize};

use crate::application::PinnedSessionSpec;
use crate::domain::AgentKind;
use crate::error::{AppError, StorageError};

/// Stored pinned-session policy loaded from `pinned_sessions.yaml`.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub(crate) struct StoredPinnedSessions {
    pub(crate) pinned_sessions: Vec<StoredPinnedSession>,
}

/// One pinned session policy row from YAML.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub(crate) struct StoredPinnedSession {
    pub(crate) name: String,
    pub(crate) position: usize,
    pub(crate) agent_kind: String,
    #[serde(default)]
    pub(crate) working_dir: Option<String>,
}

impl Default for StoredPinnedSessions {
    fn default() -> Self {
        Self {
            pinned_sessions: vec![
                StoredPinnedSession {
                    name: "manager".to_string(),
                    position: 1,
                    agent_kind: "shell".to_string(),
                    working_dir: default_pinned_working_dir(),
                },
                StoredPinnedSession {
                    name: "planner".to_string(),
                    position: 2,
                    agent_kind: "shell".to_string(),
                    working_dir: default_pinned_working_dir(),
                },
                StoredPinnedSession {
                    name: "settings".to_string(),
                    position: 3,
                    agent_kind: "shell".to_string(),
                    working_dir: Some(default_settings_working_dir()),
                },
            ],
        }
    }
}

impl StoredPinnedSessions {
    /// Load `pinned_sessions.yaml` from disk or create it with defaults.
    pub(crate) fn load_or_create(path: &Path) -> Result<Self, AppError> {
        match fs::read_to_string(path) {
            Ok(contents) => serde_yaml::from_str(&contents).map_err(|source| {
                AppError::Storage(StorageError::PinnedSessionsParse {
                    path: path.to_path_buf(),
                    source,
                })
            }),
            Err(err) if err.kind() == std::io::ErrorKind::NotFound => {
                let default = Self::default();
                write_pinned_sessions_file(path, &default)?;
                Ok(default)
            }
            Err(source) => Err(AppError::Storage(StorageError::PinnedSessionsFileIo {
                path: path.to_path_buf(),
                source,
            })),
        }
    }

    /// Convert loaded YAML rows into validated application policy.
    pub(crate) fn into_pinned_specs(self) -> Result<Vec<PinnedSessionSpec>, AppError> {
        let mut out = Vec::with_capacity(self.pinned_sessions.len());
        let mut seen_names = HashSet::<String>::new();
        let mut seen_positions = HashSet::<usize>::new();
        for row in self.pinned_sessions {
            let name = row.name.trim().to_string();
            if name.is_empty() {
                return Err(AppError::InvalidInput {
                    message: "pinned_sessions has an empty name".to_string(),
                });
            }
            if row.position == 0 {
                return Err(AppError::InvalidInput {
                    message: format!("pinned session '{name}' has invalid position 0"),
                });
            }
            if !seen_names.insert(name.clone()) {
                return Err(AppError::InvalidInput {
                    message: format!("duplicate pinned session name '{name}'"),
                });
            }
            if !seen_positions.insert(row.position) {
                return Err(AppError::InvalidInput {
                    message: format!("duplicate pinned session position {}", row.position),
                });
            }
            let agent_kind = parse_agent_kind(&row.agent_kind).ok_or(AppError::InvalidInput {
                message: format!(
                    "pinned session '{name}' has unsupported agent_kind '{}'",
                    row.agent_kind
                ),
            })?;
            out.push(PinnedSessionSpec {
                name,
                position: row.position,
                agent_kind,
                working_dir: row.working_dir,
            });
        }

        out.sort_by_key(|spec| spec.position);
        for (index, spec) in out.iter().enumerate() {
            let expected = index + 1;
            if spec.position != expected {
                return Err(AppError::InvalidInput {
                    message: format!(
                        "pinned session positions must be contiguous starting at 1 (expected {expected}, found {})",
                        spec.position
                    ),
                });
            }
        }
        Ok(out)
    }
}

fn default_settings_working_dir() -> String {
    // Prefer chezmoi's resolved destination so the default pinned session lands
    // in the same directory `chezmoi` manages on this machine. If `chezmoi`
    // is unavailable, fall back to the current user's home directory.
    resolve_chezmoi_target_dir()
        .or_else(resolve_home_dir)
        .or_else(resolve_current_dir)
        .unwrap_or_else(|| ".".to_string())
}

fn default_pinned_working_dir() -> Option<String> {
    resolve_home_dir().or_else(resolve_current_dir)
}

fn resolve_chezmoi_target_dir() -> Option<String> {
    let output = Command::new("chezmoi").arg("target-path").output().ok()?;
    if !output.status.success() {
        return None;
    }

    let path = String::from_utf8_lossy(&output.stdout).trim().to_string();
    if path.is_empty() {
        return None;
    }

    canonicalize_existing_path(path)
}

fn resolve_home_dir() -> Option<String> {
    let path = std::env::var_os("HOME")?;
    canonicalize_existing_path(path.to_string_lossy().to_string())
}

fn resolve_current_dir() -> Option<String> {
    let path = std::env::current_dir().ok()?;
    canonicalize_existing_path(path.to_string_lossy().to_string())
}

fn canonicalize_existing_path(path: String) -> Option<String> {
    std::fs::canonicalize(path)
        .ok()
        .map(|resolved| resolved.to_string_lossy().to_string())
}

fn write_pinned_sessions_file(path: &Path, config: &StoredPinnedSessions) -> Result<(), AppError> {
    let body = serde_yaml::to_string(config)
        .map_err(|source| AppError::Storage(StorageError::PinnedSessionsSerialize { source }))?;
    fs::write(path, body).map_err(|source| {
        AppError::Storage(StorageError::PinnedSessionsFileIo {
            path: path.to_path_buf(),
            source,
        })
    })
}

fn parse_agent_kind(raw: &str) -> Option<AgentKind> {
    AgentKind::parse_user_input(raw)
}

#[cfg(test)]
mod tests {
    use std::error::Error;
    use std::time::{SystemTime, UNIX_EPOCH};

    use crate::domain::AgentKind;

    use super::StoredPinnedSessions;

    type TestResult = Result<(), Box<dyn Error>>;

    fn temp_file(prefix: &str) -> std::path::PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos());
        std::env::temp_dir().join(format!("{prefix}-{nanos}.yaml"))
    }

    #[test]
    fn load_or_create_writes_default_when_missing() -> TestResult {
        let path = temp_file("ox-pinned-create");
        let config = StoredPinnedSessions::load_or_create(&path)?;
        assert_eq!(config.pinned_sessions.len(), 3);
        assert_eq!(config.pinned_sessions[0].name, "manager");
        assert!(
            config.pinned_sessions[0]
                .working_dir
                .as_deref()
                .is_some_and(|path| !path.is_empty())
        );
        assert_eq!(config.pinned_sessions[1].name, "planner");
        assert!(
            config.pinned_sessions[1]
                .working_dir
                .as_deref()
                .is_some_and(|path| !path.is_empty())
        );
        assert_eq!(config.pinned_sessions[2].name, "settings");
        assert!(
            config.pinned_sessions[2]
                .working_dir
                .as_deref()
                .is_some_and(|path| !path.is_empty())
        );
        assert!(path.exists());
        std::fs::remove_file(path)?;
        Ok(())
    }

    #[test]
    fn into_specs_parses_and_sorts() -> TestResult {
        let config = StoredPinnedSessions {
            pinned_sessions: vec![
                super::StoredPinnedSession {
                    name: "planner".to_string(),
                    position: 2,
                    agent_kind: "shell".to_string(),
                    working_dir: None,
                },
                super::StoredPinnedSession {
                    name: "manager".to_string(),
                    position: 1,
                    agent_kind: "codex".to_string(),
                    working_dir: None,
                },
            ],
        };
        let specs = config.into_pinned_specs()?;
        assert_eq!(specs[0].name, "manager");
        assert_eq!(specs[0].agent_kind, AgentKind::Codex);
        assert_eq!(specs[0].working_dir, None);
        assert_eq!(specs[1].name, "planner");
        Ok(())
    }

    #[test]
    fn into_specs_rejects_duplicate_position() {
        let config = StoredPinnedSessions {
            pinned_sessions: vec![
                super::StoredPinnedSession {
                    name: "manager".to_string(),
                    position: 1,
                    agent_kind: "shell".to_string(),
                    working_dir: None,
                },
                super::StoredPinnedSession {
                    name: "planner".to_string(),
                    position: 1,
                    agent_kind: "shell".to_string(),
                    working_dir: None,
                },
            ],
        };
        let result = config.into_pinned_specs();
        assert!(result.is_err());
    }
}
