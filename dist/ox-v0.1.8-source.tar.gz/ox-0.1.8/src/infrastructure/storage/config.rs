use std::fs;
use std::path::Path;

use serde::{Deserialize, Serialize};

use crate::application::{AppSettings, OpencodeSettings};
use crate::error::{AppError, StorageError};

/// Stored app config loaded from `config.json`.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub(crate) struct StoredConfig {
    /// Default row count for `ox events` when `--limit` is omitted.
    pub(crate) events_default_limit: usize,
    /// TUI background refresh cadence in milliseconds.
    #[serde(default = "default_tui_refresh_interval_ms")]
    pub(crate) tui_refresh_interval_ms: u64,
    /// `OpenCode` provider configuration.
    #[serde(default)]
    pub(crate) opencode: StoredOpencodeConfig,
}

/// Persisted `OpenCode` section from `config.json`.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub(crate) struct StoredOpencodeConfig {
    #[serde(default = "default_opencode_server_url")]
    pub(crate) server_url: String,
    #[serde(default = "default_opencode_username_env")]
    pub(crate) username_env: String,
    #[serde(default = "default_opencode_password_env")]
    pub(crate) password_env: String,
    #[serde(default = "default_opencode_request_timeout_ms")]
    pub(crate) request_timeout_ms: u64,
    #[serde(default = "default_opencode_read_request_timeout_ms")]
    pub(crate) read_request_timeout_ms: u64,
    #[serde(default = "default_opencode_status_poll_interval_ms")]
    pub(crate) status_poll_interval_ms: u64,
    #[serde(default = "default_opencode_conversation_page_size")]
    pub(crate) conversation_page_size: usize,
}

impl Default for StoredOpencodeConfig {
    fn default() -> Self {
        Self {
            server_url: default_opencode_server_url(),
            username_env: default_opencode_username_env(),
            password_env: default_opencode_password_env(),
            request_timeout_ms: default_opencode_request_timeout_ms(),
            read_request_timeout_ms: default_opencode_read_request_timeout_ms(),
            status_poll_interval_ms: default_opencode_status_poll_interval_ms(),
            conversation_page_size: default_opencode_conversation_page_size(),
        }
    }
}

fn default_opencode_server_url() -> String {
    "http://127.0.0.1:4096".to_string()
}

fn default_opencode_username_env() -> String {
    "OPENCODE_SERVER_USERNAME".to_string()
}

fn default_opencode_password_env() -> String {
    "OPENCODE_SERVER_PASSWORD".to_string()
}

fn default_opencode_request_timeout_ms() -> u64 {
    180_000
}

fn default_opencode_read_request_timeout_ms() -> u64 {
    15_000
}

fn default_opencode_status_poll_interval_ms() -> u64 {
    150
}

fn default_opencode_conversation_page_size() -> usize {
    50
}

impl Default for StoredConfig {
    fn default() -> Self {
        Self {
            events_default_limit: 50,
            tui_refresh_interval_ms: default_tui_refresh_interval_ms(),
            opencode: StoredOpencodeConfig::default(),
        }
    }
}

fn default_tui_refresh_interval_ms() -> u64 {
    200
}

impl StoredConfig {
    /// Load `config.json` from disk or create it with defaults if missing.
    pub(crate) fn load_or_create(path: &Path) -> Result<Self, AppError> {
        match fs::read_to_string(path) {
            Ok(contents) => {
                let parsed: Self = serde_json::from_str(&contents).map_err(|source| {
                    AppError::Storage(StorageError::ConfigParse {
                        path: path.to_path_buf(),
                        source,
                    })
                })?;
                Ok(parsed)
            }
            Err(err) if err.kind() == std::io::ErrorKind::NotFound => {
                let default = Self::default();
                let body = serde_json::to_string_pretty(&default).map_err(|source| {
                    AppError::Storage(StorageError::ConfigSerialize { source })
                })?;
                fs::write(path, body).map_err(|source| {
                    AppError::Storage(StorageError::ConfigFileIo {
                        path: path.to_path_buf(),
                        source,
                    })
                })?;
                Ok(default)
            }
            Err(source) => Err(AppError::Storage(StorageError::ConfigFileIo {
                path: path.to_path_buf(),
                source,
            })),
        }
    }

    /// Convert stored config into app-level settings.
    pub(crate) fn into_app_settings(self) -> AppSettings {
        AppSettings {
            events_default_limit: self.events_default_limit,
            tui_refresh_interval_ms: self.tui_refresh_interval_ms,
            opencode: OpencodeSettings {
                server_url: self.opencode.server_url,
                username_env: self.opencode.username_env,
                password_env: self.opencode.password_env,
                request_timeout_ms: self.opencode.request_timeout_ms,
                read_request_timeout_ms: self.opencode.read_request_timeout_ms,
                status_poll_interval_ms: self.opencode.status_poll_interval_ms,
                conversation_page_size: self.opencode.conversation_page_size,
            },
        }
    }
}

#[cfg(test)]
mod tests {
    use std::error::Error;
    use std::time::{SystemTime, UNIX_EPOCH};

    use super::StoredConfig;

    type TestResult = Result<(), Box<dyn Error>>;

    fn temp_file(prefix: &str) -> std::path::PathBuf {
        let nanos = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map_or(0, |duration| duration.as_nanos());
        std::env::temp_dir().join(format!("{prefix}-{nanos}.json"))
    }

    #[test]
    fn load_or_create_writes_default_when_missing() -> TestResult {
        let path = temp_file("ox-config-create");
        let config = StoredConfig::load_or_create(&path)?;
        assert_eq!(config.events_default_limit, 50);
        assert_eq!(config.tui_refresh_interval_ms, 200);
        assert!(path.exists());
        std::fs::remove_file(path)?;
        Ok(())
    }

    #[test]
    fn load_or_create_reads_existing_value() -> TestResult {
        let path = temp_file("ox-config-read");
        std::fs::write(&path, "{\n  \"events_default_limit\": 7\n}")?;
        let config = StoredConfig::load_or_create(&path)?;
        assert_eq!(config.events_default_limit, 7);
        assert_eq!(config.tui_refresh_interval_ms, 200);
        std::fs::remove_file(path)?;
        Ok(())
    }

    #[test]
    fn load_or_create_reads_existing_refresh_interval() -> TestResult {
        let path = temp_file("ox-config-read-refresh");
        std::fs::write(
            &path,
            "{\n  \"events_default_limit\": 7,\n  \"tui_refresh_interval_ms\": 350\n}",
        )?;
        let config = StoredConfig::load_or_create(&path)?;
        assert_eq!(config.events_default_limit, 7);
        assert_eq!(config.tui_refresh_interval_ms, 350);
        std::fs::remove_file(path)?;
        Ok(())
    }

    #[test]
    fn default_config_has_expected_values() {
        let config = StoredConfig::default();
        assert_eq!(config.events_default_limit, 50);
        assert_eq!(config.tui_refresh_interval_ms, 200);
        assert_eq!(config.opencode.read_request_timeout_ms, 15_000);
    }

    #[test]
    fn into_app_settings_maps_all_fields() {
        let config = StoredConfig {
            events_default_limit: 25,
            tui_refresh_interval_ms: 500,
            opencode: super::StoredOpencodeConfig::default(),
        };
        let settings = config.into_app_settings();
        assert_eq!(settings.events_default_limit, 25);
        assert_eq!(settings.tui_refresh_interval_ms, 500);
        assert_eq!(settings.opencode.server_url, "http://127.0.0.1:4096");
    }

    #[test]
    fn load_or_create_rejects_invalid_json() {
        let path = temp_file("ox-config-invalid");
        std::fs::write(&path, "not valid json {{{").ok();
        let result = StoredConfig::load_or_create(&path);
        assert!(result.is_err(), "invalid JSON should return error");
        std::fs::remove_file(path).ok();
    }
}
