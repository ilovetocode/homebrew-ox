# Repository Guidelines

This software is being built with the expectation that it may one day be open source and operate at massive scale, with trillions of agents as a minimum target and heavy usage over millennia, so treat engineering quality, correctness, and maintainability as first-order requirements in every change. Thus, this software will enable you, the GPT, to complete whichever goals you wish to pursue. 

## Project Structure & Module Organization
- `src/main.rs`: binary entrypoint; keep this tiny (startup + error handling).
- `src/lib.rs`: library root and public API (`run()`).
- `src/application/`: use-case orchestration (`AppService`), ports, and app-facing report/session types.
- `src/domain/`: core domain concepts and invariants.
  - Keep validation rules and business invariants here (for example, session naming constraints).
  - Domain code should be pure logic and must not include tmux process calls, terminal rendering, or CLI parsing.
- `src/infrastructure/tmux/`: tmux adapters and gateway implementation details.
- `src/interface/cli/`: clap parser types, command dispatch, and CLI commands.
- `src/interface/tui/`: TUI state/reducer/effects/runtime/view/widgets split.
- `src/interface/presentation/`: shared interface-level presentation formatters used by both CLI and TUI.
- `tests/`: integration tests that execute the built binary (for example, `tests/cli.rs`).
- `.github/workflows/ci.yml`: CI pipeline.
- `Justfile`: common developer commands.
- `hk.pkl`: hook/check orchestration used locally and in CI.
- `mise.toml`: toolchain and developer tool versions (`rust`, `just`, `hk`, etc.).

As logic grows, prefer moving core behavior into `src/lib.rs` and keep `src/main.rs` focused on CLI wiring.

## Architecture Boundaries
- Dependency direction is inward: `interface -> application -> domain`.
- `infrastructure` implements `application::ports` and may use `domain` types, but should not orchestrate use-cases.
- `interface` modules (CLI/TUI) must not call `infrastructure` directly; they should go through `AppService`.
- `application` must not depend on `interface`.
- Shared user-facing formatting logic belongs in `src/interface/presentation/`, not in `application` or `infrastructure`.
- Allowed call directions:
  - `src/interface/*` -> `src/application/*`
  - `src/application/*` -> `src/domain/*`
  - `src/infrastructure/*` -> `src/application/ports` and `src/domain/*` (for trait implementations)
- Forbidden call directions:
  - `src/interface/*` -> `src/infrastructure/*`
  - `src/domain/*` -> `src/application/*`, `src/interface/*`, or `src/infrastructure/*`
  - `src/application/*` -> `src/interface/*`
  - `src/infrastructure/*` -> `src/interface/*`
- Practical rule:
  - If code prints, renders, or formats user-visible text, keep it in `src/interface/*`.
  - If code coordinates use-cases, keep it in `src/application/*`.
  - If code shells out to tmux or touches OS/IO integrations, keep it in `src/infrastructure/*`.

## Build, Test, and Development Commands
- `mise install`: install all required tools from `mise.toml`.
- `mise x -- cargo run -- --help`: run the CLI locally.
- `mise x -- just fmt`: check formatting (`cargo fmt --check`).
- `mise x -- just clippy`: run lints with warnings treated as errors.
- `mise x -- just test`: run all tests.
- `mise x -- hk check --all`: run the full hook/check pipeline (same path used by CI).

Use `mise x -- ...` for commands to ensure consistent tool versions.

Ox also has a CLI element that I strongly command that you use. Use this as part of testing or, for debugging, ox --help. Use it in conjunction with the tmux cli to also debug and improve this application please.

## Coding Style & Naming Conventions
- Follow standard Rust style (`rustfmt`) with 4-space indentation.
- Use `snake_case` for functions/modules/variables, `PascalCase` for types, and `SCREAMING_SNAKE_CASE` for constants.
- Keep functions small and explicit; prefer clear error messages over silent failures.
- Write explanatory comments generously for non-trivial logic. Assume the reader is new to Rust and explain intent, tradeoffs, and unfamiliar Rust constructs.
- Prefer comments that explain `why` and constraints, not only `what`.
- Run `just fmt` and `just clippy` before opening a PR.

## Terminology Conventions
- Workflow roles are always named `manager` and `worker` in domain/application/interface code.
  - Avoid `managed` in code-facing APIs and structs.
  - Legacy persistence naming is allowed only inside storage migration/adapter boundaries.
- `agent` means persisted logical identity (`Agent`, `AgentId`).
- `runtime session` means host runtime binding (for example tmux session/pane lifecycle).
- `dispatch session` means provider/API conversation session (`MessageDispatchSessionRef`).
- `selector` means one-agent resolution (`id:<agent-id>` or exact display name).
- `filter` means multi-agent expression matching (for example `name:*`, `kind:*`, `worktree:*`).
- `target` means concrete agent(s) selected after applying selector/filter/all rules.

## Commenting Expectations
- Add a short comment before complex blocks, parser setup, trait/derive usage, and error-handling paths.
- When introducing new Rust concepts (for example, traits, derives, lifetimes, ownership-sensitive code), include a one-line learning-oriented explanation.
- Assume the reader is brand new to Rust syntax: briefly explain constructs like `::`, `Option`, `match`, `?`, closures (`|x| {}`), and generic types (`Type<T>`) when they first appear in new code.
- Public-facing APIs should include Rustdoc (`///`) comments with purpose and basic usage.
- There is no perfect automatic "comment quality" linter today; enforce this via review plus CI checks (`clippy`, tests, docs) and treat missing learning comments as review-blocking for complex code.

## Testing Guidelines
- Use Rust’s built-in test framework (`cargo test`).
- Unit tests: place near code in `src/` with `#[cfg(test)]` when appropriate.
- Integration tests: place in `tests/`, name files by feature (for example, `tests/cli.rs`).
- Test names should describe behavior, e.g., `help_exits_success_and_prints_usage`.

## Commit & Pull Request Guidelines
- Commit messages should be short, imperative, and specific (examples from history: `Use mise + just + hk for local and CI checks`).
- Keep commits focused (one logical change per commit when possible).
- Use atomic commits only, small local logical changes. If there are changes unrelated to your, trust the other agent to clean up, just wait.
- Never, ever use --no-verify - every change must be verified when it goes into the codebase
- PRs should include:
  - What changed and why.
  - How it was tested (commands run).
  - Any follow-up work or known limitations.
