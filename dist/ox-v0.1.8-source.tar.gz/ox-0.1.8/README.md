# ox

`ox` has a strict runtime dependency on `tmux`.
If `tmux` is not installed or not on `PATH`, `ox` exits before running any command.

This README received a minimal documentation update as part of an Argo
eval-loop smoke test for the repository automation path.

## Install (macOS)
```bash
brew install ilovetocode/ox/ox
```

Verify:
```bash
ox --help
```

If `brew`, `tmux`, or `ox` are not found, ensure Homebrew is on your shell PATH:
```bash
echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
eval "$(/opt/homebrew/bin/brew shellenv)"
```

Intel macs usually use `/usr/local/bin/brew` instead.

## Contributor setup (build from source)
```bash
cd /Users/testing/Documents/projects-personal/ox
mise install
mise x -- just install-cli
```

This installs `ox` to `$HOME/.cargo/bin`.

Ensure your shell can find it:
```bash
echo 'export PATH="$HOME/.cargo/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc
```

Run:
```bash
ox --help
ox tui
```

## tmux config behavior
- `ox tui` always runs tmux with `-f <config-path>`.
- Managed config path: `~/.config/ox/tmux.conf`
- If the resolved config file does not exist, `ox` creates it automatically.

## Agent cwd/worktree model
- `--cwd` picks the repo/context to operate in.
- `--worktree` creates a managed worktree from that repo/context.
- When `--worktree` is used, the agent starts in the created worktree path.

Commands:
```bash
# 1) Start in current cwd (best-effort git detection, no hard requirement).
ox agents create my-agent

# 2) Create managed worktree from current cwd repo context.
ox agents create my-agent --worktree
ox agents create my-agent --worktree feature-x

# 3) Same as (2), but start repo detection from explicit cwd.
ox agents create my-agent --cwd /path/to/repo --worktree
ox agents create my-agent --cwd /path/to/repo --worktree feature-x

By default, `ox agents create <name>` starts an `opencode` agent. Use
`--agent-kind shell` or another explicit kind to override that behavior.

# 4) Send prompts safely without shell escaping pitfalls.
ox agents send --agent my-agent --message "Summarize tests" --enter
ox agents send --agent my-agent --file /path/to/prompt.txt --enter
printf '%s' "Summarize tests" | ox agents send --agent my-agent --stdin --enter
```

## Workflow "looper" example

Inside the project, "looper" is the nickname for one atomic
manager-worker evaluator-optimizer pair driven by `ox workflow eo`.

Create one manager and one managed agent:

```bash
ox agents create looper-mgr --agent-kind opencode --cwd /Users/testing/Documents/projects-personal/ox
ox agents create looper-exec --agent-kind opencode --cwd /Users/testing/Documents/projects-personal/ox
```

Run the looper:

```bash
ox workflow eo run \
  --manager looper-mgr \
  --worker looper-exec \
  --goal "Ask the managed agent to make progress in small steps until the task is complete, then respond with exactly [DONE]."
```

Inspect the live transcript:

```bash
ox workflow eo status <WORKFLOW_ID>
watch -n 1 "ox workflow eo status <WORKFLOW_ID>"
```

Stop the looper:

```bash
ox workflow eo stop <WORKFLOW_ID>
```

Delete the temporary agents when finished:

```bash
ox agents delete looper-mgr --force
ox agents delete looper-exec --force
```

### Looper compaction behavior

- `ox` checks `OpenCode` token usage after each completed manager turn and
  each completed managed turn.
- When the configured threshold is exceeded, `ox` summarizes that session
  before the next workflow turn is sent.
- Compaction is treated as turn-end maintenance, not as a workflow reply.
- After summarization completes, the normal manager-managed loop continues on
  top of the summarized context.

The threshold is configured in `~/.local/state/ox/config.json`:

```json
{
  "opencode": {
    "workflow_compact_threshold_tokens": 15000
  }
}
```
